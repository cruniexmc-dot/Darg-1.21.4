#version 330

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

float roundedBoxSdf(vec2 point, vec2 halfSize, float radius) {
    vec2 q = abs(point) - halfSize + vec2(radius);
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - radius;
}

void main() {
    vec2 uv = clamp(texCoord0, 0.0, 1.0);
    vec2 uvRate = vec2(
        max(abs(dFdx(uv.x)), abs(dFdy(uv.x))),
        max(abs(dFdx(uv.y)), abs(dFdy(uv.y)))
    );
    vec2 sizePx = 1.0 / max(uvRate, vec2(0.0001));
    float radiusPx = min(float(RADIUS_PX), max(0.0, min(sizePx.x, sizePx.y) * 0.5 - 0.75));
    vec2 point = (uv - 0.5) * sizePx;
    vec2 halfSize = sizePx * 0.5;

    float distanceToEdge = roundedBoxSdf(point, halfSize, radiusPx);
    float aa = max(fwidth(distanceToEdge), 1.0);
    float coverage = 1.0 - smoothstep(-aa, aa, distanceToEdge);

    if (coverage <= 0.0) {
        discard;
    }

    float maxChannel = max(max(vertexColor.r, vertexColor.g), vertexColor.b);
    float minChannel = min(min(vertexColor.r, vertexColor.g), vertexColor.b);
    float chroma = maxChannel - minChannel;

    vec3 uvBlue = vec3(0.48, 0.78, 1.42);
    vec3 uvPink = vec3(1.28, 0.46, 1.30);
    vec3 uvCyan = vec3(0.44, 1.18, 1.18);
    float diagonal = clamp((uv.x * 0.72) + ((1.0 - uv.y) * 0.88), 0.0, 1.0);
    float centerBand = 1.0 - abs((uv.x * 2.0) - 1.0);
    float middleGlow = 1.0 - abs((uv.y * 2.0) - 1.0);
    vec3 uvTone = mix(uvBlue, uvPink, smoothstep(0.18, 0.86, diagonal));
    uvTone = mix(uvTone, uvCyan, smoothstep(0.56, 1.00, centerBand));

    float colorBoost = 0.26 + smoothstep(0.02, 0.34, chroma) * 0.34;
    float upperSweep = smoothstep(0.16, 0.92, 1.0 - uv.y) * 0.036;
    float centerSweep = pow(max(middleGlow, 0.0), 1.7) * 0.024;
    float rimSweep = smoothstep(0.75, 1.00, centerBand) * 0.018;

    // Top-to-bottom gradient: lighten toward top, darken toward bottom.
    float topGlow    = smoothstep(0.55, 0.0, uv.y) * 0.08;
    float bottomDark = smoothstep(0.45, 1.0, uv.y) * 0.18;

    vec3 surface = vertexColor.rgb;
    surface = mix(surface, surface * uvTone, colorBoost);
    surface += uvTone * (upperSweep + centerSweep + rimSweep);
    surface += surface * topGlow;
    surface *= 1.0 - bottomDark;

    vec4 color = vec4(surface, vertexColor.a * coverage) * ColorModulator;
    if (color.a <= 0.001) {
        discard;
    }

    fragColor = color;
}
