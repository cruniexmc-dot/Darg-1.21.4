#version 330

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec4 Color;

out vec2 texCoord0;
out vec4 vertexColor;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    int vertexIndex = gl_VertexID & 3;
    texCoord0 = vec2(
        (vertexIndex == 2 || vertexIndex == 3) ? 1.0 : 0.0,
        (vertexIndex == 1 || vertexIndex == 2) ? 1.0 : 0.0
    );
    vertexColor = Color;
}
