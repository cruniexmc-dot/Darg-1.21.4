package com.radium.client.gui.settings;

public class ModeSetting<T extends Enum<T>> extends Setting<T> {
    private final Class<T> enumClass;
    private String description;

    public ModeSetting(String name, T defaultValue, Class<T> enumClass) {
        super(name, defaultValue);
        this.enumClass = enumClass;
    }

    public String getDescription() {
        return this.description;
    }

    public ModeSetting<T> setDescription(String description) {
        this.description = description;
        return this;
    }

    public boolean isMode(T mode) {
        return this.getValue() == mode;
    }

    public T[] getModes() {
        return this.enumClass.getEnumConstants();
    }

    public void cycleMode() {
        T[] modes = this.getModes();
        T current = this.getValue();
        int currentIndex = -1;

        for (int i = 0; i < modes.length; i++) {
            if (modes[i] == current) {
                currentIndex = i;
                break;
            }
        }

        if (currentIndex != -1) {
            int nextIndex = (currentIndex + 1) % modes.length;
            this.setValue(modes[nextIndex]);
        }
    }

    public void setValue(String modeName) {
        if (modeName != null) {
            try {
                T mode = Enum.valueOf(this.enumClass, modeName.toUpperCase());
                this.setValue(mode);
            } catch (Exception var6) {
                for (T constant : (Enum[])this.enumClass.getEnumConstants()) {
                    if (constant.toString().equalsIgnoreCase(modeName)) {
                        this.setValue(constant);
                        return;
                    }
                }
            }
        }
    }

    @Override
    public String toString() {
        return this.getValue().name();
    }
}
