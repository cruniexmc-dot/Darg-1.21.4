package com.radium.client.modules;

import com.radium.client.gui.settings.Setting;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.MinecraftClient;

public abstract class Module {
    public static MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled;
    protected String name;
    protected String description;
    protected Module.Category category;
    protected List<Setting<?>> settings = new ArrayList<>();
    protected int keyBind = -1;

    protected Module(String name, String description, Module.Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onTick() {
    }

    public void toggle() {
        this.setEnabled(!this.enabled);
        if (this.enabled) {
            this.onEnable();
        } else {
            this.onDisable();
        }
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public Module.Category getCategory() {
        return this.category;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public List<Setting<?>> getSettings() {
        return Collections.unmodifiableList(this.settings);
    }

    public int getKeyBind() {
        return this.keyBind;
    }

    public void setKeyBind(int keyBind) {
        this.keyBind = keyBind;
    }

    public void addSettings(Setting<?>... settingsToAdd) {
        Collections.addAll(this.settings, settingsToAdd);
    }

    public static enum Category {
        COMBAT("Combat"),
        VISUAL("Visual"),
        MISC("Misc"),
        DONUT("Donut"),
        CLIENT("Client"),
        SEARCH("Search");

        private final String name;

        private Category(String name) {
            this.name = name;
        }

        public String getName() {
            return this.name;
        }
    }
}
