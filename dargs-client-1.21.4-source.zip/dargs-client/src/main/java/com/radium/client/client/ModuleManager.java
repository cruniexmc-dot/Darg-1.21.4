package com.radium.client.client;

import com.radium.client.modules.Module;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public final class ModuleManager {
    private final List<Module> modules = new CopyOnWriteArrayList<>();

    public void register(Module module) {
        if (module != null) {
            this.modules.add(module);
        }
    }

    public List<Module> getModules() {
        return new ArrayList<>(this.modules);
    }

    public Module getModule(String name) {
        for (Module module : this.modules) {
            if (module != null && module.getName().equalsIgnoreCase(name)) {
                return module;
            }
        }

        return null;
    }

    public <T extends Module> T getModule(Class<T> clazz) {
        for (Module module : this.modules) {
            if (clazz.isInstance(module)) {
                return clazz.cast(module);
            }
        }

        return null;
    }
}
