package com.radium.client.modules.misc;

import com.radium.client.modules.Module;

public final class AutoReconnect extends Module {
    public AutoReconnect() {
        super("AutoReconnect", "Compatibility stub", Module.Category.MISC);
    }
}
