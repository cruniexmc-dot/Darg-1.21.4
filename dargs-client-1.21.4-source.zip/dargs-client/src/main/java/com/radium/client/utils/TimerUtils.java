package com.radium.client.utils;

public class TimerUtils {
    private long lastTime = 0L;

    public boolean delay(float delay) {
        return this.delay((double)delay);
    }

    public boolean delay(double delay) {
        long currentTime = System.currentTimeMillis();
        if ((double)(currentTime - this.lastTime) >= delay) {
            this.reset();
            return true;
        } else {
            return false;
        }
    }

    public void reset() {
        this.lastTime = System.currentTimeMillis();
    }

    public long getElapsedTime() {
        return System.currentTimeMillis() - this.lastTime;
    }

    public boolean hasElapsedTime(long delay) {
        return this.getElapsedTime() >= delay;
    }

    public long getLastTime() {
        return this.lastTime;
    }
}
