package com.radium.client.modules.misc;

import com.radium.client.gui.settings.BooleanSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;

public final class BaseDigger extends Module {
    public final BooleanSetting autoEat = new BooleanSetting("Auto Eat", false);
    public BaseDigger.DiggingState diggingState = BaseDigger.DiggingState.NONE;

    public BaseDigger() {
        super("BaseDigger", "Compatibility stub", Module.Category.MISC);
        this.addSettings(new Setting[]{this.autoEat});
    }

    public static enum DiggingState {
        NONE;
    }
}
