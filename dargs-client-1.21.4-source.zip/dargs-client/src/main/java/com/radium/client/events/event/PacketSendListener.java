package com.radium.client.events.event;

import com.radium.client.events.CancellableEvent;
import com.radium.client.events.Listener;
import java.util.ArrayList;
import net.minecraft.network.packet.Packet;

public interface PacketSendListener extends Listener {
    void onPacketSend(PacketSendListener.PacketSendEvent var1);

    public static class PacketSendEvent extends CancellableEvent<PacketSendListener> {
        public Packet<?> packet;

        public PacketSendEvent(Packet<?> packet) {
            this.packet = packet;
        }

        @Override
        public void fire(ArrayList<PacketSendListener> listeners) {
            for (PacketSendListener listener : listeners) {
                listener.onPacketSend(this);
            }
        }

        @Override
        public Class<PacketSendListener> getListenerType() {
            return PacketSendListener.class;
        }
    }
}
