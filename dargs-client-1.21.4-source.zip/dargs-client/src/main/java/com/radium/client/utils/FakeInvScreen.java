package com.radium.client.utils;

import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.player.PlayerEntity;

public class FakeInvScreen extends InventoryScreen {
    public FakeInvScreen(PlayerEntity player) {
        super(player);
    }
}
