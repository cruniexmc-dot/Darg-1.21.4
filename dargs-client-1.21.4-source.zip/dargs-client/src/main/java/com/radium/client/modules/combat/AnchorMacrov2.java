package com.radium.client.modules.combat;

import com.radium.client.client.RadiumClient;
import com.radium.client.events.event.ItemUseListener;
import com.radium.client.events.event.TickListener;
import com.radium.client.gui.settings.BooleanSetting;
import com.radium.client.gui.settings.NumberSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;
import com.radium.client.utils.BlockUtil;
import com.radium.client.utils.InventoryUtil;
import com.radium.client.utils.KeyUtils;
import com.radium.client.utils.MathUtils;
import com.radium.client.utils.MouseSimulation;
import com.radium.client.utils.WorldUtil;
import dev.darg.client.mixin.MinecraftClientInvoker;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public final class AnchorMacrov2 extends Module implements TickListener, ItemUseListener {
    private final BooleanSetting whileUse = new BooleanSetting("While Use", false);
    private final BooleanSetting lootProtect = new BooleanSetting("Loot Protect", false);
    private final BooleanSetting clickSimulation = new BooleanSetting("Click Simulation", true);
    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 1.0, 0.0, 20.0, 1.0);
    private final NumberSetting switchChance = new NumberSetting("Switch Chance", 100.0, 0.0, 100.0, 1.0);
    private final NumberSetting placeChance = new NumberSetting("Place Chance", 100.0, 0.0, 100.0, 1.0);
    private final NumberSetting glowstoneDelay = new NumberSetting("Glowstone Delay", 0.0, 0.0, 20.0, 1.0);
    private final NumberSetting glowstoneChance = new NumberSetting("Glowstone Chance", 100.0, 0.0, 100.0, 1.0);
    private final NumberSetting explodeDelay = new NumberSetting("Explode Delay", 1.0, 0.0, 20.0, 1.0);
    private final NumberSetting explodeChance = new NumberSetting("Explode Chance", 100.0, 0.0, 100.0, 1.0);
    private final NumberSetting explodeSlot = new NumberSetting("Explode Slot", 9.0, 1.0, 9.0, 1.0);
    private final BooleanSetting onlyOwn = new BooleanSetting("Only Own", false);
    private final BooleanSetting onlyCharge = new BooleanSetting("Only Charge", false);
    private final Set<BlockPos> ownedAnchors = new HashSet<>();
    private int switchClock = 0;
    private int glowstoneClock = 0;
    private int explodeClock = 0;

    public AnchorMacrov2() {
        super("Anchor Macro v2", "Automatically blows up respawn anchors for you", Module.Category.COMBAT);
        this.addSettings(
            new Setting[]{
                this.whileUse,
                this.lootProtect,
                this.clickSimulation,
                this.placeChance,
                this.switchDelay,
                this.switchChance,
                this.glowstoneDelay,
                this.glowstoneChance,
                this.explodeDelay,
                this.explodeChance,
                this.explodeSlot,
                this.onlyOwn,
                this.onlyCharge
            }
        );
    }

    @Override
    public void onEnable() {
        RadiumClient.getEventManager().add(TickListener.class, this);
        RadiumClient.getEventManager().add(ItemUseListener.class, this);
        this.switchClock = 0;
        this.glowstoneClock = 0;
        this.explodeClock = 0;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        RadiumClient.getEventManager().remove(TickListener.class, this);
        RadiumClient.getEventManager().remove(ItemUseListener.class, this);
        super.onDisable();
    }

    @Override
    public void onTick2() {
        if (mc.player != null && mc.currentScreen == null) {
            if ((this.whileUse.getValue() || !mc.player.isUsingItem() && !WorldUtil.isTool(mc.player.getOffHandStack()))
                && (!this.lootProtect.getValue() || !WorldUtil.isDeadBodyNearby() && !WorldUtil.isValuableLootNearby())
                && KeyUtils.isKeyPressed(1)
                && mc.crosshairTarget instanceof BlockHitResult hit) {
                BlockPos pos = hit.getBlockPos();
                if (BlockUtil.isBlockAtPosition(pos, Blocks.RESPAWN_ANCHOR)) {
                    if (this.onlyOwn.getValue() && !this.ownedAnchors.contains(pos)) {
                        return;
                    }

                    mc.options.useKey.setPressed(false);
                    if (BlockUtil.isAnchorNotCharged(pos) && MathUtils.randomInt(1, 100) <= this.placeChance.getValue().intValue()) {
                        if (mc.player.getMainHandStack().getItem() != Items.GLOWSTONE) {
                            if (this.switchClock < this.switchDelay.getValue().intValue()) {
                                this.switchClock++;
                                return;
                            }

                            if (MathUtils.randomInt(1, 100) <= this.switchChance.getValue().intValue()) {
                                this.switchClock = 0;
                                InventoryUtil.swap(Items.GLOWSTONE);
                            }
                        }

                        if (mc.player.getMainHandStack().getItem() == Items.GLOWSTONE) {
                            if (this.glowstoneClock < this.glowstoneDelay.getValue().intValue()) {
                                this.glowstoneClock++;
                                return;
                            }

                            if (MathUtils.randomInt(1, 100) <= this.glowstoneChance.getValue().intValue()) {
                                this.glowstoneClock = 0;
                                if (this.clickSimulation.getValue()) {
                                    MouseSimulation.mouseClick(1);
                                }

                                ((MinecraftClientInvoker)mc).dargsclient$invokeDoItemUse();
                            }
                        }
                    }

                    if (BlockUtil.isAnchorCharged(pos)) {
                        int slot = this.explodeSlot.getValue().intValue() - 1;
                        if (mc.player.getInventory().getSelectedSlot() != slot) {
                            if (this.switchClock < this.switchDelay.getValue().intValue()) {
                                this.switchClock++;
                                return;
                            }

                            if (MathUtils.randomInt(1, 100) <= this.switchChance.getValue().intValue()) {
                                this.switchClock = 0;
                                InventoryUtil.swap(slot);
                            }
                        }

                        if (mc.player.getInventory().getSelectedSlot() == slot) {
                            if (this.explodeClock < this.explodeDelay.getValue().intValue()) {
                                this.explodeClock++;
                                return;
                            }

                            if (MathUtils.randomInt(1, 100) <= this.explodeChance.getValue().intValue()) {
                                this.explodeClock = 0;
                                if (!this.onlyCharge.getValue()) {
                                    if (this.clickSimulation.getValue()) {
                                        MouseSimulation.mouseClick(1);
                                    }

                                    ((MinecraftClientInvoker)mc).dargsclient$invokeDoItemUse();
                                    this.ownedAnchors.remove(pos);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onItemUse(ItemUseListener.ItemUseEvent event) {
        if (mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == Type.BLOCK) {
            if (mc.player.getMainHandStack().getItem() == Items.RESPAWN_ANCHOR) {
                Direction dir = hit.getSide();
                BlockPos pos = hit.getBlockPos();
                if (!mc.world.getBlockState(pos).isReplaceable()) {
                    this.ownedAnchors.add(pos.offset(dir));
                } else {
                    this.ownedAnchors.add(pos);
                }
            }

            BlockPos bp = hit.getBlockPos();
            if (BlockUtil.isAnchorCharged(bp)) {
                this.ownedAnchors.remove(bp);
            }
        }
    }
}
