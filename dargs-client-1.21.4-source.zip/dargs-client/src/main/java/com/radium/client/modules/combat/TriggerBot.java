package com.radium.client.modules.combat;

import com.radium.client.client.RadiumClient;
import com.radium.client.events.event.AttackListener;
import com.radium.client.events.event.HandleInputListener;
import com.radium.client.gui.settings.BooleanSetting;
import com.radium.client.gui.settings.MinMaxSetting;
import com.radium.client.gui.settings.ModeSetting;
import com.radium.client.gui.settings.NumberSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;
import com.radium.client.utils.CombatUtils;
import com.radium.client.utils.ItemTypeUtil;
import com.radium.client.utils.TimerUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.MaceItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

public final class TriggerBot extends Module implements HandleInputListener, AttackListener {
    private final ModeSetting<TriggerBot.Mode> mode = new ModeSetting<>("Mode", TriggerBot.Mode.WEAPONS, TriggerBot.Mode.class);
    private final BooleanSetting inScreen = new BooleanSetting("Work In Screen", false);
    private final BooleanSetting whileUse = new BooleanSetting("While Use", false);
    private final BooleanSetting onLeftClick = new BooleanSetting("On Left Click", false);
    private final MinMaxSetting swordDelay = new MinMaxSetting("Sword Delay", 0.0, 1000.0, 1.0, 540.0, 550.0);
    private final MinMaxSetting axeDelay = new MinMaxSetting("Axe Delay", 0.0, 1000.0, 1.0, 780.0, 800.0);
    private final BooleanSetting checkShield = new BooleanSetting("Check Shield", false);
    private final BooleanSetting onlyCritSword = new BooleanSetting("Only Crit Sword", false);
    private final BooleanSetting onlyCritAxe = new BooleanSetting("Only Crit Axe", false);
    private final BooleanSetting swing = new BooleanSetting("Swing Hand", true);
    private final BooleanSetting whileAscend = new BooleanSetting("While Ascending", false);
    private final BooleanSetting clickSimulation = new BooleanSetting("Click Simulation", true);
    private final BooleanSetting strayBypass = new BooleanSetting("Bypass Mode", true);
    private final BooleanSetting allEntities = new BooleanSetting("All Entities", false);
    private final BooleanSetting useShield = new BooleanSetting("Use Shield", false);
    private final NumberSetting shieldTime = new NumberSetting("Shield Time", 350.0, 100.0, 1000.0, 1.0);
    private final BooleanSetting sticky = new BooleanSetting("Same Player", false);
    private final TimerUtils timer = new TimerUtils();
    private final TimerUtils shieldTimer = new TimerUtils();
    private int currentSwordDelay;
    private int currentAxeDelay;
    private boolean isMaceAttack;

    public TriggerBot() {
        super("TriggerBot", "Automatically hits players for you", Module.Category.COMBAT);
        this.addSettings(
            new Setting[]{
                this.mode,
                this.inScreen,
                this.whileUse,
                this.onLeftClick,
                this.swordDelay,
                this.axeDelay,
                this.checkShield,
                this.whileAscend,
                this.sticky,
                this.onlyCritSword,
                this.onlyCritAxe,
                this.swing,
                this.clickSimulation,
                this.strayBypass,
                this.allEntities,
                this.useShield,
                this.shieldTime
            }
        );
    }

    @Override
    public void onEnable() {
        this.currentSwordDelay = this.swordDelay.getRandomValueInt();
        this.currentAxeDelay = this.axeDelay.getRandomValueInt();
        RadiumClient.getEventManager().add(HandleInputListener.class, this);
        RadiumClient.getEventManager().add(AttackListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        RadiumClient.getEventManager().remove(HandleInputListener.class, this);
        RadiumClient.getEventManager().remove(AttackListener.class, this);
        super.onDisable();
    }

    @Override
    public void onHandleInput() {
        try {
            if (!this.canRun()) {
                return;
            }

            Item item = mc.player.getMainHandStack().getItem();
            if (!this.isItemAllowed(item)) {
                return;
            }

            if (item instanceof MaceItem) {
                this.handleMace();
            } else if (ItemTypeUtil.isSword(item)) {
                this.handleSword();
            } else if (item instanceof AxeItem) {
                this.handleAxe();
            } else {
                this.handleAllItems();
            }
        } catch (Exception var2) {
        }
    }

    private boolean canRun() {
        if (!this.inScreen.getValue() && mc.currentScreen != null) {
            return false;
        } else if (this.onLeftClick.getValue() && GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), 0) != 1) {
            return false;
        } else {
            return !this.whileUse.getValue() && GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), 1) == 1
                ? false
                : this.whileAscend.getValue() || mc.player.isOnGround() || !(mc.player.getVelocity().y > 0.0);
        }
    }

    private boolean isItemAllowed(Item item) {
        return switch ((TriggerBot.Mode)this.mode.getValue()) {
            case MACE -> item instanceof MaceItem;
            case WEAPONS -> ItemTypeUtil.isSword(item) || item instanceof AxeItem;
            case MACE_AND_WEAPONS -> item instanceof MaceItem || ItemTypeUtil.isSword(item) || item instanceof AxeItem;
            case ALL_ITEMS -> true;
        };
    }

    private Entity getTarget() {
        if (mc.crosshairTarget instanceof EntityHitResult hit) {
            return this.sticky.getValue() && hit.getEntity() != mc.targetedEntity ? null : hit.getEntity();
        } else {
            return null;
        }
    }

    private boolean isValidTarget(Entity entity, boolean critCheck) {
        if (entity != null && entity.isAlive()) {
            boolean typeValid = entity instanceof PlayerEntity || this.strayBypass.getValue() && entity instanceof HostileEntity || this.allEntities.getValue();
            if (!typeValid) {
                return false;
            } else {
                if (entity instanceof PlayerEntity player && this.checkShield.getValue() && player.isBlocking() && !CombatUtils.isShieldFacingAway(player)) {
                    return false;
                }

                return critCheck ? this.canCrit() : true;
            }
        } else {
            return false;
        }
    }

    private boolean canCrit() {
        return !mc.player.isOnGround() && mc.player.getVelocity().y < 0.0 && !mc.player.isUsingItem() && !mc.player.isInFluid();
    }

    private void handleMace() {
        Entity entity = this.getTarget();
        if (this.isValidTarget(entity, this.onlyCritSword.getValue())) {
            this.isMaceAttack = true;
            this.disableShieldIfNeeded();
            this.doAttack(entity);
            this.isMaceAttack = false;
        }
    }

    private void handleSword() {
        Entity entity = this.getTarget();
        if (this.isValidTarget(entity, this.onlyCritSword.getValue())) {
            if (this.timer.delay((float)this.currentSwordDelay)) {
                this.disableShieldIfNeeded();
                this.doAttack(entity);
                this.currentSwordDelay = this.swordDelay.getRandomValueInt();
                this.timer.reset();
            }
        }
    }

    private void handleAxe() {
        Entity entity = this.getTarget();
        if (this.isValidTarget(entity, this.onlyCritAxe.getValue())) {
            if (this.timer.delay((float)this.currentAxeDelay)) {
                this.disableShieldIfNeeded();
                this.doAttack(entity);
                this.currentAxeDelay = this.axeDelay.getRandomValueInt();
                this.timer.reset();
            }
        }
    }

    private void handleAllItems() {
        Entity entity = this.getTarget();
        if (this.isValidTarget(entity, this.onlyCritSword.getValue())) {
            if (this.timer.delay((float)this.currentSwordDelay)) {
                this.disableShieldIfNeeded();
                this.doAttack(entity);
                this.currentSwordDelay = this.swordDelay.getRandomValueInt();
                this.timer.reset();
            }
        }
    }

    private void doAttack(Entity entity) {
        mc.interactionManager.attackEntity(mc.player, entity);
        if (this.swing.getValue()) {
            mc.player.swingHand(Hand.MAIN_HAND);
        }

        if (this.clickSimulation.getValue()) {
            mc.options.attackKey.setPressed(true);
            mc.options.attackKey.setPressed(false);
        }
    }

    private void disableShieldIfNeeded() {
        if (this.useShield.getValue()) {
            if (mc.player.getOffHandStack().getItem() == Items.SHIELD) {
                if (mc.player.isBlocking()) {
                    mc.options.useKey.setPressed(false);
                }
            }
        }
    }

    @Override
    public void onAttack(AttackListener.AttackEvent event) {
        if (GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), 0) != 1) {
            event.cancel();
        }
    }

    public boolean isMaceAttackActive() {
        return this.isMaceAttack;
    }

    public static enum Mode {
        MACE("Mace"),
        WEAPONS("Weapons"),
        MACE_AND_WEAPONS("Mace and Weapons"),
        ALL_ITEMS("All Items");

        private final String name;

        private Mode(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return this.name;
        }
    }
}
