package com.radium.client.utils;

import com.radium.client.client.RadiumClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class CombatUtils {
    public static boolean isShieldFacingAway(PlayerEntity target) {
        if (RadiumClient.mc.player != null && target != null) {
            Vec3d playerPos = RadiumClient.mc.player.getEyePos();
            Vec3d targetPos = new Vec3d(target.getX(), target.getY(), target.getZ());
            Vec3d toPlayer = playerPos.subtract(targetPos);
            Vec3d toPlayerHorizontal = new Vec3d(toPlayer.x, 0.0, toPlayer.z);
            if (toPlayerHorizontal.lengthSquared() == 0.0) {
                return false;
            } else {
                toPlayerHorizontal = toPlayerHorizontal.normalize();
                double yaw = Math.toRadians((double)target.getYaw());
                double pitch = Math.toRadians((double)target.getPitch());
                Vec3d facing = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch)).normalize();
                double dot = facing.dotProduct(toPlayerHorizontal);
                return dot < 0.0;
            }
        } else {
            return false;
        }
    }
}
