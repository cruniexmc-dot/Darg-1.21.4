package com.radium.client.gui.settings;

public class NumberSetting extends Setting<Double> {
    private final double min;
    private final double max;
    private final double increment;

    public NumberSetting(String name, double defaultValue, double min, double max, double increment) {
        super(name, defaultValue);
        this.min = min;
        this.max = max;
        this.increment = increment;
    }

    public void setValue(Double value) {
        super.setValue(Math.max(this.min, Math.min(this.max, value)));
    }

    public double getMin() {
        return this.min;
    }

    public double getMax() {
        return this.max;
    }

    public double getIncrement() {
        return this.increment;
    }

    public void increase() {
        this.setValue(this.getValue() + this.increment);
    }

    public void decrease() {
        this.setValue(this.getValue() - this.increment);
    }
}
