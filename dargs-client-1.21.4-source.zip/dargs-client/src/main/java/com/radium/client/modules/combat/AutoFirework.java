package com.radium.client.modules.combat;

import com.radium.client.client.RadiumClient;
import com.radium.client.events.event.HandleInputListener;
import com.radium.client.gui.settings.BooleanSetting;
import com.radium.client.gui.settings.NumberSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;
import com.radium.client.utils.ChatUtils;
import dev.darg.client.mixin.MinecraftClientInvoker;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class AutoFirework extends Module implements HandleInputListener {
    private final BooleanSetting onlyElytra = new BooleanSetting("Only Elytra", true);
    private final NumberSetting delay = new NumberSetting("Delay", 10.0, 1.0, 40.0, 1.0);
    private final NumberSetting durabilityWarningThreshold = new NumberSetting("Durability Warning %", 10.0, 1.0, 50.0, 1.0);
    private int cooldown = 0;
    private int previousSlot = -1;
    private boolean durabilityAlerted = false;

    public AutoFirework() {
        super("AutoFirework", "Automatically uses fireworks for elytra flying.", Module.Category.COMBAT);
        this.addSettings(new Setting[]{this.onlyElytra, this.delay, this.durabilityWarningThreshold});
    }

    @Override
    public void onEnable() {
        RadiumClient.getEventManager().add(HandleInputListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        RadiumClient.getEventManager().remove(HandleInputListener.class, this);
        super.onDisable();
    }

    @Override
    public void onHandleInput() {
        if (mc.player != null && mc.interactionManager != null && mc.currentScreen == null) {
            this.checkElytraDurability();
            if (this.cooldown > 0) {
                this.cooldown--;
            } else if (!this.onlyElytra.getValue() || mc.player.getEquippedStack(EquipmentSlot.CHEST).getItem() == Items.ELYTRA) {
                int fireworkSlot = this.findFireworkInHotbar();
                if (fireworkSlot != -1) {
                    if (this.previousSlot == -1) {
                        this.previousSlot = mc.player.getInventory().getSelectedSlot();
                    }

                    if (mc.player.getInventory().getSelectedSlot() != fireworkSlot) {
                        mc.player.getInventory().setSelectedSlot(fireworkSlot);
                    } else {
                        ((MinecraftClientInvoker)mc).dargsclient$invokeDoItemUse();
                    }

                    this.cooldown = this.delay.getValue().intValue();
                }
            }
        }
    }

    private void checkElytraDurability() {
        ItemStack chestplate = mc.player.getEquippedStack(EquipmentSlot.CHEST);
        if (chestplate.getItem() == Items.ELYTRA) {
            int maxDurability = chestplate.getMaxDamage();
            int currentDamage = chestplate.getDamage();
            int durabilityLeft = maxDurability - currentDamage;
            double durabilityPercent = (double)durabilityLeft / (double)maxDurability * 100.0;
            if (durabilityPercent <= this.durabilityWarningThreshold.getValue() && !this.durabilityAlerted) {
                ChatUtils.w("Elytra Durability at " + String.format("%.1f", durabilityPercent) + "%");
                this.durabilityAlerted = true;
            } else if (durabilityPercent > this.durabilityWarningThreshold.getValue()) {
                this.durabilityAlerted = false;
            }
        }
    }

    private int findFireworkInHotbar() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.FIREWORK_ROCKET) {
                return i;
            }
        }

        return -1;
    }
}
