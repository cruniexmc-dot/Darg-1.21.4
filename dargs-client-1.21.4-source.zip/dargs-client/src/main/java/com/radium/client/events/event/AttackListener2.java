package com.radium.client.events.event;

import com.radium.client.events.CancellableEvent;
import com.radium.client.events.Listener;
import java.util.ArrayList;
import net.minecraft.entity.Entity;

public interface AttackListener2 extends Listener {
    void onAttack(AttackListener2.AttackEvent2 var1);

    public static class AttackEvent2 extends CancellableEvent<AttackListener2> {
        public final Entity entity;

        public AttackEvent2(Entity entity) {
            this.entity = entity;
        }

        @Override
        public void fire(ArrayList<AttackListener2> listeners) {
            listeners.forEach(e -> e.onAttack(this));
        }

        @Override
        public Class<AttackListener2> getListenerType() {
            return AttackListener2.class;
        }
    }
}
