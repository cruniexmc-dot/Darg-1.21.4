package com.radium.client.modules.combat;

import com.radium.client.client.RadiumClient;
import com.radium.client.events.event.AttackListener2;
import com.radium.client.events.event.GameRenderListener;
import com.radium.client.events.event.MouseMoveListener;
import com.radium.client.gui.settings.BooleanSetting;
import com.radium.client.gui.settings.ModeSetting;
import com.radium.client.gui.settings.NumberSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;
import com.radium.client.utils.ItemTypeUtil;
import com.radium.client.utils.MathUtils;
import com.radium.client.utils.RotationUtil;
import com.radium.client.utils.TimerUtil;
import com.radium.client.utils.WorldUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.MaceItem;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public final class AimAssist extends Module implements GameRenderListener, MouseMoveListener, AttackListener2 {
    private final BooleanSetting stickyAim = new BooleanSetting("Sticky Aim", false);
    private final ModeSetting<AimAssist.WeaponMode> weaponMode = new ModeSetting<>("Filter", AimAssist.WeaponMode.WEAPONS_ONLY, AimAssist.WeaponMode.class);
    private final BooleanSetting onLeftClick = new BooleanSetting("On Left Click", false);
    private final ModeSetting<AimAssist.AimMode> aimAt = new ModeSetting<>("Aim At", AimAssist.AimMode.Head, AimAssist.AimMode.class);
    private final BooleanSetting stopAtTargetVertical = new BooleanSetting("Stop at Target Vert", true);
    private final BooleanSetting stopAtTargetHorizontal = new BooleanSetting("Stop at Target Horiz", false);
    private final NumberSetting radius = new NumberSetting("Radius", 5.0, 0.1, 6.0, 0.1);
    private final BooleanSetting seeOnly = new BooleanSetting("See Only", true);
    private final BooleanSetting lookAtNearest = new BooleanSetting("Look at Nearest", false);
    private final NumberSetting fov = new NumberSetting("FOV", 100.0, 5.0, 360.0, 1.0);
    private final NumberSetting minPitchSpeed = new NumberSetting("Min Vert Speed", 2.0, 0.0, 10.0, 0.1);
    private final NumberSetting maxPitchSpeed = new NumberSetting("Max Vert Speed", 4.0, 0.0, 10.0, 0.1);
    private final NumberSetting minYawSpeed = new NumberSetting("Min Horiz Speed", 2.0, 0.0, 10.0, 0.1);
    private final NumberSetting maxYawSpeed = new NumberSetting("Max Horiz Speed", 4.0, 0.0, 10.0, 0.1);
    private final NumberSetting speedChange = new NumberSetting("Speed Delay", 250.0, 0.0, 1000.0, 1.0);
    private final NumberSetting randomization = new NumberSetting("Chance", 50.0, 0.0, 100.0, 1.0);
    private final BooleanSetting yawAssist = new BooleanSetting("Horizontal", true);
    private final BooleanSetting pitchAssist = new BooleanSetting("Vertical", true);
    private final NumberSetting waitFor = new NumberSetting("Wait on Move", 0.0, 0.0, 1000.0, 1.0);
    private final ModeSetting<AimAssist.LerpMode> lerp = new ModeSetting<>("Lerp", AimAssist.LerpMode.Normal, AimAssist.LerpMode.class);
    private final TimerUtil timer = new TimerUtil();
    private final TimerUtil resetSpeed = new TimerUtil();
    private boolean move;
    private float pitch;
    private float yaw;
    private PlayerEntity lastAttackedPlayer = null;

    public AimAssist() {
        super("Aim Assist", "Automatically aims at players for you", Module.Category.COMBAT);
        this.addSettings(
            new Setting[]{
                this.stickyAim,
                this.weaponMode,
                this.onLeftClick,
                this.aimAt,
                this.stopAtTargetVertical,
                this.stopAtTargetHorizontal,
                this.radius,
                this.seeOnly,
                this.lookAtNearest,
                this.fov,
                this.minPitchSpeed,
                this.maxPitchSpeed,
                this.minYawSpeed,
                this.maxYawSpeed,
                this.speedChange,
                this.randomization,
                this.yawAssist,
                this.pitchAssist,
                this.waitFor,
                this.lerp
            }
        );
    }

    @Override
    public void onEnable() {
        this.move = true;
        this.pitch = this.getRandom(this.minPitchSpeed.getValue(), this.maxPitchSpeed.getValue());
        this.yaw = this.getRandom(this.minYawSpeed.getValue(), this.maxYawSpeed.getValue());
        RadiumClient.getEventManager().add(GameRenderListener.class, this);
        RadiumClient.getEventManager().add(MouseMoveListener.class, this);
        RadiumClient.getEventManager().add(AttackListener2.class, this);
        this.timer.reset();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        RadiumClient.getEventManager().remove(GameRenderListener.class, this);
        RadiumClient.getEventManager().remove(MouseMoveListener.class, this);
        RadiumClient.getEventManager().remove(AttackListener2.class, this);
        super.onDisable();
    }

    @Override
    public void onAttack(AttackListener2.AttackEvent2 event) {
        if (event.entity instanceof PlayerEntity player) {
            this.lastAttackedPlayer = player;
        }
    }

    @Override
    public void onGameRender(GameRenderListener.GameRenderEvent event) {
        if (mc.player != null && mc.currentScreen == null) {
            if (this.timer.delay((float)this.waitFor.getValue().doubleValue()) && !this.move) {
                this.move = true;
                this.timer.reset();
            }

            Item heldItem = mc.player.getMainHandStack().getItem();
            switch ((AimAssist.WeaponMode)this.weaponMode.getValue()) {
                case MACE_ONLY:
                    if (!(heldItem instanceof MaceItem)) {
                        return;
                    }
                    break;
                case WEAPONS_ONLY:
                    if (!ItemTypeUtil.isSword(heldItem) && !(heldItem instanceof AxeItem)) {
                        return;
                    }
                    break;
                case MACE_AND_WEAPONS:
                    if (!ItemTypeUtil.isSword(heldItem) && !(heldItem instanceof AxeItem) && !(heldItem instanceof MaceItem)) {
                        return;
                    }
            }

            if (!this.onLeftClick.getValue() || GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), 0) == 1) {
                PlayerEntity target = WorldUtil.findNearestPlayer(mc.player, this.radius.getValue().floatValue(), this.seeOnly.getValue(), true);
                if (this.stickyAim.getValue() && this.lastAttackedPlayer != null) {
                    if ((double)mc.player.distanceTo(this.lastAttackedPlayer) < this.radius.getValue()) {
                        target = this.lastAttackedPlayer;
                    }

                    if (this.lastAttackedPlayer.isDead()) {
                        this.lastAttackedPlayer = null;
                    }
                }

                if (target != null) {
                    if (this.resetSpeed.delay(this.speedChange.getValue().floatValue())) {
                        this.pitch = this.getRandom(this.minPitchSpeed.getValue(), this.maxPitchSpeed.getValue());
                        this.yaw = this.getRandom(this.minYawSpeed.getValue(), this.maxYawSpeed.getValue());
                        this.resetSpeed.reset();
                    }

                    Vec3d targetPos = new Vec3d(target.getX(), target.getY(), target.getZ());
                    if (this.aimAt.getValue() == AimAssist.AimMode.Head) {
                        targetPos = targetPos.add(0.0, (double)target.getEyeHeight(target.getPose()), 0.0);
                    } else if (this.aimAt.getValue() == AimAssist.AimMode.Chest) {
                        targetPos = targetPos.add(0.0, (double)target.getHeight() * 0.7, 0.0);
                    } else if (this.aimAt.getValue() == AimAssist.AimMode.Legs) {
                        targetPos = targetPos.add(0.0, (double)target.getHeight() * 0.3, 0.0);
                    }

                    if (this.lookAtNearest.getValue()) {
                        double offsetX = mc.player.getX() - target.getX() > 0.0 ? 0.29 : -0.29;
                        double offsetZ = mc.player.getZ() - target.getZ() > 0.0 ? 0.29 : -0.29;
                        targetPos = targetPos.add(offsetX, 0.0, offsetZ);
                    }

                    float[] rotations = RotationUtil.getRotationsTo(targetPos);
                    double angleToRotation = (double)RotationUtil.getRotationDistance(targetPos);
                    if (!(angleToRotation > this.fov.getValue() / 2.0)) {
                        float yawStrength = this.yaw / 50.0F;
                        float pitchStrength = this.pitch / 50.0F;
                        float currentYaw = mc.player.getYaw();
                        float currentPitch = mc.player.getPitch();
                        float targetYaw = rotations[0];
                        float targetPitch = rotations[1];
                        float yawDiff = MathHelper.wrapDegrees(targetYaw - currentYaw);
                        float pitchDiff = MathHelper.wrapDegrees(targetPitch - currentPitch);
                        float fixedTargetYaw = currentYaw + yawDiff;
                        float fixedTargetPitch = currentPitch + pitchDiff;
                        if (this.lerp.getValue() == AimAssist.LerpMode.Smoothstep) {
                            currentYaw = (float)MathUtils.smoothStepLerp((double)yawStrength, (double)currentYaw, (double)fixedTargetYaw);
                            currentPitch = (float)MathUtils.smoothStepLerp((double)pitchStrength, (double)currentPitch, (double)fixedTargetPitch);
                        } else if (this.lerp.getValue() == AimAssist.LerpMode.Normal) {
                            currentYaw = MathUtils.lerp(currentYaw, fixedTargetYaw, yawStrength);
                            currentPitch = MathUtils.lerp(currentPitch, fixedTargetPitch, pitchStrength);
                        } else if (this.lerp.getValue() == AimAssist.LerpMode.EaseOut) {
                            currentYaw = MathUtils.lerp(currentYaw, fixedTargetYaw, yawStrength * 1.5F);
                            currentPitch = MathUtils.lerp(currentPitch, fixedTargetPitch, pitchStrength * 1.5F);
                        }

                        if (MathUtils.randomInt(1, 100) <= this.randomization.getValue().intValue() && this.move) {
                            if (this.yawAssist.getValue()) {
                                if (this.stopAtTargetHorizontal.getValue()
                                    && WorldUtil.getHitResult(this.radius.getValue()) instanceof EntityHitResult entityHit
                                    && entityHit.getEntity() == target) {
                                    return;
                                }

                                mc.player.setYaw(currentYaw);
                            }

                            if (this.pitchAssist.getValue()) {
                                if (this.stopAtTargetVertical.getValue()
                                    && WorldUtil.getHitResult(this.radius.getValue()) instanceof EntityHitResult entityHit
                                    && entityHit.getEntity() == target) {
                                    return;
                                }

                                mc.player.setPitch(currentPitch);
                            }
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onMouseMove(MouseMoveListener.MouseMoveEvent event) {
        this.move = false;
        this.timer.reset();
    }

    private float getRandom(double min, double max) {
        return min >= max ? (float)min : (float)(min + (max - min) * MathUtils.random.nextDouble());
    }

    public static enum AimMode {
        Head,
        Chest,
        Legs;
    }

    public static enum LerpMode {
        Normal,
        Smoothstep,
        EaseOut;
    }

    public static enum WeaponMode {
        MACE_ONLY("Mace Only"),
        WEAPONS_ONLY("Weapons Only"),
        MACE_AND_WEAPONS("Mace and Weapons"),
        ALL("All Items");

        private final String name;

        private WeaponMode(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return this.name;
        }
    }
}
