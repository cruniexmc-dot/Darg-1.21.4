package com.radium.client.gui.settings;

import com.radium.client.client.KeybindManager;

public class KeybindSetting extends Setting<Integer> {
    private boolean listening = false;

    public KeybindSetting(String name, int defaultKey) {
        super(name, defaultKey);
    }

    public boolean isListening() {
        return this.listening;
    }

    public void setListening(boolean listening) {
        this.listening = listening;
    }

    public String getDisplayText() {
        return this.listening ? "Press a key..." : KeybindManager.getKeyName(this.getValue());
    }

    public void setKey(int keyCode) {
        this.setValue(Integer.valueOf(keyCode));
        this.setListening(false);
    }

    public void clearKey() {
        this.setValue(Integer.valueOf(-1));
        this.setListening(false);
    }
}
