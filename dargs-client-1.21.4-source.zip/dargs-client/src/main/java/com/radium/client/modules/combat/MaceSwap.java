package com.radium.client.modules.combat;

import com.radium.client.client.RadiumClient;
import com.radium.client.events.event.AttackListener2;
import com.radium.client.gui.settings.BooleanSetting;
import com.radium.client.gui.settings.NumberSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class MaceSwap extends Module implements AttackListener2 {
    private final BooleanSetting switchBack = new BooleanSetting("Switch Back", true);
    private final NumberSetting switchBackDelay = new NumberSetting("Switch Back Delay", 1.0, 0.0, 20.0, 1.0);
    private final BooleanSetting ignoreEndCrystals = new BooleanSetting("Ignore End Crystals", false);
    private int previousSlot = -1;
    private int delayCounter = 0;

    public MaceSwap() {
        super("MaceSwap", "Switches to mace when hitting", Module.Category.COMBAT);
        Setting<?>[] settingArray = new Setting[]{this.switchBack, this.switchBackDelay, this.ignoreEndCrystals};
        this.addSettings(settingArray);
    }

    @Override
    public void onEnable() {
        RadiumClient.eventManager.add(AttackListener2.class, this);
        super.onEnable();
        this.previousSlot = -1;
        this.delayCounter = 0;
    }

    @Override
    public void onDisable() {
        RadiumClient.eventManager.remove(AttackListener2.class, this);
        super.onDisable();
    }

    @Override
    public void onAttack(AttackListener2.AttackEvent2 event) {
        if (mc.player != null && mc.world != null) {
            if (!this.ignoreEndCrystals.getValue() || !(event.entity instanceof EndCrystalEntity)) {
                int maceSlot = this.findMaceInHotbar();
                if (maceSlot != -1) {
                    if (this.switchBack.getValue()) {
                        this.previousSlot = mc.player.getInventory().getSelectedSlot();
                    }

                    mc.player.getInventory().setSelectedSlot(maceSlot);
                    if (this.switchBack.getValue() && this.previousSlot != -1) {
                        this.delayCounter = this.switchBackDelay.getValue().intValue();
                    }
                }
            }
        }
    }

    @Override
    public void onTick() {
        if (mc.player != null && mc.world != null) {
            if (this.delayCounter > 0) {
                this.delayCounter--;
                if (this.delayCounter == 0 && this.previousSlot != -1) {
                    mc.player.getInventory().setSelectedSlot(this.previousSlot);
                    this.previousSlot = -1;
                }
            }
        }
    }

    private int findMaceInHotbar() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.getItem() == Items.MACE) {
                return i;
            }
        }

        return -1;
    }
}
