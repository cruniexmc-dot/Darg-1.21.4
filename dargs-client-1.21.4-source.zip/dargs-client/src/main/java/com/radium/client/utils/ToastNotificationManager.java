package com.radium.client.utils;

public final class ToastNotificationManager {
    private static final ToastNotificationManager INSTANCE = new ToastNotificationManager();

    private ToastNotificationManager() {
    }

    public static ToastNotificationManager getInstance() {
        return INSTANCE;
    }

    public void show(String title, String message, ToastNotification.ToastType type) {
    }
}
