package com.radium.client.modules.combat;

import com.radium.client.client.RadiumClient;
import com.radium.client.events.event.TickListener;
import com.radium.client.gui.settings.BooleanSetting;
import com.radium.client.gui.settings.NumberSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;
import com.radium.client.utils.ItemTypeUtil;
import dev.darg.client.mixin.MinecraftClientInvoker;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ShieldItem;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import org.lwjgl.glfw.GLFW;

public class AnchorMacro extends Module implements TickListener {
    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 0.0, 0.0, 20.0, 1.0);
    private final NumberSetting glowstoneDelay = new NumberSetting("Glowstone Delay", 0.0, 0.0, 20.0, 1.0);
    private final NumberSetting explodeDelay = new NumberSetting("Explode Delay", 0.0, 0.0, 20.0, 1.0);
    private final NumberSetting totemSlot = new NumberSetting("Totem Slot", 1.0, 1.0, 9.0, 1.0);
    private final BooleanSetting switchBackToAnchor = new BooleanSetting("Switch Back To Anchor", true);
    private final NumberSetting switchBackDelay = new NumberSetting("Switch Back Delay", 5.0, 0.0, 20.0, 1.0);
    private final BooleanSetting pauseOnKill = new BooleanSetting("Pause On Kill", true);
    private final NumberSetting pauseDelay = new NumberSetting("Pause Delay", 2.0, 0.5, 10.0, 0.5);
    private int keybindCounter;
    private int glowstoneDelayCounter;
    private int explodeDelayCounter;
    private int switchBackDelayCounter;
    private int pauseCounter;
    private boolean hasPlacedGlowstone = false;
    private boolean hasExplodedAnchor = false;
    private boolean shouldSwitchBack = false;
    private BlockHitResult lastBlockHitResult = null;
    private List<PlayerEntity> deadPlayers = new ArrayList<>();

    public AnchorMacro() {
        super("AnchorMacro", "Automatically charges and explodes respawn anchors", Module.Category.COMBAT);
        Setting<?>[] settingArray = new Setting[]{
            this.switchDelay,
            this.glowstoneDelay,
            this.explodeDelay,
            this.totemSlot,
            this.switchBackToAnchor,
            this.switchBackDelay,
            this.pauseOnKill,
            this.pauseDelay
        };
        this.addSettings(settingArray);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.resetCounters();
        this.hasPlacedGlowstone = false;
        this.hasExplodedAnchor = false;
        this.shouldSwitchBack = false;
        this.lastBlockHitResult = null;
        this.pauseCounter = 0;
        this.deadPlayers = new ArrayList<>();
        RadiumClient.getEventManager().add(TickListener.class, this);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        this.resetCounters();
        this.hasPlacedGlowstone = false;
        this.hasExplodedAnchor = false;
        this.shouldSwitchBack = false;
        this.lastBlockHitResult = null;
        this.pauseCounter = 0;
        this.deadPlayers.clear();
        RadiumClient.getEventManager().add(TickListener.class, this);
    }

    private void resetCounters() {
        this.keybindCounter = 0;
        this.glowstoneDelayCounter = 0;
        this.explodeDelayCounter = 0;
        this.switchBackDelayCounter = 0;
    }

    @Override
    public void onTick2() {
        if (mc.player != null && mc.currentScreen == null) {
            if (this.pauseCounter > 0) {
                this.pauseCounter--;
            }

            if (this.pauseOnKill.getValue() && this.checkForDeadPlayers()) {
                this.pauseCounter = (int)(this.pauseDelay.getValue() * 20.0);
            }

            if (this.pauseCounter <= 0) {
                if (!this.isShieldOrFoodActive()) {
                    if (this.shouldSwitchBack && this.switchBackToAnchor.getValue()) {
                        this.handleSwitchBackToAnchor();
                    } else {
                        if (this.isKeyPressed(1)) {
                            this.handleAnchorInteraction();
                        } else {
                            this.hasPlacedGlowstone = false;
                            this.hasExplodedAnchor = false;
                            this.shouldSwitchBack = false;
                            this.lastBlockHitResult = null;
                        }
                    }
                }
            }
        }
    }

    private boolean checkForDeadPlayers() {
        if (mc.world == null) {
            return false;
        } else {
            for (PlayerEntity player : mc.world.getPlayers()) {
                if (player != mc.player && player.getHealth() <= 0.0F && !this.deadPlayers.contains(player)) {
                    this.deadPlayers.add(player);
                    return true;
                }
            }

            this.deadPlayers.removeIf(playerx -> playerx.getHealth() > 0.0F);
            return false;
        }
    }

    private boolean isShieldOrFoodActive() {
        boolean isFood = mc.player.getMainHandStack().getItem().getComponents().contains(DataComponentTypes.FOOD)
            || mc.player.getOffHandStack().getItem().getComponents().contains(DataComponentTypes.FOOD);
        boolean isShield = mc.player.getMainHandStack().getItem() instanceof ShieldItem || mc.player.getOffHandStack().getItem() instanceof ShieldItem;
        boolean isRightClickPressed = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), 1) == 1;
        return (isFood || isShield) && isRightClickPressed;
    }

    private void handleSwitchBackToAnchor() {
        if (this.switchBackDelayCounter < this.switchBackDelay.getValue().intValue()) {
            this.switchBackDelayCounter++;
        } else {
            this.switchBackDelayCounter = 0;
            this.swapToItem(Items.RESPAWN_ANCHOR);
            this.shouldSwitchBack = false;
        }
    }

    private void handleAnchorInteraction() {
        if (mc.crosshairTarget instanceof BlockHitResult blockHitResult) {
            this.lastBlockHitResult = blockHitResult;
            if (this.isBlockAtPosition(blockHitResult.getBlockPos(), Blocks.RESPAWN_ANCHOR)) {
                mc.options.useKey.setPressed(false);
                if (this.isRespawnAnchorUncharged(blockHitResult.getBlockPos()) && !this.hasPlacedGlowstone) {
                    this.placeGlowstone(blockHitResult);
                } else if (this.isRespawnAnchorCharged(blockHitResult.getBlockPos()) && !this.hasExplodedAnchor) {
                    if (this.hasLootNearby(blockHitResult.getBlockPos())) {
                        return;
                    }

                    this.explodeAnchor(blockHitResult);
                }
            }
        }
    }

    private void placeGlowstone(BlockHitResult blockHitResult) {
        if (!mc.player.getMainHandStack().isOf(Items.GLOWSTONE)) {
            if (this.keybindCounter < this.switchDelay.getValue().intValue()) {
                this.keybindCounter++;
            } else {
                this.keybindCounter = 0;
                this.swapToItem(Items.GLOWSTONE);
            }
        } else {
            if (mc.player.getMainHandStack().isOf(Items.GLOWSTONE)) {
                if (this.glowstoneDelayCounter < this.glowstoneDelay.getValue().intValue()) {
                    this.glowstoneDelayCounter++;
                    return;
                }

                this.glowstoneDelayCounter = 0;
                ((MinecraftClientInvoker)mc).dargsclient$invokeDoItemUse();
                this.hasPlacedGlowstone = true;
            }
        }
    }

    private void explodeAnchor(BlockHitResult blockHitResult) {
        int selectedSlot = this.totemSlot.getValue().intValue() - 1;
        if (mc.player.getInventory().getSelectedSlot() != selectedSlot) {
            if (this.keybindCounter < this.switchDelay.getValue().intValue()) {
                this.keybindCounter++;
            } else {
                this.keybindCounter = 0;
                mc.player.getInventory().setSelectedSlot(selectedSlot);
            }
        } else {
            if (mc.player.getInventory().getSelectedSlot() == selectedSlot) {
                if (this.explodeDelayCounter < this.explodeDelay.getValue().intValue()) {
                    this.explodeDelayCounter++;
                    return;
                }

                this.explodeDelayCounter = 0;
                ((MinecraftClientInvoker)mc).dargsclient$invokeDoItemUse();
                this.hasExplodedAnchor = true;
                if (this.switchBackToAnchor.getValue()) {
                    this.shouldSwitchBack = true;
                    this.switchBackDelayCounter = 0;
                }
            }
        }
    }

    private void swapToItem(Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(item)) {
                mc.player.getInventory().setSelectedSlot(i);
                return;
            }
        }
    }

    private boolean isKeyPressed(int n) {
        return n <= 8 ? GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), n) == 1 : GLFW.glfwGetKey(mc.getWindow().getHandle(), n) == 1;
    }

    private boolean isBlockAtPosition(BlockPos blockPos, Block block) {
        return mc.world.getBlockState(blockPos).getBlock() == block;
    }

    private boolean isRespawnAnchorCharged(BlockPos blockPos) {
        return this.isBlockAtPosition(blockPos, Blocks.RESPAWN_ANCHOR)
            && (Integer)mc.world.getBlockState(blockPos).get(RespawnAnchorBlock.CHARGES) != 0;
    }

    private boolean isRespawnAnchorUncharged(BlockPos blockPos) {
        return this.isBlockAtPosition(blockPos, Blocks.RESPAWN_ANCHOR)
            && (Integer)mc.world.getBlockState(blockPos).get(RespawnAnchorBlock.CHARGES) == 0;
    }

    private boolean hasLootNearby(BlockPos pos) {
        if (mc.world != null && pos != null) {
            double searchRadius = 10.0;
            Box searchBox = new Box(
                (double)pos.getX() - searchRadius,
                (double)pos.getY() - searchRadius,
                (double)pos.getZ() - searchRadius,
                (double)pos.getX() + searchRadius,
                (double)pos.getY() + searchRadius,
                (double)pos.getZ() + searchRadius
            );

            for (Entity entity : mc.world.getOtherEntities(null, searchBox)) {
                if (entity instanceof ItemEntity) {
                    ItemEntity itemEntity = (ItemEntity)entity;
                    ItemStack stack = itemEntity.getStack();
                    if (!stack.isEmpty()) {
                        if (ItemTypeUtil.isArmor(stack.getItem())) {
                            return true;
                        }

                        if (ItemTypeUtil.isSword(stack.getItem())) {
                            return true;
                        }

                        if (stack.getItem() == Items.TOTEM_OF_UNDYING) {
                            return true;
                        }
                    }
                }
            }

            return false;
        } else {
            return false;
        }
    }
}
