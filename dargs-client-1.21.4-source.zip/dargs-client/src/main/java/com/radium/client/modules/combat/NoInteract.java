package com.radium.client.modules.combat;

import com.radium.client.client.RadiumClient;
import com.radium.client.events.event.AttackListener;
import com.radium.client.events.event.BlockBreakingListener;
import com.radium.client.events.event.ItemUseListener;
import com.radium.client.gui.settings.BooleanSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;
import com.radium.client.utils.BlockUtil;
import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;

public final class NoInteract extends Module implements ItemUseListener, AttackListener, BlockBreakingListener {
    private final BooleanSetting doubleGlowstone = new BooleanSetting("Double Glowstone", false);
    private final BooleanSetting obiPunch = new BooleanSetting("Obi Punch", false);
    private final BooleanSetting echestClick = new BooleanSetting("E-chest click", false);
    private final BooleanSetting anvilClick = new BooleanSetting("Anvil click", false);

    public NoInteract() {
        super("NoInteract", "Prevents you from certain actions", Module.Category.COMBAT);
        this.addSettings(new Setting[]{this.doubleGlowstone, this.obiPunch, this.echestClick, this.anvilClick});
    }

    @Override
    public void onEnable() {
        RadiumClient.eventManager.add(BlockBreakingListener.class, this);
        RadiumClient.eventManager.add(AttackListener.class, this);
        RadiumClient.eventManager.add(ItemUseListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        RadiumClient.eventManager.remove(BlockBreakingListener.class, this);
        RadiumClient.eventManager.remove(AttackListener.class, this);
        RadiumClient.eventManager.remove(ItemUseListener.class, this);
        super.onDisable();
    }

    @Override
    public void onAttack(AttackListener.AttackEvent event) {
        if (mc.crosshairTarget instanceof BlockHitResult hit
            && BlockUtil.isBlockAtPosition(hit.getBlockPos(), Blocks.OBSIDIAN)
            && this.obiPunch.getValue()
            && mc.player.isHolding(Items.END_CRYSTAL)) {
            event.cancel();
        }
    }

    @Override
    public void onBlockBreaking(BlockBreakingListener.BlockBreakingEvent event) {
        if (mc.crosshairTarget instanceof BlockHitResult hit
            && BlockUtil.isBlockAtPosition(hit.getBlockPos(), Blocks.OBSIDIAN)
            && this.obiPunch.getValue()
            && mc.player.isHolding(Items.END_CRYSTAL)) {
            event.cancel();
        }
    }

    @Override
    public void onItemUse(ItemUseListener.ItemUseEvent event) {
        if (mc.crosshairTarget instanceof BlockHitResult hit) {
            if (BlockUtil.isAnchorCharged(hit.getBlockPos()) && this.doubleGlowstone.getValue() && mc.player.isHolding(Items.GLOWSTONE)) {
                event.cancel();
            }

            if (BlockUtil.isBlockAtPosition(hit.getBlockPos(), Blocks.ENDER_CHEST) && this.echestClick.getValue()) {
                event.cancel();
            }

            if ((
                    BlockUtil.isBlockAtPosition(hit.getBlockPos(), Blocks.ANVIL)
                        || BlockUtil.isBlockAtPosition(hit.getBlockPos(), Blocks.CHIPPED_ANVIL)
                        || BlockUtil.isBlockAtPosition(hit.getBlockPos(), Blocks.DAMAGED_ANVIL)
                )
                && this.anvilClick.getValue()) {
                event.cancel();
            }
        }
    }
}
