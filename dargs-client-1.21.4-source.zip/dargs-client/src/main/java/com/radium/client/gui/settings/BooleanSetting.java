package com.radium.client.gui.settings;

public class BooleanSetting extends Setting<Boolean> {
    public BooleanSetting(String name, Boolean defaultValue) {
        super(name, defaultValue);
    }

    public void toggle() {
        this.setValue(Boolean.valueOf(!this.getValue()));
    }
}
