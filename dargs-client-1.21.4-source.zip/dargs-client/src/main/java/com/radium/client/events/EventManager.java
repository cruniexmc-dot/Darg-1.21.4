package com.radium.client.events;

public final class EventManager {
    public <L extends Listener> void add(Class<L> type, L listener) {
    }

    public <L extends Listener> void add(Class<L> type, L listener, int priority) {
    }

    public <L extends Listener> void remove(Class<L> type, L listener) {
    }

    public static <L extends Listener, E extends Event<L>> void fire(E event) {
    }
}
