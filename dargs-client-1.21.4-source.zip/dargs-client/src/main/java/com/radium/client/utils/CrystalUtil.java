package com.radium.client.utils;

import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

public class CrystalUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static boolean canPlaceCrystalClient(BlockPos block) {
        BlockState blockState = mc.world.getBlockState(block);
        return !blockState.isOf(Blocks.OBSIDIAN) && !blockState.isOf(Blocks.BEDROCK) ? false : canPlaceCrystalClientAssumeObsidian(block);
    }

    public static boolean canPlaceCrystalClientAssumeObsidian(BlockPos block) {
        BlockPos blockPos2 = block.up();
        if (!mc.world.isAir(blockPos2)) {
            return false;
        } else {
            double d = (double)blockPos2.getX();
            double e = (double)blockPos2.getY();
            double f = (double)blockPos2.getZ();
            List<Entity> list = mc.world.getOtherEntities(null, new Box(d, e, f, d + 1.0, e + 2.0, f + 1.0));
            return list.isEmpty();
        }
    }

    public static boolean canPlaceCrystalServer(BlockPos pos) {
        BlockState blockState = mc.world.getBlockState(pos);
        if (!blockState.isOf(Blocks.OBSIDIAN) && !blockState.isOf(Blocks.BEDROCK)) {
            return false;
        } else {
            BlockPos blockPos = pos.up();
            if (!mc.world.isAir(blockPos)) {
                return false;
            } else {
                double d = (double)blockPos.getX();
                double e = (double)blockPos.getY();
                double f = (double)blockPos.getZ();
                List<Entity> list = mc.world.getOtherEntities(null, new Box(d, e, f, d + 1.0, e + 2.0, f + 1.0));
                return list.isEmpty();
            }
        }
    }
}
