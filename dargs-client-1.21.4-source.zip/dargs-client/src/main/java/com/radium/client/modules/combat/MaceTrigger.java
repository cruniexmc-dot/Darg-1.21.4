package com.radium.client.modules.combat;

import com.radium.client.client.RadiumClient;
import com.radium.client.events.event.TickListener;
import com.radium.client.gui.settings.NumberSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;
import dev.darg.client.mixin.MinecraftClientInvoker;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Vec3d;

public class MaceTrigger extends Module implements TickListener {
    private final NumberSetting range = new NumberSetting("Range", 4.5, 1.0, 6.0, 0.1);
    private final NumberSetting attackDelay = new NumberSetting("Attack Delay", 3.0, 0.0, 10.0, 1.0);
    private final NumberSetting fovCheck = new NumberSetting("FOV Check", 30.0, 0.0, 180.0, 5.0);
    private int attackCooldown = 0;

    public MaceTrigger() {
        super("MaceTriggerBot", "Automatically attacks players in your crosshair when holding a mace", Module.Category.COMBAT);
        this.addSettings(new Setting[]{this.range, this.attackDelay, this.fovCheck});
    }

    @Override
    public void onTick2() {
        if (mc.player != null && mc.world != null) {
            if (!this.isHoldingMace()) {
                this.attackCooldown = 0;
            } else {
                Entity entity = null;
                if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == Type.ENTITY) {
                    entity = ((EntityHitResult)mc.crosshairTarget).getEntity();
                }

                if (entity instanceof PlayerEntity target && entity != mc.player && this.isTargetValid(target)) {
                    if (this.attackCooldown <= 0) {
                        ((MinecraftClientInvoker)mc).dargsclient$invokeDoAttack();
                        this.attackCooldown = this.attackDelay.getValue().intValue();
                    } else {
                        this.attackCooldown--;
                    }
                }
            }
        }
    }

    private boolean isHoldingMace() {
        return mc.player != null && mc.player.getMainHandStack().getItem() == Items.MACE;
    }

    private boolean isTargetValid(PlayerEntity target) {
        double distance = mc.player != null ? (double)mc.player.distanceTo(target) : Double.MAX_VALUE;
        if (distance > this.range.getValue()) {
            return false;
        } else if (!target.isAlive()) {
            return false;
        } else if (this.fovCheck.getValue() > 0.0) {
            if (mc.player == null) {
                return false;
            } else {
                Vec3d playerLook = mc.player.getRotationVec(1.0F);
                Vec3d toTarget = new Vec3d(
                        target.getX() - mc.player.getX(),
                        target.getY() - mc.player.getY(),
                        target.getZ() - mc.player.getZ()
                    )
                    .normalize();
                double angle = Math.toDegrees(Math.acos(playerLook.dotProduct(toTarget)));
                return !(angle > this.fovCheck.getValue());
            }
        } else {
            return true;
        }
    }

    @Override
    public void onDisable() {
        RadiumClient.getEventManager().remove(TickListener.class, this);
        this.attackCooldown = 0;
        super.onDisable();
    }

    @Override
    public void onEnable() {
        RadiumClient.getEventManager().add(TickListener.class, this);
        super.onEnable();
    }
}
