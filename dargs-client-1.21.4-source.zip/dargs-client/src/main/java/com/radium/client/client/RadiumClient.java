package com.radium.client.client;

import com.radium.client.events.EventManager;
import net.minecraft.client.MinecraftClient;

public final class RadiumClient {
    public static ModuleManager moduleManager = new ModuleManager();
    public static EventManager eventManager = new EventManager();
    public static KeybindManager keybindManager = new KeybindManager();
    public static MinecraftClient mc = MinecraftClient.getInstance();

    private RadiumClient() {
    }

    public static ModuleManager getModuleManager() {
        return moduleManager;
    }

    public static EventManager getEventManager() {
        return eventManager;
    }

    public static KeybindManager getKeybindManager() {
        return keybindManager;
    }
}
