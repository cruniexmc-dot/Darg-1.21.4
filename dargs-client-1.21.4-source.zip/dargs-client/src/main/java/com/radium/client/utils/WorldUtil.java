package com.radium.client.utils;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public final class WorldUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static boolean isDeadBodyNearby() {
        return mc.world != null && mc.player != null
            ? mc.world
                .getPlayers()
                .parallelStream()
                .filter(e -> e != mc.player)
                .filter(e -> e.squaredDistanceTo(mc.player) <= 36.0)
                .anyMatch(LivingEntity::isDead)
            : false;
    }

    public static boolean isValuableLootNearby() {
        if (mc.player != null && mc.world != null) {
            Box area = new Box(
                mc.player.getX() - 10.0,
                mc.player.getY() - 5.0,
                mc.player.getZ() - 10.0,
                mc.player.getX() + 10.0,
                mc.player.getY() + 5.0,
                mc.player.getZ() + 10.0
            );
            int valuableArmorCount = 0;

            for (Entity entity : mc.world.getOtherEntities(null, area)) {
                if (entity instanceof ItemEntity) {
                    ItemEntity itemEntity = (ItemEntity)entity;
                    ItemStack stack = itemEntity.getStack();
                    if (!stack.isEmpty()) {
                        if (!ItemTypeUtil.isArmor(stack.getItem())) {
                            if (stack.getCount() > 32
                                && (
                                    stack.getItem() == Items.END_CRYSTAL
                                        || stack.getItem() == Items.OBSIDIAN
                                        || stack.getItem() == Items.ENCHANTED_GOLDEN_APPLE
                                        || stack.getItem() == Items.EXPERIENCE_BOTTLE
                                )) {
                                return true;
                            }
                        } else if (stack.getItem() == Items.NETHERITE_HELMET
                            || stack.getItem() == Items.NETHERITE_CHESTPLATE
                            || stack.getItem() == Items.NETHERITE_LEGGINGS
                            || stack.getItem() == Items.NETHERITE_BOOTS
                            || stack.getItem() == Items.DIAMOND_HELMET
                            || stack.getItem() == Items.DIAMOND_CHESTPLATE
                            || stack.getItem() == Items.DIAMOND_LEGGINGS
                            || stack.getItem() == Items.DIAMOND_BOOTS) {
                            valuableArmorCount++;
                        }
                    }
                }
            }

            return valuableArmorCount >= 2;
        } else {
            return false;
        }
    }

    public static void placeBlock(BlockHitResult blockHit, boolean swingHand) {
        if (mc.interactionManager != null && mc.player != null) {
            if (mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, blockHit).isAccepted() && swingHand) {
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        }
    }

    public static void hitEntity(Entity entity, boolean swingHand) {
        if (mc.interactionManager != null && mc.player != null) {
            mc.interactionManager.attackEntity(mc.player, entity);
            if (swingHand) {
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        }
    }

    public static double distance(Vec3d from, Vec3d to) {
        return from.distanceTo(to);
    }

    public static boolean isTool(ItemStack itemStack) {
        String path = Registries.ITEM.getId(itemStack.getItem()).getPath();
        return path.endsWith("_pickaxe")
            || path.endsWith("_axe")
            || path.endsWith("_shovel")
            || path.endsWith("_hoe")
            || ItemTypeUtil.isSword(itemStack.getItem());
    }

    public static PlayerEntity findNearestPlayer(PlayerEntity sender, float radius, boolean seeOnly, boolean ignoreSelf) {
        if (mc.world == null) {
            return null;
        } else {
            PlayerEntity target = null;
            double minDistance = (double)radius;

            for (PlayerEntity player : mc.world.getPlayers()) {
                if ((!ignoreSelf || player != sender) && !player.isDead() && (!seeOnly || sender.canSee(player))) {
                    double distance = (double)sender.distanceTo(player);
                    if (distance < minDistance) {
                        minDistance = distance;
                        target = player;
                    }
                }
            }

            return target;
        }
    }

    public static HitResult getHitResult(double distance) {
        return mc.player == null ? null : mc.player.raycast(distance, 0.0F, false);
    }
}
