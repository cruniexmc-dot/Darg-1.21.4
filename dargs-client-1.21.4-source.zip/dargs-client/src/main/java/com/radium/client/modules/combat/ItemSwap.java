package com.radium.client.modules.combat;

import com.radium.client.client.RadiumClient;
import com.radium.client.events.event.AttackListener2;
import com.radium.client.gui.settings.BooleanSetting;
import com.radium.client.gui.settings.ModeSetting;
import com.radium.client.gui.settings.NumberSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;
import net.minecraft.entity.decoration.EndCrystalEntity;

public class ItemSwap extends Module implements AttackListener2 {
    private final NumberSetting switchToSlot = new NumberSetting("Switch To Slot", 1.0, 1.0, 9.0, 1.0);
    private final BooleanSetting switchBack = new BooleanSetting("Switch Back", true);
    private final ModeSetting<ItemSwap.SwitchBackMode> switchBackMode = new ModeSetting<>(
        "Switch Back Mode", ItemSwap.SwitchBackMode.PREVIOUS, ItemSwap.SwitchBackMode.class
    );
    private final NumberSetting switchBackSlot = new NumberSetting("Switch Back Slot", 1.0, 1.0, 9.0, 1.0);
    private final NumberSetting switchBackDelay = new NumberSetting("Switch Back Delay", 1.0, 0.0, 20.0, 1.0);
    private final BooleanSetting ignoreEndCrystals = new BooleanSetting("Ignore End Crystals", false);
    private int previousSlot = -1;
    private int delayCounter = 0;

    public ItemSwap() {
        super("ItemSwap", "Switches to specified slot when hitting", Module.Category.COMBAT);
        Setting<?>[] settingArray = new Setting[]{
            this.switchToSlot, this.switchBack, this.switchBackMode, this.switchBackSlot, this.switchBackDelay, this.ignoreEndCrystals
        };
        this.addSettings(settingArray);
    }

    @Override
    public void onEnable() {
        RadiumClient.eventManager.add(AttackListener2.class, this);
        super.onEnable();
        this.previousSlot = -1;
        this.delayCounter = 0;
    }

    @Override
    public void onDisable() {
        RadiumClient.eventManager.remove(AttackListener2.class, this);
        super.onDisable();
    }

    @Override
    public void onAttack(AttackListener2.AttackEvent2 event) {
        if (mc.player != null && mc.world != null) {
            if (!this.ignoreEndCrystals.getValue() || !(event.entity instanceof EndCrystalEntity)) {
                int targetSlot = this.switchToSlot.getValue().intValue() - 1;
                if (this.switchBack.getValue()) {
                    if (this.switchBackMode.isMode(ItemSwap.SwitchBackMode.PREVIOUS)) {
                        this.previousSlot = mc.player.getInventory().getSelectedSlot();
                    } else if (this.switchBackMode.isMode(ItemSwap.SwitchBackMode.SPECIFIED)) {
                        this.previousSlot = this.switchBackSlot.getValue().intValue() - 1;
                    }
                }

                mc.player.getInventory().setSelectedSlot(targetSlot);
                if (this.switchBack.getValue() && this.previousSlot != -1) {
                    this.delayCounter = this.switchBackDelay.getValue().intValue();
                }
            }
        }
    }

    @Override
    public void onTick() {
        if (mc.player != null && mc.world != null) {
            if (this.delayCounter > 0) {
                this.delayCounter--;
                if (this.delayCounter == 0 && this.previousSlot != -1) {
                    mc.player.getInventory().setSelectedSlot(this.previousSlot);
                    this.previousSlot = -1;
                }
            }
        }
    }

    public static enum SwitchBackMode {
        PREVIOUS("Previous", 0),
        SPECIFIED("Specified", 1);

        private SwitchBackMode(final String name, final int ordinal) {
        }
    }
}
