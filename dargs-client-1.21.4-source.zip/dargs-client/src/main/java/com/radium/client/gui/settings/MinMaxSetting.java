package com.radium.client.gui.settings;

import java.util.Random;

public class MinMaxSetting extends Setting<Double> {
    private final double min;
    private final double max;
    private final double increment;
    private final Random random = new Random();
    private double minValue;
    private double maxValue;

    public MinMaxSetting(String name, double min, double max, double increment, double defaultMin, double defaultMax) {
        super(name, defaultMin);
        this.min = min;
        this.max = max;
        this.increment = increment;
        this.minValue = defaultMin;
        this.maxValue = defaultMax;
    }

    public double getMinValue() {
        return this.minValue;
    }

    public void setMinValue(double value) {
        this.minValue = Math.max(this.min, Math.min(this.max, Math.min(value, this.maxValue)));
    }

    public double getMaxValue() {
        return this.maxValue;
    }

    public void setMaxValue(double value) {
        this.maxValue = Math.max(this.min, Math.max(this.minValue, Math.min(this.max, value)));
    }

    public int getRandomValueInt() {
        return this.minValue >= this.maxValue ? (int)this.minValue : (int)(this.minValue + this.random.nextDouble() * (this.maxValue - this.minValue));
    }

    public double getRandomValueDouble() {
        return this.minValue >= this.maxValue ? this.minValue : this.minValue + this.random.nextDouble() * (this.maxValue - this.minValue);
    }

    public double getMin() {
        return this.min;
    }

    public double getMax() {
        return this.max;
    }

    public double getIncrement() {
        return this.increment;
    }

    public void setValue(Double value) {
        this.setMinValue(value);
    }
}
