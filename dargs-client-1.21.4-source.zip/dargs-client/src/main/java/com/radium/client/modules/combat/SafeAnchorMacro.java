package com.radium.client.modules.combat;

import com.radium.client.client.RadiumClient;
import com.radium.client.events.event.GameRenderListener;
import com.radium.client.events.event.TickListener;
import com.radium.client.gui.settings.BooleanSetting;
import com.radium.client.gui.settings.KeybindSetting;
import com.radium.client.gui.settings.NumberSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;
import com.radium.client.utils.BlockUtil;
import com.radium.client.utils.InventoryUtil;
import com.radium.client.utils.ItemTypeUtil;
import com.radium.client.utils.KeyUtils;
import com.radium.client.utils.RotationUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public final class SafeAnchorMacro extends Module implements TickListener, GameRenderListener {
    private final KeybindSetting triggerKey = new KeybindSetting("Trigger Key", 71);
    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 2.0, 0.0, 20.0, 1.0);
    private final NumberSetting totemSlot = new NumberSetting("Totem Slot", 9.0, 1.0, 9.0, 1.0);
    private final NumberSetting range = new NumberSetting("Range", 4.5, 3.0, 6.0, 0.1);
    private final BooleanSetting useSilentRotations = new BooleanSetting("Silent Rotations", false);
    private final BooleanSetting smoothRotations = new BooleanSetting("Smooth Rotations", true);
    private final NumberSetting rotationSpeed = new NumberSetting("Rotation Speed", 180.0, 30.0, 360.0, 10.0);
    private final BooleanSetting useEasing = new BooleanSetting("Use Easing", true);
    private final NumberSetting easingStrength = new NumberSetting("Easing Strength", 3.0, 1.0, 5.0, 0.5);
    private int delayCounter = 0;
    private int step = 0;
    private boolean isActive = false;
    private BlockPos targetAnchorPos = null;
    private BlockPos protectionBlockPos = null;
    private float currentYaw = 0.0F;
    private float currentPitch = 0.0F;
    private float targetYaw = 0.0F;
    private float targetPitch = 0.0F;
    private boolean needsRotation = false;
    private boolean rotationComplete = false;
    private long lastFrameTime = 0L;
    private float startYaw = 0.0F;
    private float startPitch = 0.0F;
    private float rotationProgress = 0.0F;
    private float totalRotationDistance = 0.0F;
    private Runnable pendingAction = null;

    public SafeAnchorMacro() {
        super("SafeAnchor", "Places anchor, charges it, protects you with glowstone, and explodes", Module.Category.COMBAT);
        this.addSettings(
            new Setting[]{
                this.triggerKey,
                this.switchDelay,
                this.totemSlot,
                this.range,
                this.useSilentRotations,
                this.smoothRotations,
                this.rotationSpeed,
                this.useEasing,
                this.easingStrength
            }
        );
    }

    @Override
    public void onEnable() {
        super.onEnable();
        RadiumClient.eventManager.add(TickListener.class, this);
        RadiumClient.eventManager.add(GameRenderListener.class, this);
        this.lastFrameTime = System.nanoTime();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        RadiumClient.eventManager.remove(TickListener.class, this);
        RadiumClient.eventManager.remove(GameRenderListener.class, this);
        this.reset();
    }

    @Override
    public void onGameRender(GameRenderListener.GameRenderEvent event) {
        if (mc.player != null && this.isActive && this.smoothRotations.getValue()) {
            long currentTime = System.nanoTime();
            float deltaTime = (float)(currentTime - this.lastFrameTime) / 1.0E9F;
            this.lastFrameTime = currentTime;
            if (this.needsRotation && !this.rotationComplete) {
                if (this.useEasing.getValue()) {
                    float rotationSpeed = this.rotationSpeed.getValue().floatValue();
                    float progressIncrement = rotationSpeed * deltaTime / this.totalRotationDistance;
                    this.rotationProgress += progressIncrement;
                    this.rotationProgress = Math.min(this.rotationProgress, 1.0F);
                    float easingStrength = this.easingStrength.getValue().floatValue();
                    float easedProgress = this.applyEasing(this.rotationProgress, easingStrength);
                    float yawDiff = RotationUtil.normalizeYaw(this.targetYaw - this.startYaw);
                    this.currentYaw = RotationUtil.normalizeYaw(this.startYaw + yawDiff * easedProgress);
                    float pitchDiff = this.targetPitch - this.startPitch;
                    this.currentPitch = this.startPitch + pitchDiff * easedProgress;
                    this.currentPitch = Math.max(-90.0F, Math.min(90.0F, this.currentPitch));
                    if (this.useSilentRotations.getValue()) {
                        RotationUtil.setSilentRotation(this.currentYaw, this.currentPitch);
                    } else {
                        mc.player.setYaw(this.currentYaw);
                        mc.player.setPitch(this.currentPitch);
                    }

                    if (this.rotationProgress >= 0.98F) {
                        this.rotationComplete = true;
                        this.currentYaw = this.targetYaw;
                        this.currentPitch = this.targetPitch;
                        if (this.pendingAction != null) {
                            this.pendingAction.run();
                            this.pendingAction = null;
                        }
                    }
                } else {
                    float rotationSpeedx = this.rotationSpeed.getValue().floatValue();
                    float maxRotationThisFrame = rotationSpeedx * deltaTime;
                    float yawDiffx = RotationUtil.normalizeYaw(this.targetYaw - this.currentYaw);
                    if (Math.abs(yawDiffx) <= maxRotationThisFrame) {
                        this.currentYaw = this.targetYaw;
                    } else {
                        this.currentYaw = RotationUtil.normalizeYaw(this.currentYaw + (yawDiffx > 0.0F ? maxRotationThisFrame : -maxRotationThisFrame));
                    }

                    float pitchDiffx = this.targetPitch - this.currentPitch;
                    if (Math.abs(pitchDiffx) <= maxRotationThisFrame) {
                        this.currentPitch = this.targetPitch;
                    } else {
                        this.currentPitch += pitchDiffx > 0.0F ? maxRotationThisFrame : -maxRotationThisFrame;
                    }

                    this.currentPitch = Math.max(-90.0F, Math.min(90.0F, this.currentPitch));
                    if (this.useSilentRotations.getValue()) {
                        RotationUtil.setSilentRotation(this.currentYaw, this.currentPitch);
                    } else {
                        mc.player.setYaw(this.currentYaw);
                        mc.player.setPitch(this.currentPitch);
                    }

                    float yawError = Math.abs(RotationUtil.normalizeYaw(this.targetYaw - this.currentYaw));
                    float pitchError = Math.abs(this.targetPitch - this.currentPitch);
                    if (yawError < 1.0F && pitchError < 1.0F) {
                        this.rotationComplete = true;
                        this.currentYaw = this.targetYaw;
                        this.currentPitch = this.targetPitch;
                        if (this.pendingAction != null) {
                            this.pendingAction.run();
                            this.pendingAction = null;
                        }
                    }
                }
            }
        }
    }

    private float applyEasing(float t, float strength) {
        return 1.0F - (float)Math.pow((double)(1.0F - t), (double)strength);
    }

    private float easeOutCubic(float t) {
        float f = t - 1.0F;
        return f * f * f + 1.0F;
    }

    private float easeInOutCubic(float t) {
        if (t < 0.5F) {
            return 4.0F * t * t * t;
        } else {
            float f = 2.0F * t - 2.0F;
            return 0.5F * f * f * f + 1.0F;
        }
    }

    @Override
    public void onTick2() {
        if (mc.currentScreen == null && mc.player != null) {
            if (!this.hasRequiredItems()) {
                if (this.isActive) {
                    this.reset();
                }
            } else if (this.isActive || this.checkTriggerKey()) {
                if (!this.needsRotation || this.rotationComplete || !this.smoothRotations.getValue()) {
                    if (this.delayCounter < this.switchDelay.getValue().intValue()) {
                        this.delayCounter++;
                    } else {
                        this.delayCounter = 0;
                        switch (this.step) {
                            case 0:
                                if (!this.findTargetPosition()) {
                                    this.reset();
                                    return;
                                }

                                this.step++;
                                break;
                            case 1:
                                if (!this.placeBlock(this.targetAnchorPos, Items.RESPAWN_ANCHOR)) {
                                    this.reset();
                                    return;
                                }

                                this.step++;
                                break;
                            case 2:
                                if (!this.chargeAnchor(this.targetAnchorPos)) {
                                    this.reset();
                                    return;
                                }

                                this.step++;
                                break;
                            case 3:
                                if (!this.isReplaceable(this.protectionBlockPos)) {
                                    this.step++;
                                } else {
                                    BlockPos below = this.protectionBlockPos.down();
                                    if (this.isReplaceable(below)) {
                                        this.step++;
                                    } else {
                                        this.placeBlock(this.protectionBlockPos, Items.GLOWSTONE);
                                        this.step++;
                                    }
                                }
                                break;
                            case 4:
                                InventoryUtil.swap(this.totemSlot.getValue().intValue() - 1);
                                this.step++;
                                break;
                            case 5:
                                if (this.hasLootNearby(this.targetAnchorPos)) {
                                    this.reset();
                                    return;
                                }

                                if (!this.interactWithBlock(this.targetAnchorPos, null)) {
                                    this.reset();
                                    return;
                                }

                                this.step++;
                                break;
                            case 6:
                                this.reset();
                        }
                    }
                }
            }
        }
    }

    private void setTargetRotation(Vec3d targetPos, Runnable action) {
        Vec3d playerPos = mc.player.getEyePos();
        float[] rotation = RotationUtil.getRotationsTo(playerPos, targetPos);
        this.targetYaw = rotation[0];
        this.targetPitch = rotation[1];
        if (this.smoothRotations.getValue()) {
            if (!this.needsRotation) {
                if (this.useSilentRotations.getValue()) {
                    this.currentYaw = RotationUtil.getSilentYaw();
                    this.currentPitch = RotationUtil.getSilentPitch();
                } else {
                    this.currentYaw = mc.player.getYaw();
                    this.currentPitch = mc.player.getPitch();
                }
            } else {
                this.startYaw = this.currentYaw;
                this.startPitch = this.currentPitch;
            }

            if (!this.needsRotation) {
                this.startYaw = this.currentYaw;
                this.startPitch = this.currentPitch;
            }

            this.rotationProgress = 0.0F;
            float yawDiff = Math.abs(RotationUtil.normalizeYaw(this.targetYaw - this.startYaw));
            float pitchDiff = Math.abs(this.targetPitch - this.startPitch);
            this.totalRotationDistance = (float)Math.sqrt((double)(yawDiff * yawDiff + pitchDiff * pitchDiff));
            if (this.totalRotationDistance < 0.1F) {
                this.totalRotationDistance = 0.1F;
            }

            this.needsRotation = true;
            this.rotationComplete = false;
            this.pendingAction = action;
        } else {
            this.currentYaw = this.targetYaw;
            this.currentPitch = this.targetPitch;
            if (this.useSilentRotations.getValue()) {
                RotationUtil.setSilentRotation(this.targetYaw, this.targetPitch);
            } else {
                mc.player.setYaw(this.targetYaw);
                mc.player.setPitch(this.targetPitch);
            }

            if (action != null) {
                action.run();
            }
        }
    }

    private boolean findTargetPosition() {
        if (mc.crosshairTarget instanceof BlockHitResult hitResult) {
            BlockPos var10 = hitResult.getBlockPos();
            if (this.isReplaceable(var10)) {
                this.targetAnchorPos = var10;
            } else {
                Direction side = hitResult.getSide();
                this.targetAnchorPos = var10.offset(side);
            }

            double distance = new Vec3d(mc.player.getX(), mc.player.getY(), mc.player.getZ())
                .distanceTo(Vec3d.ofCenter(this.targetAnchorPos));
            if (distance > this.range.getValue()) {
                return false;
            } else {
                playerPos = new Vec3d(mc.player.getX(), mc.player.getY(), mc.player.getZ());
                Vec3d anchorPos = Vec3d.ofCenter(this.targetAnchorPos);
                Vec3d midpoint = playerPos.add(anchorPos).multiply(0.5);
                BlockPos protectionPos = new BlockPos((int)Math.floor(midpoint.x), mc.player.getBlockY(), (int)Math.floor(midpoint.z));
                if (protectionPos.equals(this.targetAnchorPos) || protectionPos.equals(mc.player.getBlockPos())) {
                    Direction facing = yawToHorizontalDirection(mc.player.getYaw());
                    protectionPos = mc.player.getBlockPos().offset(facing);
                    if (protectionPos.equals(this.targetAnchorPos)) {
                        protectionPos = mc.player.getBlockPos();
                    }
                }

                this.protectionBlockPos = protectionPos;
                return true;
            }
        } else {
            return false;
        }
    }

    private boolean isReplaceable(BlockPos pos) {
        if (mc.world == null) {
            return false;
        } else {
            BlockState blockState = mc.world.getBlockState(pos);
            Block block = blockState.getBlock();
            return blockState.isAir()
                ? true
                : block == Blocks.SHORT_GRASS
                    || block == Blocks.TALL_GRASS
                    || block == Blocks.FERN
                    || block == Blocks.LARGE_FERN
                    || block == Blocks.DEAD_BUSH
                    || block == Blocks.VINE
                    || block == Blocks.FIRE
                    || block == Blocks.SOUL_FIRE
                    || block == Blocks.WATER
                    || block == Blocks.LAVA
                    || block == Blocks.SNOW
                    || block == Blocks.SEAGRASS
                    || block == Blocks.TALL_SEAGRASS
                    || block == Blocks.KELP
                    || block == Blocks.KELP_PLANT
                    || blockState.isReplaceable();
        }
    }

    private boolean placeBlock(BlockPos pos, Item item) {
        if (pos != null && this.isReplaceable(pos)) {
            InventoryUtil.swap(item);
            BlockHitResult hitResult = this.findPlacementSide(pos);
            if (hitResult == null) {
                return false;
            } else {
                if (item == Items.RESPAWN_ANCHOR) {
                    BlockUtil.interactWithBlock(hitResult, true);
                } else {
                    this.setTargetRotation(hitResult.getPos(), () -> BlockUtil.interactWithBlock(hitResult, true));
                }

                return true;
            }
        } else {
            return false;
        }
    }

    private BlockHitResult findPlacementSide(BlockPos pos) {
        Direction[] directions = new Direction[]{
            Direction.DOWN, Direction.UP, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST
        };

        for (Direction dir : directions) {
            BlockPos neighbor = pos.offset(dir);
            if (!this.isReplaceable(neighbor)) {
                return new BlockHitResult(
                    Vec3d.ofCenter(neighbor)
                        .add(
                            (double)dir.getOpposite().getVector().getX() * 0.5,
                            (double)dir.getOpposite().getVector().getY() * 0.5,
                            (double)dir.getOpposite().getVector().getZ() * 0.5
                        ),
                    dir.getOpposite(),
                    neighbor,
                    false
                );
            }
        }

        return null;
    }

    private boolean interactWithBlock(BlockPos pos, Item item) {
        if (pos == null) {
            return false;
        } else {
            if (item != null) {
                InventoryUtil.swap(item);
            }

            Direction targetFace = Direction.UP;
            Vec3d targetPos = Vec3d.ofCenter(pos)
                .add((double)targetFace.getOffsetX() * 0.5, (double)targetFace.getOffsetY() * 0.5, (double)targetFace.getOffsetZ() * 0.5);
            Vec3d eyePos = mc.player.getEyePos();
            if (targetPos.y > eyePos.y) {
                targetPos = Vec3d.ofCenter(pos);
            }

            this.setTargetRotation(targetPos, () -> {
                BlockHitResult hitResult = new BlockHitResult(Vec3d.ofCenter(pos), Direction.UP, pos, false);
                BlockUtil.interactWithBlock(hitResult, true);
            });
            return true;
        }
    }

    private boolean chargeAnchor(BlockPos pos) {
        if (pos != null && !this.isReplaceable(pos)) {
            InventoryUtil.swap(Items.GLOWSTONE);
            BlockHitResult hitResult = new BlockHitResult(Vec3d.ofCenter(pos), Direction.UP, pos, false);
            BlockUtil.interactWithBlock(hitResult, false);
            return true;
        } else {
            return false;
        }
    }

    private boolean hasRequiredItems() {
        boolean hasAnchor = false;
        boolean hasGlowstone = false;

        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.getItem().equals(Items.RESPAWN_ANCHOR)) {
                hasAnchor = true;
            }

            if (stack.getItem().equals(Items.GLOWSTONE)) {
                hasGlowstone = true;
            }
        }

        return hasAnchor && hasGlowstone;
    }

    private boolean checkTriggerKey() {
        int key = this.triggerKey.getValue();
        if (key != -1 && KeyUtils.isKeyPressed(key)) {
            this.isActive = true;
            return true;
        } else {
            return false;
        }
    }

    private void reset() {
        this.isActive = false;
        this.step = 0;
        this.delayCounter = 0;
        this.targetAnchorPos = null;
        this.protectionBlockPos = null;
        this.needsRotation = false;
        this.rotationComplete = false;
        this.pendingAction = null;
        this.rotationProgress = 0.0F;
        if (this.useSilentRotations.getValue()) {
            RotationUtil.resetSilentRotation();
        }
    }

    public boolean isActive() {
        return this.isActive;
    }

    private boolean hasLootNearby(BlockPos pos) {
        if (mc.world != null && pos != null) {
            double searchRadius = 10.0;
            Box searchBox = new Box(
                (double)pos.getX() - searchRadius,
                (double)pos.getY() - searchRadius,
                (double)pos.getZ() - searchRadius,
                (double)pos.getX() + searchRadius,
                (double)pos.getY() + searchRadius,
                (double)pos.getZ() + searchRadius
            );

            for (Entity entity : mc.world.getOtherEntities(null, searchBox)) {
                if (entity instanceof ItemEntity) {
                    ItemEntity itemEntity = (ItemEntity)entity;
                    ItemStack stack = itemEntity.getStack();
                    if (!stack.isEmpty()) {
                        if (ItemTypeUtil.isArmor(stack.getItem())) {
                            return true;
                        }

                        if (ItemTypeUtil.isSword(stack.getItem())) {
                            return true;
                        }

                        if (stack.getItem() == Items.TOTEM_OF_UNDYING) {
                            return true;
                        }
                    }
                }
            }

            return false;
        } else {
            return false;
        }
    }

    private static Direction yawToHorizontalDirection(float yaw) {
        int quadrant = Math.floorMod(Math.round(yaw / 90.0F), 4);

        return switch (quadrant) {
            case 0 -> Direction.SOUTH;
            case 1 -> Direction.WEST;
            case 2 -> Direction.NORTH;
            default -> Direction.EAST;
        };
    }
}
