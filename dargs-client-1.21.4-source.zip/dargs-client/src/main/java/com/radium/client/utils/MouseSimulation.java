package com.radium.client.utils;

import com.radium.client.client.RadiumClient;
import dev.darg.client.mixin.MinecraftClientInvoker;

public final class MouseSimulation {
    private MouseSimulation() {
    }

    public static void mouseClick(int button) {
        if (RadiumClient.mc != null) {
            if (button == 1) {
                ((MinecraftClientInvoker)RadiumClient.mc).dargsclient$invokeDoItemUse();
            } else {
                if (button == 0) {
                    ((MinecraftClientInvoker)RadiumClient.mc).dargsclient$invokeDoAttack();
                }
            }
        }
    }
}
