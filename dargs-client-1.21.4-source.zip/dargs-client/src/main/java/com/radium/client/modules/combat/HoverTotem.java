package com.radium.client.modules.combat;

import com.radium.client.client.RadiumClient;
import com.radium.client.events.event.TickListener;
import com.radium.client.gui.settings.BooleanSetting;
import com.radium.client.gui.settings.NumberSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;
import dev.darg.client.mixin.HandledScreenAccessorMixin;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

public class HoverTotem extends Module implements TickListener {
    private final BooleanSetting hotbarTotem = new BooleanSetting("Hotbar Totem", true);
    private final NumberSetting hotbarSlot = new NumberSetting("Hotbar Slot", 1.0, 1.0, 9.0, 1.0);
    private final BooleanSetting autoSwitchToTotem = new BooleanSetting("Auto Switch To Totem", false);
    private final BooleanSetting autoInvOpen = new BooleanSetting("Auto Inv Open", false);
    private boolean shouldOpenInv = false;
    private boolean totemEquipped = false;
    private boolean wasAutoOpened = false;

    public HoverTotem() {
        super("HoverTotem", "Equips a totem in offhand when hovered", Module.Category.COMBAT);
        this.addSettings(new Setting[]{this.hotbarTotem, this.hotbarSlot, this.autoSwitchToTotem, this.autoInvOpen});
    }

    @Override
    public void onEnable() {
        RadiumClient.getEventManager().add(TickListener.class, this);
        super.onEnable();
        this.shouldOpenInv = false;
        this.totemEquipped = false;
        this.wasAutoOpened = false;
    }

    @Override
    public void onDisable() {
        RadiumClient.getEventManager().remove(TickListener.class, this);
        super.onDisable();
        this.shouldOpenInv = false;
        this.totemEquipped = false;
        this.wasAutoOpened = false;
    }

    @Override
    public void onTick2() {
        if (mc.player != null) {
            if (this.autoInvOpen.getValue()
                && !mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)
                && this.hasTotemInInventory()
                && mc.currentScreen == null) {
                this.shouldOpenInv = true;
            }

            if (this.shouldOpenInv && mc.currentScreen == null) {
                if (this.hasTotemInInventory()) {
                    mc.execute(() -> {
                        if (mc.player != null) {
                            mc.setScreen(new InventoryScreen(mc.player));
                            this.shouldOpenInv = false;
                            this.totemEquipped = false;
                            this.wasAutoOpened = true;
                        }
                    });
                } else {
                    this.shouldOpenInv = false;
                }
            } else if (mc.currentScreen instanceof InventoryScreen inventoryScreen) {
                if (this.autoInvOpen.getValue() && !this.totemEquipped && mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                    this.totemEquipped = true;
                    this.wasAutoOpened = false;
                    mc.execute(() -> {
                        mc.player.closeHandledScreen();
                        mc.mouse.lockCursor();
                    });
                } else {
                    Slot focusedSlot = this.getFocusedSlotSafe(inventoryScreen);
                    if (focusedSlot != null && focusedSlot.getIndex() <= 35) {
                        if (this.autoSwitchToTotem.getValue()) {
                            mc.player.getInventory().setSelectedSlot(this.hotbarSlot.getValue().intValue() - 1);
                        }

                        if (focusedSlot.getStack().isOf(Items.TOTEM_OF_UNDYING)) {
                            int slotIndex = focusedSlot.getIndex();
                            int syncId = ((PlayerScreenHandler)inventoryScreen.getScreenHandler()).syncId;
                            if (!mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                                this.equipOffhandTotem(syncId, slotIndex);
                            } else {
                                if (this.hotbarTotem.getValue()) {
                                    int hotbarIndex = this.hotbarSlot.getValue().intValue() - 1;
                                    if (!mc.player.getInventory().getStack(hotbarIndex).isOf(Items.TOTEM_OF_UNDYING)) {
                                        this.equipHotbarTotem(syncId, slotIndex, hotbarIndex);
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (this.wasAutoOpened && !this.totemEquipped && mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                    this.totemEquipped = true;
                    this.wasAutoOpened = false;
                }

                if (this.wasAutoOpened && !this.totemEquipped) {
                    this.shouldOpenInv = true;
                }
            }
        }
    }

    public void onPacketReceive(Object packet) {
        if (packet instanceof EntityStatusS2CPacket statusPacket
            && statusPacket.getStatus() == 35
            && mc.player != null
            && statusPacket.getEntity(mc.world) == mc.player
            && this.autoInvOpen.getValue()
            && mc.currentScreen == null
            && this.hasTotemInInventory()) {
            this.shouldOpenInv = true;
            this.totemEquipped = false;
            this.wasAutoOpened = true;
        }
    }

    private boolean hasTotemInInventory() {
        if (mc.player == null) {
            return false;
        } else {
            for (int i = 0; i < 36; i++) {
                ItemStack stack = mc.player.getInventory().getStack(i);
                if (stack.isOf(Items.TOTEM_OF_UNDYING)) {
                    return true;
                }
            }

            return false;
        }
    }

    private void equipOffhandTotem(int syncId, int slotIndex) {
        mc.interactionManager.clickSlot(syncId, slotIndex, 40, SlotActionType.SWAP, mc.player);
    }

    private void equipHotbarTotem(int syncId, int slotIndex, int hotbarIndex) {
        mc.interactionManager.clickSlot(syncId, slotIndex, hotbarIndex, SlotActionType.SWAP, mc.player);
    }

    private Slot getFocusedSlotSafe(InventoryScreen screen) {
        return ((HandledScreenAccessorMixin)screen).getFocusedSlot();
    }
}
