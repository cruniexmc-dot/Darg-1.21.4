package com.radium.client.modules.combat;

import com.radium.client.client.RadiumClient;
import com.radium.client.events.event.AttackListener2;
import com.radium.client.gui.settings.BooleanSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;
import com.radium.client.utils.InventoryUtil;
import com.radium.client.utils.ItemTypeUtil;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.AttributeModifiersComponent.Entry;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;

public class AutoWeapon extends Module implements AttackListener2 {
    private final BooleanSetting preferMace = new BooleanSetting("Prefer Mace", true);

    public AutoWeapon() {
        super("Auto Weapon", "Switches to the best weapon when attacking", Module.Category.COMBAT);
        this.addSettings(new Setting[]{this.preferMace});
    }

    @Override
    public void onEnable() {
        RadiumClient.getEventManager().add(AttackListener2.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        RadiumClient.getEventManager().remove(AttackListener2.class, this);
        super.onDisable();
    }

    @Override
    public void onAttack(AttackListener2.AttackEvent2 event) {
        if (mc.player != null) {
            int bestSlot = -1;
            double maxDamage = -1.0;

            for (int i = 0; i < 9; i++) {
                ItemStack stack = mc.player.getInventory().getStack(i);
                if (!stack.isEmpty()
                    && (ItemTypeUtil.isSword(stack.getItem()) || stack.getItem() instanceof AxeItem || stack.getItem() instanceof MaceItem)) {
                    double damage = this.getAttackDamage(stack);
                    if (this.preferMace.getValue() && stack.getItem() instanceof MaceItem) {
                        damage += 100.0;
                    }

                    if (damage > maxDamage) {
                        maxDamage = damage;
                        bestSlot = i;
                    }
                }
            }

            if (bestSlot != -1 && bestSlot != mc.player.getInventory().getSelectedSlot()) {
                InventoryUtil.swap(bestSlot);
            }
        }
    }

    private double getAttackDamage(ItemStack stack) {
        AttributeModifiersComponent modifiers = (AttributeModifiersComponent)stack.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
        if (modifiers == null) {
            return 0.0;
        } else {
            double damage = 0.0;

            for (Entry entry : modifiers.modifiers()) {
                if (entry.attribute().equals(EntityAttributes.ATTACK_DAMAGE)
                    && (entry.slot() == AttributeModifierSlot.MAINHAND || entry.slot() == AttributeModifierSlot.ANY)) {
                    damage += entry.modifier().value();
                }
            }

            return damage;
        }
    }
}
