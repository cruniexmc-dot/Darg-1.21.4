package com.radium.client.modules.donut;

import com.radium.client.modules.Module;

public final class TunnelBaseFinder extends Module {
    public TunnelBaseFinder() {
        super("TunnelBaseFinder", "Compatibility stub", Module.Category.DONUT);
    }
}
