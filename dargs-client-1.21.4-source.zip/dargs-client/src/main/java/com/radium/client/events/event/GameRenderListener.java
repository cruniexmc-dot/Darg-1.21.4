package com.radium.client.events.event;

import com.radium.client.events.Event;
import com.radium.client.events.Listener;
import java.util.ArrayList;
import net.minecraft.client.util.math.MatrixStack;

public interface GameRenderListener extends Listener {
    void onGameRender(GameRenderListener.GameRenderEvent var1);

    public static class GameRenderEvent extends Event<GameRenderListener> {
        public MatrixStack matrices;
        public float delta;

        public GameRenderEvent(MatrixStack matrices, float delta) {
            this.matrices = matrices;
            this.delta = delta;
        }

        @Override
        public void fire(ArrayList<GameRenderListener> listeners) {
            listeners.forEach(e -> e.onGameRender(this));
        }

        @Override
        public Class<GameRenderListener> getListenerType() {
            return GameRenderListener.class;
        }
    }
}
