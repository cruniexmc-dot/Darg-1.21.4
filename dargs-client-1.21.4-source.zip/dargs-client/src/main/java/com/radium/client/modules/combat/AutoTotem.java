package com.radium.client.modules.combat;

import com.radium.client.client.RadiumClient;
import com.radium.client.gui.settings.NumberSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;
import com.radium.client.modules.client.ClickGUI;
import com.radium.client.modules.donut.TunnelBaseFinder;
import com.radium.client.modules.misc.BaseDigger;
import com.radium.client.utils.ToastNotification;
import com.radium.client.utils.ToastNotificationManager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    private final NumberSetting delay = new NumberSetting("Delay", 0.0, 0.0, 5.0, 1.0);
    private final NumberSetting lowTotemThreshold = new NumberSetting("Low Totem Alert", 3.0, 1.0, 10.0, 1.0);
    private int delayCounter = 0;
    private int lastTotemCount = -1;

    public AutoTotem() {
        super("AutoTotem", "Automatically equips a totem to your off-hand.", Module.Category.COMBAT);
        this.addSettings(new Setting[]{this.delay, this.lowTotemThreshold});
    }

    @Override
    public void onTick() {
        if (!RadiumClient.moduleManager.getModule(TunnelBaseFinder.class).isEnabled()) {
            if (!RadiumClient.moduleManager.getModule(BaseDigger.class).isEnabled()
                || RadiumClient.moduleManager.getModule(BaseDigger.class).diggingState == BaseDigger.DiggingState.NONE) {
                if (mc.player != null && mc.interactionManager != null) {
                    if (mc.player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING) {
                        this.delayCounter = this.delay.getValue().intValue();
                    } else if (this.delayCounter > 0) {
                        this.delayCounter--;
                    } else {
                        int totemSlot = this.findItemSlot(Items.TOTEM_OF_UNDYING);
                        if (totemSlot != -1) {
                            mc.interactionManager
                                .clickSlot(
                                    mc.player.playerScreenHandler.syncId, this.convertSlotIndex(totemSlot), 40, SlotActionType.SWAP, mc.player
                                );
                            this.delayCounter = this.delay.getValue().intValue();
                        }

                        int totemCount = this.countTotems();
                        if (totemCount != this.lastTotemCount && totemCount >= 0 && totemCount <= this.lowTotemThreshold.getValue().intValue()) {
                            this.lastTotemCount = totemCount;
                            if (RadiumClient.getModuleManager() != null) {
                                ClickGUI clickGUI = RadiumClient.getModuleManager().getModule(ClickGUI.class);
                                if (clickGUI != null && clickGUI.toastNotifications.getValue()) {
                                    ToastNotificationManager.getInstance()
                                        .show("Low Totems!", "You have " + totemCount + " totem(s) remaining", ToastNotification.ToastType.LOW_TOTEM);
                                }
                            }
                        } else if (totemCount != this.lastTotemCount) {
                            this.lastTotemCount = totemCount;
                        }
                    }
                }
            }
        }
    }

    private int findItemSlot(Item item) {
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.getItem() == item) {
                return i;
            }
        }

        return -1;
    }

    private int convertSlotIndex(int slotIndex) {
        if (slotIndex >= 0 && slotIndex < 9) {
            return 36 + slotIndex;
        } else {
            return slotIndex >= 9 && slotIndex < 36 ? slotIndex : slotIndex;
        }
    }

    private int countTotems() {
        if (mc.player == null) {
            return 0;
        } else {
            int count = 0;

            for (int i = 0; i < 36; i++) {
                ItemStack stack = mc.player.getInventory().getStack(i);
                if (stack.getItem() == Items.TOTEM_OF_UNDYING) {
                    count += stack.getCount();
                }
            }

            if (mc.player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING) {
                count += mc.player.getOffHandStack().getCount();
            }

            return count;
        }
    }
}
