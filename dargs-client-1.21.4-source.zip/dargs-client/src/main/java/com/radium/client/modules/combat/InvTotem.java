package com.radium.client.modules.combat;

import com.radium.client.client.RadiumClient;
import com.radium.client.events.event.GameRenderListener;
import com.radium.client.gui.settings.BooleanSetting;
import com.radium.client.gui.settings.ModeSetting;
import com.radium.client.gui.settings.NumberSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;
import com.radium.client.utils.FakeInvScreen;
import com.radium.client.utils.InventoryUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public final class InvTotem extends Module implements GameRenderListener {
    private final ModeSetting<InvTotem.Mode> mode = new ModeSetting<>("Mode", InvTotem.Mode.Blatant, InvTotem.Mode.class);
    private final BooleanSetting autoOpen = new BooleanSetting("Auto Open", true);
    private final NumberSetting stayOpenFor = new NumberSetting("Stay Open For", 2.0, 0.0, 20.0, 1.0);
    private final List<Long> recentIntervals = new ArrayList<>();
    private final Random random = new Random();
    private long nextActionTime = 0L;
    private int closeClock = -1;
    private boolean justOpenedInventory = false;

    public InvTotem() {
        super("Inv Totem", "Automatically equips totems from your inventory", Module.Category.COMBAT);
        this.addSettings(new Setting[]{this.mode, this.autoOpen, this.stayOpenFor});
    }

    @Override
    public void onEnable() {
        RadiumClient.getEventManager().add(GameRenderListener.class, this);
        this.nextActionTime = System.currentTimeMillis();
        this.closeClock = -1;
        this.justOpenedInventory = false;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        RadiumClient.getEventManager().remove(GameRenderListener.class, this);
        super.onDisable();
    }

    @Override
    public void onGameRender(GameRenderListener.GameRenderEvent event) {
        if (mc.player != null) {
            long currentTime = System.currentTimeMillis();
            if (this.shouldOpenScreen() && this.autoOpen.getValue() && !(mc.currentScreen instanceof InventoryScreen)) {
                mc.setScreen(new FakeInvScreen(mc.player));
                this.justOpenedInventory = true;
                this.nextActionTime = currentTime + 150L + (long)this.random.nextInt(100);
            } else if (!(mc.currentScreen instanceof InventoryScreen)) {
                this.nextActionTime = currentTime;
                this.closeClock = -1;
            } else {
                if (this.closeClock == -1) {
                    this.closeClock = this.stayOpenFor.getValue().intValue() + this.random.nextInt(3);
                }

                if (currentTime >= this.nextActionTime) {
                    if (this.justOpenedInventory) {
                        this.justOpenedInventory = false;
                        this.nextActionTime = currentTime + this.generateHumanDelay();
                    } else {
                        PlayerInventory inventory = mc.player.getInventory();
                        if (mc.player.getOffHandStack().getItem() != Items.TOTEM_OF_UNDYING) {
                            int slot = this.chooseTotemSlot();
                            if (slot != -1) {
                                mc.interactionManager
                                    .clickSlot(mc.player.playerScreenHandler.syncId, this.remapSlot(slot), 40, SlotActionType.SWAP, mc.player);
                                this.nextActionTime = currentTime + this.generateHumanDelay();
                                return;
                            }
                        }

                        if (this.shouldCloseScreen() && this.autoOpen.getValue()) {
                            if (this.closeClock > 0) {
                                this.closeClock--;
                                return;
                            }

                            mc.setScreen(null);
                            this.closeClock = this.stayOpenFor.getValue().intValue() + this.random.nextInt(3);
                        }
                    }
                }
            }
        }
    }

    private boolean shouldCloseScreen() {
        return mc.player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING && mc.currentScreen instanceof FakeInvScreen;
    }

    private boolean shouldOpenScreen() {
        return mc.player.getOffHandStack().getItem() != Items.TOTEM_OF_UNDYING && InventoryUtil.countItemExceptHotbar(Items.TOTEM_OF_UNDYING) != 0;
    }

    private int remapSlot(int slot) {
        return slot < 9 ? 36 + slot : slot;
    }

    private int chooseTotemSlot() {
        if (this.mode.getValue() == InvTotem.Mode.Blatant) {
            return this.random.nextDouble() < 0.7 ? InventoryUtil.findTotemSlot() : InventoryUtil.findRandomTotemSlot();
        } else {
            return InventoryUtil.findRandomTotemSlot();
        }
    }

    private long generateHumanDelay() {
        long lastDelay = this.recentIntervals.isEmpty() ? 120L : this.recentIntervals.get(this.recentIntervals.size() - 1);
        long base = (long)(100 + this.random.nextInt(100));
        long correlatedJitter = (long)((this.random.nextDouble() - 0.5) * (double)(50 + this.random.nextInt(50)));
        long longPause = 0L;
        if (this.random.nextDouble() < 0.1) {
            longPause = (long)(200 + this.random.nextInt(300));
        }

        long delay = base + correlatedJitter + longPause;
        delay = (delay + lastDelay) / 2L;
        delay = Math.max(50L, Math.min(600L, delay));
        this.recentIntervals.add(delay);
        if (this.recentIntervals.size() > 50) {
            this.recentIntervals.remove(0);
        }

        return delay;
    }

    public static enum Mode {
        Blatant,
        Random;
    }
}
