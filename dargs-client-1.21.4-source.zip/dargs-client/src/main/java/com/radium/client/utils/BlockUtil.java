package com.radium.client.utils;

import com.radium.client.client.RadiumClient;
import java.util.Objects;
import java.util.stream.Stream;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;

public final class BlockUtil {
    public static Stream<WorldChunk> getLoadedChunks() {
        int radius = Math.max(2, RadiumClient.mc.options.getClampedViewDistance()) + 3;
        int diameter = radius * 2 + 1;
        ChunkPos center = RadiumClient.mc.player.getChunkPos();
        ChunkPos min = new ChunkPos(center.x - radius, center.z - radius);
        ChunkPos max = new ChunkPos(center.x + radius, center.z + radius);
        return Stream.<ChunkPos>iterate(min, pos -> {
                int x = pos.x;
                int z = pos.z;
                if (++x > max.x) {
                    x = min.x;
                    z++;
                }

                if (z > max.z) {
                    throw new IllegalStateException("Stream limit didn't work.");
                } else {
                    return new ChunkPos(x, z);
                }
            })
            .limit((long)diameter * (long)diameter)
            .filter(c -> RadiumClient.mc.world.isChunkLoaded(c.x, c.z))
            .map(c -> RadiumClient.mc.world.getChunk(c.x, c.z))
            .filter(Objects::nonNull);
    }

    public static boolean isAnchorCharged(BlockPos pos) {
        return isBlockAtPosition(pos, Blocks.RESPAWN_ANCHOR)
            ? (Integer)RadiumClient.mc.world.getBlockState(pos).get(RespawnAnchorBlock.CHARGES) != 0
            : false;
    }

    public static boolean isAnchorNotCharged(BlockPos pos) {
        return isBlockAtPosition(pos, Blocks.RESPAWN_ANCHOR)
            ? (Integer)RadiumClient.mc.world.getBlockState(pos).get(RespawnAnchorBlock.CHARGES) == 0
            : false;
    }

    public static boolean isBlockAtPosition(BlockPos blockPos, Block block) {
        return RadiumClient.mc.world.getBlockState(blockPos).getBlock() == block;
    }

    public static void interactWithBlock(BlockHitResult blockHitResult, boolean shouldSwingHand) {
        ActionResult result = RadiumClient.mc.interactionManager.interactBlock(RadiumClient.mc.player, Hand.MAIN_HAND, blockHitResult);
        if (result.isAccepted() && shouldSwingHand) {
            RadiumClient.mc.player.swingHand(Hand.MAIN_HAND);
        }
    }
}
