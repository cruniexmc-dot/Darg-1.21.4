package com.radium.client.utils;

public final class ToastNotification {
    private ToastNotification() {
    }

    public static enum ToastType {
        SUCCESS,
        ERROR,
        WARNING,
        INFO,
        MODULE_ENABLED,
        MODULE_DISABLED,
        CONFIG_SAVE,
        CONFIG_LOAD,
        KEYBIND_CHANGE,
        FRIEND_JOIN,
        FRIEND_LEAVE,
        LOW_TOTEM,
        CUSTOM;
    }
}
