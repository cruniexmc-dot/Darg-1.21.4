package com.radium.client.modules.client;

import com.radium.client.gui.settings.BooleanSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;

public final class ClickGUI extends Module {
    public final BooleanSetting toastNotifications = new BooleanSetting("Toast Notifications", false);

    public ClickGUI() {
        super("ClickGUI", "Compatibility stub", Module.Category.CLIENT);
        this.addSettings(new Setting[]{this.toastNotifications});
    }
}
