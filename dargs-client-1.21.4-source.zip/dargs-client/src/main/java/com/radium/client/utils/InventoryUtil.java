package com.radium.client.utils;

import com.radium.client.client.RadiumClient;
import dev.darg.client.mixin.ClientPlayerInteractionManagerAccessor;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Predicate;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;

public final class InventoryUtil {
    public static void swap(int selectedSlot) {
        if (selectedSlot >= 0 && selectedSlot <= 8) {
            RadiumClient.mc.player.getInventory().setSelectedSlot(selectedSlot);
            ((ClientPlayerInteractionManagerAccessor)RadiumClient.mc.interactionManager).dargsclient$syncSelectedSlot();
        }
    }

    public static boolean swapStack(Predicate<ItemStack> predicate) {
        PlayerInventory getInventory = RadiumClient.mc.player.getInventory();

        for (int i = 0; i < 9; i++) {
            if (predicate.test(getInventory.getStack(i))) {
                getInventory.setSelectedSlot(i);
                return true;
            }
        }

        return false;
    }

    public static boolean swapItem(Predicate<Item> predicate) {
        PlayerInventory getInventory = RadiumClient.mc.player.getInventory();

        for (int i = 0; i < 9; i++) {
            if (predicate.test(getInventory.getStack(i).getItem())) {
                getInventory.setSelectedSlot(i);
                return true;
            }
        }

        return false;
    }

    public static boolean swap(Item item) {
        return swapItem(item2 -> item2 == item);
    }

    public static int getSlot(Item obj) {
        ScreenHandler currentScreenHandler = RadiumClient.mc.player.currentScreenHandler;
        if (RadiumClient.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) {
            int n = 0;

            for (int i = 0; i < ((GenericContainerScreenHandler)RadiumClient.mc.player.currentScreenHandler).getRows() * 9; i++) {
                if (currentScreenHandler.getSlot(i).getStack().getItem().equals(obj)) {
                    n++;
                }
            }

            return n;
        } else {
            return 0;
        }
    }

    public static int findTotemSlot() {
        PlayerInventory inv = RadiumClient.mc.player.getInventory();

        for (int i = 9; i < 36; i++) {
            if (inv.getStack(i).getItem() == Items.TOTEM_OF_UNDYING) {
                return i;
            }
        }

        return -1;
    }

    public static int findRandomTotemSlot() {
        PlayerInventory inv = RadiumClient.mc.player.getInventory();
        List<Integer> slots = new ArrayList<>();

        for (int i = 9; i < 36; i++) {
            if (inv.getStack(i).getItem() == Items.TOTEM_OF_UNDYING) {
                slots.add(i);
            }
        }

        return slots.isEmpty() ? -1 : slots.get(new Random().nextInt(slots.size()));
    }

    public static int countItemExceptHotbar(Item item) {
        PlayerInventory inv = RadiumClient.mc.player.getInventory();
        int count = 0;

        for (int i = 9; i < 36; i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.getItem() == item) {
                count += stack.getCount();
            }
        }

        return count;
    }

    public static boolean isTool(ItemStack stack) {
        Item item = stack.getItem();
        String path = Registries.ITEM.getId(item).getPath();
        return path.endsWith("_pickaxe")
            || path.endsWith("_axe")
            || path.endsWith("_shovel")
            || path.endsWith("_hoe")
            || ItemTypeUtil.isSword(item)
            || ItemTypeUtil.isArmor(item);
    }
}
