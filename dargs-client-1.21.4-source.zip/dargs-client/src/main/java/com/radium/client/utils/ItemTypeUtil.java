package com.radium.client.utils;

import net.minecraft.item.Item;
import net.minecraft.registry.Registries;

public final class ItemTypeUtil {
    private ItemTypeUtil() {
    }

    public static boolean isSword(Item item) {
        return hasPathSuffix(item, "_sword");
    }

    public static boolean isArmor(Item item) {
        return hasPathSuffix(item, "_helmet")
            || hasPathSuffix(item, "_chestplate")
            || hasPathSuffix(item, "_leggings")
            || hasPathSuffix(item, "_boots")
            || hasPathSuffix(item, "_armor");
    }

    private static boolean hasPathSuffix(Item item, String suffix) {
        return item != null && Registries.ITEM.getId(item).getPath().endsWith(suffix);
    }
}
