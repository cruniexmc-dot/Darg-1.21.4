package com.radium.client.client;

import java.util.Locale;
import org.lwjgl.glfw.GLFW;

public final class KeybindManager {
    private static final int MOUSE_BUTTON_OFFSET = 1000;

    public static String getKeyName(int keyCode) {
        if (keyCode <= 0) {
            return "None";
        } else if (isMouseButton(keyCode)) {
            return switch (getMouseButtonFromKeyCode(keyCode)) {
                case 0 -> "Left Click";
                case 1 -> "Right Click";
                case 2 -> "Middle Click";
                case 3 -> "Mouse 4";
                case 4 -> "Mouse 5";
                case 5 -> "Mouse 6";
                case 6 -> "Mouse 7";
                case 7 -> "Mouse 8";
                default -> "Mouse " + keyCode;
            };
        } else {
            String glfwName = GLFW.glfwGetKeyName(keyCode, 0);
            if (glfwName != null && !glfwName.isBlank()) {
                return glfwName.toUpperCase(Locale.ROOT);
            } else {
                return switch (keyCode) {
                    case 32 -> "Space";
                    case 256 -> "Escape";
                    case 257 -> "Enter";
                    case 258 -> "Tab";
                    case 340 -> "Left Shift";
                    case 341 -> "Left Ctrl";
                    case 342 -> "Left Alt";
                    case 344 -> "Right Shift";
                    case 345 -> "Right Ctrl";
                    case 346 -> "Right Alt";
                    default -> "Key " + keyCode;
                };
            }
        }
    }

    public static int getMouseButtonKeyCode(int mouseButton) {
        return 1000 + mouseButton;
    }

    public static boolean isMouseButton(int keyCode) {
        return keyCode >= 1000;
    }

    public static int getMouseButtonFromKeyCode(int keyCode) {
        return isMouseButton(keyCode) ? keyCode - 1000 : -1;
    }
}
