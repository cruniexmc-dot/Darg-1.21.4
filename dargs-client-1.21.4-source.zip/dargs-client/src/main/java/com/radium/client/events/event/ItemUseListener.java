package com.radium.client.events.event;

import com.radium.client.events.CancellableEvent;
import com.radium.client.events.Listener;
import java.util.ArrayList;

public interface ItemUseListener extends Listener {
    void onItemUse(ItemUseListener.ItemUseEvent var1);

    public static class ItemUseEvent extends CancellableEvent<ItemUseListener> {
        @Override
        public void fire(ArrayList<ItemUseListener> listeners) {
            listeners.forEach(e -> e.onItemUse(this));
        }

        @Override
        public Class<ItemUseListener> getListenerType() {
            return ItemUseListener.class;
        }
    }
}
