package com.radium.client.utils;

import com.radium.client.client.KeybindManager;
import com.radium.client.client.RadiumClient;
import org.lwjgl.glfw.GLFW;

public final class KeyUtils {
    public static boolean isKeyPressed(int keyCode) {
        if (RadiumClient.mc.getWindow() == null) {
            return false;
        } else {
            if (KeybindManager.isMouseButton(keyCode)) {
                int mouseButton = KeybindManager.getMouseButtonFromKeyCode(keyCode);
                if (mouseButton >= 0) {
                    return GLFW.glfwGetMouseButton(RadiumClient.mc.getWindow().getHandle(), mouseButton) == 1;
                }
            }

            return keyCode <= 8
                ? GLFW.glfwGetMouseButton(RadiumClient.mc.getWindow().getHandle(), keyCode) == 1
                : GLFW.glfwGetKey(RadiumClient.mc.getWindow().getHandle(), keyCode) == 1;
        }
    }
}
