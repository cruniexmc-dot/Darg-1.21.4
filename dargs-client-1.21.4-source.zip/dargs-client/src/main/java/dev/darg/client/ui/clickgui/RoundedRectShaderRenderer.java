package dev.darg.client.ui.clickgui;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

public final class RoundedRectShaderRenderer {
    private static final float MIN_SHADER_SIDE = 11.0F;
    private static final float MIN_SHADER_RADIUS = 5.0F;
    private static final int MIN_SHADER_ALPHA = 56;
    private static final Map<Integer, RenderPipeline> PIPELINE_CACHE = new ConcurrentHashMap<>();
    private static volatile boolean disabled;

    private RoundedRectShaderRenderer() {
    }

    public static boolean shouldUseShader(float width, float height, float radius, int alpha) {
        return !disabled && alpha >= 56 && width >= 11.0F && height >= 11.0F && radius >= 5.0F;
    }

    public static boolean drawRoundedRect(DrawContext context, float x, float y, float width, float height, float radius, int color) {
        if (disabled) {
            return false;
        } else {
            int left = Math.round(x);
            int top = Math.round(y);
            int right = Math.round(x + width);
            int bottom = Math.round(y + height);
            if (right > left && bottom > top) {
                int roundedRadius = Math.max(1, Math.round(radius));

                try {
                    RenderPipeline pipeline = PIPELINE_CACHE.computeIfAbsent(roundedRadius, RoundedRectShaderRenderer::createPipeline);
                    context.fill(pipeline, left, top, right, bottom, color);
                    return true;
                } catch (Throwable var13) {
                    disabled = true;
                    System.err.println("[RoundedRectShaderRenderer] Disabling rounded-rect shader renderer: " + var13.getMessage());
                    var13.printStackTrace(System.err);
                    return false;
                }
            } else {
                return true;
            }
        }
    }

    private static RenderPipeline createPipeline(int radius) {
        Identifier pipelineId = Identifier.of("dargsclient", "pipeline/clickgui_rounded_rect_" + radius);
        Identifier shaderId = Identifier.of("dargsclient", "core/rounded_rect");
        return RenderPipelines.register(
            RenderPipeline.builder(new Snippet[0])
                .withLocation(pipelineId)
                .withVertexShader(shaderId)
                .withFragmentShader(shaderId)
                .withShaderDefine("RADIUS_PX", radius)
                .withVertexFormat(VertexFormats.POSITION_COLOR, DrawMode.QUADS)
                .withBlend(BlendFunction.TRANSLUCENT)
                .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                .withDepthWrite(false)
                .withCull(false)
                .build()
        );
    }
}
