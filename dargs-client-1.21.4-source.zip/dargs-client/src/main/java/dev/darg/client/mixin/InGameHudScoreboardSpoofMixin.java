package dev.darg.client.mixin;

import dev.darg.client.feature.utility.DisplaySpoofController;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({InGameHud.class})
public abstract class InGameHudScoreboardSpoofMixin {
    @Inject(
        method = {"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"},
        at = {@At("HEAD")}
    )
    private void dargsclient$beginSidebarSpoof(DrawContext context, ScoreboardObjective objective, CallbackInfo ci) {
        DisplaySpoofController.beginScoreboardSidebar();
        DisplaySpoofController.captureSidebarObjective(objective);
    }

    @Redirect(
        method = {"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"},
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/gui/DrawContext;drawText(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;IIIZ)V"
        )
    )
    private void dargsclient$spoofSidebarText(DrawContext context, TextRenderer textRenderer, Text text, int x, int y, int color, boolean shadow) {
        context.drawText(textRenderer, DisplaySpoofController.spoofScoreboardDrawText(text), x, y, color, shadow);
    }

    @Inject(
        method = {"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V"},
        at = {@At("RETURN")}
    )
    private void dargsclient$endSidebarSpoof(DrawContext context, ScoreboardObjective objective, CallbackInfo ci) {
        DisplaySpoofController.endScoreboardSidebar();
    }
}
