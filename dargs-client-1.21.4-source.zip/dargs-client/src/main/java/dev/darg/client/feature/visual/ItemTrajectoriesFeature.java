package dev.darg.client.feature.visual;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.mixin.RenderLayerInvoker;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.OutputTarget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.RenderSetup.Builder;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public final class ItemTrajectoriesFeature extends Feature {
    private static final double RANGE = 48.0;
    private static final int MAX_SIMULATION_STEPS = 80;
    private static final double GRAVITY = 0.04;
    private static final double AIR_DRAG = 0.98;
    private static final double WATER_DRAG = 0.8;
    private static final double PEARL_GRAVITY = 0.03;
    private static final double PEARL_AIR_DRAG = 0.99;
    private static final double PEARL_WATER_DRAG = 0.8;
    private static final double PEARL_SPEED = 1.5;
    private static final double LAVA_DRAG = 0.95;
    private static final double MIN_MOTION_SQUARED = 4.0E-4;
    private static final double MARKER_HALF_SIZE = 0.22;
    private static final double MARKER_HEIGHT = 0.045;
    private static final double MARKER_Y_OFFSET = 0.012;
    private static final int ACCENT_RGB = 16773851;
    private static final int WARM_GLOW_RGB = 16766117;
    private static final int PEARL_GLOW_RGB = 4972543;
    private static final int PEARL_EDGE_RGB = 12057599;
    private static final int PEARL_FILL_RGB = 7924991;
    private static final int WHITE_RGB = 16777215;
    private static final ItemTrajectoriesFeature.TrajectoryPalette ITEM_PALETTE = new ItemTrajectoriesFeature.TrajectoryPalette(
        16766117, 16773851, 16773851, 16777215, 16773851, 16773851, 16777215
    );
    private static final ItemTrajectoriesFeature.TrajectoryPalette PEARL_PALETTE = new ItemTrajectoriesFeature.TrajectoryPalette(
        4972543, 12057599, 7924991, 16777215, 7924991, 12057599, 16777215
    );
    private static final Object RENDER_LAYER_LOCK = new Object();
    private static RenderLayer noDepthLineLayer;
    private static RenderLayer noDepthFillLayer;
    private int lastTrajectoryCount;
    private boolean lastPearlPreviewActive;

    public ItemTrajectoriesFeature() {
        super("ItemTrajectories", Category.RENDER);
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity player = client.player;
        if (client.world != null && player != null) {
            MatrixStack matrices = context.matrices();
            if (matrices == null) {
                this.lastTrajectoryCount = 0;
                this.lastPearlPreviewActive = false;
            } else {
                List<ItemEntity> items = client.world
                    .getEntitiesByClass(ItemEntity.class, player.getBoundingBox().expand(48.0), ItemTrajectoriesFeature::shouldTrackItem);
                float tickProgress = client.getRenderTickCounter().getTickProgress(false);
                List<ItemTrajectoriesFeature.PredictedTrajectory> itemTrajectories = new ArrayList<>();

                for (ItemEntity itemEntity : items) {
                    ItemTrajectoriesFeature.PredictedTrajectory trajectory = predictTrajectory(itemEntity, tickProgress);
                    if (trajectory != null) {
                        itemTrajectories.add(trajectory);
                    }
                }

                this.lastTrajectoryCount = itemTrajectories.size();
                ItemTrajectoriesFeature.PredictedTrajectory pearlTrajectory = predictHeldPearlTrajectory(player, tickProgress);
                this.lastPearlPreviewActive = pearlTrajectory != null;
                if (!itemTrajectories.isEmpty() || pearlTrajectory != null) {
                    float pulse = 0.82F + 0.18F * (float)Math.sin((double)(((float)client.world.getTime() + tickProgress) * 0.28F));
                    Vec3d cameraPos = client.gameRenderer.getCamera().getCameraPos();
                    OrderedRenderCommandQueue commandQueue = context.commandQueue();
                    if (!itemTrajectories.isEmpty()) {
                        this.renderTrajectoryGroup(commandQueue, matrices, itemTrajectories, cameraPos, pulse, ITEM_PALETTE);
                    }

                    if (pearlTrajectory != null) {
                        this.renderTrajectoryGroup(commandQueue, matrices, List.of(pearlTrajectory), cameraPos, pulse, PEARL_PALETTE);
                    }
                }
            }
        } else {
            this.lastTrajectoryCount = 0;
            this.lastPearlPreviewActive = false;
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of(
            "State: " + (this.isEnabled() ? "Enabled" : "Disabled"),
            "Range: 48 blocks",
            "Trajectories: " + this.lastTrajectoryCount,
            "Pearl Preview: " + (this.lastPearlPreviewActive ? "Active" : "Hold pearl"),
            "Style: Glowing landing arc"
        );
    }

    @Override
    public String getHudSuffix() {
        if (this.lastPearlPreviewActive) {
            return "PEARL";
        } else {
            return this.lastTrajectoryCount > 0 ? Integer.toString(this.lastTrajectoryCount) : null;
        }
    }

    private void renderTrajectoryGroup(
        OrderedRenderCommandQueue commandQueue,
        MatrixStack matrices,
        List<ItemTrajectoriesFeature.PredictedTrajectory> trajectories,
        Vec3d cameraPos,
        float pulse,
        ItemTrajectoriesFeature.TrajectoryPalette palette
    ) {
        this.submitTrajectoryLines(commandQueue, matrices, trajectories, cameraPos, pulse, 5.0F, false, palette);
        this.submitTrajectoryLines(commandQueue, matrices, trajectories, cameraPos, pulse, 2.15F, true, palette);
        this.submitLandingFills(commandQueue, matrices, trajectories, cameraPos, pulse, palette);
        this.submitLandingOutlines(commandQueue, matrices, trajectories, cameraPos, pulse, palette);
    }

    private static boolean shouldTrackItem(ItemEntity itemEntity) {
        if (itemEntity.isAlive() && !itemEntity.getStack().isEmpty()) {
            Vec3d velocity = itemEntity.getVelocity();
            if (velocity.lengthSquared() <= 4.0E-4) {
                return false;
            } else {
                return !itemEntity.isOnGround() && !itemEntity.isTouchingWater() && !itemEntity.isInLava() ? !isTouchingBlock(itemEntity) : false;
            }
        } else {
            return false;
        }
    }

    private static ItemTrajectoriesFeature.PredictedTrajectory predictHeldPearlTrajectory(PlayerEntity player, float tickProgress) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world != null && isHoldingPearl(player)) {
            Vec3d position = player.getCameraPosVec(tickProgress).add(0.0, -0.1, 0.0);
            Vec3d velocity = Vec3d.fromPolar(player.getPitch(tickProgress), player.getYaw(tickProgress)).normalize().multiply(1.5);
            Vec3d playerVelocity = player.getVelocity();
            velocity = velocity.add(playerVelocity.x, player.isOnGround() ? 0.0 : playerVelocity.y, playerVelocity.z);
            return predictArc(client, player, position, velocity, 0.03, 0.99, 0.8);
        } else {
            return null;
        }
    }

    private static boolean isTouchingBlock(ItemEntity itemEntity) {
        MinecraftClient client = MinecraftClient.getInstance();
        return client.world == null ? false : client.world.getBlockCollisions(itemEntity, itemEntity.getBoundingBox().expand(0.02)).iterator().hasNext();
    }

    private static ItemTrajectoriesFeature.PredictedTrajectory predictTrajectory(ItemEntity itemEntity, float tickProgress) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) {
            return null;
        } else {
            Vec3d position = itemEntity.getLerpedPos(tickProgress).add(0.0, (double)itemEntity.getHeight() * 0.35, 0.0);
            Vec3d velocity = itemEntity.getVelocity();
            return predictArc(client, itemEntity, position, velocity, 0.04, 0.98, 0.8, itemEntity.isTouchingWater(), itemEntity.isInLava());
        }
    }

    private static ItemTrajectoriesFeature.PredictedTrajectory predictArc(
        MinecraftClient client, Entity source, Vec3d position, Vec3d velocity, double gravity, double airDrag, double waterDrag
    ) {
        return predictArc(client, source, position, velocity, gravity, airDrag, waterDrag, isInWater(client, position), isInLava(client, position));
    }

    private static ItemTrajectoriesFeature.PredictedTrajectory predictArc(
        MinecraftClient client,
        Entity source,
        Vec3d position,
        Vec3d velocity,
        double gravity,
        double airDrag,
        double waterDrag,
        boolean touchingWater,
        boolean touchingLava
    ) {
        List<Vec3d> points = new ArrayList<>();
        points.add(position);

        for (int step = 0; step < 80; step++) {
            velocity = velocity.add(0.0, -gravity, 0.0);
            Vec3d nextPosition = position.add(velocity);
            BlockHitResult hitResult = client.world
                .raycast(new RaycastContext(position, nextPosition, ShapeType.COLLIDER, FluidHandling.NONE, source));
            if (hitResult.getType() == Type.BLOCK) {
                Vec3d landingPos = hitResult.getPos();
                points.add(landingPos);
                return points.size() < 2 ? null : new ItemTrajectoriesFeature.PredictedTrajectory(points, landingPos, true);
            }

            points.add(nextPosition);
            position = nextPosition;
            touchingWater = isInWater(client, nextPosition);
            touchingLava = isInLava(client, nextPosition);
            double drag = touchingWater ? waterDrag : (touchingLava ? 0.95 : airDrag);
            velocity = velocity.multiply(drag);
            if (nextPosition.y < (double)client.world.getBottomY() - 4.0) {
                break;
            }
        }

        return points.size() < 2 ? null : new ItemTrajectoriesFeature.PredictedTrajectory(points, points.get(points.size() - 1), false);
    }

    private static boolean isHoldingPearl(PlayerEntity player) {
        return player.getMainHandStack().isOf(Items.ENDER_PEARL) || player.getOffHandStack().isOf(Items.ENDER_PEARL);
    }

    private static boolean isInWater(MinecraftClient client, Vec3d position) {
        return client.world != null && client.world.getFluidState(BlockPos.ofFloored(position)).isIn(FluidTags.WATER);
    }

    private static boolean isInLava(MinecraftClient client, Vec3d position) {
        return client.world != null && client.world.getFluidState(BlockPos.ofFloored(position)).isIn(FluidTags.LAVA);
    }

    private void submitTrajectoryLines(
        OrderedRenderCommandQueue commandQueue,
        MatrixStack matrices,
        List<ItemTrajectoriesFeature.PredictedTrajectory> trajectories,
        Vec3d cameraPos,
        float pulse,
        float lineWidth,
        boolean corePass,
        ItemTrajectoriesFeature.TrajectoryPalette palette
    ) {
        commandQueue.submitCustom(matrices, getNoDepthLineLayer(), (entry, consumer) -> {
            for (ItemTrajectoriesFeature.PredictedTrajectory trajectory : trajectories) {
                int segmentCount = trajectory.points().size() - 1;

                for (int index = 0; index < segmentCount; index++) {
                    Vec3d start = trajectory.points().get(index).subtract(cameraPos);
                    Vec3d end = trajectory.points().get(index + 1).subtract(cameraPos);
                    float startProgress = (float)index / (float)Math.max(1, segmentCount);
                    float endProgress = (float)(index + 1) / (float)Math.max(1, segmentCount);
                    int startColor = corePass ? resolveCoreColor(startProgress, pulse, palette) : resolveGlowColor(startProgress, pulse, palette);
                    int endColor = corePass ? resolveCoreColor(endProgress, pulse, palette) : resolveGlowColor(endProgress, pulse, palette);
                    drawLine(entry, consumer, start, end, startColor, endColor, lineWidth);
                }
            }
        });
    }

    private void submitLandingFills(
        OrderedRenderCommandQueue commandQueue,
        MatrixStack matrices,
        List<ItemTrajectoriesFeature.PredictedTrajectory> trajectories,
        Vec3d cameraPos,
        float pulse,
        ItemTrajectoriesFeature.TrajectoryPalette palette
    ) {
        commandQueue.submitCustom(
            matrices,
            getNoDepthFillLayer(),
            (entry, consumer) -> {
                for (ItemTrajectoriesFeature.PredictedTrajectory trajectory : trajectories) {
                    if (trajectory.landed()) {
                        double halfSize = 0.22 + 0.03 * (double)pulse;
                        double height = 0.045 + 0.012 * (double)pulse;
                        double x = trajectory.landingPos().x - cameraPos.x;
                        double y = trajectory.landingPos().y - cameraPos.y + 0.012;
                        double z = trajectory.landingPos().z - cameraPos.z;
                        drawFilledBox(
                            entry,
                            consumer,
                            x - halfSize,
                            y,
                            z - halfSize,
                            x + halfSize,
                            y + height,
                            z + halfSize,
                            withAlpha(palette.fillRgb(), (int)(58.0F * pulse))
                        );
                    }
                }
            }
        );
    }

    private void submitLandingOutlines(
        OrderedRenderCommandQueue commandQueue,
        MatrixStack matrices,
        List<ItemTrajectoriesFeature.PredictedTrajectory> trajectories,
        Vec3d cameraPos,
        float pulse,
        ItemTrajectoriesFeature.TrajectoryPalette palette
    ) {
        commandQueue.submitCustom(
            matrices,
            getNoDepthLineLayer(),
            (entry, consumer) -> {
                for (ItemTrajectoriesFeature.PredictedTrajectory trajectory : trajectories) {
                    if (trajectory.landed()) {
                        double halfSize = 0.22 + 0.03 * (double)pulse;
                        double height = 0.045 + 0.012 * (double)pulse;
                        double x = trajectory.landingPos().x - cameraPos.x;
                        double y = trajectory.landingPos().y - cameraPos.y + 0.012;
                        double z = trajectory.landingPos().z - cameraPos.z;
                        ItemTrajectoriesFeature.QueuedMarker marker = new ItemTrajectoriesFeature.QueuedMarker(
                            x - halfSize, y, z - halfSize, x + halfSize, y + height, z + halfSize
                        );
                        int glowColor = withAlpha(palette.markerGlowRgb(), (int)(150.0F * pulse));
                        int coreColor = withAlpha(palette.markerCoreRgb(), (int)(230.0F * pulse));
                        drawBoxOutline(entry, consumer, marker, glowColor, 2.25F);
                        drawBoxOutline(entry, consumer, marker, coreColor, 1.2F);
                    }
                }
            }
        );
    }

    private static RenderLayer getNoDepthLineLayer() {
        RenderLayer layer = noDepthLineLayer;
        if (layer != null) {
            return layer;
        } else {
            synchronized (RENDER_LAYER_LOCK) {
                if (noDepthLineLayer == null) {
                    RenderPipeline pipeline = RenderPipelines.register(
                        RenderPipeline.builder(new Snippet[]{RenderPipelines.RENDERTYPE_LINES_SNIPPET})
                            .withLocation("pipeline/dargsclient_item_trajectory_line_no_depth")
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .build()
                    );
                    noDepthLineLayer = createRenderLayer("dargs_item_trajectory_line_no_depth", pipeline, true);
                }

                return noDepthLineLayer;
            }
        }
    }

    private static RenderLayer getNoDepthFillLayer() {
        RenderLayer layer = noDepthFillLayer;
        if (layer != null) {
            return layer;
        } else {
            synchronized (RENDER_LAYER_LOCK) {
                if (noDepthFillLayer == null) {
                    RenderPipeline pipeline = RenderPipelines.register(
                        RenderPipeline.builder(new Snippet[]{RenderPipelines.POSITION_COLOR_SNIPPET})
                            .withLocation("pipeline/dargsclient_item_trajectory_fill_no_depth")
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build()
                    );
                    noDepthFillLayer = createRenderLayer("dargs_item_trajectory_fill_no_depth", pipeline, false);
                }

                return noDepthFillLayer;
            }
        }
    }

    private static RenderLayer createRenderLayer(String name, RenderPipeline pipeline, boolean itemEntityTarget) {
        try {
            Builder setupBuilder = RenderSetup.builder(pipeline).layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING);
            if (itemEntityTarget) {
                setupBuilder.outputTarget(OutputTarget.ITEM_ENTITY_TARGET);
            } else {
                setupBuilder.translucent();
            }

            return RenderLayerInvoker.dargsclient$invokeOf(name, setupBuilder.build());
        } catch (RuntimeException var4) {
            throw new IllegalStateException("Failed to create ItemTrajectories render layer", var4);
        }
    }

    private static int resolveGlowColor(float progress, float pulse, ItemTrajectoriesFeature.TrajectoryPalette palette) {
        int rgb = interpolateRgb(palette.glowStartRgb(), palette.glowEndRgb(), 0.35F + 0.65F * progress);
        int alpha = 34 + (int)(48.0F * progress * pulse);
        return withAlpha(rgb, alpha);
    }

    private static int resolveCoreColor(float progress, float pulse, ItemTrajectoriesFeature.TrajectoryPalette palette) {
        int rgb = interpolateRgb(palette.coreStartRgb(), palette.coreEndRgb(), 0.18F + 0.62F * progress);
        int alpha = 128 + (int)(90.0F * progress * pulse);
        return withAlpha(rgb, alpha);
    }

    private static void drawLine(Entry entry, VertexConsumer consumer, Vec3d start, Vec3d end, int startColor, int endColor, float lineWidth) {
        float startX = (float)start.x;
        float startY = (float)start.y;
        float startZ = (float)start.z;
        float endX = (float)end.x;
        float endY = (float)end.y;
        float endZ = (float)end.z;
        float dx = endX - startX;
        float dy = endY - startY;
        float dz = endZ - startZ;
        float length = (float)Math.sqrt((double)(dx * dx + dy * dy + dz * dz));
        if (!(length < 1.0E-4F)) {
            float nx = dx / length;
            float ny = dy / length;
            float nz = dz / length;
            consumer.vertex(entry, startX, startY, startZ)
                .color(red(startColor), green(startColor), blue(startColor), alpha(startColor))
                .normal(entry, nx, ny, nz)
                .lineWidth(lineWidth);
            consumer.vertex(entry, endX, endY, endZ)
                .color(red(endColor), green(endColor), blue(endColor), alpha(endColor))
                .normal(entry, nx, ny, nz)
                .lineWidth(lineWidth);
        }
    }

    private static void drawBoxOutline(Entry entry, VertexConsumer consumer, ItemTrajectoriesFeature.QueuedMarker marker, int color, float lineWidth) {
        drawLine(entry, consumer, marker.minX(), marker.minY(), marker.minZ(), marker.maxX(), marker.minY(), marker.minZ(), color, lineWidth);
        drawLine(entry, consumer, marker.maxX(), marker.minY(), marker.minZ(), marker.maxX(), marker.minY(), marker.maxZ(), color, lineWidth);
        drawLine(entry, consumer, marker.maxX(), marker.minY(), marker.maxZ(), marker.minX(), marker.minY(), marker.maxZ(), color, lineWidth);
        drawLine(entry, consumer, marker.minX(), marker.minY(), marker.maxZ(), marker.minX(), marker.minY(), marker.minZ(), color, lineWidth);
        drawLine(entry, consumer, marker.minX(), marker.maxY(), marker.minZ(), marker.maxX(), marker.maxY(), marker.minZ(), color, lineWidth);
        drawLine(entry, consumer, marker.maxX(), marker.maxY(), marker.minZ(), marker.maxX(), marker.maxY(), marker.maxZ(), color, lineWidth);
        drawLine(entry, consumer, marker.maxX(), marker.maxY(), marker.maxZ(), marker.minX(), marker.maxY(), marker.maxZ(), color, lineWidth);
        drawLine(entry, consumer, marker.minX(), marker.maxY(), marker.maxZ(), marker.minX(), marker.maxY(), marker.minZ(), color, lineWidth);
        drawLine(entry, consumer, marker.minX(), marker.minY(), marker.minZ(), marker.minX(), marker.maxY(), marker.minZ(), color, lineWidth);
        drawLine(entry, consumer, marker.maxX(), marker.minY(), marker.minZ(), marker.maxX(), marker.maxY(), marker.minZ(), color, lineWidth);
        drawLine(entry, consumer, marker.maxX(), marker.minY(), marker.maxZ(), marker.maxX(), marker.maxY(), marker.maxZ(), color, lineWidth);
        drawLine(entry, consumer, marker.minX(), marker.minY(), marker.maxZ(), marker.minX(), marker.maxY(), marker.maxZ(), color, lineWidth);
    }

    private static void drawLine(
        Entry entry, VertexConsumer consumer, double startX, double startY, double startZ, double endX, double endY, double endZ, int color, float lineWidth
    ) {
        drawLine(entry, consumer, new Vec3d(startX, startY, startZ), new Vec3d(endX, endY, endZ), color, color, lineWidth);
    }

    private static void drawFilledBox(
        Entry entry, VertexConsumer consumer, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, int color
    ) {
        float x1 = (float)minX;
        float y1 = (float)minY;
        float z1 = (float)minZ;
        float x2 = (float)maxX;
        float y2 = (float)maxY;
        float z2 = (float)maxZ;
        emitQuad(consumer, entry, x1, y1, z1, x2, y1, z1, x2, y2, z1, x1, y2, z1, color);
        emitQuad(consumer, entry, x2, y1, z2, x1, y1, z2, x1, y2, z2, x2, y2, z2, color);
        emitQuad(consumer, entry, x1, y1, z2, x1, y1, z1, x1, y2, z1, x1, y2, z2, color);
        emitQuad(consumer, entry, x2, y1, z1, x2, y1, z2, x2, y2, z2, x2, y2, z1, color);
        emitQuad(consumer, entry, x1, y2, z1, x2, y2, z1, x2, y2, z2, x1, y2, z2, color);
        emitQuad(consumer, entry, x1, y1, z2, x2, y1, z2, x2, y1, z1, x1, y1, z1, color);
    }

    private static void emitQuad(
        VertexConsumer consumer,
        Entry entry,
        float x1,
        float y1,
        float z1,
        float x2,
        float y2,
        float z2,
        float x3,
        float y3,
        float z3,
        float x4,
        float y4,
        float z4,
        int color
    ) {
        consumer.vertex(entry, x1, y1, z1).color(red(color), green(color), blue(color), alpha(color));
        consumer.vertex(entry, x2, y2, z2).color(red(color), green(color), blue(color), alpha(color));
        consumer.vertex(entry, x3, y3, z3).color(red(color), green(color), blue(color), alpha(color));
        consumer.vertex(entry, x4, y4, z4).color(red(color), green(color), blue(color), alpha(color));
    }

    private static int interpolateRgb(int startRgb, int endRgb, float progress) {
        float clampedProgress = Math.max(0.0F, Math.min(1.0F, progress));
        int red = (int)((float)red(startRgb) + (float)(red(endRgb) - red(startRgb)) * clampedProgress);
        int green = (int)((float)green(startRgb) + (float)(green(endRgb) - green(startRgb)) * clampedProgress);
        int blue = (int)((float)blue(startRgb) + (float)(blue(endRgb) - blue(startRgb)) * clampedProgress);
        return red << 16 | green << 8 | blue;
    }

    private static int withAlpha(int rgb, int alpha) {
        return Math.max(0, Math.min(255, alpha)) << 24 | rgb & 16777215;
    }

    private static int red(int color) {
        return color >> 16 & 0xFF;
    }

    private static int green(int color) {
        return color >> 8 & 0xFF;
    }

    private static int blue(int color) {
        return color & 0xFF;
    }

    private static int alpha(int color) {
        return color >> 24 & 0xFF;
    }

    private static record PredictedTrajectory(List<Vec3d> points, Vec3d landingPos, boolean landed) {
    }

    private static record QueuedMarker(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
    }

    private static record TrajectoryPalette(
        int glowStartRgb, int glowEndRgb, int coreStartRgb, int coreEndRgb, int fillRgb, int markerGlowRgb, int markerCoreRgb
    ) {
    }
}
