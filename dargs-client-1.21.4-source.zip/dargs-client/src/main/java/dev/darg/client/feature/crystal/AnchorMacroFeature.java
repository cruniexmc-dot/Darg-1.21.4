package dev.darg.client.feature.crystal;

import dev.darg.client.feature.Category;
import dev.darg.client.feature.combat.CombatSupport;
import dev.darg.client.feature.combat.ConfigurableCombatFeature;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;

public final class AnchorMacroFeature extends ConfigurableCombatFeature {
    private final ConfigurableCombatFeature.BooleanSetting whileUse = this.booleanSetting("while_use", "While Use", true);
    private final ConfigurableCombatFeature.BooleanSetting stopOnKill = this.booleanSetting("stop_on_kill", "Stop On Kill", false);
    private final ConfigurableCombatFeature.BooleanSetting clickSimulation = this.booleanSetting("click_simulation", "Click Simulation", false);
    private final ConfigurableCombatFeature.NumberSetting switchDelay = this.intSetting("switch_delay", "Switch Delay", 0, 0, 20);
    private final ConfigurableCombatFeature.NumberSetting switchChance = this.intSetting("switch_chance", "Switch Chance", 100, 0, 100);
    private final ConfigurableCombatFeature.NumberSetting placeChance = this.intSetting("place_chance", "Place Chance", 100, 0, 100);
    private final ConfigurableCombatFeature.NumberSetting glowstoneDelay = this.intSetting("glowstone_delay", "Glowstone Delay", 0, 0, 20);
    private final ConfigurableCombatFeature.NumberSetting glowstoneChance = this.intSetting("glowstone_chance", "Glowstone Chance", 100, 0, 100);
    private final ConfigurableCombatFeature.NumberSetting explodeDelay = this.intSetting("explode_delay", "Explode Delay", 0, 0, 20);
    private final ConfigurableCombatFeature.NumberSetting explodeChance = this.intSetting("explode_chance", "Explode Chance", 100, 0, 100);
    private final ConfigurableCombatFeature.NumberSetting explodeSlot = this.intSetting("explode_slot", "Explode Slot", 1, 1, 9);
    private final ConfigurableCombatFeature.BooleanSetting onlyOwn = this.booleanSetting("only_own", "Only Own", false);
    private final ConfigurableCombatFeature.BooleanSetting onlyCharge = this.booleanSetting("only_charge", "Only Charge", false);
    private final Set<BlockPos> ownedAnchors = new HashSet<>();
    private int switchClock;
    private int glowstoneClock;
    private int explodeClock;

    public AnchorMacroFeature() {
        super("AnchorMacro", Category.CRYSTAL);
    }

    @Override
    protected void onEnable() {
        this.switchClock = 0;
        this.glowstoneClock = 0;
        this.explodeClock = 0;
        this.ownedAnchors.clear();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        ClientPlayerInteractionManager im = mc.interactionManager;
        if (player != null && im != null && mc.world != null && mc.currentScreen == null) {
            if (this.whileUse.get() || !CombatSupport.isUsingFoodOrShield(player) || GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), 1) != 1) {
                if (!this.stopOnKill.get() || !CombatSupport.hasNearbyDeadPlayer(mc.world, player, 24.0)) {
                    if (GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), 1) == 1) {
                        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != Type.BLOCK) {
                            return;
                        }

                        if (mc.world.getBlockState(hit.getBlockPos()).isOf(Blocks.RESPAWN_ANCHOR)) {
                            mc.options.useKey.setPressed(false);
                            if (!this.onlyOwn.get() || this.ownedAnchors.contains(hit.getBlockPos())) {
                                boolean charged = (Integer)mc.world.getBlockState(hit.getBlockPos()).get(RespawnAnchorBlock.CHARGES) > 0;
                                if (charged) {
                                    int slot = this.explodeSlot.intValue() - 1;
                                    if (player.getInventory().getSelectedSlot() != slot) {
                                        if (this.switchClock > 0) {
                                            this.switchClock--;
                                        } else {
                                            if (Math.random() * 100.0 <= this.switchChance.doubleValue()) {
                                                player.getInventory().setSelectedSlot(slot);
                                                player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
                                                this.switchClock = this.switchDelay.intValue();
                                            }
                                        }
                                    } else if (this.explodeClock > 0) {
                                        this.explodeClock--;
                                    } else {
                                        if (Math.random() * 100.0 <= this.explodeChance.doubleValue()) {
                                            if (!this.onlyCharge.get()) {
                                                im.interactBlock(player, Hand.MAIN_HAND, hit);
                                                player.swingHand(Hand.MAIN_HAND);
                                                this.ownedAnchors.remove(hit.getBlockPos());
                                            }

                                            this.explodeClock = this.explodeDelay.intValue() + (int)(Math.random() * 2.0);
                                        }
                                    }
                                } else if (this.placeChance.intValue() >= 100 || !(Math.random() * 100.0 > this.placeChance.doubleValue())) {
                                    if (!player.getMainHandStack().isOf(Items.GLOWSTONE)) {
                                        if (this.switchClock > 0) {
                                            this.switchClock--;
                                            return;
                                        }

                                        if (selectFromHotbar(player, Items.GLOWSTONE) && Math.random() * 100.0 <= this.switchChance.doubleValue()) {
                                            this.switchClock = this.switchDelay.intValue();
                                        }
                                    }

                                    if (player.getMainHandStack().isOf(Items.GLOWSTONE)) {
                                        if (this.glowstoneClock > 0) {
                                            this.glowstoneClock--;
                                            return;
                                        }

                                        if (Math.random() * 100.0 <= this.glowstoneChance.doubleValue()) {
                                            im.interactBlock(player, Hand.MAIN_HAND, hit);
                                            player.swingHand(Hand.MAIN_HAND);
                                            this.glowstoneClock = this.glowstoneDelay.intValue() + (int)(Math.random() * 2.0);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private static boolean selectFromHotbar(ClientPlayerEntity player, Item item) {
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getStack(i).isOf(item)) {
                player.getInventory().setSelectedSlot(i);
                player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(i));
                return true;
            }
        }

        return false;
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("Hold right-click on respawn anchor", "Explode slot: " + this.explodeSlot.intValue());
    }
}
