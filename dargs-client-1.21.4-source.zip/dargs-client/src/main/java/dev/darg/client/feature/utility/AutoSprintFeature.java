package dev.darg.client.feature.utility;

import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

public final class AutoSprintFeature extends Feature {
    public AutoSprintFeature() {
        super("AutoSprint", Category.UTILITY);
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player != null && !player.isSneaking() && player.input != null) {
            if (player.input.hasForwardMovement()) {
                player.setSprinting(true);
            }
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("State: " + (this.isEnabled() ? "Enabled" : "Disabled"), "Sprint trigger: Forward input", "Stops while sneaking");
    }
}
