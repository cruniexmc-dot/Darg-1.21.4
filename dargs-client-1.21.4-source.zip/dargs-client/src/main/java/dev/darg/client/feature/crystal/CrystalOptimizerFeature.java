package dev.darg.client.feature.crystal;

import dev.darg.client.feature.Category;
import dev.darg.client.feature.combat.CombatFeatureHooks;
import dev.darg.client.feature.combat.CombatSupport;
import dev.darg.client.feature.combat.ConfigurableCombatFeature;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.Entity.RemovalReason;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket.Handler;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Vec3d;

public final class CrystalOptimizerFeature extends ConfigurableCombatFeature implements CombatFeatureHooks.PacketSendHook {
    public CrystalOptimizerFeature() {
        super("CrystalOptimizer", Category.CRYSTAL);
    }

    @Override
    public boolean onSendPacket(MinecraftClient client, Packet<?> packet) {
        if (packet instanceof PlayerInteractEntityC2SPacket interactPacket && client.player != null) {
            interactPacket.handle(new Handler() {
                public void interact(Hand hand) {
                }

                public void interactAt(Hand hand, Vec3d pos) {
                }

                public void attack() {
                    if (client.crosshairTarget != null && client.crosshairTarget.getType() == Type.ENTITY) {
                        if (!(client.crosshairTarget instanceof EntityHitResult hit) || !(hit.getEntity() instanceof EndCrystalEntity)) {
                            return;
                        }

                        if (CombatSupport.canBreakCrystalWithCurrentItem(client.player)) {
                            Entity entity = hit.getEntity();
                            entity.discard();
                            entity.setRemoved(RemovalReason.KILLED);
                            entity.onRemoved();
                        }
                    }
                }
            });
            return false;
        }

        return false;
    }
}
