package dev.darg.client.feature.combat;

import dev.darg.client.feature.crystal.CrystalUtils;
import dev.darg.client.mixin.HandledScreenAccessorMixin;
import java.util.Comparator;
import java.util.function.Predicate;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ShieldItem;
import net.minecraft.item.SplashPotionItem;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public final class CombatSupport {
    private CombatSupport() {
    }

    public static boolean selectHotbarSlot(ClientPlayerEntity player, int slot) {
        if (player != null && slot >= 0 && slot < PlayerInventory.getHotbarSize()) {
            if (player.getInventory().getSelectedSlot() == slot) {
                return true;
            } else {
                player.getInventory().setSelectedSlot(slot);
                player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
                return true;
            }
        } else {
            return false;
        }
    }

    public static boolean selectHotbarItem(ClientPlayerEntity player, Item item) {
        return selectHotbarSlot(player, findHotbarSlot(player, stack -> stack.isOf(item)));
    }

    public static int findHotbarSlot(ClientPlayerEntity player, Predicate<ItemStack> predicate) {
        if (player == null) {
            return -1;
        } else {
            PlayerInventory inventory = player.getInventory();

            for (int slot = 0; slot < PlayerInventory.getHotbarSize(); slot++) {
                if (predicate.test(inventory.getStack(slot))) {
                    return slot;
                }
            }

            return -1;
        }
    }

    public static int findInventorySlot(ClientPlayerEntity player, Predicate<ItemStack> predicate, boolean includeHotbar) {
        if (player == null) {
            return -1;
        } else {
            int start = includeHotbar ? 0 : PlayerInventory.getHotbarSize();

            for (int slot = start; slot < 36; slot++) {
                if (predicate.test(player.getInventory().getStack(slot))) {
                    return slot;
                }
            }

            return -1;
        }
    }

    public static int screenSlotFromInventory(int inventorySlot) {
        return inventorySlot < PlayerInventory.getHotbarSize() ? 36 + inventorySlot : inventorySlot;
    }

    public static int countItemOutsideHotbar(ClientPlayerEntity player, Item item) {
        if (player == null) {
            return 0;
        } else {
            int count = 0;

            for (int slot = PlayerInventory.getHotbarSize(); slot < 36; slot++) {
                ItemStack stack = player.getInventory().getStack(slot);
                if (stack.isOf(item)) {
                    count += stack.getCount();
                }
            }

            return count;
        }
    }

    public static Slot getFocusedSlot(HandledScreen<?> screen) {
        return screen == null ? null : ((HandledScreenAccessorMixin)screen).getFocusedSlot();
    }

    public static boolean isHoldingWeapon(ClientPlayerEntity player) {
        if (player == null) {
            return false;
        } else {
            Item item = player.getMainHandStack().getItem();
            return isSwordItem(item) || item instanceof AxeItem;
        }
    }

    public static boolean isSwordItem(Item item) {
        return isSword(item);
    }

    public static boolean isUsingFoodOrShield(ClientPlayerEntity player) {
        return player == null ? false : isFoodOrShield(player.getMainHandStack()) || isFoodOrShield(player.getOffHandStack());
    }

    public static boolean isFoodOrShield(ItemStack stack) {
        return !stack.isEmpty() && (stack.contains(DataComponentTypes.FOOD) || stack.getItem() instanceof ShieldItem);
    }

    public static boolean isSplashInstantHealth(ItemStack stack) {
        if (stack != null && !stack.isEmpty() && stack.getItem() instanceof SplashPotionItem) {
            PotionContentsComponent contents = (PotionContentsComponent)stack.get(DataComponentTypes.POTION_CONTENTS);
            if (contents == null) {
                return false;
            } else {
                for (StatusEffectInstance effect : contents.getEffects()) {
                    if (effect.getEffectType().value() == StatusEffects.INSTANT_HEALTH) {
                        return true;
                    }
                }

                return false;
            }
        } else {
            return false;
        }
    }

    public static int findHotbarInstantHealthSplash(ClientPlayerEntity player) {
        return findHotbarSlot(player, CombatSupport::isSplashInstantHealth);
    }

    public static int findInventoryInstantHealthSplash(ClientPlayerEntity player) {
        return findInventorySlot(player, CombatSupport::isSplashInstantHealth, false);
    }

    public static int findHotbarAxe(ClientPlayerEntity player) {
        return findHotbarSlot(player, stack -> stack.getItem() instanceof AxeItem);
    }

    public static int findHotbarSword(ClientPlayerEntity player) {
        return findHotbarSlot(player, stack -> isSword(stack.getItem()));
    }

    public static boolean hasNearbyDeadPlayer(World world, ClientPlayerEntity self, double range) {
        if (world != null && self != null) {
            double squaredRange = range * range;
            return world.getPlayers()
                .stream()
                .filter(player -> player != self)
                .anyMatch(player -> !player.isAlive() && player.squaredDistanceTo(self) <= squaredRange);
        } else {
            return false;
        }
    }

    public static PlayerEntity findNearestPlayer(ClientPlayerEntity self, double radius, boolean visibleOnly, boolean ignoreDead) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (self != null && client.world != null) {
            double squaredRadius = radius * radius;
            return client.world
                .getPlayers()
                .stream()
                .filter(player -> player != self)
                .filter(player -> !ignoreDead || player.getHealth() > 0.0F)
                .filter(player -> player.squaredDistanceTo(self) <= squaredRadius)
                .filter(player -> !visibleOnly || self.canSee(player))
                .min(Comparator.comparingDouble(player -> self.squaredDistanceTo(player)))
                .orElse(null);
        } else {
            return null;
        }
    }

    public static boolean isShieldFacingAway(PlayerEntity target, LivingEntity attacker) {
        if (target != null && attacker != null) {
            Vec3d facing = target.getRotationVec(1.0F).normalize();
            Vec3d toAttacker = new Vec3d(
                    attacker.getX() - target.getX(),
                    attacker.getY() - target.getY(),
                    attacker.getZ() - target.getZ()
                )
                .normalize();
            return facing.dotProduct(toAttacker) < 0.25;
        } else {
            return true;
        }
    }

    public static boolean canBreakCrystalWithCurrentItem(ClientPlayerEntity player) {
        if (player == null) {
            return false;
        } else {
            StatusEffectInstance weakness = player.getStatusEffect(StatusEffects.WEAKNESS);
            if (weakness == null) {
                return true;
            } else {
                StatusEffectInstance strength = player.getStatusEffect(StatusEffects.STRENGTH);
                return strength != null && strength.getAmplifier() > weakness.getAmplifier() ? true : isHoldingWeapon(player);
            }
        }
    }

    public static float estimateExplosionDamage(ClientPlayerEntity player, Vec3d explosionPos, float radius) {
        if (player == null) {
            return 0.0F;
        } else {
            Vec3d centre = new Vec3d(player.getX(), player.getY() + (double)player.getHeight() / 2.0, player.getZ());
            double distance = explosionPos.distanceTo(centre);
            if (distance >= (double)radius) {
                return 0.0F;
            } else {
                double impact = 1.0 - distance / (double)radius;
                float raw = (float)((impact * impact + impact) / 2.0 * 7.0 * (double)radius + 1.0);
                float armor = (float)player.getArmor();
                double toughness = player.getAttributeValue(EntityAttributes.ARMOR_TOUGHNESS);
                float divisor = 2.0F + (float)toughness / 4.0F;
                float absorbed = MathHelper.clamp(armor - raw / divisor, armor / 5.0F, 20.0F);
                return Math.max(0.0F, raw * (1.0F - absorbed / 25.0F));
            }
        }
    }

    public static boolean canPlaceCrystal(BlockPos pos, World world) {
        return CrystalUtils.canPlaceCrystal(pos, world);
    }

    public static boolean isCrystalBase(BlockState state) {
        return state.isOf(Blocks.OBSIDIAN) || state.isOf(Blocks.BEDROCK);
    }

    public static void swapWithOffhand(ClientPlayerEntity player) {
        if (player != null) {
            player.networkHandler.sendPacket(new PlayerActionC2SPacket(Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ORIGIN, Direction.DOWN));
        }
    }

    public static Vec3d eyes(PlayerEntity player) {
        return player == null ? Vec3d.ZERO : player.getEyePos();
    }

    public static Vec3d lookVec(PlayerEntity player) {
        return player == null ? Vec3d.ZERO : player.getRotationVec(1.0F);
    }

    public static boolean isValidBlockTarget(BlockHitResult blockHitResult) {
        return blockHitResult != null && blockHitResult.getType() == Type.BLOCK;
    }

    private static boolean isSword(Item item) {
        return item == Items.WOODEN_SWORD
            || item == Items.STONE_SWORD
            || item == Items.IRON_SWORD
            || item == Items.GOLDEN_SWORD
            || item == Items.DIAMOND_SWORD
            || item == Items.NETHERITE_SWORD;
    }
}
