package dev.darg.client.feature;

public enum Category {
    RENDER("Render"),
    UTILITY("Utility"),
    CRYSTAL("Crystal"),
    COMBAT("Combat"),
    BASEFINDING("Basefinding"),
    OPTIMIZER("Optimizer"),
    SETTINGS("Settings");

    private final String displayName;

    private Category(String displayName) {
        this.displayName = displayName;
    }

    public String displayName() {
        return this.displayName;
    }
}
