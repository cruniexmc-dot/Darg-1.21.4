package dev.darg.client.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import dev.darg.client.mixin.RenderLayerInvoker;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;

public final class ItemBillboardRenderUtil {
    private static final float FLAT_DEPTH_SCALE = 0.035F;
    private static final float FLAT_UPSCALE = 1.08F;
    private static final float QUAD_HALF_SIZE = 0.5F;
    private static final Map<Identifier, RenderLayer> SPRITE_LAYERS = new ConcurrentHashMap<>();
    private static final Random SPRITE_RANDOM = Random.create(0L);

    private ItemBillboardRenderUtil() {
    }

    public static void renderItemRow(
        MinecraftClient client,
        MatrixStack matrices,
        OrderedRenderCommandQueue queue,
        Camera camera,
        Vec3d relPos,
        List<ItemStack> stacks,
        ItemRenderState scratchState,
        float scale,
        float spacing
    ) {
        renderItemRowInternal(client, matrices, queue, camera, relPos, stacks, scratchState, scale, spacing, false);
    }

    public static void renderFlatItemRow(
        MinecraftClient client,
        MatrixStack matrices,
        OrderedRenderCommandQueue queue,
        Camera camera,
        Vec3d relPos,
        List<ItemStack> stacks,
        ItemRenderState scratchState,
        float scale,
        float spacing
    ) {
        renderItemRowInternal(client, matrices, queue, camera, relPos, stacks, scratchState, scale, spacing, true);
    }

    private static void renderItemRowInternal(
        MinecraftClient client,
        MatrixStack matrices,
        OrderedRenderCommandQueue queue,
        Camera camera,
        Vec3d relPos,
        List<ItemStack> stacks,
        ItemRenderState scratchState,
        float scale,
        float spacing,
        boolean flattenDepth
    ) {
        if (client.world != null) {
            if (!stacks.isEmpty()) {
                int n = stacks.size();
                float mid = (float)(n - 1) * 0.5F;
                matrices.push();
                matrices.translate(relPos.x, relPos.y, relPos.z);
                matrices.multiply(camera.getRotation());
                float appliedScale = flattenDepth ? scale * 1.08F : scale;
                matrices.scale(appliedScale, appliedScale, flattenDepth ? Math.max(0.01F, appliedScale * 0.035F) : appliedScale);

                for (int i = 0; i < n; i++) {
                    ItemStack stack = stacks.get(i);
                    if (!stack.isEmpty()) {
                        ItemRenderState state = new ItemRenderState();
                        client.getItemModelManager().clearAndUpdate(state, stack, ItemDisplayContext.GUI, client.world, null, 0);
                        if (!state.isEmpty()) {
                            Sprite sprite = getParticleSprite(state);
                            if (sprite != null) {
                                matrices.push();
                                matrices.translate(((float)i - mid) * spacing, 0.0F, 0.0F);
                                queue.submitCustom(matrices, getSpriteLayer(sprite.getAtlasId()), (entry, buffer) -> {
                                    VertexConsumer spriteBuffer = sprite.getTextureSpecificVertexConsumer(buffer);
                                    drawTexturedQuad(entry, spriteBuffer, sprite);
                                });
                                matrices.pop();
                            }
                        }
                    }
                }

                matrices.pop();
            }
        }
    }

    private static Sprite getParticleSprite(ItemRenderState state) {
        SPRITE_RANDOM.setSeed(0L);
        return state.getParticleSprite(SPRITE_RANDOM);
    }

    private static void drawTexturedQuad(Entry entry, VertexConsumer buffer, Sprite sprite) {
        float minU = sprite.getMinU();
        float maxU = sprite.getMaxU();
        float minV = sprite.getMinV();
        float maxV = sprite.getMaxV();
        buffer.vertex(entry, -0.5F, -0.5F, 0.0F).color(255, 255, 255, 255).texture(minU, maxV);
        buffer.vertex(entry, 0.5F, -0.5F, 0.0F).color(255, 255, 255, 255).texture(maxU, maxV);
        buffer.vertex(entry, 0.5F, 0.5F, 0.0F).color(255, 255, 255, 255).texture(maxU, minV);
        buffer.vertex(entry, -0.5F, 0.5F, 0.0F).color(255, 255, 255, 255).texture(minU, minV);
    }

    private static RenderLayer getSpriteLayer(Identifier atlasId) {
        return SPRITE_LAYERS.computeIfAbsent(atlasId, ItemBillboardRenderUtil::createSpriteLayer);
    }

    private static RenderLayer createSpriteLayer(Identifier atlasId) {
        String layerSuffix = sanitizeIdentifier(atlasId);
        String layerName = "dargsclient_item_billboard_" + layerSuffix;
        return RenderLayerInvoker.dargsclient$invokeOf(
            layerName,
            RenderSetup.builder(
                    RenderPipelines.register(
                        RenderPipeline.builder(new Snippet[]{RenderPipelines.POSITION_TEX_COLOR_SNIPPET})
                            .withLocation("pipeline/" + layerName)
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build()
                    )
                )
                .texture("Sampler0", atlasId)
                .layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
                .translucent()
                .build()
        );
    }

    private static String sanitizeIdentifier(Identifier id) {
        String raw = id.toString();
        StringBuilder sanitized = new StringBuilder(raw.length());

        for (int index = 0; index < raw.length(); index++) {
            char character = raw.charAt(index);
            if ((character < 'a' || character > 'z') && (character < '0' || character > '9') && character != '_') {
                sanitized.append('_');
            } else {
                sanitized.append(character);
            }
        }

        return sanitized.toString();
    }
}
