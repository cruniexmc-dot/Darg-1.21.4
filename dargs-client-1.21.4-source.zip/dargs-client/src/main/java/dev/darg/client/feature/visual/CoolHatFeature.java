package dev.darg.client.feature.visual;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.mixin.RenderLayerInvoker;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.OutputTarget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.RenderSetup.Builder;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class CoolHatFeature extends Feature {
    private static final double RANGE = 128.0;
    private static final int SHAFT_SEGMENTS = 18;
    private static final int SPHERE_LAT_SEGMENTS = 7;
    private static final int SPHERE_LON_SEGMENTS = 14;
    private static final double SHAFT_LENGTH = 0.52;
    private static final double SHAFT_RADIUS = 0.115;
    private static final double GLANS_LENGTH = 0.17;
    private static final double BASE_OFFSET = 0.11;
    private static final double TILT = 0.19;
    private static final int SHAFT_COLOR = 16770232;
    private static final int GLANS_COLOR = 16773320;
    private static final int BASE_COLOR = 16766370;
    private static final int HIGHLIGHT_COLOR = 16775398;
    private static final Object RENDER_LAYER_LOCK = new Object();
    private static RenderLayer fillLayer;
    private static RenderLayer lineLayer;
    private int lastRenderedCount;

    public CoolHatFeature() {
        super("CoolHat", Category.RENDER);
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity cameraPlayer = client.player;
        if (client.world != null && cameraPlayer != null) {
            MatrixStack matrices = context.matrices();
            if (matrices == null) {
                this.lastRenderedCount = 0;
            } else {
                float tickProgress = client.getRenderTickCounter().getTickProgress(false);
                Vec3d cameraPos = client.gameRenderer.getCamera().getCameraPos();
                OrderedRenderCommandQueue commandQueue = context.commandQueue();
                this.lastRenderedCount = (int)client.world
                    .getPlayers()
                    .stream()
                    .filter(target -> target.isAlive() && !target.isSpectator() && cameraPlayer.squaredDistanceTo(target) <= 16384.0)
                    .count();
                if (this.lastRenderedCount != 0) {
                    commandQueue.submitCustom(matrices, getFillLayer(), (entry, consumer) -> {
                        for (PlayerEntity target : client.world.getPlayers()) {
                            if (target.isAlive() && !target.isSpectator() && !(cameraPlayer.squaredDistanceTo(target) > 16384.0)) {
                                this.renderModel(entry, consumer, target, tickProgress, cameraPos);
                            }
                        }
                    });
                    commandQueue.submitCustom(matrices, getLineLayer(), (entry, consumer) -> {
                        for (PlayerEntity target : client.world.getPlayers()) {
                            if (target.isAlive() && !target.isSpectator() && !(cameraPlayer.squaredDistanceTo(target) > 16384.0)) {
                                this.renderHighlights(entry, consumer, target, tickProgress, cameraPos);
                            }
                        }
                    });
                }
            }
        } else {
            this.lastRenderedCount = 0;
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of(
            "State: " + (this.isEnabled() ? "Enabled" : "Disabled"), "Targets: " + this.lastRenderedCount, "Style: Smooth sculpted hat", "Range: 128 blocks"
        );
    }

    @Override
    public String getHudSuffix() {
        return this.lastRenderedCount > 0 ? Integer.toString(this.lastRenderedCount) : "HAT";
    }

    private void renderModel(Entry entry, VertexConsumer consumer, PlayerEntity target, float tickProgress, Vec3d cameraPos) {
        CoolHatFeature.ModelBasis basis = this.createBasis(target, tickProgress, cameraPos);
        Vec3d shaftBottom = basis.baseCenter();
        Vec3d shaftTop = shaftBottom.add(basis.axis().multiply(0.52));
        Vec3d glansMid = shaftTop.add(basis.axis().multiply(0.0646));
        Vec3d glansTip = shaftTop.add(basis.axis().multiply(0.17));
        Vec3d ballLeft = shaftBottom.subtract(basis.axis().multiply(0.035))
            .subtract(basis.right().multiply(0.135))
            .subtract(basis.forward().multiply(0.028));
        Vec3d ballRight = shaftBottom.subtract(basis.axis().multiply(0.035))
            .add(basis.right().multiply(0.135))
            .subtract(basis.forward().multiply(0.028));
        this.drawTube(entry, consumer, shaftBottom, shaftTop, basis.right(), basis.cross(), 0.115, 0.1173, 18, withAlpha(16770232, 220));
        this.drawTube(entry, consumer, shaftTop, glansMid, basis.right(), basis.cross(), 0.11960000000000001, 0.1403, 18, withAlpha(16773320, 228));
        this.drawTube(entry, consumer, glansMid, glansTip, basis.right(), basis.cross(), 0.1403, 0.032200000000000006, 18, withAlpha(16773320, 236));
        this.drawSphere(entry, consumer, ballLeft, basis.right(), basis.cross(), basis.axis(), 0.155, 0.125, 0.135, withAlpha(16766370, 214));
        this.drawSphere(entry, consumer, ballRight, basis.right(), basis.cross(), basis.axis(), 0.155, 0.125, 0.135, withAlpha(16766370, 214));
    }

    private void renderHighlights(Entry entry, VertexConsumer consumer, PlayerEntity target, float tickProgress, Vec3d cameraPos) {
        CoolHatFeature.ModelBasis basis = this.createBasis(target, tickProgress, cameraPos);
        Vec3d shaftBottom = basis.baseCenter();
        Vec3d shaftTop = shaftBottom.add(basis.axis().multiply(0.52));
        Vec3d glansRim = shaftTop.add(basis.axis().multiply(0.030600000000000002));
        int highlight = withAlpha(16775398, 185);
        this.drawRing(
            entry, consumer, shaftBottom.add(basis.axis().multiply(0.02)), basis.right(), basis.cross(), 0.11960000000000001, 18, highlight, 1.25F
        );
        this.drawRing(entry, consumer, glansRim, basis.right(), basis.cross(), 0.1357, 18, highlight, 1.35F);
        drawLine(
            entry,
            consumer,
            shaftTop.subtract(basis.right().multiply(0.023000000000000003)),
            shaftTop.add(basis.axis().multiply(0.11220000000000001)),
            highlight,
            1.1F
        );
    }

    private CoolHatFeature.ModelBasis createBasis(PlayerEntity target, float tickProgress, Vec3d cameraPos) {
        Vec3d lerpedPos = target.getLerpedPos(tickProgress).subtract(cameraPos);
        double yawRadians = Math.toRadians((double)target.getYaw(tickProgress));
        Vec3d forward = new Vec3d(-Math.sin(yawRadians), 0.0, Math.cos(yawRadians)).normalize();
        Vec3d axis = new Vec3d(forward.x * 0.19, 1.0, forward.z * 0.19).normalize();
        Vec3d right = new Vec3d(forward.z, 0.0, -forward.x).normalize();
        Vec3d cross = axis.crossProduct(right).normalize();
        Vec3d baseCenter = lerpedPos.add(0.0, (double)target.getHeight() + 0.11, 0.0);
        return new CoolHatFeature.ModelBasis(baseCenter, axis, right, cross, forward);
    }

    private void drawTube(
        Entry entry,
        VertexConsumer consumer,
        Vec3d startCenter,
        Vec3d endCenter,
        Vec3d right,
        Vec3d cross,
        double startRadius,
        double endRadius,
        int segments,
        int color
    ) {
        for (int index = 0; index < segments; index++) {
            double angleA = (Math.PI * 2) * (double)index / (double)segments;
            double angleB = (Math.PI * 2) * (double)(index + 1) / (double)segments;
            Vec3d p1 = circlePoint(startCenter, right, cross, startRadius, angleA);
            Vec3d p2 = circlePoint(startCenter, right, cross, startRadius, angleB);
            Vec3d p3 = circlePoint(endCenter, right, cross, endRadius, angleB);
            Vec3d p4 = circlePoint(endCenter, right, cross, endRadius, angleA);
            emitQuad(consumer, entry, p1, p2, p3, p4, color);
        }
    }

    private void drawSphere(
        Entry entry, VertexConsumer consumer, Vec3d center, Vec3d right, Vec3d cross, Vec3d axis, double radiusX, double radiusY, double radiusZ, int color
    ) {
        for (int lat = 0; lat < 7; lat++) {
            double phiA = (-Math.PI / 2) + Math.PI * (double)lat / 7.0;
            double phiB = (-Math.PI / 2) + Math.PI * (double)(lat + 1) / 7.0;

            for (int lon = 0; lon < 14; lon++) {
                double thetaA = (Math.PI * 2) * (double)lon / 14.0;
                double thetaB = (Math.PI * 2) * (double)(lon + 1) / 14.0;
                Vec3d p1 = ellipsoidPoint(center, right, cross, axis, radiusX, radiusY, radiusZ, thetaA, phiA);
                Vec3d p2 = ellipsoidPoint(center, right, cross, axis, radiusX, radiusY, radiusZ, thetaB, phiA);
                Vec3d p3 = ellipsoidPoint(center, right, cross, axis, radiusX, radiusY, radiusZ, thetaB, phiB);
                Vec3d p4 = ellipsoidPoint(center, right, cross, axis, radiusX, radiusY, radiusZ, thetaA, phiB);
                emitQuad(consumer, entry, p1, p2, p3, p4, color);
            }
        }
    }

    private void drawRing(Entry entry, VertexConsumer consumer, Vec3d center, Vec3d right, Vec3d cross, double radius, int segments, int color, float lineWidth) {
        for (int index = 0; index < segments; index++) {
            double angleA = (Math.PI * 2) * (double)index / (double)segments;
            double angleB = (Math.PI * 2) * (double)(index + 1) / (double)segments;
            drawLine(entry, consumer, circlePoint(center, right, cross, radius, angleA), circlePoint(center, right, cross, radius, angleB), color, lineWidth);
        }
    }

    private static Vec3d circlePoint(Vec3d center, Vec3d right, Vec3d cross, double radius, double angle) {
        return center.add(right.multiply(Math.cos(angle) * radius)).add(cross.multiply(Math.sin(angle) * radius));
    }

    private static Vec3d ellipsoidPoint(
        Vec3d center, Vec3d right, Vec3d cross, Vec3d axis, double radiusX, double radiusY, double radiusZ, double theta, double phi
    ) {
        double cosPhi = Math.cos(phi);
        double sinPhi = Math.sin(phi);
        double cosTheta = Math.cos(theta);
        double sinTheta = Math.sin(theta);
        return center.add(right.multiply(cosTheta * cosPhi * radiusX))
            .add(cross.multiply(sinTheta * cosPhi * radiusZ))
            .add(axis.multiply(sinPhi * radiusY));
    }

    private static void drawLine(Entry entry, VertexConsumer consumer, Vec3d start, Vec3d end, int color, float lineWidth) {
        float startX = (float)start.x;
        float startY = (float)start.y;
        float startZ = (float)start.z;
        float endX = (float)end.x;
        float endY = (float)end.y;
        float endZ = (float)end.z;
        float dx = endX - startX;
        float dy = endY - startY;
        float dz = endZ - startZ;
        float length = MathHelper.sqrt(dx * dx + dy * dy + dz * dz);
        if (!(length < 1.0E-4F)) {
            float nx = dx / length;
            float ny = dy / length;
            float nz = dz / length;
            consumer.vertex(entry, startX, startY, startZ)
                .color(red(color), green(color), blue(color), alpha(color))
                .normal(entry, nx, ny, nz)
                .lineWidth(lineWidth);
            consumer.vertex(entry, endX, endY, endZ)
                .color(red(color), green(color), blue(color), alpha(color))
                .normal(entry, nx, ny, nz)
                .lineWidth(lineWidth);
        }
    }

    private static void emitQuad(VertexConsumer consumer, Entry entry, Vec3d a, Vec3d b, Vec3d c, Vec3d d, int color) {
        consumer.vertex(entry, (float)a.x, (float)a.y, (float)a.z)
            .color(red(color), green(color), blue(color), alpha(color));
        consumer.vertex(entry, (float)b.x, (float)b.y, (float)b.z)
            .color(red(color), green(color), blue(color), alpha(color));
        consumer.vertex(entry, (float)c.x, (float)c.y, (float)c.z)
            .color(red(color), green(color), blue(color), alpha(color));
        consumer.vertex(entry, (float)d.x, (float)d.y, (float)d.z)
            .color(red(color), green(color), blue(color), alpha(color));
    }

    private static RenderLayer getFillLayer() {
        RenderLayer layer = fillLayer;
        if (layer != null) {
            return layer;
        } else {
            synchronized (RENDER_LAYER_LOCK) {
                if (fillLayer == null) {
                    RenderPipeline pipeline = RenderPipelines.register(
                        RenderPipeline.builder(new Snippet[]{RenderPipelines.POSITION_COLOR_SNIPPET})
                            .withLocation("pipeline/dargsclient_cool_hat_fill")
                            .withCull(false)
                            .build()
                    );
                    fillLayer = createRenderLayer("dargs_cool_hat_fill", pipeline, false);
                }

                return fillLayer;
            }
        }
    }

    private static RenderLayer getLineLayer() {
        RenderLayer layer = lineLayer;
        if (layer != null) {
            return layer;
        } else {
            synchronized (RENDER_LAYER_LOCK) {
                if (lineLayer == null) {
                    RenderPipeline pipeline = RenderPipelines.register(
                        RenderPipeline.builder(new Snippet[]{RenderPipelines.RENDERTYPE_LINES_SNIPPET}).withLocation("pipeline/dargsclient_cool_hat_line").build()
                    );
                    lineLayer = createRenderLayer("dargs_cool_hat_line", pipeline, true);
                }

                return lineLayer;
            }
        }
    }

    private static RenderLayer createRenderLayer(String name, RenderPipeline pipeline, boolean itemEntityTarget) {
        try {
            Builder setupBuilder = RenderSetup.builder(pipeline).layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING);
            if (itemEntityTarget) {
                setupBuilder.outputTarget(OutputTarget.ITEM_ENTITY_TARGET);
            } else {
                setupBuilder.translucent();
            }

            return RenderLayerInvoker.dargsclient$invokeOf(name, setupBuilder.build());
        } catch (RuntimeException var4) {
            throw new IllegalStateException("Failed to create CoolHat render layer", var4);
        }
    }

    private static int withAlpha(int rgb, int alpha) {
        return Math.max(0, Math.min(255, alpha)) << 24 | rgb & 16777215;
    }

    private static int red(int color) {
        return color >> 16 & 0xFF;
    }

    private static int green(int color) {
        return color >> 8 & 0xFF;
    }

    private static int blue(int color) {
        return color & 0xFF;
    }

    private static int alpha(int color) {
        return color >> 24 & 0xFF;
    }

    private static record ModelBasis(Vec3d baseCenter, Vec3d axis, Vec3d right, Vec3d cross, Vec3d forward) {
    }
}
