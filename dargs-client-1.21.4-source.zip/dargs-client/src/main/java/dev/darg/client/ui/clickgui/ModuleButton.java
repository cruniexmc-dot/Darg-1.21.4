package dev.darg.client.ui.clickgui;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.theme.ClientTheme;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class ModuleButton {
    private static final float ROW_HEIGHT = 32.0F;
    private static final float ACTION_HEIGHT = 20.0F;
    private static final float ACTION_SPACING = 6.0F;
    private static final float ACTION_PAD_TOP = 22.0F;
    private static final float ACTION_PAD_BOTTOM = 10.0F;
    private static final float SETTINGS_PAD_LEFT = 10.0F;
    private static final float SETTINGS_PAD_RIGHT = 10.0F;
    private final Feature feature;
    private boolean searchHighlighted;
    float x;
    float y;
    float width;
    float height = 32.0F;
    boolean expanded;

    public ModuleButton(Feature feature) {
        this.feature = feature;
    }

    public Feature getFeature() {
        return this.feature;
    }

    public void setExpanded(boolean value) {
        this.expanded = value;
    }

    public void setSearchHighlighted(boolean value) {
        this.searchHighlighted = value;
    }

    public void setPosition(float x, float y, float width) {
        this.x = x;
        this.y = y;
        this.width = width;
    }

    public float getRenderHeight() {
        return this.height + (this.expanded ? this.getExpandedHeight() : 0.0F);
    }

    public void render(DrawContext context, TextRenderer textRenderer, ClientTheme theme, int mouseX, int mouseY) {
        boolean hovered = this.containsBody((double)mouseX, (double)mouseY);
        boolean enabled = this.feature.isEnabled();
        float surfaceX = this.x + 6.0F;
        float surfaceY = this.y + 2.0F;
        float surfaceW = this.width - 12.0F;
        float surfaceH = this.height - 4.0F;
        int fill = enabled ? theme.moduleButtonFillHover() : theme.moduleButtonFill();
        if (hovered && !enabled) {
            fill = RenderUtil.mixColor(theme.moduleButtonFill(), theme.moduleButtonFillHover(), 0.72F);
        }

        if (this.searchHighlighted) {
            RenderUtil.drawRoundedRect(
                context, surfaceX - 1.0F, surfaceY - 1.0F, surfaceW + 2.0F, surfaceH + 2.0F, 11.0F, RenderUtil.withAlpha(theme.accent(), 34)
            );
        }

        RenderUtil.drawGradientRoundedRect(context, surfaceX, surfaceY, surfaceW, surfaceH, 10.0F, fill, RenderUtil.darken(fill, 0.14F));
        if (enabled || this.searchHighlighted) {
            int railColor = enabled ? theme.accent() : RenderUtil.withAlpha(theme.accent(), 148);
            RenderUtil.drawRoundedRect(context, surfaceX, surfaceY + 6.0F, 3.0F, surfaceH - 12.0F, 2.0F, railColor);
        }

        float expandSize = 16.0F;
        float expandX = surfaceX + surfaceW - expandSize - 8.0F;
        float expandY = surfaceY + (surfaceH - expandSize) * 0.5F;
        RenderUtil.drawRoundedRect(context, expandX, expandY, expandSize, expandSize, 6.0F, theme.moduleButtonActionFill());
        RenderUtil.drawText(context, textRenderer, this.expanded ? "v" : ">", expandX + 5.0F, expandY + 4.0F, theme.softGray());
        float stateX = expandX - 36.0F;
        this.drawStateChip(context, textRenderer, theme, enabled, stateX, surfaceY + (surfaceH - 14.0F) * 0.5F);
        float textRight = stateX - 8.0F;
        String bindLabel = DargsClient.getInstance().getKeybindManager().getBindLabel(this.feature);
        if (DargsClient.getInstance().getKeybindManager().isCapturing(this.feature) || !this.feature.getKeybind().isNone()) {
            float bindWidth = Math.min(74.0F, Math.max(36.0F, (float)RenderUtil.getTextWidth(textRenderer, bindLabel) + 10.0F));
            float bindX = textRight - bindWidth;
            this.drawMetaChip(
                context,
                textRenderer,
                theme,
                InlineControlRenderer.fitText(textRenderer, bindLabel, Math.round(bindWidth - 10.0F)),
                bindX,
                surfaceY + (surfaceH - 14.0F) * 0.5F,
                false
            );
            textRight = bindX - 8.0F;
        }

        String displayName = InlineControlRenderer.fitText(textRenderer, this.feature.getName(), Math.round(Math.max(36.0F, textRight - (surfaceX + 12.0F))));
        RenderUtil.drawText(context, textRenderer, displayName, surfaceX + 12.0F, surfaceY + 10.0F, enabled ? theme.white() : theme.softGray());
        if (this.expanded) {
            this.renderExpanded(context, textRenderer, theme, mouseX, mouseY);
        }
    }

    private void drawStateChip(DrawContext context, TextRenderer textRenderer, ClientTheme theme, boolean enabled, float x, float y) {
        String label = enabled ? "ON" : "OFF";
        float chipWidth = Math.max(26.0F, (float)RenderUtil.getTextWidth(textRenderer, label) + 10.0F);
        float chipHeight = 14.0F;
        int chipColor = enabled ? theme.accent() : theme.moduleButtonActionFill();
        int textColor = enabled ? theme.darkText() : theme.softGray();
        RenderUtil.drawRoundedRect(context, x, y, chipWidth, chipHeight, 7.0F, chipColor);
        RenderUtil.drawText(context, textRenderer, label, x + (chipWidth - (float)RenderUtil.getTextWidth(textRenderer, label)) * 0.5F, y + 3.0F, textColor);
    }

    private void drawMetaChip(DrawContext context, TextRenderer textRenderer, ClientTheme theme, String label, float x, float y, boolean primary) {
        float chipWidth = Math.max(30.0F, (float)RenderUtil.getTextWidth(textRenderer, label) + 10.0F);
        int fill = primary ? theme.accent() : theme.moduleButtonActionFill();
        int textColor = primary ? theme.darkText() : theme.softGray();
        RenderUtil.drawRoundedRect(context, x, y, chipWidth, 14.0F, 7.0F, fill);
        RenderUtil.drawText(context, textRenderer, label, x + (chipWidth - (float)RenderUtil.getTextWidth(textRenderer, label)) * 0.5F, y + 3.0F, textColor);
    }

    private void renderExpanded(DrawContext context, TextRenderer textRenderer, ClientTheme theme, int mouseX, int mouseY) {
        float expY = this.y + this.height - 1.0F;
        float expHeight = this.getExpandedHeight() + 1.0F;
        RenderUtil.drawRoundedRect(context, this.x + 6.0F, expY, this.width - 12.0F, expHeight, 10.0F, theme.moduleButtonExpandedFill());
        RenderUtil.drawText(
            context,
            textRenderer,
            this.feature.hasCustomClickGuiContent() ? "SETTINGS" : "ACTIONS",
            this.x + 10.0F,
            this.y + this.height + 8.0F,
            theme.softGray()
        );
        if (this.feature.hasCustomClickGuiContent()) {
            this.feature.renderCustomClickGuiContent(context, textRenderer, this.x, this.getExpandedContentY(), this.width, mouseX, mouseY);
        } else {
            List<Feature.ClickGuiAction> actions = this.getActions();
            if (actions.isEmpty()) {
                RenderUtil.drawText(context, textRenderer, "No extra controls", this.x + 10.0F, this.getExpandedContentY() + 2.0F, theme.mutedGray());
            } else {
                float actionY = this.getExpandedContentY();
                float innerW = this.width - 10.0F - 10.0F;

                for (int i = 0; i < actions.size(); i++) {
                    Feature.ClickGuiAction action = actions.get(i);
                    float bx = this.x + 10.0F;
                    float by = actionY + (float)i * 26.0F;
                    boolean hovered = (float)mouseX >= bx && (float)mouseX <= bx + innerW && (float)mouseY >= by && (float)mouseY <= by + 20.0F;
                    int fill = action.primary()
                        ? (
                            hovered
                                ? RenderUtil.mixColor(theme.accent(), theme.white(), 0.12F)
                                : RenderUtil.mixColor(theme.accent(), theme.moduleButtonActionHoverFill(), 0.22F)
                        )
                        : (hovered ? theme.moduleButtonActionHoverFill() : theme.moduleButtonActionFill());
                    if (action.primary() && hovered) {
                        fill = RenderUtil.mixColor(theme.accent(), theme.white(), 0.12F);
                    }

                    int labelColor = theme.white();
                    RenderUtil.drawRoundedRect(context, bx, by, innerW, 20.0F, 7.0F, fill);
                    RenderUtil.drawText(context, textRenderer, action.label(), bx + 8.0F, by + 5.0F, labelColor);
                }
            }
        }
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button, NotificationManager notificationManager) {
        if (this.containsBody(mouseX, mouseY)) {
            if (button == 0) {
                if (this.feature.onClickGuiPrimaryClick(notificationManager)) {
                    return true;
                }

                this.feature.toggle();
                DargsClient.getInstance().getFeatureManager().notifyToggle(this.feature);
                notificationManager.push(
                    this.feature.getName() + (this.feature.isEnabled() ? " enabled" : " disabled"),
                    this.feature.isEnabled() ? NotificationManager.Type.SUCCESS : NotificationManager.Type.INFO
                );
                return true;
            }

            if (button == 1) {
                if (this.feature.onClickGuiSecondaryClick(notificationManager)) {
                    return true;
                }

                this.expanded = !this.expanded;
                return true;
            }
        }

        if (this.expanded
            && this.feature.hasCustomClickGuiContent()
            && this.feature.onCustomClickGuiMouseClicked(mouseX, mouseY, button, this.x, this.getExpandedContentY(), this.width, notificationManager)) {
            return true;
        } else {
            if (this.expanded && button == 0) {
                List<Feature.ClickGuiAction> actions = this.getActions();

                for (int i = 0; i < actions.size(); i++) {
                    if (this.containsAction(mouseX, mouseY, i)) {
                        return this.handleAction(actions.get(i), notificationManager);
                    }
                }
            }

            return this.expanded && this.containsExpanded(mouseX, mouseY);
        }
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        return this.expanded
                && this.feature.hasCustomClickGuiContent()
                && this.feature.onCustomClickGuiMouseReleased(mouseX, mouseY, button, this.x, this.getExpandedContentY(), this.width)
            ? true
            : this.containsBody(mouseX, mouseY) || this.expanded && this.containsExpanded(mouseX, mouseY);
    }

    public boolean isExpanded() {
        return this.expanded;
    }

    public boolean isHovered(double mouseX, double mouseY) {
        return this.containsBody(mouseX, mouseY) || this.expanded && this.containsExpanded(mouseX, mouseY);
    }

    private boolean containsBody(double mouseX, double mouseY) {
        return mouseX >= (double)this.x && mouseX <= (double)(this.x + this.width) && mouseY >= (double)this.y && mouseY <= (double)(this.y + this.height);
    }

    private boolean containsExpanded(double mouseX, double mouseY) {
        float expY = this.y + this.height;
        float expHeight = this.getExpandedHeight();
        return mouseX >= (double)this.x && mouseX <= (double)(this.x + this.width) && mouseY >= (double)expY && mouseY <= (double)(expY + expHeight);
    }

    private boolean containsAction(double mouseX, double mouseY, int index) {
        float bx = this.x + 10.0F;
        float by = this.y + this.height + 22.0F + (float)index * 26.0F;
        float bw = this.width - 10.0F - 10.0F;
        return mouseX >= (double)bx && mouseX <= (double)(bx + bw) && mouseY >= (double)by && mouseY <= (double)(by + 20.0F);
    }

    private float getExpandedHeight() {
        if (this.feature.hasCustomClickGuiContent()) {
            return 22.0F + this.feature.getCustomClickGuiHeight(this.width) + 10.0F;
        } else {
            List<Feature.ClickGuiAction> actions = this.getActions();
            return actions.isEmpty() ? 44.0F : 22.0F + (float)actions.size() * 20.0F + (float)Math.max(0, actions.size() - 1) * 6.0F + 10.0F;
        }
    }

    private float getExpandedContentY() {
        return this.y + this.height + 22.0F;
    }

    private List<Feature.ClickGuiAction> getActions() {
        List<Feature.ClickGuiAction> actions = new ArrayList<>();
        boolean capturing = DargsClient.getInstance().getKeybindManager().isCapturing(this.feature);
        actions.add(new Feature.ClickGuiAction(capturing ? "__bind_cancel" : "__bind_set", capturing ? "Cancel Bind" : "Set Bind", true));
        if (!this.feature.getKeybind().isNone()) {
            actions.add(new Feature.ClickGuiAction("__bind_clear", "Clear Bind", false));
        }

        actions.addAll(this.feature.getClickGuiActions());
        return actions;
    }

    private boolean handleAction(Feature.ClickGuiAction action, NotificationManager notificationManager) {
        String var3 = action.id();

        return switch (var3) {
            case "__bind_set" -> {
                DargsClient.getInstance().getKeybindManager().beginCapture(this.feature, notificationManager);
                yield true;
            }
            case "__bind_cancel" -> {
                DargsClient.getInstance().getKeybindManager().cancelCapture(notificationManager);
                yield true;
            }
            case "__bind_clear" -> {
                DargsClient.getInstance().getKeybindManager().clearBind(this.feature, notificationManager);
                yield true;
            }
            default -> this.feature.handleClickGuiAction(action.id(), notificationManager);
        };
    }
}
