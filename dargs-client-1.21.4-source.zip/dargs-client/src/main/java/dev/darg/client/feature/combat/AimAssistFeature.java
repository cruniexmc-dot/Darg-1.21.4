package dev.darg.client.feature.combat;

import dev.darg.client.feature.Category;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public final class AimAssistFeature extends ConfigurableCombatFeature {
    private final ConfigurableCombatFeature.BooleanSetting stickyAim = this.booleanSetting("sticky_aim", "Sticky Aim", false);
    private final ConfigurableCombatFeature.BooleanSetting onlyWeapon = this.booleanSetting("only_weapon", "Only Weapon", true);
    private final ConfigurableCombatFeature.BooleanSetting onLeftClick = this.booleanSetting("on_left_click", "On Left Click", false);
    private final ConfigurableCombatFeature.EnumSetting<AimAssistFeature.AimMode> aimAt = this.enumSetting(
        "aim_at", "Aim At", AimAssistFeature.AimMode.Head, AimAssistFeature.AimMode.class
    );
    private final ConfigurableCombatFeature.BooleanSetting stopAtTargetVertical = this.booleanSetting("stop_at_target_vertical", "Stop At Target Vert", true);
    private final ConfigurableCombatFeature.BooleanSetting stopAtTargetHorizontal = this.booleanSetting(
        "stop_at_target_horizontal", "Stop At Target Horiz", false
    );
    private final ConfigurableCombatFeature.NumberSetting radius = this.floatSetting("radius", "Radius", 5.0, 0.1, 6.0, 0.1, 1);
    private final ConfigurableCombatFeature.BooleanSetting seeOnly = this.booleanSetting("see_only", "Visible Only", true);
    private final ConfigurableCombatFeature.BooleanSetting ignoreNoHP = this.booleanSetting("ignore_no_hp", "Ignore 0 HP", false);
    private final ConfigurableCombatFeature.BooleanSetting lookAtNearest = this.booleanSetting("look_at_nearest", "Look At Nearest", false);
    private final ConfigurableCombatFeature.NumberSetting fov = this.intSetting("fov", "FOV", 180, 5, 360);
    private final ConfigurableCombatFeature.NumberSetting pitchSpeed = this.floatSetting("pitch_speed", "Vertical Speed", 2.0, 0.1, 10.0, 0.1, 1);
    private final ConfigurableCombatFeature.NumberSetting yawSpeed = this.floatSetting("yaw_speed", "Horizontal Speed", 2.0, 0.1, 10.0, 0.1, 1);
    private final ConfigurableCombatFeature.NumberSetting speedChange = this.intSetting("speed_change", "Speed Delay", 250, 0, 1000);
    private final ConfigurableCombatFeature.NumberSetting randomization = this.intSetting("randomization", "Chance", 100, 0, 100);
    private final ConfigurableCombatFeature.BooleanSetting yawAssist = this.booleanSetting("yaw_assist", "Horizontal", true);
    private final ConfigurableCombatFeature.BooleanSetting pitchAssist = this.booleanSetting("pitch_assist", "Vertical", true);
    private final ConfigurableCombatFeature.NumberSetting waitFor = this.intSetting("wait_for", "Wait On Move", 0, 0, 1000);
    private final ConfigurableCombatFeature.EnumSetting<AimAssistFeature.LerpMode> lerp = this.enumSetting(
        "lerp", "Lerp", AimAssistFeature.LerpMode.Normal, AimAssistFeature.LerpMode.class
    );
    private final ConfigurableCombatFeature.EnumSetting<AimAssistFeature.PosMode> posMode = this.enumSetting(
        "pos_mode", "Pos Mode", AimAssistFeature.PosMode.Normal, AimAssistFeature.PosMode.class
    );
    private PlayerEntity stickyTarget;
    private long lastSpeedUpdateMs;
    private long lastAssistMs;
    private float currentYawSpeed = 2.0F;
    private float currentPitchSpeed = 2.0F;

    public AimAssistFeature() {
        super("AimAssist", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        this.stickyTarget = null;
        this.lastSpeedUpdateMs = 0L;
        this.lastAssistMs = 0L;
        this.currentYawSpeed = (float)this.yawSpeed.doubleValue();
        this.currentPitchSpeed = (float)this.pitchSpeed.doubleValue();
    }

    @Override
    protected void onDisable() {
        this.stickyTarget = null;
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.currentScreen != null) {
            this.stickyTarget = null;
        } else if (!this.onlyWeapon.get() || CombatSupport.isHoldingWeapon(player)) {
            if (!this.onLeftClick.get() || GLFW.glfwGetMouseButton(client.getWindow().getHandle(), 0) == 1) {
                long now = System.currentTimeMillis();
                int waitMs = this.waitFor.intValue();
                if (waitMs <= 0 || now - this.lastAssistMs >= (long)waitMs) {
                    if (this.speedChange.intValue() > 0
                        && (now - this.lastSpeedUpdateMs >= (long)this.speedChange.intValue() || this.currentYawSpeed <= 0.0F || this.currentPitchSpeed <= 0.0F)
                        )
                     {
                        this.currentYawSpeed = this.jitterSpeed((float)this.yawSpeed.doubleValue());
                        this.currentPitchSpeed = this.jitterSpeed((float)this.pitchSpeed.doubleValue());
                        this.lastSpeedUpdateMs = now;
                    }

                    PlayerEntity target = this.resolveTarget(player, client);
                    if (target != null) {
                        if (!this.ignoreNoHP.get() || !(target.getHealth() <= 0.0F)) {
                            if (!this.seeOnly.get() || player.canSee(target)) {
                                Vec3d targetPos = this.resolveTargetPos(client, target);
                                if (this.lookAtNearest.get()) {
                                    targetPos = this.adjustNearest(targetPos, player, target);
                                }

                                AimAssistFeature.Rotation rotation = this.toRotation(player.getEyePos(), targetPos);
                                float yawDiff = MathHelper.wrapDegrees(rotation.yaw() - player.getYaw());
                                float pitchDiff = MathHelper.wrapDegrees(rotation.pitch() - player.getPitch());
                                if (!(Math.abs(yawDiff) > (float)this.fov.intValue() / 2.0F)) {
                                    if (ThreadLocalRandom.current().nextInt(100) < this.randomization.intValue()) {
                                        if (this.yawAssist.get() && (!this.stopAtTargetHorizontal.get() || !this.isAlreadyAimedAt(client, target))) {
                                            player.setYaw(this.lerpYaw(player.getYaw(), rotation.yaw(), this.currentYawSpeed));
                                        }

                                        if (this.pitchAssist.get() && (!this.stopAtTargetVertical.get() || !this.isAlreadyAimedAt(client, target))) {
                                            player.setPitch(this.lerpPitch(player.getPitch(), rotation.pitch(), this.currentPitchSpeed));
                                        }

                                        this.lastAssistMs = now;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of(
            "Sticky target: " + this.stickyAim.get(),
            "Range: " + this.formatOne(this.radius.doubleValue()) + " blocks",
            "FOV: " + this.fov.intValue() + " degrees"
        );
    }

    private PlayerEntity resolveTarget(ClientPlayerEntity player, MinecraftClient client) {
        if (this.stickyAim.get()
            && this.stickyTarget != null
            && this.stickyTarget.isAlive()
            && this.stickyTarget.squaredDistanceTo(player) <= this.radius.doubleValue() * this.radius.doubleValue()) {
            return this.stickyTarget;
        } else {
            PlayerEntity target = CombatSupport.findNearestPlayer(player, this.radius.doubleValue(), this.seeOnly.get(), true);
            this.stickyTarget = target;
            return target;
        }
    }

    private Vec3d resolveTargetPos(MinecraftClient client, PlayerEntity target) {
        double tickProgress = (double)client.getRenderTickCounter().getTickProgress(false);
        Vec3d pos = this.posMode.get() == AimAssistFeature.PosMode.Lerped
            ? target.getLerpedPos((float)tickProgress)
            : new Vec3d(target.getX(), target.getY(), target.getZ());

        return switch ((AimAssistFeature.AimMode)this.aimAt.get()) {
            case Head -> pos.add(0.0, (double)target.getStandingEyeHeight() * 0.92, 0.0);
            case Chest -> pos.add(0.0, (double)(-target.getHeight()) * 0.12, 0.0);
            case Legs -> pos.add(0.0, (double)(-target.getHeight()) * 0.56, 0.0);
        };
    }

    private Vec3d adjustNearest(Vec3d targetPos, ClientPlayerEntity player, PlayerEntity target) {
        double offsetX = player.getX() - target.getX() > 0.0 ? 0.29 : -0.29;
        double offsetZ = player.getZ() - target.getZ() > 0.0 ? 0.29 : -0.29;
        return targetPos.add(offsetX, 0.0, offsetZ);
    }

    private boolean isAlreadyAimedAt(MinecraftClient client, PlayerEntity target) {
        if (client.crosshairTarget instanceof EntityHitResult hitResult && hitResult.getEntity() == target) {
            return true;
        }

        return false;
    }

    private float lerpYaw(float start, float end, float speed) {
        return start + MathHelper.wrapDegrees(end - start) * Math.max(0.01F, speed / 50.0F);
    }

    private float lerpPitch(float start, float end, float speed) {
        return start + MathHelper.wrapDegrees(end - start) * Math.max(0.01F, speed / 50.0F);
    }

    private AimAssistFeature.Rotation toRotation(Vec3d source, Vec3d target) {
        Vec3d delta = target.subtract(source);
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float yaw = (float)Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0F;
        float pitch = (float)(-Math.toDegrees(Math.atan2(delta.y, horizontal)));
        return new AimAssistFeature.Rotation(yaw, pitch);
    }

    private float jitterSpeed(float base) {
        float clamped = Math.max(0.1F, base);
        float variance = ThreadLocalRandom.current().nextFloat() * 0.35F + 0.825F;
        return Math.max(0.1F, clamped * variance);
    }

    private boolean isSword(Item item) {
        return item == Items.WOODEN_SWORD
            || item == Items.STONE_SWORD
            || item == Items.IRON_SWORD
            || item == Items.GOLDEN_SWORD
            || item == Items.DIAMOND_SWORD
            || item == Items.NETHERITE_SWORD;
    }

    private String formatOne(double value) {
        return String.format(Locale.ROOT, "%.1f", value);
    }

    public static enum AimMode {
        Head,
        Chest,
        Legs;
    }

    public static enum LerpMode {
        Normal,
        Smoothstep,
        EaseOut;
    }

    public static enum PosMode {
        Normal,
        Lerped;
    }

    private static record Rotation(float yaw, float pitch) {
    }
}
