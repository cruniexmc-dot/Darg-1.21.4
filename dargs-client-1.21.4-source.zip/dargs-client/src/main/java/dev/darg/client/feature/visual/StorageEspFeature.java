package dev.darg.client.feature.visual;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import dev.darg.client.DargsClient;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.mixin.RenderLayerInvoker;
import dev.darg.client.render.WorldRenderUtil;
import dev.darg.client.ui.clickgui.InlineControlRenderer;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnchantingTableBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.TrappedChestBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.OutputTarget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

public final class StorageEspFeature extends Feature {
    private static final float BOX_LINE_WIDTH = 1.3F;
    private static final float TRACER_LINE_WIDTH = 1.0F;
    private static final float TRACER_START_OFFSET = 0.15F;
    private static final float INLINE_HEIGHT = 88.0F;
    private static final int RGB_CHEST = 10246912;
    private static final int RGB_TRAPPED_CHEST = 13130496;
    private static final int RGB_ENDER_CHEST = 7667967;
    private static final int RGB_SPAWNER = 9076390;
    private static final int RGB_SHULKER = 11141307;
    private static final int RGB_FURNACE = 8947848;
    private static final int RGB_BARREL = 16747616;
    private static final int RGB_ENCHANTING = 5263615;
    private static final Object LAYER_LOCK = new Object();
    private static volatile RenderLayer noDepthOutlineLayer;
    private int alpha = 200;
    private boolean tracers = false;
    private boolean donutBypass = false;
    private boolean draggingAlpha = false;

    public StorageEspFeature() {
        super("StorageESP", Category.RENDER);
    }

    public boolean isDonutBypassEnabled() {
        return this.isEnabled() && this.donutBypass;
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of(
            "State: " + (this.isEnabled() ? "Enabled" : "Disabled"),
            "Alpha: " + this.alpha,
            "Tracers: " + (this.tracers ? "On" : "Off"),
            "Donut Bypass: " + (this.donutBypass ? "On" : "Off")
        );
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 88.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        if (this.draggingAlpha) {
            this.setAlphaFromMouse((double)mouseX, x, width);
        }

        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        float contentX = x + 10.0F;
        float contentWidth = width - 20.0F;
        float sliderY = y + 10.0F;
        float tracersY = y + 31.0F;
        float donutY = y + 47.0F;
        float keybindY = y + 63.0F;
        float bindButtonWidth = 70.0F;
        float bindButtonX = x + width - bindButtonWidth - 10.0F;
        boolean hoverTracers = InlineControlRenderer.containsToggle((double)mouseX, (double)mouseY, contentX, tracersY, contentWidth);
        boolean hoverDonut = InlineControlRenderer.containsToggle((double)mouseX, (double)mouseY, contentX, donutY, contentWidth);
        boolean hoverKeybind = InlineControlRenderer.containsButton((double)mouseX, (double)mouseY, bindButtonX, keybindY, bindButtonWidth);
        boolean capturing = DargsClient.getInstance().getKeybindManager().isCapturing(this);
        String bindLabel = InlineControlRenderer.fitText(
            textRenderer, DargsClient.getInstance().getKeybindManager().getBindLabel(this).toUpperCase(Locale.ROOT), 58
        );
        InlineControlRenderer.drawSlider(
            context, textRenderer, theme, "ALPHA", Integer.toString(this.alpha), contentX, sliderY, contentWidth, (float)this.alpha / 255.0F
        );
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "TRACERS", this.tracers, hoverTracers, contentX, tracersY, contentWidth);
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "DONUT BYPASS", this.donutBypass, hoverDonut, contentX, donutY, contentWidth);
        InlineControlRenderer.drawButton(context, textRenderer, theme, bindLabel, capturing, hoverKeybind, bindButtonX, keybindY, bindButtonWidth);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (!this.containsInline(mouseX, mouseY, x, y, width)) {
            return false;
        } else {
            float contentX = x + 10.0F;
            float contentWidth = width - 20.0F;
            if (button == 0 && InlineControlRenderer.containsSlider(mouseX, mouseY, contentX, y + 10.0F, contentWidth)) {
                this.draggingAlpha = true;
                this.setAlphaFromMouse(mouseX, x, width);
                return true;
            } else if (button == 0 && InlineControlRenderer.containsToggle(mouseX, mouseY, contentX, y + 31.0F, contentWidth)) {
                this.tracers = !this.tracers;
                notificationManager.push(
                    "StorageESP tracers " + (this.tracers ? "enabled" : "disabled"),
                    this.tracers ? NotificationManager.Type.SUCCESS : NotificationManager.Type.INFO
                );
                return true;
            } else if (button == 0 && InlineControlRenderer.containsToggle(mouseX, mouseY, contentX, y + 47.0F, contentWidth)) {
                this.donutBypass = !this.donutBypass;
                notificationManager.push(
                    "Donut bypass " + (this.donutBypass ? "enabled" : "disabled"),
                    this.donutBypass ? NotificationManager.Type.SUCCESS : NotificationManager.Type.INFO
                );
                return true;
            } else {
                float bindButtonWidth = 70.0F;
                float bindButtonX = x + width - bindButtonWidth - 10.0F;
                if (button == 0 && InlineControlRenderer.containsButton(mouseX, mouseY, bindButtonX, y + 63.0F, bindButtonWidth)) {
                    if (DargsClient.getInstance().getKeybindManager().isCapturing(this)) {
                        DargsClient.getInstance().getKeybindManager().cancelCapture(notificationManager);
                    } else {
                        DargsClient.getInstance().getKeybindManager().beginCapture(this, notificationManager);
                    }

                    return true;
                } else {
                    return true;
                }
            }
        }
    }

    @Override
    public boolean onCustomClickGuiMouseReleased(double mouseX, double mouseY, int button, float x, float y, float width) {
        if (button == 0 && this.draggingAlpha) {
            this.draggingAlpha = false;
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity player = client.player;
        if (client.world != null && player != null) {
            MatrixStack matrices = context.matrices();
            VertexConsumerProvider consumers = context.consumers();
            OrderedRenderCommandQueue commandQueue = context.commandQueue();
            if (matrices != null && commandQueue != null) {
                Camera camera = client.gameRenderer.getCamera();
                Vec3d cameraPos = camera.getCameraPos();
                float tickProgress = client.getRenderTickCounter().getTickProgress(false);
                Vec3d tracerStart = this.tracers && consumers != null ? WorldRenderUtil.getTracerStart(camera, tickProgress, 0.15F) : null;
                int chunkX = player.getChunkPos().x;
                int chunkZ = player.getChunkPos().z;
                int viewDistance = (Integer)client.options.getViewDistance().getValue();
                Map<Integer, List<float[]>> boxesByColor = new LinkedHashMap<>();
                List<float[]> tracerTargets = this.tracers ? new ArrayList<>() : null;

                for (int cx = chunkX - viewDistance; cx <= chunkX + viewDistance; cx++) {
                    for (int cz = chunkZ - viewDistance; cz <= chunkZ + viewDistance; cz++) {
                        WorldChunk chunk = client.world.getChunk(cx, cz);
                        if (chunk != null && !chunk.isEmpty()) {
                            for (Entry<BlockPos, BlockEntity> blockEntityEntry : chunk.getBlockEntities().entrySet()) {
                                BlockPos blockPos = blockEntityEntry.getKey();
                                BlockEntity blockEntity = blockEntityEntry.getValue();
                                int rgb = getBlockEntityRgb(blockEntity);
                                if (rgb >= 0) {
                                    int boxColor = WorldRenderUtil.argb(this.alpha, rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF);
                                    float minX = (float)((double)blockPos.getX() + 0.05 - cameraPos.x);
                                    float minY = (float)((double)blockPos.getY() + 0.05 - cameraPos.y);
                                    float minZ = (float)((double)blockPos.getZ() + 0.05 - cameraPos.z);
                                    float maxX = (float)((double)blockPos.getX() + 0.95 - cameraPos.x);
                                    float maxY = (float)((double)blockPos.getY() + 0.9 - cameraPos.y);
                                    float maxZ = (float)((double)blockPos.getZ() + 0.95 - cameraPos.z);
                                    boxesByColor.computeIfAbsent(boxColor, k -> new ArrayList<>()).add(new float[]{minX, minY, minZ, maxX, maxY, maxZ});
                                    if (tracerTargets != null) {
                                        int tracerAlpha = Math.min(255, this.alpha + 40);
                                        int tracerColor = WorldRenderUtil.argb(tracerAlpha, rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF);
                                        tracerTargets.add(
                                            new float[]{
                                                (float)((double)blockPos.getX() + 0.5 - cameraPos.x),
                                                (float)((double)blockPos.getY() + 0.5 - cameraPos.y),
                                                (float)((double)blockPos.getZ() + 0.5 - cameraPos.z),
                                                Float.intBitsToFloat(tracerColor)
                                            }
                                        );
                                    }
                                }
                            }
                        }
                    }
                }

                if (!boxesByColor.isEmpty()) {
                    RenderLayer outlineLayer = getNoDepthOutlineLayer();

                    for (Entry<Integer, List<float[]>> entry : boxesByColor.entrySet()) {
                        int color = entry.getKey();
                        List<float[]> boxes = entry.getValue();
                        commandQueue.submitCustom(matrices, outlineLayer, (matEntry, consumer) -> {
                            for (float[] box : boxes) {
                                WorldRenderUtil.drawWireBox(matEntry, consumer, box[0], box[1], box[2], box[3], box[4], box[5], color, 1.3F);
                            }
                        });
                    }

                    if (tracerStart != null && tracerTargets != null && !tracerTargets.isEmpty() && consumers != null) {
                        matrices.push();

                        try {
                            net.minecraft.client.util.math.MatrixStack.Entry entry = matrices.peek();
                            VertexConsumer lineBuffer = consumers.getBuffer(RenderLayers.linesTranslucent());

                            for (float[] t : tracerTargets) {
                                Vec3d center = new Vec3d((double)t[0], (double)t[1], (double)t[2]);
                                int tracerColor = Float.floatToRawIntBits(t[3]);
                                WorldRenderUtil.drawLine(entry, lineBuffer, tracerStart, center, tracerColor, 1.0F);
                            }
                        } finally {
                            matrices.pop();
                        }
                    }
                }
            }
        }
    }

    private static int getBlockEntityRgb(BlockEntity blockEntity) {
        if (blockEntity instanceof TrappedChestBlockEntity) {
            return 13130496;
        } else if (blockEntity instanceof ChestBlockEntity) {
            return 10246912;
        } else if (blockEntity instanceof EnderChestBlockEntity) {
            return 7667967;
        } else if (blockEntity instanceof MobSpawnerBlockEntity) {
            return 9076390;
        } else if (blockEntity instanceof ShulkerBoxBlockEntity) {
            return 11141307;
        } else if (blockEntity instanceof AbstractFurnaceBlockEntity) {
            return 8947848;
        } else if (blockEntity instanceof BarrelBlockEntity) {
            return 16747616;
        } else {
            return blockEntity instanceof EnchantingTableBlockEntity ? 5263615 : -1;
        }
    }

    private static RenderLayer getNoDepthOutlineLayer() {
        RenderLayer layer = noDepthOutlineLayer;
        if (layer != null) {
            return layer;
        } else {
            synchronized (LAYER_LOCK) {
                if (noDepthOutlineLayer == null) {
                    RenderPipeline pipeline = RenderPipelines.register(
                        RenderPipeline.builder(new Snippet[]{RenderPipelines.RENDERTYPE_LINES_SNIPPET})
                            .withLocation("pipeline/dargsclient_storage_esp_outline_no_depth")
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .build()
                    );
                    noDepthOutlineLayer = RenderLayerInvoker.dargsclient$invokeOf(
                        "dargs_storage_esp_outline_no_depth",
                        RenderSetup.builder(pipeline).layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING).outputTarget(OutputTarget.ITEM_ENTITY_TARGET).build()
                    );
                }

                return noDepthOutlineLayer;
            }
        }
    }

    private void setAlphaFromMouse(double mouseX, float x, float width) {
        float sliderStart = x + 10.0F;
        float sliderWidth = width - 20.0F;
        float ratio = Math.max(0.0F, Math.min(1.0F, (float)((mouseX - (double)sliderStart) / (double)sliderWidth)));
        this.alpha = Math.round(ratio * 255.0F);
    }

    private boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + 88.0F);
    }
}
