package dev.darg.client.feature.crystal;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.combat.CombatSupport;
import dev.darg.client.feature.combat.ConfigurableCombatFeature;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public final class AutoDoubleHandFeature extends ConfigurableCombatFeature {
    private static final float CRYSTAL_POWER = 6.0F;
    private static final float ANCHOR_POWER = 5.0F;
    private static final int MIN_RADIUS = 2;
    private static final int MAX_RADIUS = 12;
    private final ConfigurableCombatFeature.BooleanSetting stopOnCrystal = this.booleanSetting("stop_on_crystal", "Stop On Crystal", false);
    private final ConfigurableCombatFeature.BooleanSetting checkShield = this.booleanSetting("check_shield", "Check Shield", false);
    private final ConfigurableCombatFeature.BooleanSetting onPop = this.booleanSetting("on_pop", "On Pop", false);
    private final ConfigurableCombatFeature.BooleanSetting onHealth = this.booleanSetting("on_health", "On Health", false);
    private final ConfigurableCombatFeature.BooleanSetting predict = this.booleanSetting("predict_damage", "Predict Damage", true);
    private final ConfigurableCombatFeature.NumberSetting health = this.intSetting("health", "Health", 2, 1, 20);
    private final ConfigurableCombatFeature.BooleanSetting onGround = this.booleanSetting("on_ground", "On Ground", true);
    private final ConfigurableCombatFeature.BooleanSetting checkPlayers = this.booleanSetting("check_players", "Check Players", true);
    private final ConfigurableCombatFeature.NumberSetting distance = this.floatSetting("distance", "Distance", 5.0, 1.0, 10.0, 0.1, 1);
    private final ConfigurableCombatFeature.BooleanSetting predictCrystals = this.booleanSetting("predict_crystals", "Predict Crystals", false);
    private final ConfigurableCombatFeature.BooleanSetting checkAim = this.booleanSetting("check_aim", "Check Aim", false);
    private final ConfigurableCombatFeature.BooleanSetting checkItems = this.booleanSetting("check_items", "Check Items", false);
    private final ConfigurableCombatFeature.NumberSetting activatesAbove = this.floatSetting("activates_above", "Activates Above", 0.2, 0.0, 4.0, 0.1, 1);
    private boolean belowHealth;
    private boolean offhandHasNoTotem;

    public AutoDoubleHandFeature() {
        super("AutoDoubleHand", Category.CRYSTAL);
    }

    @Override
    protected void onEnable() {
        this.belowHealth = false;
        this.offhandHasNoTotem = false;
    }

    @Override
    protected void onDisable() {
        this.belowHealth = false;
        this.offhandHasNoTotem = false;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player != null && mc.world != null) {
            if (player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                this.belowHealth = false;
                this.offhandHasNoTotem = false;
            } else {
                if (this.stopOnCrystal.get()) {
                    AutoCrystalFeature autoCrystal = DargsClient.getInstance().getFeatureManager().getFeature(AutoCrystalFeature.class);
                    if (autoCrystal != null && autoCrystal.isEnabled() && autoCrystal.crystalling) {
                        return;
                    }
                }

                if (!this.checkShield.get() || !player.isBlocking()) {
                    double squaredDistance = this.distance.doubleValue() * this.distance.doubleValue();
                    float threshold = this.health.floatValue();
                    float buffer = player.getHealth() + player.getAbsorptionAmount();
                    if (this.onPop.get() && !this.offhandHasNoTotem && this.equipTotem(mc, player)) {
                        this.offhandHasNoTotem = true;
                    } else {
                        if (player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                            this.offhandHasNoTotem = false;
                        }

                        if (this.onHealth.get() && player.getHealth() <= threshold && !this.belowHealth && this.equipTotem(mc, player)) {
                            this.belowHealth = true;
                        } else {
                            if (player.getHealth() > threshold) {
                                this.belowHealth = false;
                            }

                            if (this.predict.get()) {
                                if (!(player.getHealth() > 19.0F)) {
                                    if (this.onGround.get() || !player.isOnGround()) {
                                        if (!this.checkPlayers.get()
                                            || !mc.world
                                                .getPlayers()
                                                .stream()
                                                .filter(other -> other != player)
                                                .noneMatch(other -> player.squaredDistanceTo(other) <= squaredDistance)) {
                                            double above = this.activatesAbove.doubleValue();
                                            int floor = MathHelper.floor(above);

                                            for (int i = 1; i <= floor; i++) {
                                                if (!mc.world.getBlockState(player.getBlockPos().add(0, -i, 0)).isAir()) {
                                                    return;
                                                }
                                            }

                                            Vec3d playerPos = new Vec3d(player.getX(), player.getY(), player.getZ());
                                            BlockPos anchorBase = new BlockPos(
                                                (int)playerPos.x, (int)playerPos.y - (int)above, (int)playerPos.z
                                            );
                                            if (mc.world.getBlockState(anchorBase).isAir()) {
                                                Box searchBox = new Box(
                                                    playerPos.add(
                                                        -this.distance.doubleValue(), -this.distance.doubleValue(), -this.distance.doubleValue()
                                                    ),
                                                    playerPos.add(this.distance.doubleValue(), this.distance.doubleValue(), this.distance.doubleValue())
                                                );

                                                for (EndCrystalEntity crystal : mc.world.getEntitiesByClass(EndCrystalEntity.class, searchBox, entity -> true)) {
                                                    float damage = this.estimateDamage(player, crystal.getEyePos(), 12.0F);
                                                    if (damage >= buffer) {
                                                        this.equipTotem(mc, player);
                                                        return;
                                                    }
                                                }

                                                for (int dx = -6; dx <= 6; dx++) {
                                                    for (int dy = -8; dy <= 2; dy++) {
                                                        for (int dz = -6; dz <= 6; dz++) {
                                                            BlockPos pos = player.getBlockPos().add(dx, dy, dz);
                                                            if (CombatSupport.isCrystalBase(mc.world.getBlockState(pos))
                                                                && CrystalUtils.canPlaceCrystalAssumeBase(pos, mc.world)
                                                                && (
                                                                    !this.predictCrystals.get()
                                                                        || !this.checkAim.get()
                                                                        || this.isAnyoneAimingAtBlock(mc, pos, this.checkItems.get())
                                                                )) {
                                                                Vec3d explosionPos = Vec3d.ofBottomCenter(pos).add(0.0, 1.0, 0.0);
                                                                float damage = this.estimateDamage(player, explosionPos, 6.0F);
                                                                if (damage >= buffer) {
                                                                    this.equipTotem(mc, player);
                                                                    return;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }

                                                for (int dx = -6; dx <= 6; dx++) {
                                                    for (int dy = -8; dy <= 2; dy++) {
                                                        for (int dzx = -6; dzx <= 6; dzx++) {
                                                            BlockPos pos = player.getBlockPos().add(dx, dy, dzx);
                                                            BlockState state = mc.world.getBlockState(pos);
                                                            if (state.isOf(Blocks.RESPAWN_ANCHOR)
                                                                && (Integer)state.get(RespawnAnchorBlock.CHARGES) != 0) {
                                                                Vec3d explosionPos = Vec3d.ofCenter(pos);
                                                                float damage = this.estimateDamage(player, explosionPos, 10.0F);
                                                                if (damage >= buffer) {
                                                                    this.equipTotem(mc, player);
                                                                    return;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private boolean equipTotem(MinecraftClient mc, ClientPlayerEntity player) {
        int previous = player.getInventory().getSelectedSlot();

        for (int slot = 0; slot < 9; slot++) {
            if (player.getInventory().getStack(slot).isOf(Items.TOTEM_OF_UNDYING)) {
                if (previous != slot) {
                    player.getInventory().setSelectedSlot(slot);
                    player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
                }

                CombatSupport.swapWithOffhand(player);
                if (player.getInventory().getSelectedSlot() != previous) {
                    player.getInventory().setSelectedSlot(previous);
                    player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(previous));
                }

                return true;
            }
        }

        return false;
    }

    private float estimateDamage(ClientPlayerEntity player, Vec3d explosionPos, float radius) {
        Vec3d centre = new Vec3d(player.getX(), player.getY() + (double)player.getHeight() / 2.0, player.getZ());
        double dist = explosionPos.distanceTo(centre);
        if (dist >= (double)radius) {
            return 0.0F;
        } else {
            double impact = 1.0 - dist / (double)radius;
            float raw = (float)((impact * impact + impact) / 2.0 * 7.0 * (double)radius + 1.0);
            float armor = (float)player.getArmor();
            float toughness = (float)player.getAttributeValue(EntityAttributes.ARMOR_TOUGHNESS);
            float f = 2.0F + toughness / 4.0F;
            float absorbed = MathHelper.clamp(armor - raw / f, armor / 5.0F, 20.0F);
            return Math.max(0.0F, raw * (1.0F - absorbed / 25.0F));
        }
    }

    private boolean isAnyoneAimingAtBlock(MinecraftClient mc, BlockPos blockPos, boolean requireCrystal) {
        return mc.world != null && mc.player != null
            ? mc.world
                .getPlayers()
                .stream()
                .filter(player -> player != mc.player)
                .filter(player -> !requireCrystal || player.isHolding(Items.END_CRYSTAL))
                .anyMatch(player -> {
                    Vec3d eyes = player.getEyePos();
                    Vec3d look = player.getRotationVec(1.0F);
                    Vec3d reach = eyes.add(look.multiply(4.5));
                    BlockHitResult hit = mc.world.raycast(new RaycastContext(eyes, reach, ShapeType.COLLIDER, FluidHandling.NONE, player));
                    return hit != null && hit.getBlockPos().equals(blockPos);
                })
            : false;
    }
}
