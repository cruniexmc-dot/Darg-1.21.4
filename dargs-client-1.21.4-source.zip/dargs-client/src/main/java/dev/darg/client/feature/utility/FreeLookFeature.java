package dev.darg.client.feature.utility;

import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public final class FreeLookFeature extends Feature {
    private float cameraYaw;
    private float cameraPitch;
    private boolean initialized;
    private Perspective savedPerspective;

    public FreeLookFeature() {
        super("FreeLook", Category.UTILITY);
    }

    @Override
    protected void onEnable() {
        this.initialized = false;
        MinecraftClient client = MinecraftClient.getInstance();
        this.savedPerspective = client.options.getPerspective();
        if (this.savedPerspective != Perspective.THIRD_PERSON_BACK) {
            client.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        }
    }

    @Override
    protected void onDisable() {
        this.initialized = false;
        MinecraftClient client = MinecraftClient.getInstance();
        if (this.savedPerspective != null) {
            client.options.setPerspective(this.savedPerspective);
            this.savedPerspective = null;
        }
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            this.setEnabled(false);
        }
    }

    public void applyMouseLook(Entity entity, float tickProgress, double deltaX, double deltaY) {
        this.ensureInitialized(entity, tickProgress);
        this.cameraPitch = MathHelper.clamp(this.cameraPitch + (float)(deltaY * 0.15F), -90.0F, 90.0F);
        this.cameraYaw = MathHelper.wrapDegrees(this.cameraYaw + (float)(deltaX * 0.15F));
    }

    public float getCameraYaw(Entity entity, float tickProgress) {
        this.ensureInitialized(entity, tickProgress);
        return this.cameraYaw;
    }

    public float getCameraPitch(Entity entity, float tickProgress) {
        this.ensureInitialized(entity, tickProgress);
        return this.cameraPitch;
    }

    public boolean shouldOverrideCamera(Entity entity) {
        MinecraftClient client = MinecraftClient.getInstance();
        return this.isEnabled() && entity != null && client.player != null && entity == client.player;
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("State: " + (this.isEnabled() ? "Enabled" : "Disabled"), "Camera: Detached from player head", "Movement: Uses real player rotation");
    }

    private void ensureInitialized(Entity entity, float tickProgress) {
        if (!this.initialized && entity != null) {
            this.cameraYaw = entity.getYaw(tickProgress);
            this.cameraPitch = entity.getPitch(tickProgress);
            this.initialized = true;
        }
    }
}
