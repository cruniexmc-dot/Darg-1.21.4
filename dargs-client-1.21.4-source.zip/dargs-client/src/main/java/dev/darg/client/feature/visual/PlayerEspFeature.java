package dev.darg.client.feature.visual;

import dev.darg.client.DargsClient;
import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.render.WorldRenderUtil;
import dev.darg.client.ui.clickgui.InlineControlRenderer;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.List;
import java.util.Locale;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class PlayerEspFeature extends Feature {
    private static final double RANGE = 256.0;
    private static final float BOX_LINE_WIDTH = 1.5F;
    private static final float TRACER_LINE_WIDTH = 1.5F;
    private static final float TRACER_START_OFFSET = 0.15F;
    private static final float INLINE_HEIGHT = 46.0F;
    private static final int BOX_COLOR = -922791856;
    private static final int TRACER_COLOR = -1258294565;
    private boolean tracers = ClientConfig.getInstance().isPlayerEspTracersEnabled();
    private int lastVisibleTargets;

    public PlayerEspFeature() {
        super("PlayerESP", Category.RENDER);
    }

    public boolean hasTracersEnabled() {
        return this.isEnabled() && this.tracers;
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 46.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        float contentX = x + 10.0F;
        float contentWidth = width - 20.0F;
        float toggleY = y + 8.0F;
        float keybindY = y + 24.0F;
        boolean hoverToggle = InlineControlRenderer.containsToggle((double)mouseX, (double)mouseY, contentX, toggleY, contentWidth);
        boolean capturing = DargsClient.getInstance().getKeybindManager().isCapturing(this);
        float bindButtonWidth = 70.0F;
        float bindButtonX = x + width - bindButtonWidth - 10.0F;
        boolean hoverKeybind = InlineControlRenderer.containsButton((double)mouseX, (double)mouseY, bindButtonX, keybindY, bindButtonWidth);
        String bindLabel = InlineControlRenderer.fitText(
            textRenderer, DargsClient.getInstance().getKeybindManager().getBindLabel(this).toUpperCase(Locale.ROOT), 58
        );
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "TRACERS", this.tracers, hoverToggle, contentX, toggleY, contentWidth);
        InlineControlRenderer.drawButton(context, textRenderer, theme, bindLabel, capturing, hoverKeybind, bindButtonX, keybindY, bindButtonWidth);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (!this.containsInline(mouseX, mouseY, x, y, width)) {
            return false;
        } else if (button == 0 && this.containsTracersToggle(mouseX, mouseY, x, y, width)) {
            this.tracers = !this.tracers;
            ClientConfig config = ClientConfig.getInstance();
            config.setPlayerEspTracersEnabled(this.tracers);
            config.save();
            notificationManager.push(
                "PlayerESP tracers " + (this.tracers ? "enabled" : "disabled"), this.tracers ? NotificationManager.Type.SUCCESS : NotificationManager.Type.INFO
            );
            return true;
        } else if (button == 0 && this.containsKeybindButton(mouseX, mouseY, x, y, width)) {
            if (DargsClient.getInstance().getKeybindManager().isCapturing(this)) {
                DargsClient.getInstance().getKeybindManager().cancelCapture(notificationManager);
            } else {
                DargsClient.getInstance().getKeybindManager().beginCapture(this, notificationManager);
            }

            return true;
        } else {
            return true;
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of(
            "State: " + (this.isEnabled() ? "Enabled" : "Disabled"),
            "Range: 256 blocks",
            "Tracers: " + (this.tracers ? "On" : "Off"),
            "Visible: " + this.lastVisibleTargets,
            "Style: Box outline"
        );
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity player = client.player;
        if (client.world != null && player != null) {
            MatrixStack matrices = context.matrices();
            VertexConsumerProvider consumers = context.consumers();
            if (matrices != null && consumers != null) {
                float tickProgress = client.getRenderTickCounter().getTickProgress(false);
                Vec3d cameraPos = client.gameRenderer.getCamera().getCameraPos();
                Vec3d tracerStart = this.tracers ? WorldRenderUtil.getTracerStart(client.gameRenderer.getCamera(), tickProgress, 0.15F) : null;
                int visibleTargets = 0;
                matrices.push();

                try {
                    Entry entry = matrices.peek();
                    VertexConsumer lineBuffer = consumers.getBuffer(RenderLayers.linesTranslucent());

                    for (PlayerEntity target : client.world.getPlayers()) {
                        if (target != player && target.isAlive() && !target.isSpectator() && !(player.squaredDistanceTo(target) > 65536.0)) {
                            Vec3d lerpedPos = target.getLerpedPos(tickProgress);
                            double halfWidth = (double)target.getWidth() / 2.0;
                            double height = (double)target.getHeight();
                            float minX = (float)(lerpedPos.x - halfWidth - cameraPos.x);
                            float minY = (float)(lerpedPos.y - cameraPos.y);
                            float minZ = (float)(lerpedPos.z - halfWidth - cameraPos.z);
                            float maxX = (float)(lerpedPos.x + halfWidth - cameraPos.x);
                            float maxY = (float)(lerpedPos.y + height - cameraPos.y);
                            float maxZ = (float)(lerpedPos.z + halfWidth - cameraPos.z);
                            WorldRenderUtil.drawWireBox(entry, lineBuffer, minX, minY, minZ, maxX, maxY, maxZ, -922791856, 1.5F);
                            if (tracerStart != null) {
                                Vec3d targetCenter = lerpedPos.add(0.0, (double)target.getStandingEyeHeight() * 0.9, 0.0).subtract(cameraPos);
                                WorldRenderUtil.drawLine(entry, lineBuffer, tracerStart, targetCenter, -1258294565, 1.5F);
                            }

                            visibleTargets++;
                        }
                    }
                } finally {
                    matrices.pop();
                }

                this.lastVisibleTargets = visibleTargets;
            }
        }
    }

    private boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + 46.0F);
    }

    private boolean containsTracersToggle(double mouseX, double mouseY, float x, float y, float width) {
        return InlineControlRenderer.containsToggle(mouseX, mouseY, x + 10.0F, y + 8.0F, width - 20.0F);
    }

    private boolean containsKeybindButton(double mouseX, double mouseY, float x, float y, float width) {
        float bindButtonWidth = 70.0F;
        float bindButtonX = x + width - bindButtonWidth - 10.0F;
        return InlineControlRenderer.containsButton(mouseX, mouseY, bindButtonX, y + 24.0F, bindButtonWidth);
    }
}
