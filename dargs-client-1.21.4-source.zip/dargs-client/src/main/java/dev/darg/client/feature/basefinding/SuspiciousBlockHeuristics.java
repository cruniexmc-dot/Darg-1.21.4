package dev.darg.client.feature.basefinding;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.Direction.Axis;

public final class SuspiciousBlockHeuristics {
    private SuspiciousBlockHeuristics() {
    }

    public static boolean isRotatedDeepslate(BlockState state) {
        return state != null && state.isOf(Blocks.DEEPSLATE) && state.contains(Properties.AXIS)
            ? state.get(Properties.AXIS) != Axis.Y
            : false;
    }

    public static boolean isKelp(BlockState state) {
        return state != null && (state.isOf(Blocks.KELP) || state.isOf(Blocks.KELP_PLANT));
    }

    public static boolean isCaveVine(BlockState state) {
        return state == null
            ? false
            : state.isOf(Blocks.CAVE_VINES) && state.contains(Properties.BERRIES) && (Boolean)state.get(Properties.BERRIES);
    }

    public static boolean isVine(BlockState state) {
        return state != null && state.isOf(Blocks.VINE);
    }

    public static boolean isAmethystGrowth(BlockState state) {
        return state == null ? false : state.getBlock() == Blocks.AMETHYST_CLUSTER;
    }

    public static boolean isBeehive(BlockState state) {
        return state != null && state.isOf(Blocks.BEEHIVE);
    }
}
