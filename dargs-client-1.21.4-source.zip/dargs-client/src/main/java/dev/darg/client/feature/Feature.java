package dev.darg.client.feature;

import dev.darg.client.input.FeatureBind;
import dev.darg.client.ui.clickgui.NotificationManager;
import java.util.List;
import java.util.Locale;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;

public abstract class Feature {
    private final String name;
    private final Category category;
    private FeatureBind keybind = FeatureBind.none();
    private boolean enabled;

    protected Feature(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    public final String getName() {
        return this.name;
    }

    public final Category getCategory() {
        return this.category;
    }

    public String getConfigKey() {
        StringBuilder key = new StringBuilder();
        String lower = this.name.toLowerCase(Locale.ROOT);

        for (int index = 0; index < lower.length(); index++) {
            char character = lower.charAt(index);
            if ((character < 'a' || character > 'z') && (character < '0' || character > '9')) {
                if (!key.isEmpty() && key.charAt(key.length() - 1) != '_') {
                    key.append('_');
                }
            } else {
                key.append(character);
            }
        }

        if (!key.isEmpty() && key.charAt(key.length() - 1) == '_') {
            key.setLength(key.length() - 1);
        }

        return key.isEmpty() ? "feature" : key.toString();
    }

    public final boolean isEnabled() {
        return this.enabled;
    }

    public final FeatureBind getKeybind() {
        return this.keybind;
    }

    public final void setKeybind(FeatureBind keybind) {
        this.keybind = keybind == null ? FeatureBind.none() : keybind;
    }

    public boolean isVisibleInClickGui() {
        return true;
    }

    public boolean shouldPersistEnabledState() {
        return this.isVisibleInClickGui();
    }

    public List<String> getClickGuiDetails() {
        return List.of("State: " + (this.enabled ? "Enabled" : "Disabled"), "Category: " + this.category.displayName());
    }

    public String getHudSuffix() {
        return null;
    }

    public List<Feature.ClickGuiAction> getClickGuiActions() {
        return List.of();
    }

    public boolean handleClickGuiAction(String actionId, NotificationManager notificationManager) {
        return false;
    }

    public boolean onClickGuiPrimaryClick(NotificationManager notificationManager) {
        return false;
    }

    public boolean onClickGuiSecondaryClick(NotificationManager notificationManager) {
        return false;
    }

    public boolean hasCustomClickGuiContent() {
        return false;
    }

    public float getCustomClickGuiHeight(float width) {
        return 0.0F;
    }

    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
    }

    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        return false;
    }

    public boolean onCustomClickGuiMouseReleased(double mouseX, double mouseY, int button, float x, float y, float width) {
        return false;
    }

    public boolean isClickGuiInteractionActive() {
        return false;
    }

    public final void toggle() {
        this.setEnabled(!this.enabled);
    }

    public final void setEnabled(boolean enabled) {
        if (this.enabled != enabled) {
            this.enabled = enabled;
            if (enabled) {
                this.onEnable();
            } else {
                this.onDisable();
            }
        }
    }

    protected void onEnable() {
    }

    protected void onDisable() {
    }

    public void onTick() {
    }

    public void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
    }

    public void onWorldRender(WorldRenderContext context) {
    }

    public void onMouseMove(double deltaX, double deltaY) {
    }

    public void onAttackEntity(Entity entity) {
    }

    public void onClickGuiRender(DrawContext context, int mouseX, int mouseY, float delta) {
    }

    public boolean onClickGuiMouseClicked(double mouseX, double mouseY, int button) {
        return false;
    }

    public boolean onClickGuiMouseReleased(double mouseX, double mouseY, int button) {
        return false;
    }

    public boolean onClickGuiMouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        return false;
    }

    public boolean onClickGuiKeyPressed(KeyInput keyInput) {
        return false;
    }

    public boolean onClickGuiCharTyped(CharInput charInput) {
        return false;
    }

    public static record ClickGuiAction(String id, String label, boolean primary) {
    }
}
