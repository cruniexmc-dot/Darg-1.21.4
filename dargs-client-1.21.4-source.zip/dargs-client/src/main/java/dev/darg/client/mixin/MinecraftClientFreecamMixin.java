package dev.darg.client.mixin;

import dev.darg.client.feature.utility.FreecamController;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.HitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({MinecraftClient.class})
public abstract class MinecraftClientFreecamMixin {
    @Shadow
    public ClientPlayerEntity player;
    @Shadow
    public HitResult crosshairTarget;
    @Shadow
    public Entity targetedEntity;
    @Unique
    private HitResult dargsclient$storedCrosshairTarget;
    @Unique
    private Entity dargsclient$storedTargetedEntity;
    @Unique
    private int dargsclient$actionSwapDepth;

    @Shadow
    public abstract RenderTickCounter getRenderTickCounter();

    @Inject(
        method = {"getCameraEntity"},
        at = {@At("HEAD")},
        cancellable = true
    )
    private void dargsclient$freecamCameraEntity(CallbackInfoReturnable<Entity> cir) {
        FreecamController controller = FreecamController.getInstance();
        if (controller.usesCameraActionSource()) {
            OtherClientPlayerEntity raycast = controller.getRaycastEntity();
            if (raycast != null) {
                cir.setReturnValue(raycast);
            }
        }
    }

    @Inject(
        method = {"doAttack"},
        at = {@At("HEAD")}
    )
    private void dargsclient$swapAttackSource(CallbackInfoReturnable<Boolean> callbackInfo) {
        this.dargsclient$beginPlayerActionSwap();
    }

    @Inject(
        method = {"doAttack"},
        at = {@At("RETURN")}
    )
    private void dargsclient$restoreAttackSource(CallbackInfoReturnable<Boolean> callbackInfo) {
        this.dargsclient$endPlayerActionSwap();
    }

    @Inject(
        method = {"doItemUse"},
        at = {@At("HEAD")}
    )
    private void dargsclient$swapUseSource(CallbackInfo callbackInfo) {
        this.dargsclient$beginPlayerActionSwap();
    }

    @Inject(
        method = {"doItemUse"},
        at = {@At("RETURN")}
    )
    private void dargsclient$restoreUseSource(CallbackInfo callbackInfo) {
        this.dargsclient$endPlayerActionSwap();
    }

    @Inject(
        method = {"handleBlockBreaking"},
        at = {@At("HEAD")}
    )
    private void dargsclient$swapMiningSource(boolean breaking, CallbackInfo callbackInfo) {
        this.dargsclient$beginPlayerActionSwap();
    }

    @Inject(
        method = {"handleBlockBreaking"},
        at = {@At("RETURN")}
    )
    private void dargsclient$restoreMiningSource(boolean breaking, CallbackInfo callbackInfo) {
        this.dargsclient$endPlayerActionSwap();
    }

    @Unique
    private void dargsclient$beginPlayerActionSwap() {
        FreecamController controller = FreecamController.getInstance();
        if (controller.usesPlayerActionSource() && this.player != null) {
            if (this.dargsclient$actionSwapDepth++ <= 0) {
                this.dargsclient$storedCrosshairTarget = this.crosshairTarget;
                this.dargsclient$storedTargetedEntity = this.targetedEntity;
                float tickProgress = this.getRenderTickCounter().getTickProgress(true);
                HitResult playerTarget = controller.getPlayerActionTarget(tickProgress);
                this.crosshairTarget = playerTarget;
                this.targetedEntity = controller.getPlayerActionEntity(tickProgress);
            }
        }
    }

    @Unique
    private void dargsclient$endPlayerActionSwap() {
        if (this.dargsclient$actionSwapDepth > 0) {
            this.dargsclient$actionSwapDepth--;
            if (this.dargsclient$actionSwapDepth <= 0) {
                this.crosshairTarget = this.dargsclient$storedCrosshairTarget;
                this.targetedEntity = this.dargsclient$storedTargetedEntity;
                this.dargsclient$storedCrosshairTarget = null;
                this.dargsclient$storedTargetedEntity = null;
            }
        }
    }
}
