package dev.darg.client.feature.combat;

import dev.darg.client.feature.Category;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult.Type;

public final class NoMissDelayFeature extends ConfigurableCombatFeature implements CombatFeatureHooks.AttackHook, CombatFeatureHooks.BlockBreakingHook {
    private final ConfigurableCombatFeature.BooleanSetting onlyWeapon = this.booleanSetting("only_weapon", "Only weapon", true);
    private final ConfigurableCombatFeature.BooleanSetting air = this.booleanSetting("air", "Air", true);
    private final ConfigurableCombatFeature.BooleanSetting blocks = this.booleanSetting("blocks", "Blocks", false);

    public NoMissDelayFeature() {
        super("NoMissDelay", Category.COMBAT);
    }

    @Override
    public boolean onBeforeAttack(MinecraftClient client) {
        if (client.player == null || client.crosshairTarget == null) {
            return false;
        } else if (this.onlyWeapon.get() && !this.isWeapon(client.player.getMainHandStack().getItem())) {
            return false;
        } else {
            return switch (client.crosshairTarget.getType()) {
                case MISS -> this.air.get();
                case BLOCK -> this.blocks.get();
                default -> false;
            };
        }
    }

    @Override
    public boolean onBeforeBlockBreaking(MinecraftClient client, boolean breaking) {
        if (!breaking || client.player == null || client.crosshairTarget == null) {
            return false;
        } else {
            return this.onlyWeapon.get() && !this.isWeapon(client.player.getMainHandStack().getItem())
                ? false
                : client.crosshairTarget.getType() == Type.BLOCK && this.blocks.get();
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("Air: " + this.air.get(), "Blocks: " + this.blocks.get(), "Weapon only: " + this.onlyWeapon.get());
    }

    private boolean isWeapon(Item item) {
        return item == Items.WOODEN_SWORD
            || item == Items.STONE_SWORD
            || item == Items.IRON_SWORD
            || item == Items.GOLDEN_SWORD
            || item == Items.DIAMOND_SWORD
            || item == Items.NETHERITE_SWORD
            || item == Items.WOODEN_AXE
            || item == Items.STONE_AXE
            || item == Items.IRON_AXE
            || item == Items.GOLDEN_AXE
            || item == Items.DIAMOND_AXE
            || item == Items.NETHERITE_AXE;
    }
}
