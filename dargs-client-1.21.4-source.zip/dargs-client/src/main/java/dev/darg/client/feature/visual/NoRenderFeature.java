package dev.darg.client.feature.visual;

import dev.darg.client.config.ClientConfig;
import dev.darg.client.config.FeatureSettingParse;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.clickgui.InlineControlRenderer;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.decoration.painting.PaintingEntity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.GuardianEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.util.math.BlockPos;

public final class NoRenderFeature extends Feature {
    private static final float ROW_STEP = 14.0F;
    private static final int TOGGLE_ROWS = 17;
    private static final float SLIDER_BLOCK_H = 24.0F;
    private static final float PADDING_TOP = 8.0F;
    private static final float PADDING_BOTTOM = 10.0F;
    private static final int MAX_ENTITY_RANGE = 512;
    private static final int MAX_BLOCK_RANGE = 256;
    private static final int MIN_BLOCK_RANGE = 8;
    private static final String[] SETTING_KEYS = new String[]{
        "hide_rain",
        "hide_snow",
        "hide_thunder",
        "hide_fog",
        "hide_fire",
        "hide_water",
        "hide_lava",
        "hide_armor_stands",
        "hide_item_frames",
        "hide_paintings",
        "hide_enderman",
        "hide_guardian",
        "hide_slime",
        "hide_dropped_items",
        "hide_hurt_cam",
        "hide_totem_anim",
        "hide_hand_swing"
    };
    private static final String[] LABELS = new String[]{
        "HIDE RAIN",
        "HIDE SNOW",
        "HIDE THUNDER",
        "HIDE FOG",
        "HIDE FIRE",
        "HIDE WATER",
        "HIDE LAVA",
        "HIDE ARMOR STANDS",
        "HIDE ITEM FRAMES",
        "HIDE PAINTINGS",
        "HIDE ENDERMEN",
        "HIDE GUARDIANS",
        "HIDE SLIMES",
        "HIDE ITEM DROPS",
        "HIDE HURT CAM",
        "HIDE TOTEM POP",
        "HIDE HAND SWING"
    };
    private static final boolean[] DEFAULT_TOGGLES = new boolean[]{
        true, true, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false
    };
    private final ClientConfig config = ClientConfig.getInstance();
    private final boolean[] toggles = new boolean[17];
    private int entityCullDistance = 64;
    private int blockEffectDistance = 128;
    private int draggingSlider = -1;
    private boolean hideRain;
    private boolean hideSnow;
    private boolean hideThunder;
    private boolean hideFog;
    private boolean hideFire;
    private boolean hideWater;
    private boolean hideLava;
    private boolean hideArmorStands;
    private boolean hideItemFrames;
    private boolean hidePaintings;
    private boolean hideEnderman;
    private boolean hideGuardian;
    private boolean hideSlime;
    private boolean hideDroppedItems;
    private boolean hideHurtCam;
    private boolean hideTotemAnimation;
    private boolean hideHandSwing;

    public NoRenderFeature() {
        super("NoRender", Category.RENDER);
        this.reloadFromConfig();
    }

    private void reloadFromConfig() {
        String fk = this.getConfigKey();

        for (int i = 0; i < 17; i++) {
            this.toggles[i] = FeatureSettingParse.parseBool(this.config.getFeatureSetting(fk, SETTING_KEYS[i]), DEFAULT_TOGGLES[i]);
        }

        this.entityCullDistance = FeatureSettingParse.parseInt(this.config.getFeatureSetting(fk, "entity_range"), 64, 0, 512);
        this.blockEffectDistance = FeatureSettingParse.parseInt(this.config.getFeatureSetting(fk, "block_range"), 128, 8, 256);
        this.syncFieldsFromToggles();
    }

    private void syncFieldsFromToggles() {
        this.hideRain = this.toggles[0];
        this.hideSnow = this.toggles[1];
        this.hideThunder = this.toggles[2];
        this.hideFog = this.toggles[3];
        this.hideFire = this.toggles[4];
        this.hideWater = this.toggles[5];
        this.hideLava = this.toggles[6];
        this.hideArmorStands = this.toggles[7];
        this.hideItemFrames = this.toggles[8];
        this.hidePaintings = this.toggles[9];
        this.hideEnderman = this.toggles[10];
        this.hideGuardian = this.toggles[11];
        this.hideSlime = this.toggles[12];
        this.hideDroppedItems = this.toggles[13];
        this.hideHurtCam = this.toggles[14];
        this.hideTotemAnimation = this.toggles[15];
        this.hideHandSwing = this.toggles[16];
    }

    private void persistToggle(int index) {
        this.config.setFeatureSetting(this.getConfigKey(), SETTING_KEYS[index], this.toggles[index] ? "true" : "false");
        this.syncFieldsFromToggles();
        this.config.save();
    }

    private void persistEntityRange() {
        this.config.setFeatureSetting(this.getConfigKey(), "entity_range", Integer.toString(this.entityCullDistance));
        this.config.save();
    }

    private void persistBlockRange() {
        this.config.setFeatureSetting(this.getConfigKey(), "block_range", Integer.toString(this.blockEffectDistance));
        this.config.save();
    }

    private float togglesBottom(float y) {
        return y + 8.0F + 238.0F;
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 304.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        float cx = x + 10.0F;
        float cw = width - 20.0F;
        if (this.draggingSlider == 0) {
            this.setEntityRangeFromMouse((double)mouseX, cx, cw);
        } else if (this.draggingSlider == 1) {
            this.setBlockRangeFromMouse((double)mouseX, cx, cw);
        }

        for (int i = 0; i < 17; i++) {
            float ty = y + 8.0F + (float)i * 14.0F;
            boolean hover = InlineControlRenderer.containsToggle((double)mouseX, (double)mouseY, cx, ty, cw);
            InlineControlRenderer.drawToggle(context, textRenderer, theme, LABELS[i], this.toggles[i], hover, cx, ty, cw);
        }

        float s1y = this.togglesBottom(y);
        float erRatio = this.entityCullDistance <= 0 ? 0.0F : (float)this.entityCullDistance / 512.0F;
        String erLabel = this.entityCullDistance <= 0 ? "OFF" : this.entityCullDistance + "m";
        InlineControlRenderer.drawSlider(context, textRenderer, theme, "ENTITY CULL RANGE", erLabel, cx, s1y, cw, erRatio);
        float s2y = s1y + 24.0F;
        float brRatio = (float)(this.blockEffectDistance - 8) / 248.0F;
        InlineControlRenderer.drawSlider(context, textRenderer, theme, "BLOCK FX RANGE", this.blockEffectDistance + "m", cx, s2y, cw, brRatio);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (!this.containsInline(mouseX, mouseY, x, y, width)) {
            return false;
        } else {
            float cx = x + 10.0F;
            float cw = width - 20.0F;
            if (button == 0) {
                for (int i = 0; i < 17; i++) {
                    float ty = y + 8.0F + (float)i * 14.0F;
                    if (InlineControlRenderer.containsToggle(mouseX, mouseY, cx, ty, cw)) {
                        this.toggles[i] = !this.toggles[i];
                        this.persistToggle(i);
                        return true;
                    }
                }

                float s1y = this.togglesBottom(y);
                if (containsSliderBand(mouseX, mouseY, cx, s1y, cw)) {
                    this.draggingSlider = 0;
                    this.setEntityRangeFromMouse(mouseX, cx, cw);
                    return true;
                }

                float s2y = s1y + 24.0F;
                if (containsSliderBand(mouseX, mouseY, cx, s2y, cw)) {
                    this.draggingSlider = 1;
                    this.setBlockRangeFromMouse(mouseX, cx, cw);
                    return true;
                }
            }

            return true;
        }
    }

    @Override
    public boolean onCustomClickGuiMouseReleased(double mouseX, double mouseY, int button, float x, float y, float width) {
        if (this.draggingSlider == 0) {
            this.draggingSlider = -1;
            this.persistEntityRange();
            return true;
        } else if (this.draggingSlider == 1) {
            this.draggingSlider = -1;
            this.persistBlockRange();
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isClickGuiInteractionActive() {
        return this.draggingSlider >= 0;
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world != null) {
            if (this.hideRain || this.hideSnow) {
                client.world.setRainGradient(0.0F);
            }

            if (this.hideThunder) {
                client.world.setThunderGradient(0.0F);
            }
        }
    }

    @Override
    protected void onDisable() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world != null) {
            client.world.setRainGradient(1.0F);
            client.world.setThunderGradient(1.0F);
        }
    }

    public boolean shouldRenderRain() {
        return !this.hideRain;
    }

    public boolean shouldRenderSnow() {
        return !this.hideSnow;
    }

    public boolean shouldRenderThunder() {
        return !this.hideThunder;
    }

    public boolean shouldRenderFog() {
        return !this.hideFog;
    }

    public boolean shouldRenderHurtCam() {
        return !this.hideHurtCam;
    }

    public boolean shouldRenderTotemAnimation() {
        return !this.hideTotemAnimation;
    }

    public boolean shouldRenderSwing() {
        return !this.hideHandSwing;
    }

    public boolean shouldRenderEntity(Entity entity) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (entity == null || client.player == null) {
            return true;
        } else if (entity == client.player) {
            return true;
        } else if (this.entityCullDistance > 0 && client.player.distanceTo(entity) > (float)this.entityCullDistance) {
            return false;
        } else if (this.hideDroppedItems && entity instanceof ItemEntity) {
            return false;
        } else if (this.hideArmorStands && entity instanceof ArmorStandEntity) {
            return false;
        } else if (this.hideItemFrames && entity instanceof ItemFrameEntity) {
            return false;
        } else if (this.hidePaintings && entity instanceof PaintingEntity) {
            return false;
        } else if (this.hideEnderman && entity instanceof EndermanEntity) {
            return false;
        } else {
            return this.hideGuardian && entity instanceof GuardianEntity ? false : !this.hideSlime || !(entity instanceof SlimeEntity);
        }
    }

    public boolean shouldRenderBlock(BlockState state, BlockPos pos) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (state != null && client.player != null) {
            if (client.player.getBlockPos().getSquaredDistance(pos) > (double)this.blockEffectDistance * (double)this.blockEffectDistance) {
                return false;
            } else if (this.hideWater && state.getBlock() == Blocks.WATER) {
                return false;
            } else {
                return this.hideLava && state.getBlock() == Blocks.LAVA ? false : !this.hideFire || state.getBlock() != Blocks.FIRE;
            }
        } else {
            return true;
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of(
            "Entity cull: " + (this.entityCullDistance <= 0 ? "off" : this.entityCullDistance + "m"),
            "Block FX range: " + this.blockEffectDistance + "m",
            "Toggles: expand panel below"
        );
    }

    private boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        float h = this.getCustomClickGuiHeight(width);
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + h);
    }

    private static boolean containsSliderBand(double mouseX, double mouseY, float cx, float sliderTopY, float cw) {
        float trackY = sliderTopY + 14.0F;
        return mouseX >= (double)cx && mouseX <= (double)(cx + cw) && mouseY >= (double)(trackY - 5.0F) && mouseY <= (double)(trackY + 12.0F);
    }

    private void setEntityRangeFromMouse(double mouseX, float cx, float cw) {
        float ratio = Math.max(0.0F, Math.min(1.0F, (float)((mouseX - (double)cx) / (double)cw)));
        if (ratio < 0.02F) {
            this.entityCullDistance = 0;
        } else {
            this.entityCullDistance = Math.max(1, Math.round(ratio * 512.0F));
        }
    }

    private void setBlockRangeFromMouse(double mouseX, float cx, float cw) {
        float ratio = Math.max(0.0F, Math.min(1.0F, (float)((mouseX - (double)cx) / (double)cw)));
        this.blockEffectDistance = Math.round(8.0F + ratio * 248.0F);
    }
}
