package dev.darg.client.ui.clickgui;

import dev.darg.client.DargsClient;
import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.util.Window;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;

public final class ClickGuiScreen extends Screen {
    private static final float PANEL_WIDTH = 208.0F;
    private static final float PANEL_SPACING = 12.0F;
    private static final float PANEL_TOP = 92.0F;
    private static final float MENU_SIDE_PADDING = 18.0F;
    private static final float MENU_BOTTOM_PADDING = 14.0F;
    private static final float REFERENCE_WINDOW_WIDTH = 1920.0F;
    private static final float REFERENCE_WINDOW_HEIGHT = 1080.0F;
    private static final float BASE_MENU_PIXEL_SCALE = 1.9F;
    private static final float MIN_MENU_PIXEL_SCALE = 1.2F;
    private static final float MAX_MENU_PIXEL_SCALE = 2.1F;
    private static final float MENU_PRESENTATION_SCALE = 0.92F;
    private static final float OPEN_ANIMATION_MS = 180.0F;
    private final ClientConfig config = ClientConfig.getInstance();
    private final List<CategoryPanel> panels = new ArrayList<>();
    private final NotificationManager notificationManager = new NotificationManager();
    private float menuScale = 1.0F;
    private float menuSpaceWidth = 0.0F;
    private float menuSpaceHeight = 0.0F;
    private float panelTop = 92.0F;
    private boolean panelPositionsInitialized = false;
    private CategoryPanel draggingPanel;
    private float panelDragOffsetX;
    private float panelDragOffsetY;
    private boolean panelMoveDragFreezingFit;
    private float panelMoveDragFrozenContentWidth;
    private CategoryPanel resizingPanel;
    private float resizeStartMouseX;
    private float resizeStartWidth;
    private long openTimestamp = -1L;
    private final ClickGuiSearchBar clickGuiSearch = new ClickGuiSearchBar();
    private Feature searchHighlightedFeature;

    public ClickGuiScreen() {
        super(Text.literal("Darg's Client"));
    }

    protected void init() {
        this.buildPanels();
        this.updateMenuMetrics();
        this.initializePanelPositions();
        this.layoutPanels();
        this.openTimestamp = System.currentTimeMillis();
        this.clickGuiSearch.clear();
        this.searchHighlightedFeature = null;
    }

    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        long elapsed = this.openTimestamp >= 0L ? System.currentTimeMillis() - this.openTimestamp : 180L;
        float t = Math.min(1.0F, (float)elapsed / 180.0F);
        float eased = t * t * (3.0F - 2.0F * t);
        int targetAlpha = theme.clickGuiBackdrop() >> 24 & 0xFF;
        int backdropAlpha = Math.round(eased * (float)targetAlpha);
        int backdropRgb = theme.clickGuiBackdrop() & 16777215;
        int backdropAlphaBottom = Math.min(255, Math.round((float)backdropAlpha * 1.2F));
        context.fillGradient(0, 0, this.width, this.height, backdropAlpha << 24 | backdropRgb, backdropAlphaBottom << 24 | backdropRgb);
        this.updateMenuMetrics();
        int panelMouseX = this.toMenuSpace((double)mouseX);
        int panelMouseY = this.toMenuSpace((double)mouseY);
        if (this.draggingPanel != null) {
            this.updateDraggedPanel((double)panelMouseX, (double)panelMouseY);
        }

        if (this.resizingPanel != null) {
            float resizeDelta = (float)panelMouseX - this.resizeStartMouseX;
            this.resizingPanel.setWidth(this.resizeStartWidth + resizeDelta);
        }

        this.layoutPanels();

        for (CategoryPanel panel : this.panels) {
            for (ModuleButton module : panel.getModules()) {
                module.setSearchHighlighted(module.getFeature() == this.searchHighlightedFeature);
            }
        }

        context.getMatrices().pushMatrix();
        context.getMatrices().scale(this.menuScale, this.menuScale);
        this.renderHudOverlay(context, theme);

        for (CategoryPanel panel : this.panels) {
            if (panel.intersects(0.0F, 0.0F, this.menuSpaceWidth, this.menuSpaceHeight)) {
                panel.render(context, this.textRenderer, theme, panelMouseX, panelMouseY);
            }
        }

        context.getMatrices().popMatrix();
        this.clickGuiSearch.render(context, this.textRenderer, theme, this.width, mouseX, mouseY);
        DargsClient.getInstance().getFeatureManager().renderClickGuiOverlay(context, mouseX, mouseY, delta);
        this.notificationManager.render(context, this.textRenderer, this.width, this.height);
    }

    public boolean mouseClicked(Click click, boolean doubleClick) {
        this.updateMenuMetrics();
        this.layoutPanels();
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();
        if (DargsClient.getInstance().getFeatureManager().clickGuiMouseClicked(mouseX, mouseY, button)) {
            return true;
        } else if (DargsClient.getInstance().getKeybindManager().handleCaptureMouse(button, this.notificationManager)) {
            return true;
        } else {
            if (this.clickGuiSearch.containsPoint(mouseX, mouseY, this.width)) {
                if (this.clickGuiSearch.mouseClicked(mouseX, mouseY, button, this.width, this::searchToggleFeature, this::searchLocateFeature)) {
                    return true;
                }
            } else {
                this.clickGuiSearch.onClickOutside();
                this.searchHighlightedFeature = null;
            }

            double panelMouseX = (double)this.toMenuSpace(mouseX);
            double panelMouseY = (double)this.toMenuSpace(mouseY);
            if (button == 0) {
                for (int index = this.panels.size() - 1; index >= 0; index--) {
                    CategoryPanel panel = this.panels.get(index);
                    if (panel.containsResizeHandle(panelMouseX, panelMouseY) && !panel.containsExpandButton(panelMouseX, panelMouseY)) {
                        this.resizingPanel = panel;
                        this.resizeStartMouseX = (float)panelMouseX;
                        this.resizeStartWidth = panel.width;
                        return true;
                    }

                    if (panel.containsExpandButton(panelMouseX, panelMouseY)) {
                        panel.toggleExpanded();
                        this.layoutPanels();
                        return true;
                    }

                    if (panel.containsHeader(panelMouseX, panelMouseY)) {
                        this.beginPanelDrag(panel, panelMouseX, panelMouseY);
                        return true;
                    }
                }
            }

            if (button == 1) {
                for (int index = this.panels.size() - 1; index >= 0; index--) {
                    CategoryPanel panelx = this.panels.get(index);
                    if (panelx.containsHeader(panelMouseX, panelMouseY)) {
                        panelx.toggleExpanded();
                        this.layoutPanels();
                        return true;
                    }
                }
            }

            for (int indexx = this.panels.size() - 1; indexx >= 0; indexx--) {
                CategoryPanel panelx = this.panels.get(indexx);
                if (panelx.mouseClicked(panelMouseX, panelMouseY, button, this.notificationManager)) {
                    return true;
                }
            }

            return super.mouseClicked(click, doubleClick);
        }
    }

    public boolean mouseReleased(Click click) {
        this.updateMenuMetrics();
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();
        if (DargsClient.getInstance().getFeatureManager().clickGuiMouseReleased(mouseX, mouseY, button)) {
            return true;
        } else if (this.resizingPanel != null && button == 0) {
            this.config.setClickGuiPanelPosition(this.resizingPanel.getKey(), this.resizingPanel.x, this.resizingPanel.y, this.resizingPanel.width);
            this.config.save();
            this.resizingPanel = null;
            return true;
        } else if (this.draggingPanel != null && button == 0) {
            this.finishPanelDrag();
            return true;
        } else {
            double panelMouseX = (double)this.toMenuSpace(mouseX);
            double panelMouseY = (double)this.toMenuSpace(mouseY);

            for (int index = this.panels.size() - 1; index >= 0; index--) {
                CategoryPanel panel = this.panels.get(index);
                if (panel.mouseReleased(panelMouseX, panelMouseY, button)) {
                    return true;
                }
            }

            return super.mouseReleased(click);
        }
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (DargsClient.getInstance().getFeatureManager().clickGuiMouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount)) {
            return true;
        } else {
            return this.clickGuiSearch.mouseScrolled(mouseX, mouseY, verticalAmount, this.width)
                ? true
                : super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
        }
    }

    public boolean keyPressed(KeyInput keyInput) {
        boolean hasActiveInteraction = DargsClient.getInstance().getFeatureManager().hasActiveClickGuiInteraction() || this.clickGuiSearch.isFocused();
        if (DargsClient.getInstance().getFeatureManager().clickGuiKeyPressed(keyInput)) {
            return true;
        } else if (DargsClient.getInstance().getKeybindManager().handleCaptureKey(keyInput, this.notificationManager)) {
            return true;
        } else if (this.clickGuiSearch.keyPressed(keyInput.key(), this.width, this::searchToggleFeature, this::searchLocateFeature)) {
            return true;
        } else if (keyInput.key() == 256) {
            if (this.clickGuiSearch.hasQuery()) {
                this.clickGuiSearch.clear();
                this.searchHighlightedFeature = null;
                return true;
            } else {
                this.close();
                return true;
            }
        } else if (this.client == null || !this.client.options.inventoryKey.matchesKey(keyInput)) {
            return super.keyPressed(keyInput);
        } else if (hasActiveInteraction) {
            return true;
        } else {
            this.close();
            return true;
        }
    }

    public boolean charTyped(CharInput charInput) {
        if (DargsClient.getInstance().getFeatureManager().clickGuiCharTyped(charInput)) {
            return true;
        } else if (!this.clickGuiSearch.isFocused()) {
            return super.charTyped(charInput);
        } else {
            if (charInput.isValidChar()) {
                String s = charInput.asString();

                for (int i = 0; i < s.length(); i++) {
                    this.clickGuiSearch.charTyped(s.charAt(i));
                }
            }

            return true;
        }
    }

    public boolean shouldPause() {
        return false;
    }

    public void close() {
        MinecraftClient minecraftClient = MinecraftClient.getInstance();
        DargsClient.getInstance().getKeybindManager().cancelCapture();
        if (this.draggingPanel != null) {
            this.finishPanelDrag();
        }

        this.clickGuiSearch.clear();
        this.searchHighlightedFeature = null;
        minecraftClient.setScreen(null);
    }

    private void renderHudOverlay(DrawContext context, ClientTheme theme) {
        float x = 16.0F;
        float y = 16.0F;
        float height = 50.0F;
        float width = 246.0F;
        float artSize = 28.0F;
        String subtitle = this.panels.size() + " categories · " + this.getVisibleModuleCount() + " modules";
        String chip = "CTRL+F";
        float chipWidth = Math.max(44.0F, (float)RenderUtil.getTextWidth(this.textRenderer, chip) + 14.0F);
        RenderUtil.drawRoundedRect(context, x + 2.0F, y + 3.0F, width, height, 13.0F, theme.clickGuiHudShadow());
        RenderUtil.drawRoundedRect(context, x, y, width, height, 13.0F, theme.clickGuiHudPanel());
        RenderUtil.drawRoundedRect(context, x + 8.0F, y + 10.0F, artSize, artSize, 8.0F, theme.moduleButtonFill());
        RenderUtil.drawRoundedRect(context, x + 14.0F, y + 18.0F, 12.0F, 12.0F, 6.0F, theme.accent());
        RenderUtil.drawText(context, this.textRenderer, "Darg's Client", x + 48.0F, y + 10.0F, theme.white());
        RenderUtil.drawText(context, this.textRenderer, subtitle, x + 48.0F, y + 23.0F, theme.softGray());
        RenderUtil.drawRoundedRect(context, x + width - chipWidth - 10.0F, y + 10.0F, chipWidth, 16.0F, 8.0F, theme.moduleButtonFill());
        RenderUtil.drawText(
            context,
            this.textRenderer,
            chip,
            x + width - chipWidth - 10.0F + (chipWidth - (float)RenderUtil.getTextWidth(this.textRenderer, chip)) * 0.5F,
            y + 15.0F,
            theme.softGray()
        );
        RenderUtil.drawRoundedRect(context, x + 48.0F, y + 38.0F, width - 60.0F, 3.0F, 2.0F, RenderUtil.withAlpha(theme.white(), 18));
        RenderUtil.drawRoundedRect(context, x + 48.0F, y + 38.0F, Math.min(width - 60.0F, 108.0F), 3.0F, 2.0F, theme.accent());
    }

    private void layoutPanels() {
        for (CategoryPanel panel : this.panels) {
            panel.layout();
            this.clampPanelToView(panel);
            panel.layout();
        }
    }

    private void updateMenuMetrics() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) {
            this.menuScale = 1.0F;
            this.menuSpaceWidth = (float)this.width;
            this.menuSpaceHeight = (float)this.height;
        } else {
            Window window = client.getWindow();
            float resolutionScale = Math.min((float)window.getWidth() / 1920.0F, (float)window.getHeight() / 1080.0F);
            float targetPixelScale = clamp(1.9F * resolutionScale, 1.2F, 2.1F);
            this.menuScale = targetPixelScale / Math.max(1.0F, (float)window.getScaleFactor());
            float contentWidth = this.panelMoveDragFreezingFit
                ? this.panelMoveDragFrozenContentWidth
                : (this.panelPositionsInitialized ? this.getOccupiedPanelWidth() : this.getTotalPanelWidth());
            float fitScaleX = (float)this.width / Math.max(1.0F, contentWidth + 36.0F);
            float requiredHeight = this.getTallestPanelHeight() + 18.0F + 14.0F;
            float fitScaleY = (float)this.height / Math.max(1.0F, requiredHeight);
            this.menuScale = Math.max(0.001F, Math.min(this.menuScale, Math.min(fitScaleX, fitScaleY)) * 0.92F);
            this.menuSpaceWidth = (float)this.width / this.menuScale;
            this.menuSpaceHeight = (float)this.height / this.menuScale;
            this.panelTop = this.computeDefaultPanelTop();
        }
    }

    private int toMenuSpace(double value) {
        return Math.round((float)value / Math.max(0.001F, this.menuScale));
    }

    float getMenuSpaceWidth() {
        return this.menuSpaceWidth;
    }

    float getMenuSpaceHeight() {
        return this.menuSpaceHeight;
    }

    float getPanelTop() {
        return this.panelTop;
    }

    private float getTotalPanelWidth() {
        return this.panels.isEmpty() ? 0.0F : (float)this.panels.size() * 208.0F + (float)(this.panels.size() - 1) * 12.0F;
    }

    private float getOccupiedPanelWidth() {
        if (this.panels.isEmpty()) {
            return 0.0F;
        } else {
            float minX = Float.MAX_VALUE;
            float maxX = -Float.MAX_VALUE;

            for (CategoryPanel panel : this.panels) {
                minX = Math.min(minX, panel.x);
                maxX = Math.max(maxX, panel.x + panel.width);
            }

            return Math.max(0.0F, maxX - minX);
        }
    }

    private float getTallestPanelHeight() {
        float tallest = 0.0F;

        for (CategoryPanel panel : this.panels) {
            panel.layout();
            tallest = Math.max(tallest, panel.height);
        }

        return tallest;
    }

    private float computeDefaultPanelTop() {
        return Math.max(18.0F, Math.min(92.0F, this.menuSpaceHeight - this.getTallestPanelHeight() - 14.0F));
    }

    private void initializePanelPositions() {
        float totalWidth = this.getTotalPanelWidth();
        float startX = Math.max(18.0F, (this.menuSpaceWidth - totalWidth) * 0.5F);
        float currentX = startX;
        float defaultTop = this.computeDefaultPanelTop();
        int freshIndex = 0;

        for (CategoryPanel panel : this.panels) {
            ClientConfig.PanelPosition savedPosition = this.config.getClickGuiPanelPosition(panel.getKey());
            if (savedPosition != null) {
                panel.setPosition(savedPosition.x(), savedPosition.y());
                if (savedPosition.width() > 0.0F) {
                    panel.setWidth(savedPosition.width());
                }
            } else {
                float staggerY = defaultTop + Math.min(44.0F, (float)freshIndex * 11.0F);
                panel.setPosition(currentX, staggerY);
                currentX += 220.0F;
                freshIndex++;
            }

            panel.layout();
        }

        this.panelPositionsInitialized = true;
    }

    private void clampPanelToView(CategoryPanel panel) {
        float minX = 18.0F;
        float maxX = Math.max(minX, this.menuSpaceWidth - panel.width - 18.0F);
        float minY = 18.0F;
        float maxY = Math.max(minY, this.menuSpaceHeight - panel.height - 14.0F);
        float clampedX = clamp(panel.x, minX, maxX);
        float clampedY = clamp(panel.y, minY, maxY);
        if (clampedX != panel.x || clampedY != panel.y) {
            panel.setPosition(clampedX, clampedY);
        }
    }

    private void beginPanelDrag(CategoryPanel panel, double mouseX, double mouseY) {
        this.bringPanelToFront(panel);
        this.draggingPanel = panel;
        this.panelDragOffsetX = (float)mouseX - panel.x;
        this.panelDragOffsetY = (float)mouseY - panel.y;
        this.panelMoveDragFreezingFit = true;
        this.panelMoveDragFrozenContentWidth = this.panelPositionsInitialized ? this.getOccupiedPanelWidth() : this.getTotalPanelWidth();
    }

    private void updateDraggedPanel(double mouseX, double mouseY) {
        if (this.draggingPanel != null) {
            this.draggingPanel.setPosition((float)mouseX - this.panelDragOffsetX, (float)mouseY - this.panelDragOffsetY);
            this.draggingPanel.layout();
            this.clampPanelToView(this.draggingPanel);
        }
    }

    private void finishPanelDrag() {
        if (this.draggingPanel != null) {
            this.config.setClickGuiPanelPosition(this.draggingPanel.getKey(), this.draggingPanel.x, this.draggingPanel.y, this.draggingPanel.width);
            this.config.save();
            this.draggingPanel = null;
            this.panelMoveDragFreezingFit = false;
        }
    }

    private void bringPanelToFront(CategoryPanel panel) {
        if (this.panels.remove(panel)) {
            this.panels.add(panel);
        }
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private void searchToggleFeature(Feature feature) {
        if (!feature.onClickGuiPrimaryClick(this.notificationManager)) {
            feature.toggle();
            DargsClient.getInstance().getFeatureManager().notifyToggle(feature);
            this.notificationManager
                .push(
                    feature.getName() + (feature.isEnabled() ? " enabled" : " disabled"),
                    feature.isEnabled() ? NotificationManager.Type.SUCCESS : NotificationManager.Type.INFO
                );
        }
    }

    private void searchLocateFeature(Feature feature) {
        this.searchHighlightedFeature = feature;

        for (CategoryPanel panel : this.panels) {
            for (ModuleButton module : panel.getModules()) {
                if (module.getFeature() == feature) {
                    this.bringPanelToFront(panel);
                    panel.setExpanded(true);
                    module.setExpanded(true);
                    this.layoutPanels();
                    return;
                }
            }
        }
    }

    private void buildPanels() {
        this.panels.clear();
        this.panels.add(this.createPanel("COMBAT", Category.COMBAT, new ItemStack(Items.DIAMOND_SWORD), "More coming soon!"));
        this.panels.add(this.createPanel("CRYSTAL", Category.CRYSTAL, new ItemStack(Items.END_CRYSTAL)));
        this.panels.add(this.createPanel("UTILITY", Category.UTILITY, new ItemStack(Items.REDSTONE)));
        this.panels.add(this.createPanel("BASEFINDING", Category.BASEFINDING, new ItemStack(Items.RECOVERY_COMPASS)));
        this.panels.add(this.createPanel("RENDER", Category.RENDER, new ItemStack(Items.SPYGLASS)));
        this.panels.add(this.createPanel("SETTINGS", Category.SETTINGS, new ItemStack(Items.COMPARATOR)));
    }

    private CategoryPanel createPanel(String title, Category category, ItemStack icon) {
        return this.createPanel(title, category, icon, "No features");
    }

    private CategoryPanel createPanel(String title, Category category, ItemStack icon, String emptyMessage) {
        CategoryPanel panel = new CategoryPanel(category.name().toLowerCase(Locale.ROOT), title, icon, 0.0F, 0.0F, 208.0F, emptyMessage);

        for (Feature feature : DargsClient.getInstance().getFeatureManager().getFeatures()) {
            if (feature.isVisibleInClickGui() && feature.getCategory() == category) {
                panel.addModule(new ModuleButton(feature));
            }
        }

        return panel;
    }

    private int getVisibleModuleCount() {
        int count = 0;

        for (CategoryPanel panel : this.panels) {
            count += panel.getModules().size();
        }

        return count;
    }
}
