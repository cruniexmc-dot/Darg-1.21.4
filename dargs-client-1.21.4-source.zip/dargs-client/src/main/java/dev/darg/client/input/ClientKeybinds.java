package dev.darg.client.input;

import dev.darg.client.DargsClient;
import dev.darg.client.ui.clickgui.ClickGuiScreen;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.KeyBinding.Category;
import net.minecraft.client.util.InputUtil.Type;
import net.minecraft.util.Identifier;

public final class ClientKeybinds {
    private static final Category DARGS_CATEGORY = Category.create(Identifier.of("dargsclient", "general"));
    private static final KeyBinding OPEN_CLICK_GUI = KeyBindingHelper.registerKeyBinding(
        new KeyBinding("key.dargsclient.open_click_gui", Type.KEYSYM, 344, DARGS_CATEGORY)
    );

    private ClientKeybinds() {
    }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(ClientKeybinds::handleClientTick);
    }

    private static void handleClientTick(MinecraftClient client) {
        while (OPEN_CLICK_GUI.wasPressed()) {
            if (client.player != null && !(client.currentScreen instanceof ClickGuiScreen)) {
                client.setScreen(DargsClient.getInstance().getUiManager().createClickGuiScreen());
            }
        }

        DargsClient dargsClient = DargsClient.getInstance();
        if (dargsClient != null) {
            dargsClient.getKeybindManager().handleClientTick(client, dargsClient.getFeatureManager());
        }
    }
}
