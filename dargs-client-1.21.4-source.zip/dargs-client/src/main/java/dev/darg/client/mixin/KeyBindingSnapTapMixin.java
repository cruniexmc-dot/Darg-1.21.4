package dev.darg.client.mixin;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.utility.SnapTapFeature;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil.Key;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({KeyBinding.class})
public abstract class KeyBindingSnapTapMixin {
    @Shadow
    @Final
    private Key defaultKey;
    @Shadow
    private boolean pressed;

    @Inject(
        method = {"isPressed"},
        at = {@At("HEAD")},
        cancellable = true
    )
    private void dargsclient$snapTapPressed(CallbackInfoReturnable<Boolean> cir) {
        DargsClient client = DargsClient.getInstance();
        if (client != null) {
            SnapTapFeature snapTap = client.getFeatureManager().getFeature(SnapTapFeature.class);
            if (snapTap != null && snapTap.isEnabled()) {
                int code = this.defaultKey.getCode();
                if (code == 65) {
                    if (this.pressed) {
                        if (SnapTapFeature.rightStrafeLastPressTime == 0L) {
                            cir.setReturnValue(true);
                            cir.cancel();
                            return;
                        }

                        cir.setReturnValue(SnapTapFeature.rightStrafeLastPressTime <= SnapTapFeature.leftStrafeLastPressTime);
                        cir.cancel();
                    }
                } else if (code == 68) {
                    if (this.pressed) {
                        if (SnapTapFeature.leftStrafeLastPressTime == 0L) {
                            cir.setReturnValue(true);
                            cir.cancel();
                            return;
                        }

                        cir.setReturnValue(SnapTapFeature.leftStrafeLastPressTime <= SnapTapFeature.rightStrafeLastPressTime);
                        cir.cancel();
                    }
                } else if (code == 87) {
                    if (this.pressed) {
                        if (SnapTapFeature.backwardStrafeLastPressTime == 0L) {
                            cir.setReturnValue(true);
                            cir.cancel();
                            return;
                        }

                        cir.setReturnValue(SnapTapFeature.backwardStrafeLastPressTime <= SnapTapFeature.forwardStrafeLastPressTime);
                        cir.cancel();
                    }
                } else if (code == 83 && this.pressed) {
                    if (SnapTapFeature.forwardStrafeLastPressTime == 0L) {
                        cir.setReturnValue(true);
                        cir.cancel();
                        return;
                    }

                    cir.setReturnValue(SnapTapFeature.forwardStrafeLastPressTime <= SnapTapFeature.backwardStrafeLastPressTime);
                    cir.cancel();
                }
            }
        }
    }

    @Inject(
        method = {"setPressed"},
        at = {@At("HEAD")}
    )
    private void dargsclient$snapTapSetPressed(boolean pressed, CallbackInfo ci) {
        DargsClient client = DargsClient.getInstance();
        if (client != null) {
            SnapTapFeature snapTap = client.getFeatureManager().getFeature(SnapTapFeature.class);
            if (snapTap != null && snapTap.isEnabled()) {
                int code = this.defaultKey.getCode();
                long now = System.currentTimeMillis();
                if (code == 65) {
                    SnapTapFeature.leftStrafeLastPressTime = pressed ? now : 0L;
                } else if (code == 68) {
                    SnapTapFeature.rightStrafeLastPressTime = pressed ? now : 0L;
                } else if (code == 87) {
                    SnapTapFeature.forwardStrafeLastPressTime = pressed ? now : 0L;
                } else if (code == 83) {
                    SnapTapFeature.backwardStrafeLastPressTime = pressed ? now : 0L;
                }
            }
        }
    }
}
