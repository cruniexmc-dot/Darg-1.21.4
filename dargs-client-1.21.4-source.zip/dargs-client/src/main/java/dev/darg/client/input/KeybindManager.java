package dev.darg.client.input;

import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.Feature;
import dev.darg.client.feature.FeatureManager;
import dev.darg.client.ui.clickgui.NotificationManager;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.KeyInput;

public final class KeybindManager {
    private final ClientConfig config = ClientConfig.getInstance();
    private final Map<String, Boolean> pressedStates = new HashMap<>();
    private Feature capturedFeature;

    public void initialize(FeatureManager featureManager) {
        for (Feature feature : featureManager.getFeatures()) {
            String saved = this.config.getFeatureBind(configKey(feature));
            if (!saved.isBlank()) {
                feature.setKeybind(FeatureBind.parse(saved));
            }
        }
    }

    public void handleClientTick(MinecraftClient client, FeatureManager featureManager) {
        if (client.player == null) {
            this.pressedStates.clear();
        } else {
            boolean allowToggle = client.currentScreen == null;
            Map<String, Boolean> nextStates = new HashMap<>();

            for (Feature feature : featureManager.getFeatures()) {
                FeatureBind bind = feature.getKeybind();
                if (!bind.isNone()) {
                    String stateKey = bind.serialize();
                    boolean pressed = bind.isPressed(client.getWindow());
                    boolean wasPressed = this.pressedStates.getOrDefault(stateKey, false);
                    if (allowToggle && pressed && !wasPressed) {
                        feature.toggle();
                        featureManager.notifyToggle(feature);
                    }

                    nextStates.put(stateKey, pressed);
                }
            }

            this.pressedStates.clear();
            this.pressedStates.putAll(nextStates);
        }
    }

    public boolean isCapturing() {
        return this.capturedFeature != null;
    }

    public boolean isCapturing(Feature feature) {
        return this.capturedFeature == feature;
    }

    public String getBindLabel(Feature feature) {
        return this.isCapturing(feature) ? "Listening..." : feature.getKeybind().getDisplayName();
    }

    public void beginCapture(Feature feature, NotificationManager notificationManager) {
        this.capturedFeature = feature;
        if (notificationManager != null) {
            notificationManager.push("Press a key or mouse button for " + feature.getName(), NotificationManager.Type.INFO);
        }
    }

    public void clearBind(Feature feature, NotificationManager notificationManager) {
        feature.setKeybind(FeatureBind.none());
        this.config.clearFeatureBind(configKey(feature));
        this.config.save();
        this.pressedStates.clear();
        if (this.capturedFeature == feature) {
            this.capturedFeature = null;
        }

        if (notificationManager != null) {
            notificationManager.push(feature.getName() + " bind cleared", NotificationManager.Type.INFO);
        }
    }

    public void cancelCapture() {
        this.capturedFeature = null;
    }

    public void cancelCapture(NotificationManager notificationManager) {
        if (this.capturedFeature != null) {
            String featureName = this.capturedFeature.getName();
            this.capturedFeature = null;
            if (notificationManager != null) {
                notificationManager.push(featureName + " bind capture cancelled", NotificationManager.Type.INFO);
            }
        }
    }

    public boolean handleCaptureKey(KeyInput keyInput, NotificationManager notificationManager) {
        if (this.capturedFeature == null) {
            return false;
        } else {
            int keyCode = keyInput.key();
            if (keyCode == 256) {
                this.cancelCapture(notificationManager);
                return true;
            } else if (keyCode == 261 || keyCode == 259) {
                this.clearBind(this.capturedFeature, notificationManager);
                return true;
            } else if (keyCode == -1) {
                return true;
            } else {
                this.assignBind(this.capturedFeature, FeatureBind.keyboard(keyCode), notificationManager);
                return true;
            }
        }
    }

    public boolean handleCaptureMouse(int button, NotificationManager notificationManager) {
        if (this.capturedFeature != null && button >= 0) {
            this.assignBind(this.capturedFeature, FeatureBind.mouse(button), notificationManager);
            return true;
        } else {
            return false;
        }
    }

    private void assignBind(Feature feature, FeatureBind bind, NotificationManager notificationManager) {
        feature.setKeybind(bind);
        this.config.setFeatureBind(configKey(feature), bind.serialize());
        this.config.save();
        this.pressedStates.clear();
        this.capturedFeature = null;
        if (notificationManager != null) {
            notificationManager.push(feature.getName() + " bound to " + bind.getDisplayName(), NotificationManager.Type.SUCCESS);
        }
    }

    private static String configKey(Feature feature) {
        return feature.getConfigKey();
    }
}
