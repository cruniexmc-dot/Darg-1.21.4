package dev.darg.client.feature.visual;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import dev.darg.client.DargsClient;
import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.mixin.RenderLayerInvoker;
import dev.darg.client.render.WorldRenderUtil;
import dev.darg.client.ui.clickgui.InlineControlRenderer;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.Map.Entry;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.OutputTarget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.RenderSetup.Builder;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Vector3f;

public final class BlockEspFeature extends Feature {
    private static final int SCAN_BATCH_SIZE = 10;
    private static final int STALE_RESCAN_INTERVAL_TICKS = 180;
    private static final int CHUNK_RETRY_DELAY_TICKS = 30;
    private static final int MAX_STALE_ENQUEUE_PER_TICK = 8;
    private static final int MAX_RETRY_ENQUEUE_PER_TICK = 8;
    private static final int MAX_TRACER_COUNT = 64;
    private static final int WHITE = -1;
    private static final int SOFT_GRAY = -4671304;
    private static final int MUTED_GRAY = -8750470;
    private static final int DARK_TEXT = -15592942;
    private static final int ACCENT = -3365;
    private static final int DEFAULT_BLOCK_RGB = 16773851;
    private static final int PANEL_DARK = -15198180;
    private static final int PANEL_MID = -14606042;
    private static final int PANEL_LIGHT = -14013903;
    private static final int PANEL_HOVER = -13553352;
    private static final int SEARCH_FILL = -15329766;
    private static final int ACTION_RED = -11325136;
    private static final int MODAL_OVERLAY = -1979119351;
    private static final int MODAL_PANEL = -266724833;
    private static final int MODAL_HEADER = -14408661;
    private static final int MODAL_SHADOW = 1509949440;
    private static final int SCROLL_TRACK = -15527145;
    private static final int SCROLL_THUMB = -10000531;
    private static final int GRID_FILL = -15000800;
    private static final int GRID_HOVER = -14211283;
    private static final int GRID_SELECTED_BORDER = -855641381;
    private static final int COLOR_PICKER_PANEL = -266198488;
    private static final int COLOR_PICKER_BORDER = -13027005;
    private static final int COLOR_PICKER_SHADOW = 1509949440;
    private static final int COLOR_PICKER_HINT = -7500395;
    private static final int COLOR_PICKER_PREVIEW = -15592938;
    private static final float INLINE_HEIGHT = 88.0F;
    private static final float TRACER_START_OFFSET = 0.15F;
    private static final float TRACER_LINE_WIDTH = 1.3F;
    private static final float MODAL_WIDTH = 556.0F;
    private static final float MODAL_HEIGHT = 350.0F;
    private static final float GRID_CELL_SIZE = 34.0F;
    private static final float GRID_CELL_SPACING = 6.0F;
    private static final float GRID_STEP = 40.0F;
    private static final int GRID_COLUMNS = 11;
    private static final float SCROLL_STEP = 80.0F;
    private static final float COLOR_WHEEL_SIZE = 112.0F;
    private static final float COLOR_VALUE_SLIDER_WIDTH = 12.0F;
    private static final float COLOR_PICKER_PADDING = 10.0F;
    private static final float COLOR_PICKER_GAP = 10.0F;
    private static final float COLOR_PICKER_TOP = 46.0F;
    private static final float COLOR_PICKER_HANDLE_SIZE = 8.0F;
    private static final Identifier COLOR_WHEEL_TEXTURE_ID = Identifier.of("dargsclient", "ui/block_esp_color_wheel");
    private static final List<BlockEspFeature.BlockEntry> BLOCK_OPTIONS = buildBlockOptions();
    private static final Object NO_DEPTH_LAYER_LOCK = new Object();
    private static RenderLayer noDepthOutlineLayer;
    private static RenderLayer noDepthFillLayer;
    private final ClientConfig config = ClientConfig.getInstance();
    private final Set<Identifier> selectedBlockIds = new LinkedHashSet<>();
    private final Map<Identifier, Integer> selectedBlockColors = new LinkedHashMap<>();
    private final Set<Block> selectedBlocks = new LinkedHashSet<>();
    private final Set<Identifier> draftBlockIds = new LinkedHashSet<>();
    private final Map<Identifier, Integer> draftBlockColors = new LinkedHashMap<>();
    private final Map<Long, List<BlockEspFeature.CachedMatch>> cachedMatchesByChunk = new LinkedHashMap<>();
    private final Map<Long, Integer> chunkScanTicks = new LinkedHashMap<>();
    private final Map<Long, Integer> chunkRetryTicks = new LinkedHashMap<>();
    private final Deque<Long> scanQueue = new ArrayDeque<>();
    private final Set<Long> queuedChunks = new LinkedHashSet<>();
    private final List<BlockEspFeature.CachedMatch> cachedMatches = new ArrayList<>();
    private int lastScanChunkX = Integer.MIN_VALUE;
    private int lastScanChunkZ = Integer.MIN_VALUE;
    private int lastScanViewDistance = -1;
    private int scanTick;
    private int alpha;
    private boolean tracers;
    private boolean scanDirty = true;
    private boolean cachedMatchesDirty;
    private boolean draggingAlpha;
    private boolean selectorOpen;
    private boolean searchFocused;
    private boolean draggingScrollbar;
    private boolean draggingColorWheel;
    private boolean draggingColorValue;
    private float scrollbarDragOffset;
    private float scrollOffset;
    private String searchText = "";
    private BlockEspFeature.SelectorTab selectorTab = BlockEspFeature.SelectorTab.ALL;
    private Identifier colorPickerBlockId;
    private int[] colorWheelPixels;
    private NativeImageBackedTexture colorWheelTexture;
    private float colorPickerX;
    private float colorPickerY;
    private float colorPickerHue;
    private float colorPickerSaturation;
    private float colorPickerValue = 1.0F;

    public BlockEspFeature() {
        super("BlockESP", Category.RENDER);
        this.alpha = this.config.getBlockEspAlpha();
        this.tracers = this.config.isBlockEspTracersEnabled();
        this.loadSelectedBlocks(this.config.getBlockEspSelectedBlocks());
        this.loadBlockColors(this.config.getBlockEspBlockColors());
    }

    @Override
    protected void onEnable() {
        this.resetScanState();
        this.scanDirty = true;
    }

    @Override
    protected void onDisable() {
        this.resetScanState();
    }

    public boolean hasTracersEnabled() {
        return this.isEnabled() && this.tracers;
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 88.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        if (this.draggingAlpha) {
            this.setAlphaFromMouse((double)mouseX, x, width);
        }

        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        float contentX = x + 10.0F;
        float contentWidth = width - 20.0F;
        float sliderY = y + 10.0F;
        String alphaValue = Integer.toString(this.alpha);
        float toggleY = y + 31.0F;
        float blocksY = y + 50.0F;
        float keybindY = y + 65.0F;
        boolean hoverBlocks = this.containsBlocksLabel((double)mouseX, (double)mouseY, x, y, width);
        boolean hoverToggle = this.containsTracersToggle((double)mouseX, (double)mouseY, x, y, width);
        boolean hoverKeybind = this.containsKeybindButton((double)mouseX, (double)mouseY, x, y, width);
        String bindLabel = InlineControlRenderer.fitText(
            textRenderer, DargsClient.getInstance().getKeybindManager().getBindLabel(this).toUpperCase(Locale.ROOT), 58
        );
        InlineControlRenderer.drawSlider(context, textRenderer, theme, "ALPHA", alphaValue, contentX, sliderY, contentWidth, (float)this.alpha / 255.0F);
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "TRACERS", this.tracers, hoverToggle, contentX, toggleY, contentWidth);
        RenderUtil.drawText(
            context, textRenderer, "BLOCKS: " + formatBlockCount(this.selectedBlockIds.size()), contentX, blocksY, hoverBlocks ? theme.accent() : theme.white()
        );
        float bindButtonWidth = 70.0F;
        float bindButtonX = x + width - bindButtonWidth - 10.0F;
        boolean capturing = DargsClient.getInstance().getKeybindManager().isCapturing(this);
        InlineControlRenderer.drawButton(context, textRenderer, theme, bindLabel, capturing, hoverKeybind, bindButtonX, keybindY, bindButtonWidth);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (!this.containsInline(mouseX, mouseY, x, y, width)) {
            return false;
        } else if (button == 0 && this.containsAlphaSlider(mouseX, mouseY, x, y, width)) {
            this.draggingAlpha = true;
            this.setAlphaFromMouse(mouseX, x, width);
            return true;
        } else if (button == 0 && this.containsTracersToggle(mouseX, mouseY, x, y, width)) {
            this.tracers = !this.tracers;
            this.saveSettings();
            notificationManager.push(
                "BlockESP tracers " + (this.tracers ? "enabled" : "disabled"), this.tracers ? NotificationManager.Type.SUCCESS : NotificationManager.Type.INFO
            );
            return true;
        } else if (button == 0 && this.containsBlocksLabel(mouseX, mouseY, x, y, width)) {
            this.openSelector();
            return true;
        } else if (button == 0 && this.containsKeybindButton(mouseX, mouseY, x, y, width)) {
            if (DargsClient.getInstance().getKeybindManager().isCapturing(this)) {
                DargsClient.getInstance().getKeybindManager().cancelCapture(notificationManager);
            } else {
                DargsClient.getInstance().getKeybindManager().beginCapture(this, notificationManager);
            }

            return true;
        } else {
            return true;
        }
    }

    @Override
    public boolean onCustomClickGuiMouseReleased(double mouseX, double mouseY, int button, float x, float y, float width) {
        if (button == 0 && this.draggingAlpha) {
            this.draggingAlpha = false;
            this.saveSettings();
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isClickGuiInteractionActive() {
        return this.selectorOpen;
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of(
            "State: " + (this.isEnabled() ? "Enabled" : "Disabled"),
            "Tracked Blocks: " + this.selectedBlockIds.size(),
            "Cached Matches: " + this.cachedMatches.size(),
            "Cached Chunks: " + this.cachedMatchesByChunk.size() + ", Queued: " + this.scanQueue.size(),
            "Alpha: " + this.alpha,
            "Tracers: " + (this.tracers ? "On (nearest 64)" : "Off")
        );
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity player = client.player;
        if (client.world != null && player != null && !this.selectedBlocks.isEmpty()) {
            this.scanTick++;
            int currentChunkX = player.getChunkPos().x;
            int currentChunkZ = player.getChunkPos().z;
            int viewDistance = (Integer)client.options.getViewDistance().getValue();
            int chunkRadius = this.getChunkRadius(viewDistance);
            if (this.scanDirty) {
                this.rebuildScanQueue(currentChunkX, currentChunkZ, chunkRadius, true);
                this.scanDirty = false;
            } else if (this.lastScanViewDistance == -1) {
                this.rebuildScanQueue(currentChunkX, currentChunkZ, chunkRadius, false);
            } else {
                if (viewDistance != this.lastScanViewDistance) {
                    this.rebuildScanQueue(currentChunkX, currentChunkZ, chunkRadius, false);
                } else if (currentChunkX != this.lastScanChunkX || currentChunkZ != this.lastScanChunkZ) {
                    this.enqueueNewWindowChunks(this.lastScanChunkX, this.lastScanChunkZ, currentChunkX, currentChunkZ, chunkRadius);
                }

                this.cleanupDistant(currentChunkX, currentChunkZ, chunkRadius);
                this.enqueueReadyChunkRetries(currentChunkX, currentChunkZ, chunkRadius);
                this.enqueueStaleChunks(currentChunkX, currentChunkZ, chunkRadius);
            }

            this.processScanQueue(client);
            if (this.cachedMatchesDirty) {
                this.rebuildCachedMatches();
            }

            this.lastScanChunkX = currentChunkX;
            this.lastScanChunkZ = currentChunkZ;
            this.lastScanViewDistance = viewDistance;
        } else {
            this.resetScanState();
        }
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity player = client.player;
        if (client.world != null && player != null && !this.cachedMatches.isEmpty()) {
            MatrixStack matrices = context.matrices();
            VertexConsumerProvider consumers = context.consumers();
            if (matrices != null && consumers != null) {
                Camera camera = client.gameRenderer.getCamera();
                Vec3d cameraPos = camera.getCameraPos();
                VertexConsumer tracerBuffer = consumers.getBuffer(RenderLayers.linesTranslucent());
                float tickProgress = client.getRenderTickCounter().getTickProgress(false);
                Map<Integer, List<BlockEspFeature.QueuedOutline>> queuedOutlinesByColor = new LinkedHashMap<>();
                PriorityQueue<BlockEspFeature.TracerTarget> tracerTargets = this.tracers
                    ? new PriorityQueue<>(Comparator.comparingDouble(BlockEspFeature.TracerTarget::distanceSq).reversed())
                    : null;

                for (BlockEspFeature.CachedMatch cachedMatch : this.cachedMatches) {
                    int blockColor = this.getConfiguredBlockColor(this.selectedBlockColors, cachedMatch.blockId());
                    BlockPos blockPos = cachedMatch.pos();
                    queuedOutlinesByColor.computeIfAbsent(blockColor, ignored -> new ArrayList<>())
                        .add(
                            new BlockEspFeature.QueuedOutline(
                                cachedMatch.shape(),
                                (double)blockPos.getX() - cameraPos.x,
                                (double)blockPos.getY() - cameraPos.y,
                                (double)blockPos.getZ() - cameraPos.z
                            )
                        );
                    if (tracerTargets != null) {
                        this.queueTracerTarget(tracerTargets, blockPos, cameraPos, blockColor);
                    }
                }

                for (Entry<Integer, List<BlockEspFeature.QueuedOutline>> entry : queuedOutlinesByColor.entrySet()) {
                    this.submitQueuedFills(context.commandQueue(), matrices, entry.getValue(), this.toFillColor(entry.getKey()));
                    this.submitQueuedOutlines(context.commandQueue(), matrices, entry.getValue(), this.toOutlineColor(entry.getKey()));
                }

                if (tracerTargets != null && !tracerTargets.isEmpty()) {
                    List<BlockEspFeature.TracerTarget> nearestTargets = new ArrayList<>(tracerTargets);
                    nearestTargets.sort(Comparator.comparingDouble(BlockEspFeature.TracerTarget::distanceSq));

                    for (BlockEspFeature.TracerTarget target : nearestTargets) {
                        this.drawTracer(tracerBuffer, matrices, camera, cameraPos, target.pos(), tickProgress, target.rgbColor());
                    }
                }
            }
        }
    }

    @Override
    public void onClickGuiRender(DrawContext context, int mouseX, int mouseY, float delta) {
        if (this.selectorOpen) {
            if (this.draggingScrollbar) {
                this.updateScrollbarFromMouse(mouseY);
            }

            if (this.draggingColorWheel) {
                this.updateColorFromWheel((double)mouseX, (double)mouseY);
            }

            if (this.draggingColorValue) {
                this.updateColorFromValue((double)mouseY);
            }

            this.renderSelectorModal(context, MinecraftClient.getInstance().textRenderer, mouseX, mouseY);
        }
    }

    @Override
    public boolean onClickGuiMouseClicked(double mouseX, double mouseY, int button) {
        if (!this.selectorOpen) {
            return false;
        } else {
            MinecraftClient client = MinecraftClient.getInstance();
            float modalX = this.getModalX(client);
            float modalY = this.getModalY(client);
            if (!this.containsModal(mouseX, mouseY, modalX, modalY)) {
                this.searchFocused = false;
                this.closeColorPicker();
                return true;
            } else {
                if (this.colorPickerBlockId != null) {
                    if (button == 0 && this.containsColorWheel(mouseX, mouseY)) {
                        this.draggingColorWheel = true;
                        this.updateColorFromWheel(mouseX, mouseY);
                        return true;
                    }

                    if (button == 0 && this.containsColorValueSlider(mouseX, mouseY)) {
                        this.draggingColorValue = true;
                        this.updateColorFromValue(mouseY);
                        return true;
                    }

                    if (this.containsColorPicker(mouseX, mouseY)) {
                        return true;
                    }

                    if (button == 0 || button == 1) {
                        this.closeColorPicker();
                    }
                }

                BlockEspFeature.BlockEntry entry = this.getEntryAt(mouseX, mouseY, modalX, modalY);
                if (button == 1 && entry != null) {
                    this.openColorPicker(entry.id(), mouseX, mouseY, modalX, modalY);
                    return true;
                } else if (button != 0) {
                    return true;
                } else if (this.containsTab(mouseX, mouseY, modalX, modalY, BlockEspFeature.SelectorTab.ALL)) {
                    this.selectorTab = BlockEspFeature.SelectorTab.ALL;
                    this.clampScroll();
                    return true;
                } else if (this.containsTab(mouseX, mouseY, modalX, modalY, BlockEspFeature.SelectorTab.SELECTED)) {
                    this.selectorTab = BlockEspFeature.SelectorTab.SELECTED;
                    this.clampScroll();
                    return true;
                } else if (this.containsSearch(mouseX, mouseY, modalX, modalY)) {
                    this.searchFocused = true;
                    return true;
                } else {
                    this.searchFocused = false;
                    if (this.containsScrollbarThumb(mouseX, mouseY, modalX, modalY)) {
                        this.draggingScrollbar = true;
                        this.scrollbarDragOffset = (float)mouseY - this.getScrollbarThumbY(modalY);
                        return true;
                    } else if (this.containsScrollbarTrack(mouseX, mouseY, modalX, modalY)) {
                        this.jumpScrollbar(mouseY, modalY);
                        return true;
                    } else if (entry != null) {
                        this.toggleDraftSelection(entry.id());
                        return true;
                    } else if (this.containsActionButton(mouseX, mouseY, modalX, modalY, BlockEspFeature.ModalAction.CLEAR)) {
                        this.draftBlockIds.clear();
                        this.clampScroll();
                        return true;
                    } else if (this.containsActionButton(mouseX, mouseY, modalX, modalY, BlockEspFeature.ModalAction.CANCEL)) {
                        this.closeSelector(false);
                        return true;
                    } else if (this.containsActionButton(mouseX, mouseY, modalX, modalY, BlockEspFeature.ModalAction.SAVE)) {
                        this.closeSelector(true);
                        return true;
                    } else {
                        return true;
                    }
                }
            }
        }
    }

    @Override
    public boolean onClickGuiMouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            boolean handled = this.draggingScrollbar || this.draggingColorWheel || this.draggingColorValue;
            this.draggingScrollbar = false;
            this.draggingColorWheel = false;
            this.draggingColorValue = false;
            if (handled) {
                return true;
            }
        }

        return this.selectorOpen;
    }

    @Override
    public boolean onClickGuiMouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (!this.selectorOpen) {
            return false;
        } else {
            MinecraftClient client = MinecraftClient.getInstance();
            float modalX = this.getModalX(client);
            float modalY = this.getModalY(client);
            if (this.containsColorPicker(mouseX, mouseY)) {
                return true;
            } else if (!this.containsGrid(mouseX, mouseY, modalX, modalY)) {
                return this.containsModal(mouseX, mouseY, modalX, modalY);
            } else {
                this.scrollOffset = clamp(this.scrollOffset - (float)verticalAmount * 80.0F, 0.0F, this.getMaxScroll());
                return true;
            }
        }
    }

    @Override
    public boolean onClickGuiKeyPressed(KeyInput keyInput) {
        if (!this.selectorOpen) {
            return false;
        } else {
            int key = keyInput.key();
            if (key == 256) {
                if (this.colorPickerBlockId != null) {
                    this.closeColorPicker();
                    return true;
                } else {
                    this.closeSelector(false);
                    return true;
                }
            } else if (key == 257) {
                this.closeSelector(true);
                return true;
            } else if (this.searchFocused && (key == 259 || key == 261)) {
                if (!this.searchText.isEmpty()) {
                    this.searchText = this.searchText.substring(0, this.searchText.length() - 1);
                    this.clampScroll();
                }

                return true;
            } else {
                return false;
            }
        }
    }

    @Override
    public boolean onClickGuiCharTyped(CharInput charInput) {
        if (this.selectorOpen && this.searchFocused && charInput.isValidChar()) {
            String input = charInput.asString();
            if (input.isBlank() && charInput.codepoint() != 32) {
                return false;
            } else if (this.searchText.length() >= 48) {
                return true;
            } else {
                this.searchText = this.searchText + input.toLowerCase(Locale.ROOT);
                this.clampScroll();
                return true;
            }
        } else {
            return false;
        }
    }

    private void renderSelectorModal(DrawContext context, TextRenderer textRenderer, int mouseX, int mouseY) {
        MinecraftClient client = MinecraftClient.getInstance();
        float modalX = this.getModalX(client);
        float modalY = this.getModalY(client);
        float gridX = modalX + 18.0F;
        float gridY = modalY + 96.0F;
        float gridWidth = 472.0F;
        float gridHeight = 178.0F;
        List<BlockEspFeature.BlockEntry> visibleEntries = this.getVisibleEntries();
        BlockEspFeature.BlockEntry hoveredEntry = null;
        context.fill(0, 0, client.getWindow().getScaledWidth(), client.getWindow().getScaledHeight(), -1979119351);
        RenderUtil.drawRoundedRect(context, modalX + 3.0F, modalY + 4.0F, 556.0F, 350.0F, 10.0F, 1509949440);
        RenderUtil.drawRoundedRect(context, modalX, modalY, 556.0F, 350.0F, 10.0F, -266724833);
        RenderUtil.drawRoundedRect(context, modalX, modalY, 556.0F, 28.0F, 10.0F, -14408661);
        context.fill(Math.round(modalX), Math.round(modalY + 22.0F), Math.round(modalX + 556.0F), Math.round(modalY + 28.0F), -14408661);
        RenderUtil.drawText(
            context, textRenderer, "BLOCK COLORS: BLOCKS (" + formatBlockCount(this.draftBlockIds.size()) + ")", modalX + 16.0F, modalY + 9.0F, -1
        );
        this.renderTab(context, textRenderer, modalX + 18.0F, modalY + 42.0F, 132.0F, BlockEspFeature.SelectorTab.ALL, "ALL BLOCKS", mouseX, mouseY);
        this.renderTab(
            context,
            textRenderer,
            modalX + 160.0F,
            modalY + 42.0F,
            152.0F,
            BlockEspFeature.SelectorTab.SELECTED,
            "SELECTED (" + this.draftBlockIds.size() + ")",
            mouseX,
            mouseY
        );
        boolean searchHover = this.containsSearch((double)mouseX, (double)mouseY, modalX, modalY);
        RenderUtil.drawRoundedRect(context, modalX + 18.0F, modalY + 72.0F, 472.0F, 22.0F, 5.0F, !searchHover && !this.searchFocused ? -15329766 : -14606042);
        drawOutline(context, modalX + 18.0F, modalY + 72.0F, 472.0F, 22.0F, this.searchFocused ? -3365 : -14013903);
        RenderUtil.drawText(context, textRenderer, "SEARCH:", modalX + 28.0F, modalY + 79.0F, -8750470);
        RenderUtil.drawText(
            context,
            textRenderer,
            this.searchText.isEmpty() ? "type block name or id" : this.searchText,
            modalX + 100.0F,
            modalY + 79.0F,
            this.searchText.isEmpty() ? -8750470 : -1
        );
        RenderUtil.drawRoundedRect(context, gridX - 2.0F, gridY - 2.0F, gridWidth + 4.0F, gridHeight + 4.0F, 7.0F, -15329766);
        context.enableScissor(Math.round(gridX), Math.round(gridY), Math.round(gridX + gridWidth), Math.round(gridY + gridHeight));

        try {
            for (int index = 0; index < visibleEntries.size(); index++) {
                BlockEspFeature.BlockEntry entry = visibleEntries.get(index);
                int column = index % 11;
                int row = index / 11;
                float cellX = gridX + (float)column * 40.0F;
                float cellY = gridY + (float)row * 40.0F - this.scrollOffset;
                if (!(cellY + 34.0F < gridY) && !(cellY > gridY + gridHeight)) {
                    boolean hovered = (float)mouseX >= cellX && (float)mouseX <= cellX + 34.0F && (float)mouseY >= cellY && (float)mouseY <= cellY + 34.0F;
                    boolean selected = this.draftBlockIds.contains(entry.id());
                    int blockColor = this.getConfiguredBlockColor(this.draftBlockColors, entry.id());
                    int cellColor = selected ? withAlpha(blockColor, 68) : (hovered ? -14211283 : -15000800);
                    RenderUtil.drawRoundedRect(context, cellX, cellY, 34.0F, 34.0F, 5.0F, cellColor);
                    if (selected) {
                        drawOutline(context, cellX, cellY, 34.0F, 34.0F, withAlpha(blockColor, 216));
                    } else if (this.colorPickerBlockId != null && this.colorPickerBlockId.equals(entry.id())) {
                        drawOutline(context, cellX, cellY, 34.0F, 34.0F, -855641381);
                    }

                    context.drawItemWithoutEntity(entry.icon(), Math.round(cellX + 9.0F), Math.round(cellY + 9.0F));
                    if (selected) {
                        float swatchX = cellX + 34.0F - 10.0F;
                        float swatchY = cellY + 34.0F - 10.0F;
                        RenderUtil.drawRoundedRect(context, swatchX, swatchY, 7.0F, 7.0F, 2.0F, withAlpha(blockColor, 255));
                        drawOutline(context, swatchX, swatchY, 7.0F, 7.0F, -15198180);
                    }

                    if (hovered) {
                        hoveredEntry = entry;
                    }
                }
            }
        } finally {
            context.disableScissor();
        }

        if (visibleEntries.isEmpty()) {
            RenderUtil.drawText(context, textRenderer, "No blocks found", gridX + 8.0F, gridY + 10.0F, -8750470);
        }

        this.renderScrollbar(context, modalY, gridHeight);
        this.renderActionButton(context, textRenderer, modalX + 222.0F, modalY + 302.0F, 102.0F, BlockEspFeature.ModalAction.CLEAR, mouseX, mouseY);
        this.renderActionButton(context, textRenderer, modalX + 334.0F, modalY + 302.0F, 102.0F, BlockEspFeature.ModalAction.CANCEL, mouseX, mouseY);
        this.renderActionButton(context, textRenderer, modalX + 446.0F, modalY + 302.0F, 92.0F, BlockEspFeature.ModalAction.SAVE, mouseX, mouseY);
        if (this.colorPickerBlockId != null) {
            this.renderColorPicker(context, textRenderer, mouseX, mouseY);
        }

        if (hoveredEntry != null) {
            context.drawItemTooltip(textRenderer, hoveredEntry.icon(), mouseX, mouseY);
        }
    }

    private void renderTab(
        DrawContext context, TextRenderer textRenderer, float x, float y, float width, BlockEspFeature.SelectorTab tab, String label, int mouseX, int mouseY
    ) {
        boolean active = this.selectorTab == tab;
        boolean hovered = (float)mouseX >= x && (float)mouseX <= x + width && (float)mouseY >= y && (float)mouseY <= y + 24.0F;
        int fill = active ? -3365 : (hovered ? -13553352 : -14013903);
        int textColor = active ? -15592942 : -1;
        RenderUtil.drawRoundedRect(context, x, y, width, 24.0F, 6.0F, fill);
        RenderUtil.drawText(context, textRenderer, label, x + 12.0F, y + 8.0F, textColor);
    }

    private void renderActionButton(
        DrawContext context, TextRenderer textRenderer, float x, float y, float width, BlockEspFeature.ModalAction action, int mouseX, int mouseY
    ) {
        boolean hovered = contains((double)mouseX, (double)mouseY, x, y, width, 22.0F);

        int fill = switch (action) {
            case CLEAR -> hovered ? -9879490 : -11325136;
            case CANCEL -> hovered ? -13553352 : -14013903;
            case SAVE -> hovered ? -134176 : -3365;
        };
        int textColor = action == BlockEspFeature.ModalAction.SAVE ? -15592942 : -1;
        RenderUtil.drawRoundedRect(context, x, y, width, 22.0F, 6.0F, fill);
        RenderUtil.drawText(context, textRenderer, action.label, x + (width - (float)textRenderer.getWidth(action.label)) * 0.5F, y + 7.0F, textColor);
    }

    private void renderScrollbar(DrawContext context, float modalY, float gridHeight) {
        float trackX = this.getScrollbarX();
        float trackY = modalY + 96.0F;
        float thumbHeight = this.getScrollbarThumbHeight();
        float thumbY = this.getScrollbarThumbY(modalY);
        RenderUtil.drawRoundedRect(context, trackX, trackY, 7.0F, gridHeight, 3.0F, -15527145);
        RenderUtil.drawRoundedRect(context, trackX, thumbY, 7.0F, thumbHeight, 3.0F, -10000531);
    }

    private void drawTracer(
        VertexConsumer lineBuffer, MatrixStack matrices, Camera camera, Vec3d cameraPos, BlockPos blockPos, float tickProgress, int rgbColor
    ) {
        Vec3d targetPos = new Vec3d((double)blockPos.getX() + 0.5, (double)blockPos.getY() + 0.5, (double)blockPos.getZ() + 0.5)
            .subtract(cameraPos);
        Vec3d start = WorldRenderUtil.getTracerStart(camera, tickProgress, 0.15F);
        Vec3d direction = targetPos.subtract(start);
        if (!(direction.lengthSquared() <= 1.0E-4)) {
            Vec3d normal = direction.normalize();
            net.minecraft.client.util.math.MatrixStack.Entry entry = matrices.peek();
            int lineAlpha = Math.max(this.alpha, 110);
            lineBuffer.vertex(entry, (float)start.x, (float)start.y, (float)start.z)
                .color(red(rgbColor), green(rgbColor), blue(rgbColor), lineAlpha)
                .normal(entry, (float)normal.x, (float)normal.y, (float)normal.z)
                .lineWidth(1.3F);
            lineBuffer.vertex(entry, (float)targetPos.x, (float)targetPos.y, (float)targetPos.z)
                .color(red(rgbColor), green(rgbColor), blue(rgbColor), lineAlpha)
                .normal(entry, (float)normal.x, (float)normal.y, (float)normal.z)
                .lineWidth(1.3F);
        }
    }

    private void submitQueuedFills(OrderedRenderCommandQueue commandQueue, MatrixStack matrices, List<BlockEspFeature.QueuedOutline> queuedOutlines, int color) {
        commandQueue.submitCustom(
            matrices,
            getNoDepthFillLayer(),
            (entry, consumer) -> {
                for (BlockEspFeature.QueuedOutline queuedOutline : queuedOutlines) {
                    queuedOutline.shape()
                        .forEachBox(
                            (minX, minY, minZ, maxX, maxY, maxZ) -> this.drawFilledBox(
                                    entry,
                                    consumer,
                                    queuedOutline.x() + minX,
                                    queuedOutline.y() + minY,
                                    queuedOutline.z() + minZ,
                                    queuedOutline.x() + maxX,
                                    queuedOutline.y() + maxY,
                                    queuedOutline.z() + maxZ,
                                    color
                                )
                        );
                }
            }
        );
    }

    private void submitQueuedOutlines(
        OrderedRenderCommandQueue commandQueue, MatrixStack matrices, List<BlockEspFeature.QueuedOutline> queuedOutlines, int color
    ) {
        commandQueue.submitCustom(matrices, getNoDepthOutlineLayer(), (entry, consumer) -> {
            for (BlockEspFeature.QueuedOutline queuedOutline : queuedOutlines) {
                this.drawQueuedOutline(entry, consumer, queuedOutline, color);
            }
        });
    }

    private static RenderLayer getNoDepthOutlineLayer() {
        RenderLayer layer = noDepthOutlineLayer;
        if (layer != null) {
            return layer;
        } else {
            synchronized (NO_DEPTH_LAYER_LOCK) {
                if (noDepthOutlineLayer == null) {
                    RenderPipeline pipeline = RenderPipelines.register(
                        RenderPipeline.builder(new Snippet[]{RenderPipelines.RENDERTYPE_LINES_SNIPPET})
                            .withLocation("pipeline/dargsclient_block_esp_outline_no_depth")
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .build()
                    );
                    noDepthOutlineLayer = createRenderLayer("dargs_block_esp_outline_no_depth", pipeline, true);
                }

                return noDepthOutlineLayer;
            }
        }
    }

    private static RenderLayer getNoDepthFillLayer() {
        RenderLayer layer = noDepthFillLayer;
        if (layer != null) {
            return layer;
        } else {
            synchronized (NO_DEPTH_LAYER_LOCK) {
                if (noDepthFillLayer == null) {
                    RenderPipeline pipeline = RenderPipelines.register(
                        RenderPipeline.builder(new Snippet[]{RenderPipelines.POSITION_COLOR_SNIPPET})
                            .withLocation("pipeline/dargsclient_block_esp_fill_no_depth")
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build()
                    );
                    noDepthFillLayer = createRenderLayer("dargs_block_esp_fill_no_depth", pipeline, false);
                }

                return noDepthFillLayer;
            }
        }
    }

    private static RenderLayer createRenderLayer(String name, RenderPipeline pipeline, boolean itemEntityTarget) {
        try {
            Builder setupBuilder = RenderSetup.builder(pipeline).layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING);
            if (itemEntityTarget) {
                setupBuilder.outputTarget(OutputTarget.ITEM_ENTITY_TARGET);
            } else {
                setupBuilder.translucent();
            }

            return RenderLayerInvoker.dargsclient$invokeOf(name, setupBuilder.build());
        } catch (RuntimeException var4) {
            throw new IllegalStateException("Failed to create BlockESP render layer", var4);
        }
    }

    private void drawQueuedOutline(
        net.minecraft.client.util.math.MatrixStack.Entry entry, VertexConsumer consumer, BlockEspFeature.QueuedOutline queuedOutline, int color
    ) {
        int red = red(color);
        int green = green(color);
        int blue = blue(color);
        int alpha = alpha(color);
        queuedOutline.shape()
            .forEachEdge(
                (startX, startY, startZ, endX, endY, endZ) -> {
                    Vector3f normal = new Vector3f((float)(endX - startX), (float)(endY - startY), (float)(endZ - startZ));
                    if (normal.lengthSquared() > 0.0F) {
                        normal.normalize();
                    }

                    consumer.vertex(entry, (float)(startX + queuedOutline.x()), (float)(startY + queuedOutline.y()), (float)(startZ + queuedOutline.z()))
                        .color(red, green, blue, alpha)
                        .normal(entry, normal)
                        .lineWidth(1.4F);
                    consumer.vertex(entry, (float)(endX + queuedOutline.x()), (float)(endY + queuedOutline.y()), (float)(endZ + queuedOutline.z()))
                        .color(red, green, blue, alpha)
                        .normal(entry, normal)
                        .lineWidth(1.4F);
                }
            );
    }

    private void drawFilledBox(
        net.minecraft.client.util.math.MatrixStack.Entry entry,
        VertexConsumer consumer,
        double minX,
        double minY,
        double minZ,
        double maxX,
        double maxY,
        double maxZ,
        int color
    ) {
        float x1 = (float)minX;
        float y1 = (float)minY;
        float z1 = (float)minZ;
        float x2 = (float)maxX;
        float y2 = (float)maxY;
        float z2 = (float)maxZ;
        emitQuad(consumer, entry, x1, y1, z1, x2, y1, z1, x2, y2, z1, x1, y2, z1, color);
        emitQuad(consumer, entry, x2, y1, z2, x1, y1, z2, x1, y2, z2, x2, y2, z2, color);
        emitQuad(consumer, entry, x1, y1, z2, x1, y1, z1, x1, y2, z1, x1, y2, z2, color);
        emitQuad(consumer, entry, x2, y1, z1, x2, y1, z2, x2, y2, z2, x2, y2, z1, color);
        emitQuad(consumer, entry, x1, y2, z1, x2, y2, z1, x2, y2, z2, x1, y2, z2, color);
        emitQuad(consumer, entry, x1, y1, z2, x2, y1, z2, x2, y1, z1, x1, y1, z1, color);
    }

    private static void emitQuad(
        VertexConsumer consumer,
        net.minecraft.client.util.math.MatrixStack.Entry entry,
        float x1,
        float y1,
        float z1,
        float x2,
        float y2,
        float z2,
        float x3,
        float y3,
        float z3,
        float x4,
        float y4,
        float z4,
        int color
    ) {
        int red = red(color);
        int green = green(color);
        int blue = blue(color);
        int alpha = alpha(color);
        consumer.vertex(entry, x1, y1, z1).color(red, green, blue, alpha);
        consumer.vertex(entry, x2, y2, z2).color(red, green, blue, alpha);
        consumer.vertex(entry, x3, y3, z3).color(red, green, blue, alpha);
        consumer.vertex(entry, x4, y4, z4).color(red, green, blue, alpha);
    }

    private void openSelector() {
        this.draftBlockIds.clear();
        this.draftBlockIds.addAll(this.selectedBlockIds);
        this.draftBlockColors.clear();
        this.draftBlockColors.putAll(this.selectedBlockColors);
        this.selectorTab = BlockEspFeature.SelectorTab.ALL;
        this.selectorOpen = true;
        this.draggingScrollbar = false;
        this.draggingColorWheel = false;
        this.draggingColorValue = false;
        this.searchFocused = false;
        this.searchText = "";
        this.scrollOffset = 0.0F;
        this.closeColorPicker();
    }

    private void closeSelector(boolean saveChanges) {
        if (saveChanges) {
            this.selectedBlockIds.clear();
            this.selectedBlockIds.addAll(this.draftBlockIds);
            this.selectedBlockColors.clear();

            for (Identifier blockId : this.selectedBlockIds) {
                int color = this.getConfiguredBlockColor(this.draftBlockColors, blockId);
                if (color != 16773851) {
                    this.selectedBlockColors.put(blockId, color);
                }
            }

            this.rebuildSelectedBlocks();
            this.persistSelectedBlocks();
            this.scanDirty = true;
        } else {
            this.draftBlockIds.clear();
            this.draftBlockColors.clear();
        }

        this.selectorOpen = false;
        this.draggingScrollbar = false;
        this.draggingColorWheel = false;
        this.draggingColorValue = false;
        this.searchFocused = false;
        this.scrollOffset = 0.0F;
        this.searchText = "";
        this.closeColorPicker();
    }

    private void toggleDraftSelection(Identifier blockId) {
        if (!this.draftBlockIds.add(blockId)) {
            this.draftBlockIds.remove(blockId);
        }

        this.clampScroll();
    }

    private void persistSelectedBlocks() {
        Set<String> serializedIds = new LinkedHashSet<>();
        Map<String, Integer> serializedColors = new LinkedHashMap<>();

        for (Identifier blockId : this.selectedBlockIds) {
            serializedIds.add(blockId.toString());
        }

        for (Entry<Identifier, Integer> entry : this.selectedBlockColors.entrySet()) {
            serializedColors.put(entry.getKey().toString(), entry.getValue());
        }

        this.config.setBlockEspSelectedBlocks(serializedIds);
        this.config.setBlockEspBlockColors(serializedColors);
        this.config.save();
    }

    private void saveSettings() {
        this.config.setBlockEspAlpha(this.alpha);
        this.config.setBlockEspTracersEnabled(this.tracers);
        this.config.save();
    }

    private void setAlphaFromMouse(double mouseX, float x, float width) {
        float sliderStart = x + 10.0F;
        float sliderWidth = width - 22.0F;
        float ratio = clamp((float)((mouseX - (double)sliderStart) / (double)sliderWidth), 0.0F, 1.0F);
        this.alpha = Math.max(0, Math.min(255, Math.round(ratio * 255.0F)));
    }

    private List<BlockEspFeature.BlockEntry> getVisibleEntries() {
        List<BlockEspFeature.BlockEntry> entries = new ArrayList<>();
        String filter = this.searchText.trim().toLowerCase(Locale.ROOT);

        for (BlockEspFeature.BlockEntry entry : BLOCK_OPTIONS) {
            if ((this.selectorTab != BlockEspFeature.SelectorTab.SELECTED || this.draftBlockIds.contains(entry.id()))
                && (filter.isEmpty() || entry.searchValue().contains(filter))) {
                entries.add(entry);
            }
        }

        return entries;
    }

    private void clampScroll() {
        this.scrollOffset = clamp(this.scrollOffset, 0.0F, this.getMaxScroll());
    }

    private float getMaxScroll() {
        int rows = (int)Math.ceil((double)this.getVisibleEntries().size() / 11.0);
        float contentHeight = Math.max(0.0F, (float)rows * 40.0F - 6.0F);
        return Math.max(0.0F, contentHeight - 178.0F);
    }

    private void updateScrollbarFromMouse(int mouseY) {
        float modalY = this.getModalY(MinecraftClient.getInstance());
        float trackTop = modalY + 96.0F;
        float thumbHeight = this.getScrollbarThumbHeight();
        float maxScroll = this.getMaxScroll();
        float travel = 178.0F - thumbHeight;
        if (!(travel <= 0.0F) && !(maxScroll <= 0.0F)) {
            float relative = clamp((float)mouseY - trackTop - this.scrollbarDragOffset, 0.0F, travel);
            this.scrollOffset = relative / travel * maxScroll;
        } else {
            this.scrollOffset = 0.0F;
        }
    }

    private void jumpScrollbar(double mouseY, float modalY) {
        float trackTop = modalY + 96.0F;
        float thumbHeight = this.getScrollbarThumbHeight();
        float maxScroll = this.getMaxScroll();
        float travel = 178.0F - thumbHeight;
        if (!(travel <= 0.0F) && !(maxScroll <= 0.0F)) {
            float relative = clamp((float)mouseY - trackTop - thumbHeight * 0.5F, 0.0F, travel);
            this.scrollOffset = relative / travel * maxScroll;
        } else {
            this.scrollOffset = 0.0F;
        }
    }

    private void renderColorPicker(DrawContext context, TextRenderer textRenderer, int mouseX, int mouseY) {
        float width = this.getColorPickerWidth();
        float height = this.getColorPickerHeight();
        float wheelX = this.getColorWheelX();
        float wheelY = this.getColorWheelY();
        float sliderX = this.getColorValueSliderX();
        int currentColor = hsvToRgb(this.colorPickerHue, this.colorPickerSaturation, this.colorPickerValue);
        this.ensureColorWheelTexture();
        RenderUtil.drawRoundedRect(context, this.colorPickerX + 2.0F, this.colorPickerY + 3.0F, width, height, 7.0F, 1509949440);
        RenderUtil.drawRoundedRect(context, this.colorPickerX, this.colorPickerY, width, height, 7.0F, -266198488);
        drawOutline(context, this.colorPickerX, this.colorPickerY, width, height, -13027005);
        RenderUtil.drawRoundedRect(context, this.colorPickerX + 10.0F, this.colorPickerY + 8.0F, 16.0F, 16.0F, 4.0F, -15592938);
        RenderUtil.drawRoundedRect(context, this.colorPickerX + 12.0F, this.colorPickerY + 10.0F, 12.0F, 12.0F, 3.0F, withAlpha(currentColor, 255));
        RenderUtil.drawText(context, textRenderer, "BLOCK COLOR", this.colorPickerX + 32.0F, this.colorPickerY + 8.0F, -1);
        RenderUtil.drawText(context, textRenderer, "#" + toHexColor(currentColor), this.colorPickerX + 32.0F, this.colorPickerY + 20.0F, -4671304);
        RenderUtil.drawText(context, textRenderer, "drag inside the wheel for any color", this.colorPickerX + 10.0F, this.colorPickerY + 32.0F, -7500395);
        context.drawTexture(
            RenderPipelines.GUI_TEXTURED,
            COLOR_WHEEL_TEXTURE_ID,
            Math.round(wheelX),
            Math.round(wheelY),
            0.0F,
            0.0F,
            Math.round(112.0F),
            Math.round(112.0F),
            Math.round(112.0F),
            Math.round(112.0F),
            Math.round(112.0F),
            Math.round(112.0F)
        );
        this.renderColorValueSlider(context, sliderX, wheelY);
        float wheelRadius = 56.0F;
        float angle = this.colorPickerHue * (float) (Math.PI * 2);
        float indicatorDistance = this.colorPickerSaturation * wheelRadius;
        float indicatorX = wheelX + wheelRadius + (float)Math.cos((double)angle) * indicatorDistance - 4.0F;
        float indicatorY = wheelY + wheelRadius + (float)Math.sin((double)angle) * indicatorDistance - 4.0F;
        RenderUtil.drawRoundedRect(context, indicatorX - 1.0F, indicatorY - 1.0F, 10.0F, 10.0F, 4.0F, -15198180);
        RenderUtil.drawRoundedRect(context, indicatorX, indicatorY, 8.0F, 8.0F, 4.0F, -1);
        float valueIndicatorY = wheelY + (1.0F - this.colorPickerValue) * 112.0F - 2.0F;
        RenderUtil.drawRoundedRect(context, sliderX - 1.0F, valueIndicatorY, 14.0F, 4.0F, 2.0F, -15198180);
        RenderUtil.drawRoundedRect(context, sliderX, valueIndicatorY + 1.0F, 12.0F, 2.0F, 1.0F, -1);
    }

    private void renderColorValueSlider(DrawContext context, float x, float y) {
        int steps = Math.max(24, Math.round(112.0F));

        for (int step = 0; step < steps; step++) {
            float progress = (float)step / (float)(steps - 1);
            int color = hsvToRgb(this.colorPickerHue, this.colorPickerSaturation, 1.0F - progress);
            float startY = y + progress * 112.0F;
            float endY = y + (float)(step + 1) / (float)steps * 112.0F;
            RenderUtil.drawRoundedRect(context, x, startY, 12.0F, Math.max(1.0F, endY - startY), 0.0F, withAlpha(color, 255));
        }

        drawOutline(context, x, y, 12.0F, 112.0F, -13027005);
    }

    private float getScrollbarThumbHeight() {
        float maxScroll = this.getMaxScroll();
        if (maxScroll <= 0.0F) {
            return 178.0F;
        } else {
            int rows = (int)Math.ceil((double)this.getVisibleEntries().size() / 11.0);
            float contentHeight = Math.max(178.0F, (float)rows * 40.0F - 6.0F);
            return Math.max(24.0F, 31684.0F / contentHeight);
        }
    }

    private float getScrollbarThumbY(float modalY) {
        float trackTop = modalY + 96.0F;
        float maxScroll = this.getMaxScroll();
        float thumbHeight = this.getScrollbarThumbHeight();
        float travel = 178.0F - thumbHeight;
        return !(maxScroll <= 0.0F) && !(travel <= 0.0F) ? trackTop + this.scrollOffset / maxScroll * travel : trackTop;
    }

    private float getModalX(MinecraftClient client) {
        return ((float)client.getWindow().getScaledWidth() - 556.0F) * 0.5F;
    }

    private float getModalY(MinecraftClient client) {
        return ((float)client.getWindow().getScaledHeight() - 350.0F) * 0.5F;
    }

    private float getScrollbarX() {
        MinecraftClient client = MinecraftClient.getInstance();
        return this.getModalX(client) + 503.0F;
    }

    private boolean containsModal(double mouseX, double mouseY, float modalX, float modalY) {
        return contains(mouseX, mouseY, modalX, modalY, 556.0F, 350.0F);
    }

    private boolean containsTab(double mouseX, double mouseY, float modalX, float modalY, BlockEspFeature.SelectorTab tab) {
        float x = tab == BlockEspFeature.SelectorTab.ALL ? modalX + 18.0F : modalX + 160.0F;
        float width = tab == BlockEspFeature.SelectorTab.ALL ? 132.0F : 152.0F;
        return contains(mouseX, mouseY, x, modalY + 42.0F, width, 24.0F);
    }

    private boolean containsSearch(double mouseX, double mouseY, float modalX, float modalY) {
        return contains(mouseX, mouseY, modalX + 18.0F, modalY + 72.0F, 472.0F, 22.0F);
    }

    private boolean containsGrid(double mouseX, double mouseY, float modalX, float modalY) {
        return contains(mouseX, mouseY, modalX + 18.0F, modalY + 96.0F, 472.0F, 178.0F);
    }

    private boolean containsScrollbarTrack(double mouseX, double mouseY, float modalX, float modalY) {
        return contains(mouseX, mouseY, modalX + 503.0F, modalY + 96.0F, 7.0F, 178.0F);
    }

    private boolean containsScrollbarThumb(double mouseX, double mouseY, float modalX, float modalY) {
        return contains(mouseX, mouseY, modalX + 503.0F, this.getScrollbarThumbY(modalY), 7.0F, this.getScrollbarThumbHeight());
    }

    private boolean containsActionButton(double mouseX, double mouseY, float modalX, float modalY, BlockEspFeature.ModalAction action) {
        return switch (action) {
            case CLEAR -> contains(mouseX, mouseY, modalX + 222.0F, modalY + 302.0F, 102.0F, 22.0F);
            case CANCEL -> contains(mouseX, mouseY, modalX + 334.0F, modalY + 302.0F, 102.0F, 22.0F);
            case SAVE -> contains(mouseX, mouseY, modalX + 446.0F, modalY + 302.0F, 92.0F, 22.0F);
        };
    }

    private boolean containsColorPicker(double mouseX, double mouseY) {
        return this.colorPickerBlockId != null
            && contains(mouseX, mouseY, this.colorPickerX, this.colorPickerY, this.getColorPickerWidth(), this.getColorPickerHeight());
    }

    private boolean containsColorWheel(double mouseX, double mouseY) {
        if (this.colorPickerBlockId == null) {
            return false;
        } else {
            float centerX = this.getColorWheelX() + 56.0F;
            float centerY = this.getColorWheelY() + 56.0F;
            float radius = 56.0F;
            double dx = (mouseX - (double)centerX) / (double)radius;
            double dy = (mouseY - (double)centerY) / (double)radius;
            return dx * dx + dy * dy <= 1.0;
        }
    }

    private boolean containsColorValueSlider(double mouseX, double mouseY) {
        return this.colorPickerBlockId != null && contains(mouseX, mouseY, this.getColorValueSliderX(), this.getColorWheelY(), 12.0F, 112.0F);
    }

    private float getColorWheelX() {
        return this.colorPickerX + 10.0F;
    }

    private float getColorWheelY() {
        return this.colorPickerY + 46.0F;
    }

    private float getColorValueSliderX() {
        return this.getColorWheelX() + 112.0F + 10.0F;
    }

    private BlockEspFeature.BlockEntry getEntryAt(double mouseX, double mouseY, float modalX, float modalY) {
        if (!this.containsGrid(mouseX, mouseY, modalX, modalY)) {
            return null;
        } else {
            List<BlockEspFeature.BlockEntry> entries = this.getVisibleEntries();
            float gridX = modalX + 18.0F;
            float gridY = modalY + 96.0F;

            for (int index = 0; index < entries.size(); index++) {
                int column = index % 11;
                int row = index / 11;
                float cellX = gridX + (float)column * 40.0F;
                float cellY = gridY + (float)row * 40.0F - this.scrollOffset;
                if (!(cellY + 34.0F < gridY) && !(cellY > gridY + 178.0F) && contains(mouseX, mouseY, cellX, cellY, 34.0F, 34.0F)) {
                    return entries.get(index);
                }
            }

            return null;
        }
    }

    private boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        return contains(mouseX, mouseY, x, y, width, 88.0F);
    }

    private boolean containsAlphaSlider(double mouseX, double mouseY, float x, float y, float width) {
        return InlineControlRenderer.containsSlider(mouseX, mouseY, x + 10.0F, y + 10.0F, width - 20.0F);
    }

    private boolean containsTracersToggle(double mouseX, double mouseY, float x, float y, float width) {
        return InlineControlRenderer.containsToggle(mouseX, mouseY, x + 10.0F, y + 31.0F, width - 20.0F);
    }

    private boolean containsBlocksLabel(double mouseX, double mouseY, float x, float y, float width) {
        return contains(mouseX, mouseY, x + 10.0F, y + 48.0F, width - 20.0F, 14.0F);
    }

    private boolean containsKeybindButton(double mouseX, double mouseY, float x, float y, float width) {
        return InlineControlRenderer.containsButton(mouseX, mouseY, x + width - 80.0F, y + 65.0F, 70.0F);
    }

    private void loadSelectedBlocks(Set<String> blockIds) {
        this.selectedBlockIds.clear();

        for (String blockId : blockIds) {
            Identifier identifier = Identifier.tryParse(blockId);
            if (identifier != null && Registries.BLOCK.containsId(identifier)) {
                this.selectedBlockIds.add(identifier);
            }
        }

        if (this.selectedBlockIds.isEmpty()) {
            this.selectedBlockIds.add(Identifier.of("minecraft:diamond_ore"));
            this.selectedBlockIds.add(Identifier.of("minecraft:deepslate_diamond_ore"));
        }

        this.rebuildSelectedBlocks();
    }

    private void loadBlockColors(Map<String, Integer> blockColors) {
        this.selectedBlockColors.clear();

        for (Entry<String, Integer> entry : blockColors.entrySet()) {
            Identifier blockId = Identifier.tryParse(entry.getKey());
            Integer color = entry.getValue();
            if (blockId != null && color != null && Registries.BLOCK.containsId(blockId)) {
                this.selectedBlockColors.put(blockId, color & 16777215);
            }
        }
    }

    private boolean isTrackedBlockState(BlockState state) {
        return this.selectedBlocks.contains(state.getBlock());
    }

    private void resetScanState() {
        this.cachedMatchesByChunk.clear();
        this.chunkScanTicks.clear();
        this.chunkRetryTicks.clear();
        this.scanQueue.clear();
        this.queuedChunks.clear();
        this.cachedMatches.clear();
        this.lastScanChunkX = Integer.MIN_VALUE;
        this.lastScanChunkZ = Integer.MIN_VALUE;
        this.lastScanViewDistance = -1;
        this.scanTick = 0;
        this.cachedMatchesDirty = false;
    }

    private int getChunkRadius(int viewDistance) {
        return Math.max(2, viewDistance + 1);
    }

    private void rebuildScanQueue(int centerChunkX, int centerChunkZ, int chunkRadius, boolean clearCachedResults) {
        if (clearCachedResults) {
            this.cachedMatchesByChunk.clear();
            this.chunkScanTicks.clear();
            this.chunkRetryTicks.clear();
            this.cachedMatches.clear();
            this.cachedMatchesDirty = false;
        }

        this.scanQueue.clear();
        this.queuedChunks.clear();

        for (ChunkPos chunkPos : buildScanOrder(centerChunkX, centerChunkZ, chunkRadius)) {
            long chunkKey = toChunkKey(chunkPos.x, chunkPos.z);
            if (clearCachedResults || !this.cachedMatchesByChunk.containsKey(chunkKey)) {
                this.enqueueChunk(chunkKey);
            }
        }
    }

    private void enqueueNewWindowChunks(int oldChunkX, int oldChunkZ, int newChunkX, int newChunkZ, int chunkRadius) {
        if (oldChunkX != Integer.MIN_VALUE && oldChunkZ != Integer.MIN_VALUE && Math.abs(newChunkX - oldChunkX) <= 1 && Math.abs(newChunkZ - oldChunkZ) <= 1) {
            List<ChunkPos> newChunks = new ArrayList<>();

            for (int chunkX = newChunkX - chunkRadius; chunkX <= newChunkX + chunkRadius; chunkX++) {
                for (int chunkZ = newChunkZ - chunkRadius; chunkZ <= newChunkZ + chunkRadius; chunkZ++) {
                    if (Math.abs(chunkX - oldChunkX) > chunkRadius || Math.abs(chunkZ - oldChunkZ) > chunkRadius) {
                        long chunkKey = toChunkKey(chunkX, chunkZ);
                        if (!this.cachedMatchesByChunk.containsKey(chunkKey) && !this.queuedChunks.contains(chunkKey)) {
                            newChunks.add(new ChunkPos(chunkX, chunkZ));
                        }
                    }
                }
            }

            newChunks.sort(Comparator.comparingInt(pos -> chunkDistanceSq(pos.x, pos.z, newChunkX, newChunkZ)));

            for (ChunkPos chunkPos : newChunks) {
                this.enqueueChunk(toChunkKey(chunkPos.x, chunkPos.z));
            }
        } else {
            this.rebuildScanQueue(newChunkX, newChunkZ, chunkRadius, false);
        }
    }

    private void enqueueStaleChunks(int centerChunkX, int centerChunkZ, int chunkRadius) {
        int budget = 8;

        for (Entry<Long, Integer> entry : this.chunkScanTicks.entrySet()) {
            if (budget <= 0) {
                return;
            }

            long chunkKey = entry.getKey();
            ChunkPos chunkPos = fromChunkKey(chunkKey);
            if (isWithinWindow(chunkPos.x, chunkPos.z, centerChunkX, centerChunkZ, chunkRadius)
                && this.scanTick - entry.getValue() >= 180
                && !this.queuedChunks.contains(chunkKey)) {
                this.enqueueChunk(chunkKey);
                budget--;
            }
        }
    }

    private void enqueueReadyChunkRetries(int centerChunkX, int centerChunkZ, int chunkRadius) {
        int budget = 8;
        List<Long> readyKeys = new ArrayList<>();

        for (Entry<Long, Integer> entry : this.chunkRetryTicks.entrySet()) {
            if (budget <= 0) {
                break;
            }

            long chunkKey = entry.getKey();
            ChunkPos chunkPos = fromChunkKey(chunkKey);
            if (!isWithinWindow(chunkPos.x, chunkPos.z, centerChunkX, centerChunkZ, chunkRadius)) {
                readyKeys.add(chunkKey);
            } else if (entry.getValue() <= this.scanTick && !this.queuedChunks.contains(chunkKey)) {
                readyKeys.add(chunkKey);
                this.enqueueChunk(chunkKey);
                budget--;
            }
        }

        for (Long chunkKey : readyKeys) {
            this.chunkRetryTicks.remove(chunkKey);
        }
    }

    private void processScanQueue(MinecraftClient client) {
        if (client.world != null && !this.selectedBlocks.isEmpty()) {
            for (int scanned = 0; scanned < 10 && !this.scanQueue.isEmpty(); scanned++) {
                long chunkKey = this.scanQueue.pollFirst();
                this.queuedChunks.remove(chunkKey);
                this.scanChunk(client, fromChunkKey(chunkKey));
            }
        }
    }

    private void scanChunk(MinecraftClient client, ChunkPos chunkPos) {
        if (client.world != null) {
            WorldChunk chunk = client.world.getChunk(chunkPos.x, chunkPos.z);
            if (chunk != null && !chunk.isEmpty()) {
                List<BlockEspFeature.CachedMatch> matches = new ArrayList<>();
                Mutable mutablePos = new Mutable();
                int bottomSectionCoord = client.world.getBottomSectionCoord();
                ChunkSection[] sections = chunk.getSectionArray();

                for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
                    ChunkSection section = sections[sectionIndex];
                    if (section != null && !section.isEmpty() && section.hasAny(this::isTrackedBlockState)) {
                        int worldX = chunkPos.x << 4;
                        int worldY = ChunkSectionPos.getBlockCoord(bottomSectionCoord + sectionIndex);
                        int worldZ = chunkPos.z << 4;

                        for (int localX = 0; localX < 16; localX++) {
                            for (int localY = 0; localY < 16; localY++) {
                                for (int localZ = 0; localZ < 16; localZ++) {
                                    BlockState state = section.getBlockState(localX, localY, localZ);
                                    Block block = state.getBlock();
                                    if (this.selectedBlocks.contains(block)) {
                                        mutablePos.set(worldX + localX, worldY + localY, worldZ + localZ);
                                        VoxelShape outlineShape = state.getOutlineShape(client.world, mutablePos, ShapeContext.absent());
                                        if (outlineShape.isEmpty()) {
                                            outlineShape = VoxelShapes.fullCube();
                                        }

                                        matches.add(
                                            new BlockEspFeature.CachedMatch(mutablePos.toImmutable(), Registries.BLOCK.getId(block), outlineShape)
                                        );
                                    }
                                }
                            }
                        }
                    }
                }

                long chunkKey = toChunkKey(chunkPos.x, chunkPos.z);
                this.cachedMatchesByChunk.put(chunkKey, matches);
                this.chunkScanTicks.put(chunkKey, this.scanTick);
                this.chunkRetryTicks.remove(chunkKey);
                this.cachedMatchesDirty = true;
            } else {
                this.chunkRetryTicks.put(toChunkKey(chunkPos.x, chunkPos.z), this.scanTick + 30);
            }
        }
    }

    private void cleanupDistant(int centerChunkX, int centerChunkZ, int chunkRadius) {
        boolean removedMatches = this.cachedMatchesByChunk.keySet().removeIf(chunkKey -> {
            ChunkPos chunkPos = fromChunkKey(chunkKey);
            return !isWithinWindow(chunkPos.x, chunkPos.z, centerChunkX, centerChunkZ, chunkRadius);
        });
        if (removedMatches) {
            this.cachedMatchesDirty = true;
        }

        this.chunkScanTicks.keySet().removeIf(chunkKey -> {
            ChunkPos chunkPos = fromChunkKey(chunkKey);
            return !isWithinWindow(chunkPos.x, chunkPos.z, centerChunkX, centerChunkZ, chunkRadius);
        });
        this.chunkRetryTicks.keySet().removeIf(chunkKey -> {
            ChunkPos chunkPos = fromChunkKey(chunkKey);
            return !isWithinWindow(chunkPos.x, chunkPos.z, centerChunkX, centerChunkZ, chunkRadius);
        });
        this.scanQueue.removeIf(chunkKey -> {
            ChunkPos chunkPos = fromChunkKey(chunkKey);
            return !isWithinWindow(chunkPos.x, chunkPos.z, centerChunkX, centerChunkZ, chunkRadius);
        });
        this.queuedChunks.removeIf(chunkKey -> {
            ChunkPos chunkPos = fromChunkKey(chunkKey);
            return !isWithinWindow(chunkPos.x, chunkPos.z, centerChunkX, centerChunkZ, chunkRadius);
        });
    }

    private void rebuildCachedMatches() {
        this.cachedMatches.clear();

        for (List<BlockEspFeature.CachedMatch> chunkMatches : this.cachedMatchesByChunk.values()) {
            this.cachedMatches.addAll(chunkMatches);
        }

        this.cachedMatchesDirty = false;
    }

    private static List<ChunkPos> buildScanOrder(int centerChunkX, int centerChunkZ, int chunkRadius) {
        List<ChunkPos> positions = new ArrayList<>();

        for (int chunkX = centerChunkX - chunkRadius; chunkX <= centerChunkX + chunkRadius; chunkX++) {
            for (int chunkZ = centerChunkZ - chunkRadius; chunkZ <= centerChunkZ + chunkRadius; chunkZ++) {
                positions.add(new ChunkPos(chunkX, chunkZ));
            }
        }

        positions.sort(
            Comparator.<ChunkPos>comparingInt(pos -> chunkDistanceSq(pos.x, pos.z, centerChunkX, centerChunkZ))
                .thenComparingInt(pos -> Math.abs(pos.x - centerChunkX) + Math.abs(pos.z - centerChunkZ))
        );
        return positions;
    }

    private static boolean isWithinWindow(int chunkX, int chunkZ, int centerChunkX, int centerChunkZ, int chunkRadius) {
        return Math.abs(chunkX - centerChunkX) <= chunkRadius && Math.abs(chunkZ - centerChunkZ) <= chunkRadius;
    }

    private void enqueueChunk(long chunkKey) {
        if (this.queuedChunks.add(chunkKey)) {
            this.scanQueue.addLast(chunkKey);
        }
    }

    private void queueTracerTarget(PriorityQueue<BlockEspFeature.TracerTarget> tracerTargets, BlockPos blockPos, Vec3d cameraPos, int rgbColor) {
        double targetX = (double)blockPos.getX() + 0.5;
        double targetY = (double)blockPos.getY() + 0.5;
        double targetZ = (double)blockPos.getZ() + 0.5;
        double dx = targetX - cameraPos.x;
        double dy = targetY - cameraPos.y;
        double dz = targetZ - cameraPos.z;
        double distanceSq = dx * dx + dy * dy + dz * dz;
        tracerTargets.add(new BlockEspFeature.TracerTarget(blockPos, rgbColor, distanceSq));
        if (tracerTargets.size() > 64) {
            tracerTargets.poll();
        }
    }

    private static long toChunkKey(int chunkX, int chunkZ) {
        return (long)chunkX << 32 ^ (long)chunkZ & 4294967295L;
    }

    private static ChunkPos fromChunkKey(long chunkKey) {
        return new ChunkPos((int)(chunkKey >> 32), (int)chunkKey);
    }

    private static int chunkDistanceSq(int chunkX, int chunkZ, int centerChunkX, int centerChunkZ) {
        int dx = chunkX - centerChunkX;
        int dz = chunkZ - centerChunkZ;
        return dx * dx + dz * dz;
    }

    private void rebuildSelectedBlocks() {
        this.selectedBlocks.clear();

        for (Identifier blockId : this.selectedBlockIds) {
            if (Registries.BLOCK.containsId(blockId)) {
                Block block = (Block)Registries.BLOCK.get(blockId);
                if (block != null && block.asItem() != Items.AIR) {
                    this.selectedBlocks.add(block);
                }
            }
        }
    }

    private void openColorPicker(Identifier blockId, double mouseX, double mouseY, float modalX, float modalY) {
        float width = this.getColorPickerWidth();
        float height = this.getColorPickerHeight();
        int currentColor = this.getConfiguredBlockColor(this.draftBlockColors, blockId);
        this.ensureColorWheelTexture();
        this.colorPickerBlockId = blockId;
        this.colorPickerX = clamp((float)mouseX + 10.0F, modalX + 18.0F, modalX + 556.0F - width - 18.0F);
        this.colorPickerY = clamp((float)mouseY - 8.0F, modalY + 38.0F, modalY + 350.0F - height - 18.0F);
        float[] hsv = this.findClosestWheelHsv(currentColor);
        this.colorPickerHue = hsv[0];
        this.colorPickerSaturation = hsv[1];
        this.colorPickerValue = hsv[2];
    }

    private void closeColorPicker() {
        this.colorPickerBlockId = null;
        this.draggingColorWheel = false;
        this.draggingColorValue = false;
    }

    private void applyDraftBlockColor(Identifier blockId, int color) {
        this.draftBlockIds.add(blockId);
        if ((color & 16777215) == 16773851) {
            this.draftBlockColors.remove(blockId);
        } else {
            this.draftBlockColors.put(blockId, color & 16777215);
        }

        this.clampScroll();
    }

    private float getColorPickerWidth() {
        return 154.0F;
    }

    private float getColorPickerHeight() {
        return 168.0F;
    }

    private void ensureColorWheelTexture() {
        if (this.colorWheelTexture == null) {
            int size = Math.round(112.0F);
            NativeImage image = new NativeImage(size, size, true);
            this.colorWheelPixels = new int[size * size];
            float radius = (float)size * 0.5F;

            for (int y = 0; y < size; y++) {
                for (int x = 0; x < size; x++) {
                    float normalizedX = ((float)x + 0.5F - radius) / radius;
                    float normalizedY = ((float)y + 0.5F - radius) / radius;
                    float distance = (float)Math.sqrt((double)(normalizedX * normalizedX + normalizedY * normalizedY));
                    if (distance > 1.0F) {
                        this.colorWheelPixels[y * size + x] = 0;
                        image.setColor(x, y, 0);
                    } else {
                        float hue = normalizeHue((float)(Math.atan2((double)normalizedY, (double)normalizedX) / (Math.PI * 2)));
                        int color = hsvToRgb(hue, clamp(distance, 0.0F, 1.0F), 1.0F);
                        int argbColor = withAlpha(color, 255);
                        this.colorWheelPixels[y * size + x] = argbColor;
                        image.setColor(x, y, argbToAbgr(argbColor));
                    }
                }
            }

            this.colorWheelTexture = new NativeImageBackedTexture(() -> "block-esp-color-wheel", image);
            MinecraftClient.getInstance().getTextureManager().registerTexture(COLOR_WHEEL_TEXTURE_ID, this.colorWheelTexture);
        }
    }

    private void updateColorFromWheel(double mouseX, double mouseY) {
        if (this.colorPickerBlockId != null) {
            float radius = 56.0F;
            float centerX = this.getColorWheelX() + radius;
            float centerY = this.getColorWheelY() + radius;
            float dx = (float)((mouseX - (double)centerX) / (double)radius);
            float dy = (float)((mouseY - (double)centerY) / (double)radius);
            float distance = (float)Math.sqrt((double)(dx * dx + dy * dy));
            if (distance > 1.0F && distance > 0.0F) {
                dx /= distance;
                dy /= distance;
                distance = 1.0F;
            }

            if (distance > 1.0E-4F) {
                this.colorPickerHue = normalizeHue((float)(Math.atan2((double)dy, (double)dx) / (Math.PI * 2)));
            }

            this.colorPickerSaturation = clamp(distance, 0.0F, 1.0F);
            this.syncPickerToDisplayedWheel(dx, dy);
            this.applyDraftCurrentPickerColor();
        }
    }

    private void updateColorFromValue(double mouseY) {
        if (this.colorPickerBlockId != null) {
            float relative = clamp((float)((mouseY - (double)this.getColorWheelY()) / 112.0), 0.0F, 1.0F);
            this.colorPickerValue = 1.0F - relative;
            this.applyDraftCurrentPickerColor();
        }
    }

    private void applyDraftCurrentPickerColor() {
        if (this.colorPickerBlockId != null) {
            this.applyDraftBlockColor(this.colorPickerBlockId, hsvToRgb(this.colorPickerHue, this.colorPickerSaturation, this.colorPickerValue));
        }
    }

    private void syncPickerToDisplayedWheel(float dx, float dy) {
        if (this.colorWheelPixels != null) {
            int imageSize = Math.round(112.0F);
            int sampleX = Math.max(0, Math.min(imageSize - 1, Math.round((dx * 0.5F + 0.5F) * (float)(imageSize - 1))));
            int sampleY = Math.max(0, Math.min(imageSize - 1, Math.round((dy * 0.5F + 0.5F) * (float)(imageSize - 1))));
            int sampledColor = this.colorWheelPixels[sampleY * imageSize + sampleX];
            if (alpha(sampledColor) > 0) {
                float[] hsv = rgbToHsv(sampledColor);
                this.colorPickerHue = hsv[0];
                this.colorPickerSaturation = hsv[1];
            }
        }
    }

    private float[] findClosestWheelHsv(int rgbColor) {
        if (this.colorWheelPixels == null) {
            return rgbToHsv(rgbColor);
        } else {
            int width = Math.round(112.0F);
            int height = width;
            int bestDistance = Integer.MAX_VALUE;
            float bestHue = 0.0F;
            float bestSaturation = 0.0F;

            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    int pixel = this.colorWheelPixels[y * width + x];
                    if (alpha(pixel) > 0) {
                        int colorDistance = colorDistanceSquared(pixel, rgbColor);
                        if (colorDistance < bestDistance) {
                            float normalizedX = ((float)x + 0.5F) / (float)width * 2.0F - 1.0F;
                            float normalizedY = ((float)y + 0.5F) / (float)height * 2.0F - 1.0F;
                            float distance = (float)Math.sqrt((double)(normalizedX * normalizedX + normalizedY * normalizedY));
                            if (!(distance > 1.0F)) {
                                bestDistance = colorDistance;
                                bestHue = normalizeHue((float)(Math.atan2((double)normalizedY, (double)normalizedX) / (Math.PI * 2)));
                                bestSaturation = clamp(distance, 0.0F, 1.0F);
                            }
                        }
                    }
                }
            }

            float[] hsv = rgbToHsv(rgbColor);
            hsv[0] = bestHue;
            hsv[1] = bestSaturation;
            return hsv;
        }
    }

    private int getConfiguredBlockColor(Map<Identifier, Integer> colorMap, Identifier blockId) {
        return colorMap.getOrDefault(blockId, 16773851);
    }

    private int toOutlineColor(int rgbColor) {
        return (this.alpha & 0xFF) << 24 | rgbColor & 16777215;
    }

    private int toFillColor(int rgbColor) {
        int fillAlpha = Math.max(24, Math.min(96, this.alpha / 2));
        return fillAlpha << 24 | rgbColor & 16777215;
    }

    private static int hsvToRgb(float hue, float saturation, float value) {
        float wrappedHue = normalizeHue(hue) * 6.0F;
        float clampedSaturation = clamp(saturation, 0.0F, 1.0F);
        float clampedValue = clamp(value, 0.0F, 1.0F);
        int sector = (int)Math.floor((double)wrappedHue);
        float fraction = wrappedHue - (float)sector;
        float p = clampedValue * (1.0F - clampedSaturation);
        float q = clampedValue * (1.0F - fraction * clampedSaturation);
        float t = clampedValue * (1.0F - (1.0F - fraction) * clampedSaturation);
        float red;
        float green;
        float blue;
        switch (sector % 6) {
            case 0:
                red = clampedValue;
                green = t;
                blue = p;
                break;
            case 1:
                red = q;
                green = clampedValue;
                blue = p;
                break;
            case 2:
                red = p;
                green = clampedValue;
                blue = t;
                break;
            case 3:
                red = p;
                green = q;
                blue = clampedValue;
                break;
            case 4:
                red = t;
                green = p;
                blue = clampedValue;
                break;
            default:
                red = clampedValue;
                green = p;
                blue = q;
        }

        return Math.round(red * 255.0F) << 16 | Math.round(green * 255.0F) << 8 | Math.round(blue * 255.0F);
    }

    private static float[] rgbToHsv(int rgbColor) {
        float red = (float)red(rgbColor) / 255.0F;
        float green = (float)green(rgbColor) / 255.0F;
        float blue = (float)blue(rgbColor) / 255.0F;
        float max = Math.max(red, Math.max(green, blue));
        float min = Math.min(red, Math.min(green, blue));
        float delta = max - min;
        float hue = 0.0F;
        if (delta > 0.0F) {
            if (max == red) {
                hue = (green - blue) / delta % 6.0F;
            } else if (max == green) {
                hue = (blue - red) / delta + 2.0F;
            } else {
                hue = (red - green) / delta + 4.0F;
            }

            hue /= 6.0F;
        }

        float saturation = max <= 0.0F ? 0.0F : delta / max;
        return new float[]{normalizeHue(hue), saturation, max};
    }

    private static float normalizeHue(float hue) {
        float normalized = hue % 1.0F;
        return normalized < 0.0F ? normalized + 1.0F : normalized;
    }

    private static String toHexColor(int color) {
        return String.format(Locale.ROOT, "%06X", color & 16777215);
    }

    private static List<BlockEspFeature.BlockEntry> buildBlockOptions() {
        List<BlockEspFeature.BlockEntry> entries = new ArrayList<>();

        for (Block block : Registries.BLOCK) {
            if (block.asItem() != Items.AIR) {
                Identifier id = Registries.BLOCK.getId(block);
                if (id != null) {
                    ItemStack icon = new ItemStack(block.asItem());
                    String displayName = icon.getName().getString();
                    String searchValue = (displayName + " " + id + " " + id.getPath()).toLowerCase(Locale.ROOT);
                    entries.add(new BlockEspFeature.BlockEntry(id, icon, displayName, searchValue));
                }
            }
        }

        entries.sort(Comparator.comparing(BlockEspFeature.BlockEntry::displayName, String.CASE_INSENSITIVE_ORDER));
        return List.copyOf(entries);
    }

    private static boolean contains(double mouseX, double mouseY, float x, float y, float width, float height) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + height);
    }

    private static void drawOutline(DrawContext context, float x, float y, float width, float height, int color) {
        int left = Math.round(x);
        int top = Math.round(y);
        int right = Math.round(x + width);
        int bottom = Math.round(y + height);
        context.fill(left, top, right, top + 1, color);
        context.fill(left, bottom - 1, right, bottom, color);
        context.fill(left, top + 1, left + 1, bottom - 1, color);
        context.fill(right - 1, top + 1, right, bottom - 1, color);
    }

    private static String formatBlockCount(int count) {
        return count + (count == 1 ? " BLOCK" : " BLOCKS");
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static int withAlpha(int color, int alpha) {
        return (alpha & 0xFF) << 24 | color & 16777215;
    }

    private static int red(int color) {
        return color >> 16 & 0xFF;
    }

    private static int green(int color) {
        return color >> 8 & 0xFF;
    }

    private static int blue(int color) {
        return color & 0xFF;
    }

    private static int alpha(int color) {
        return color >> 24 & 0xFF;
    }

    private static int colorDistanceSquared(int leftColor, int rightColor) {
        int redDelta = red(leftColor) - red(rightColor);
        int greenDelta = green(leftColor) - green(rightColor);
        int blueDelta = blue(leftColor) - blue(rightColor);
        return redDelta * redDelta + greenDelta * greenDelta + blueDelta * blueDelta;
    }

    private static int argbToAbgr(int color) {
        return alpha(color) << 24 | blue(color) << 16 | green(color) << 8 | red(color);
    }

    private static record BlockEntry(Identifier id, ItemStack icon, String displayName, String searchValue) {
    }

    private static record CachedMatch(BlockPos pos, Identifier blockId, VoxelShape shape) {
    }

    private static enum ModalAction {
        CLEAR("CLEAR ALL"),
        CANCEL("CANCEL"),
        SAVE("SAVE");

        private final String label;

        private ModalAction(String label) {
            this.label = label;
        }
    }

    private static record QueuedOutline(VoxelShape shape, double x, double y, double z) {
    }

    private static enum SelectorTab {
        ALL,
        SELECTED;
    }

    private static record TracerTarget(BlockPos pos, int rgbColor, double distanceSq) {
    }
}
