package dev.darg.client.feature.visual;

import dev.darg.client.DargsClient;
import dev.darg.client.config.ClientConfig;
import dev.darg.client.config.FeatureSettingParse;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.clickgui.InlineControlRenderer;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class SwingSpeedFeature extends Feature {
    private static final float MIN_MULT = 0.25F;
    private static final float MAX_MULT = 2.0F;
    private static final float INLINE_HEIGHT = 58.0F;
    private final ClientConfig config = ClientConfig.getInstance();
    private float speedMultiplier = 1.0F;
    private boolean draggingSlider;

    public SwingSpeedFeature() {
        super("SwingSpeed", Category.RENDER);
        this.reloadFromConfig();
    }

    private void reloadFromConfig() {
        this.speedMultiplier = FeatureSettingParse.parseFloat(this.config.getFeatureSetting(this.getConfigKey(), "multiplier"), 1.0F, 0.25F, 2.0F);
    }

    public float getSwingSpeedMultiplier() {
        return !this.isEnabled() ? 1.0F : this.speedMultiplier;
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 58.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        float cx = x + 10.0F;
        float cw = width - 20.0F;
        if (this.draggingSlider) {
            this.setMultFromMouse((double)mouseX, cx, cw);
        }

        float sliderY = y + 8.0F;
        float ratio = (this.speedMultiplier - 0.25F) / 1.75F;
        String valueLabel = String.format(Locale.ROOT, "%.2fx", this.speedMultiplier);
        InlineControlRenderer.drawSlider(context, textRenderer, theme, "SWING SPEED", valueLabel, cx, sliderY, cw, ratio);
        float keybindY = y + 36.0F;
        float bindW = 70.0F;
        float bindX = x + width - bindW - 10.0F;
        boolean capturing = DargsClient.getInstance().getKeybindManager().isCapturing(this);
        boolean hoverBind = InlineControlRenderer.containsButton((double)mouseX, (double)mouseY, bindX, keybindY, bindW);
        String bindLabel = InlineControlRenderer.fitText(
            textRenderer, DargsClient.getInstance().getKeybindManager().getBindLabel(this).toUpperCase(Locale.ROOT), 58
        );
        InlineControlRenderer.drawButton(context, textRenderer, theme, bindLabel, capturing, hoverBind, bindX, keybindY, bindW);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (!this.containsInline(mouseX, mouseY, x, y, width)) {
            return false;
        } else {
            float cx = x + 10.0F;
            float cw = width - 20.0F;
            if (button == 0 && this.containsSlider(mouseX, mouseY, x, y, width)) {
                this.draggingSlider = true;
                this.setMultFromMouse(mouseX, cx, cw);
                return true;
            } else {
                float bindW = 70.0F;
                float bindX = x + width - bindW - 10.0F;
                float keybindY = y + 36.0F;
                if (button == 0 && InlineControlRenderer.containsButton(mouseX, mouseY, bindX, keybindY, bindW)) {
                    DargsClient.getInstance().getKeybindManager().beginCapture(this, notificationManager);
                    return true;
                } else if (button == 1 && InlineControlRenderer.containsButton(mouseX, mouseY, bindX, keybindY, bindW)) {
                    DargsClient.getInstance().getKeybindManager().clearBind(this, notificationManager);
                    return true;
                } else {
                    return true;
                }
            }
        }
    }

    @Override
    public boolean onCustomClickGuiMouseReleased(double mouseX, double mouseY, int button, float x, float y, float width) {
        if (this.draggingSlider) {
            this.draggingSlider = false;
            this.config.setFeatureSetting(this.getConfigKey(), "multiplier", String.format(Locale.ROOT, "%.4f", this.speedMultiplier));
            this.config.save();
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isClickGuiInteractionActive() {
        return this.draggingSlider;
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("Multiplier: " + String.format(Locale.ROOT, "%.2fx", this.speedMultiplier), "Higher = faster swing animation");
    }

    private void setMultFromMouse(double mouseX, float cx, float cw) {
        float ratio = Math.max(0.0F, Math.min(1.0F, (float)((mouseX - (double)cx) / (double)cw)));
        this.speedMultiplier = 0.25F + ratio * 1.75F;
    }

    private boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + 58.0F);
    }

    private boolean containsSlider(double mouseX, double mouseY, float x, float y, float width) {
        float cx = x + 10.0F;
        float cw = width - 20.0F;
        float trackY = y + 8.0F + 14.0F;
        return mouseX >= (double)cx && mouseX <= (double)(cx + cw) && mouseY >= (double)(trackY - 5.0F) && mouseY <= (double)(trackY + 12.0F);
    }
}
