package dev.darg.client.ui.entry;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.stream.ImageInputStream;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public final class AnimatedGifBackground {
    private static final String GIF_IMAGE_METADATA = "javax_imageio_gif_image_1.0";
    private static final String GIF_STREAM_METADATA = "javax_imageio_gif_stream_1.0";
    private static final String DISPOSAL_RESTORE_TO_BACKGROUND = "restoreToBackgroundColor";
    private static final String DISPOSAL_RESTORE_TO_PREVIOUS = "restoreToPrevious";
    private final String resourcePath;
    private final String texturePrefix;
    private final boolean coverScreen;
    private final int extraBlurPasses;
    private final List<AnimatedGifBackground.GifFrame> frames = new ArrayList<>();
    private boolean loaded;
    private int totalDurationMs;
    private int preparedScreenWidth;
    private int preparedScreenHeight;

    public AnimatedGifBackground(String resourcePath) {
        this(resourcePath, true, 0);
    }

    public AnimatedGifBackground(String resourcePath, int extraBlurPasses) {
        this(resourcePath, true, extraBlurPasses);
    }

    public AnimatedGifBackground(String resourcePath, boolean coverScreen, int extraBlurPasses) {
        this.resourcePath = resourcePath;
        this.coverScreen = coverScreen;
        this.extraBlurPasses = Math.max(0, extraBlurPasses);
        this.texturePrefix = Integer.toUnsignedString((resourcePath + "|" + coverScreen + "|" + extraBlurPasses).hashCode());
    }

    public void render(DrawContext context, int screenWidth, int screenHeight, long timeMs) {
        this.ensureLoaded(screenWidth, screenHeight);
        if (this.frames.isEmpty()) {
            context.fill(0, 0, screenWidth, screenHeight, -16248546);
        } else {
            AnimatedGifBackground.GifFrame frame = this.frameAt(timeMs);
            float scale = scaleFactor(screenWidth, screenHeight, frame.width(), frame.height(), this.coverScreen);
            int drawWidth = Math.max(1, Math.round((float)frame.width() * scale));
            int drawHeight = Math.max(1, Math.round((float)frame.height() * scale));
            int drawX = (screenWidth - drawWidth) / 2;
            int drawY = (screenHeight - drawHeight) / 2;
            context.drawTexture(
                RenderPipelines.GUI_TEXTURED,
                frame.textureId(),
                drawX,
                drawY,
                0.0F,
                0.0F,
                drawWidth,
                drawHeight,
                frame.width(),
                frame.height(),
                frame.width(),
                frame.height()
            );
        }
    }

    private AnimatedGifBackground.GifFrame frameAt(long timeMs) {
        if (this.frames.size() != 1 && this.totalDurationMs > 0) {
            int timeline = Math.floorMod((int)timeMs, this.totalDurationMs);
            int cursor = 0;

            for (AnimatedGifBackground.GifFrame frame : this.frames) {
                cursor += frame.durationMs();
                if (timeline < cursor) {
                    return frame;
                }
            }

            return this.frames.getLast();
        } else {
            return this.frames.getFirst();
        }
    }

    private void ensureLoaded(int screenWidth, int screenHeight) {
        if (!this.loaded || this.preparedScreenWidth < screenWidth || this.preparedScreenHeight < screenHeight) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null) {
                this.clear(client);
                this.loaded = true;
                this.preparedScreenWidth = Math.max(1, screenWidth);
                this.preparedScreenHeight = Math.max(1, screenHeight);

                try {
                    label196: {
                        try (InputStream stream = AnimatedGifBackground.class.getResourceAsStream(this.resourcePath)) {
                            if (stream != null) {
                                Iterator<ImageReader> readers = ImageIO.getImageReadersByFormatName("gif");
                                if (!readers.hasNext()) {
                                    return;
                                }

                                ImageReader reader = readers.next();

                                try (ImageInputStream imageInput = ImageIO.createImageInputStream(stream)) {
                                    reader.setInput(imageInput, false, false);
                                    int frameCount = reader.getNumImages(true);
                                    AnimatedGifBackground.GifCanvas canvas = readCanvas(reader);
                                    BufferedImage composedFrame = new BufferedImage(canvas.width(), canvas.height(), 2);

                                    for (int index = 0; index < frameCount; index++) {
                                        AnimatedGifBackground.FrameInfo frameInfo = readFrameInfo(
                                            reader.getImageMetadata(index), canvas.width(), canvas.height()
                                        );
                                        BufferedImage image = reader.read(index);
                                        BufferedImage previousFrame = "restoreToPrevious".equals(frameInfo.disposalMethod()) ? copyImage(composedFrame) : null;
                                        composeFrame(composedFrame, image, frameInfo, canvas);
                                        BufferedImage scaledImage = scaleToScreen(
                                            composedFrame, this.preparedScreenWidth, this.preparedScreenHeight, this.coverScreen, this.extraBlurPasses
                                        );
                                        NativeImage nativeImage = toNativeImage(scaledImage);
                                        Identifier textureId = Identifier.of(
                                            "dargsclient", "ui/animated_background_" + this.texturePrefix + "_" + index
                                        );
                                        int frameIndex = index;
                                        NativeImageBackedTexture texture = new NativeImageBackedTexture(
                                            () -> "animated-background-" + this.texturePrefix + "-" + frameIndex, nativeImage
                                        );
                                        client.getTextureManager().registerTexture(textureId, texture);
                                        int durationMs = Math.max(40, frameInfo.durationMs());
                                        this.frames
                                            .add(new AnimatedGifBackground.GifFrame(textureId, scaledImage.getWidth(), scaledImage.getHeight(), durationMs));
                                        this.totalDurationMs += durationMs;
                                        applyDisposal(composedFrame, previousFrame, frameInfo, canvas);
                                    }
                                    break label196;
                                } finally {
                                    reader.dispose();
                                }
                            }
                        }

                        return;
                    }
                } catch (IOException var33) {
                    this.clear(client);
                }
            }
        }
    }

    private void clear(MinecraftClient client) {
        for (AnimatedGifBackground.GifFrame frame : this.frames) {
            client.getTextureManager().destroyTexture(frame.textureId());
        }

        this.frames.clear();
        this.totalDurationMs = 0;
    }

    private static AnimatedGifBackground.GifCanvas readCanvas(ImageReader reader) throws IOException {
        IIOMetadata metadata = reader.getStreamMetadata();
        int width = reader.getWidth(0);
        int height = reader.getHeight(0);
        if (metadata == null) {
            return new AnimatedGifBackground.GifCanvas(width, height);
        } else {
            Node root = metadata.getAsTree("javax_imageio_gif_stream_1.0");
            ArrayDeque<Node> nodes = new ArrayDeque<>();
            nodes.add(root);

            while (!nodes.isEmpty()) {
                Node current = nodes.removeFirst();
                if ("LogicalScreenDescriptor".equals(current.getNodeName())) {
                    NamedNodeMap attributes = current.getAttributes();
                    if (attributes != null) {
                        width = readInt(attributes.getNamedItem("logicalScreenWidth"), width);
                        height = readInt(attributes.getNamedItem("logicalScreenHeight"), height);
                    }
                }

                for (Node child = current.getFirstChild(); child != null; child = child.getNextSibling()) {
                    nodes.add(child);
                }
            }

            return new AnimatedGifBackground.GifCanvas(width, height);
        }
    }

    private static AnimatedGifBackground.FrameInfo readFrameInfo(IIOMetadata metadata, int canvasWidth, int canvasHeight) {
        int x = 0;
        int y = 0;
        int width = canvasWidth;
        int height = canvasHeight;
        int durationMs = 100;
        String disposalMethod = "";
        if (metadata == null) {
            return new AnimatedGifBackground.FrameInfo(x, y, canvasWidth, canvasHeight, durationMs, disposalMethod);
        } else {
            Node root = metadata.getAsTree("javax_imageio_gif_image_1.0");
            ArrayDeque<Node> nodes = new ArrayDeque<>();
            nodes.add(root);

            while (!nodes.isEmpty()) {
                Node current = nodes.removeFirst();
                NamedNodeMap attributes = current.getAttributes();
                if ("GraphicControlExtension".equals(current.getNodeName()) && attributes != null) {
                    durationMs = Math.max(10, readInt(attributes.getNamedItem("delayTime"), 10) * 10);
                    Node disposalNode = attributes.getNamedItem("disposalMethod");
                    if (disposalNode != null) {
                        disposalMethod = disposalNode.getNodeValue();
                    }
                }

                if ("ImageDescriptor".equals(current.getNodeName()) && attributes != null) {
                    x = readInt(attributes.getNamedItem("imageLeftPosition"), x);
                    y = readInt(attributes.getNamedItem("imageTopPosition"), y);
                    width = readInt(attributes.getNamedItem("imageWidth"), width);
                    height = readInt(attributes.getNamedItem("imageHeight"), height);
                }

                for (Node child = current.getFirstChild(); child != null; child = child.getNextSibling()) {
                    nodes.add(child);
                }
            }

            return new AnimatedGifBackground.FrameInfo(x, y, width, height, durationMs, disposalMethod);
        }
    }

    private static void composeFrame(
        BufferedImage composedFrame, BufferedImage image, AnimatedGifBackground.FrameInfo frameInfo, AnimatedGifBackground.GifCanvas canvas
    ) {
        Graphics2D graphics = composedFrame.createGraphics();

        try {
            graphics.setComposite(AlphaComposite.SrcOver);
            if (image.getWidth() == canvas.width() && image.getHeight() == canvas.height()) {
                graphics.drawImage(image, 0, 0, null);
            } else {
                graphics.drawImage(image, frameInfo.x(), frameInfo.y(), null);
            }
        } finally {
            graphics.dispose();
        }
    }

    private static void applyDisposal(
        BufferedImage composedFrame, BufferedImage previousFrame, AnimatedGifBackground.FrameInfo frameInfo, AnimatedGifBackground.GifCanvas canvas
    ) {
        if ("restoreToPrevious".equals(frameInfo.disposalMethod()) && previousFrame != null) {
            Graphics2D graphics = composedFrame.createGraphics();

            try {
                graphics.setComposite(AlphaComposite.Src);
                graphics.drawImage(previousFrame, 0, 0, null);
            } finally {
                graphics.dispose();
            }
        } else {
            if ("restoreToBackgroundColor".equals(frameInfo.disposalMethod())) {
                int clearWidth = Math.max(0, Math.min(frameInfo.width(), canvas.width() - frameInfo.x()));
                int clearHeight = Math.max(0, Math.min(frameInfo.height(), canvas.height() - frameInfo.y()));
                if (clearWidth == 0 || clearHeight == 0) {
                    return;
                }

                Graphics2D graphics = composedFrame.createGraphics();

                try {
                    graphics.setComposite(AlphaComposite.Clear);
                    graphics.fillRect(Math.max(0, frameInfo.x()), Math.max(0, frameInfo.y()), clearWidth, clearHeight);
                } finally {
                    graphics.dispose();
                }
            }
        }
    }

    private static BufferedImage copyImage(BufferedImage image) {
        BufferedImage copy = new BufferedImage(image.getWidth(), image.getHeight(), 2);
        Graphics2D graphics = copy.createGraphics();

        try {
            graphics.setComposite(AlphaComposite.Src);
            graphics.drawImage(image, 0, 0, null);
        } finally {
            graphics.dispose();
        }

        return copy;
    }

    private static int readInt(Node node, int fallback) {
        if (node == null) {
            return fallback;
        } else {
            try {
                return Integer.parseInt(node.getNodeValue());
            } catch (NumberFormatException var3) {
                return fallback;
            }
        }
    }

    private static NativeImage toNativeImage(BufferedImage image) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        ImageIO.write(image, "png", output);
        return NativeImage.read(output.toByteArray());
    }

    private static BufferedImage scaleToScreen(BufferedImage image, int screenWidth, int screenHeight, boolean coverScreen, int extraBlurPasses) {
        float scale = scaleFactor(screenWidth, screenHeight, image.getWidth(), image.getHeight(), coverScreen);
        int targetWidth = Math.max(1, Math.round((float)image.getWidth() * scale));
        int targetHeight = Math.max(1, Math.round((float)image.getHeight() * scale));
        BufferedImage current = image;
        int currentWidth = image.getWidth();
        int currentHeight = image.getHeight();

        while (currentWidth < targetWidth || currentHeight < targetHeight) {
            int nextWidth = Math.min(targetWidth, Math.max(currentWidth + 1, currentWidth * 2));
            int nextHeight = Math.min(targetHeight, Math.max(currentHeight + 1, currentHeight * 2));
            BufferedImage next = new BufferedImage(nextWidth, nextHeight, 2);
            Graphics2D graphics = next.createGraphics();

            try {
                graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                graphics.drawImage(current, 0, 0, nextWidth, nextHeight, null);
            } finally {
                graphics.dispose();
            }

            current = next;
            currentWidth = nextWidth;
            currentHeight = nextHeight;
        }

        if (scale > 1.4F) {
            current = soften(current, scale > 2.3F ? 2 : 1);
        }

        if (extraBlurPasses > 0) {
            current = soften(current, extraBlurPasses);
        }

        return current;
    }

    private static float scaleFactor(int screenWidth, int screenHeight, int contentWidth, int contentHeight, boolean coverScreen) {
        float widthScale = (float)screenWidth / (float)Math.max(1, contentWidth);
        float heightScale = (float)screenHeight / (float)Math.max(1, contentHeight);
        return coverScreen ? Math.max(widthScale, heightScale) : Math.min(widthScale, heightScale);
    }

    private static BufferedImage soften(BufferedImage image, int passes) {
        float[] kernelData = new float[]{0.0625F, 0.125F, 0.0625F, 0.125F, 0.25F, 0.125F, 0.0625F, 0.125F, 0.0625F};
        ConvolveOp blur = new ConvolveOp(new Kernel(3, 3, kernelData), 1, null);
        BufferedImage current = image;

        for (int pass = 0; pass < passes; pass++) {
            BufferedImage softened = new BufferedImage(current.getWidth(), current.getHeight(), 2);
            blur.filter(current, softened);
            current = softened;
        }

        return current;
    }

    private static record FrameInfo(int x, int y, int width, int height, int durationMs, String disposalMethod) {
    }

    private static record GifCanvas(int width, int height) {
    }

    private static record GifFrame(Identifier textureId, int width, int height, int durationMs) {
    }
}
