package dev.darg.client.feature.utility;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public final class FreecamController {
    private static final double DEFAULT_SPEED = 0.45;
    private static final double MIN_SPEED = 0.1;
    private static final double MAX_SPEED = 3.5;
    private static final double SPEED_STEP = 1.2;
    private static final FreecamController INSTANCE = new FreecamController();
    private FreecamController.ActionSource actionSource = FreecamController.ActionSource.CAMERA;
    private OtherClientPlayerEntity raycastEntity;
    private boolean active;
    private Vec3d previousCameraPos = Vec3d.ZERO;
    private Vec3d cameraPos = Vec3d.ZERO;
    private float cameraYaw;
    private float cameraPitch;
    private double speed = 0.45;
    private PlayerInput latchedPlayerInput = PlayerInput.DEFAULT;
    private Vec2f latchedMovementVector = Vec2f.ZERO;
    private boolean latchedAttack;
    private boolean latchedUse;

    private FreecamController() {
    }

    public static FreecamController getInstance() {
        return INSTANCE;
    }

    public boolean enable(FreecamController.ActionSource actionSource) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && client.world != null) {
            if (this.active) {
                this.disable();
            }

            this.actionSource = actionSource;
            this.cameraPos = client.player.getCameraPosVec(1.0F);
            this.previousCameraPos = this.cameraPos;
            this.cameraYaw = client.player.getYaw();
            this.cameraPitch = client.player.getPitch();
            this.captureActionState(client);
            this.raycastEntity = this.createRaycastEntity(client.player);
            this.syncRaycastEntity();
            client.chunkCullingEnabled = false;
            this.active = true;
            return true;
        } else {
            return false;
        }
    }

    public void disable() {
        if (this.active) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null) {
                client.chunkCullingEnabled = true;
                this.restoreActionKeys(client);
            }

            this.raycastEntity = null;
            this.previousCameraPos = Vec3d.ZERO;
            this.cameraPos = Vec3d.ZERO;
            this.latchedPlayerInput = PlayerInput.DEFAULT;
            this.latchedMovementVector = Vec2f.ZERO;
            this.latchedAttack = false;
            this.latchedUse = false;
            this.active = false;
        }
    }

    public void tick() {
        if (this.active) {
            MinecraftClient client = MinecraftClient.getInstance();
            ClientPlayerEntity player = client.player;
            if (player != null && client.world != null && this.raycastEntity != null) {
                if (this.actionSource == FreecamController.ActionSource.PLAYER) {
                    this.syncLatchedActionKeys(client);
                }

                this.previousCameraPos = this.cameraPos;
                double moveSpeed = this.speed;
                if (client.options.sprintKey.isPressed()) {
                    moveSpeed *= 2.2;
                }

                Vec3d movement = Vec3d.ZERO;
                float radians = this.cameraYaw * (float) (Math.PI / 180.0);
                double sin = Math.sin((double)radians);
                double cos = Math.cos((double)radians);
                Vec3d forward = new Vec3d(-sin, 0.0, cos);
                Vec3d right = new Vec3d(-cos, 0.0, -sin);
                if (client.options.forwardKey.isPressed()) {
                    movement = movement.add(forward);
                }

                if (client.options.backKey.isPressed()) {
                    movement = movement.subtract(forward);
                }

                if (client.options.leftKey.isPressed()) {
                    movement = movement.subtract(right);
                }

                if (client.options.rightKey.isPressed()) {
                    movement = movement.add(right);
                }

                if (client.options.jumpKey.isPressed()) {
                    movement = movement.add(0.0, 1.0, 0.0);
                }

                if (client.options.sneakKey.isPressed()) {
                    movement = movement.add(0.0, -1.0, 0.0);
                }

                if (movement.lengthSquared() > 0.0) {
                    movement = movement.normalize().multiply(moveSpeed);
                    this.cameraPos = this.cameraPos.add(movement);
                }

                this.syncRaycastEntity();
            } else {
                this.disable();
            }
        }
    }

    public boolean isActive() {
        return this.active && this.raycastEntity != null;
    }

    public OtherClientPlayerEntity getRaycastEntity() {
        return this.raycastEntity;
    }

    public boolean usesPlayerActionSource() {
        return this.isActive() && this.actionSource == FreecamController.ActionSource.PLAYER;
    }

    public boolean usesCameraActionSource() {
        return this.isActive() && this.actionSource == FreecamController.ActionSource.CAMERA;
    }

    public PlayerInput getLatchedPlayerInput() {
        return this.latchedPlayerInput;
    }

    public Vec2f getLatchedMovementVector() {
        return this.latchedMovementVector;
    }

    public void applyMouseLook(double deltaX, double deltaY) {
        if (this.isActive()) {
            this.cameraPitch = MathHelper.clamp(this.cameraPitch + (float)(deltaY * 0.15F), -90.0F, 90.0F);
            this.cameraYaw = MathHelper.wrapDegrees(this.cameraYaw + (float)(deltaX * 0.15F));
            this.syncRaycastEntity();
        }
    }

    public Vec3d getCameraPos() {
        return this.cameraPos;
    }

    public Vec3d getRenderCameraPos(float tickProgress) {
        return this.previousCameraPos.lerp(this.cameraPos, (double)tickProgress);
    }

    public float getCameraYaw() {
        return this.cameraYaw;
    }

    public float getCameraPitch() {
        return this.cameraPitch;
    }

    public double getSpeed() {
        return this.speed;
    }

    public void adjustSpeed(double scrollAmount) {
        if (this.isActive() && scrollAmount != 0.0) {
            int steps = Math.max(1, (int)Math.round(Math.abs(scrollAmount)));
            double factor = Math.pow(1.2, (double)steps);
            this.speed = scrollAmount > 0.0 ? this.speed * factor : this.speed / factor;
            this.speed = MathHelper.clamp(this.speed, 0.1, 3.5);
        }
    }

    public HitResult getPlayerActionTarget(float tickProgress) {
        MinecraftClient client = MinecraftClient.getInstance();
        return this.usesPlayerActionSource() && client.player != null ? client.player.getCrosshairTarget(tickProgress, client.player) : null;
    }

    public HitResult getCameraActionTarget(float tickProgress) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (this.usesCameraActionSource() && client.player != null && this.raycastEntity != null) {
            this.syncRaycastEntity();
            return client.player.getCrosshairTarget(tickProgress, this.raycastEntity);
        } else {
            return null;
        }
    }

    public Entity getCameraActionEntity(float tickProgress) {
        return this.getCameraActionTarget(tickProgress) instanceof EntityHitResult entityHitResult ? entityHitResult.getEntity() : null;
    }

    public Entity getPlayerActionEntity(float tickProgress) {
        return this.getPlayerActionTarget(tickProgress) instanceof EntityHitResult entityHitResult ? entityHitResult.getEntity() : null;
    }

    private OtherClientPlayerEntity createRaycastEntity(ClientPlayerEntity player) {
        GameProfile profile = player.getGameProfile();
        OtherClientPlayerEntity entity = new OtherClientPlayerEntity((ClientWorld)player.getEntityWorld(), profile);
        entity.copyPositionAndRotation(player);
        entity.setHeadYaw(player.getHeadYaw());
        entity.setBodyYaw(player.getBodyYaw());
        entity.noClip = true;
        entity.setNoGravity(true);
        return entity;
    }

    private void captureActionState(MinecraftClient client) {
        if (this.actionSource == FreecamController.ActionSource.PLAYER && client != null) {
            boolean forward = client.options.forwardKey.isPressed();
            boolean backward = client.options.backKey.isPressed();
            boolean left = client.options.leftKey.isPressed();
            boolean right = client.options.rightKey.isPressed();
            boolean jump = client.options.jumpKey.isPressed();
            boolean sneak = client.options.sneakKey.isPressed();
            boolean sprint = client.options.sprintKey.isPressed();
            this.latchedPlayerInput = new PlayerInput(forward, backward, left, right, jump, sneak, sprint);
            this.latchedMovementVector = new Vec2f(movementMultiplier(left, right), movementMultiplier(forward, backward)).normalize();
            this.latchedAttack = client.options.attackKey.isPressed();
            this.latchedUse = client.options.useKey.isPressed();
        } else {
            this.latchedPlayerInput = PlayerInput.DEFAULT;
            this.latchedMovementVector = Vec2f.ZERO;
            this.latchedAttack = false;
            this.latchedUse = false;
        }
    }

    private void syncLatchedActionKeys(MinecraftClient client) {
        if (client.currentScreen == null) {
            client.options.attackKey.setPressed(client.options.attackKey.isPressed() || this.latchedAttack);
            client.options.useKey.setPressed(client.options.useKey.isPressed() || this.latchedUse);
        }
    }

    private void restoreActionKeys(MinecraftClient client) {
        long window = client.getWindow().getHandle();
        client.options.attackKey.setPressed(GLFW.glfwGetMouseButton(window, 0) == 1);
        client.options.useKey.setPressed(GLFW.glfwGetMouseButton(window, 1) == 1);
    }

    private static float movementMultiplier(boolean negative, boolean positive) {
        if (negative == positive) {
            return 0.0F;
        } else {
            return negative ? 1.0F : -1.0F;
        }
    }

    private void syncRaycastEntity() {
        if (this.raycastEntity != null) {
            float eyeHeight = this.raycastEntity.getStandingEyeHeight();
            Vec3d basePos = this.cameraPos.subtract(0.0, (double)eyeHeight, 0.0);
            this.raycastEntity.setPosition(basePos.x, basePos.y, basePos.z);
            this.raycastEntity.setYaw(this.cameraYaw);
            this.raycastEntity.setPitch(this.cameraPitch);
            this.raycastEntity.setHeadYaw(this.cameraYaw);
            this.raycastEntity.setBodyYaw(this.cameraYaw);
            this.raycastEntity.setVelocity(Vec3d.ZERO);
            this.raycastEntity.setNoGravity(true);
            this.raycastEntity.noClip = true;
            this.raycastEntity.lastX = basePos.x;
            this.raycastEntity.lastY = basePos.y;
            this.raycastEntity.lastZ = basePos.z;
            this.raycastEntity.lastRenderX = basePos.x;
            this.raycastEntity.lastRenderY = basePos.y;
            this.raycastEntity.lastRenderZ = basePos.z;
            this.raycastEntity.lastYaw = this.cameraYaw;
            this.raycastEntity.lastPitch = this.cameraPitch;
        }
    }

    public static enum ActionSource {
        CAMERA,
        PLAYER;
    }
}
