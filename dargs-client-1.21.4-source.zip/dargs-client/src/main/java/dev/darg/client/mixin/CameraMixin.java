package dev.darg.client.mixin;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.utility.FreeLookFeature;
import dev.darg.client.feature.utility.FreecamController;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Camera.class})
public abstract class CameraMixin {
    @Shadow
    private float cameraY;
    @Shadow
    private float lastCameraY;

    @Shadow
    protected abstract void setRotation(float var1, float var2);

    @Shadow
    protected abstract void setPos(double var1, double var3, double var5);

    @Shadow
    protected abstract void moveBy(float var1, float var2, float var3);

    @Shadow
    protected abstract float clipToSpace(float var1);

    @Inject(
        method = {"update"},
        at = {@At("TAIL")}
    )
    private void dargsclient$applyFreeLook(
        World world, Entity focusedEntity, boolean thirdPerson, boolean inverseView, float tickProgress, CallbackInfo callbackInfo
    ) {
        FreecamController freecamController = FreecamController.getInstance();
        if (freecamController.isActive()) {
            Vec3d cameraPos = freecamController.getRenderCameraPos(tickProgress);
            this.setRotation(freecamController.getCameraYaw(), freecamController.getCameraPitch());
            this.setPos(cameraPos.x, cameraPos.y, cameraPos.z);
        } else {
            DargsClient client = DargsClient.getInstance();
            if (client != null) {
                FreeLookFeature freeLookFeature = client.getFeatureManager().getFeature(FreeLookFeature.class);
                if (freeLookFeature != null && freeLookFeature.shouldOverrideCamera(focusedEntity)) {
                    float cameraYaw = freeLookFeature.getCameraYaw(focusedEntity, tickProgress);
                    float cameraPitch = freeLookFeature.getCameraPitch(focusedEntity, tickProgress);
                    if (!thirdPerson) {
                        this.setRotation(cameraYaw, cameraPitch);
                    } else {
                        double baseX = MathHelper.lerp((double)tickProgress, focusedEntity.lastX, focusedEntity.getX());
                        double baseY = MathHelper.lerp((double)tickProgress, focusedEntity.lastY, focusedEntity.getY())
                            + (double)MathHelper.lerp(tickProgress, this.lastCameraY, this.cameraY);
                        double baseZ = MathHelper.lerp((double)tickProgress, focusedEntity.lastZ, focusedEntity.getZ());
                        float renderYaw = inverseView ? cameraYaw + 180.0F : cameraYaw;
                        float renderPitch = inverseView ? -cameraPitch : cameraPitch;
                        float cameraDistance = 4.0F;
                        float scale = 1.0F;
                        if (focusedEntity instanceof LivingEntity livingEntity) {
                            scale = livingEntity.getScale();
                            cameraDistance = (float)livingEntity.getAttributeValue(EntityAttributes.CAMERA_DISTANCE);
                        }

                        this.setPos(baseX, baseY, baseZ);
                        this.setRotation(renderYaw, renderPitch);
                        this.moveBy(-this.clipToSpace(cameraDistance * scale), 0.0F, 0.0F);
                    }
                }
            }
        }
    }
}
