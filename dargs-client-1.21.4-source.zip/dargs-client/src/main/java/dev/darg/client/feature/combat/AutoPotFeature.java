package dev.darg.client.feature.combat;

import dev.darg.client.feature.Category;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;

public final class AutoPotFeature extends ConfigurableCombatFeature {
    private final ConfigurableCombatFeature.NumberSetting minHealth = this.intSetting("min_health", "Min Health", 10, 1, 20);
    private final ConfigurableCombatFeature.NumberSetting switchDelay = this.intSetting("switch_delay", "Switch Delay", 0, 0, 10);
    private final ConfigurableCombatFeature.NumberSetting throwDelay = this.intSetting("throw_delay", "Throw Delay", 0, 0, 10);
    private final ConfigurableCombatFeature.BooleanSetting goToPrevSlot = this.booleanSetting("switch_back", "Switch Back", true);
    private final ConfigurableCombatFeature.BooleanSetting lookDown = this.booleanSetting("look_down", "Look Down", true);
    private int switchClock;
    private int throwClock;
    private int previousSlot = -1;
    private float previousPitch = Float.NaN;
    private boolean healing;

    public AutoPotFeature() {
        super("AutoPot", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        this.switchClock = 0;
        this.throwClock = 0;
        this.previousSlot = -1;
        this.previousPitch = Float.NaN;
        this.healing = false;
    }

    @Override
    protected void onDisable() {
        this.restoreState();
        this.healing = false;
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        ClientPlayerInteractionManager interactionManager = client.interactionManager;
        if (player != null && interactionManager != null && client.world != null && client.currentScreen == null) {
            boolean shouldHeal = player.getHealth() <= (float)this.minHealth.intValue() || this.healing;
            if (!shouldHeal) {
                if (this.healing) {
                    this.restoreState();
                }
            } else {
                this.healing = true;
                if (player.getHealth() >= player.getMaxHealth()) {
                    this.restoreState();
                    this.healing = false;
                } else {
                    if (this.previousSlot < 0) {
                        this.previousSlot = player.getInventory().getSelectedSlot();
                    }

                    if (Float.isNaN(this.previousPitch)) {
                        this.previousPitch = player.getPitch();
                    }

                    if (this.switchClock < this.switchDelay.intValue()) {
                        this.switchClock++;
                    } else if (CombatSupport.isSplashInstantHealth(player.getMainHandStack())) {
                        if (this.throwClock < this.throwDelay.intValue()) {
                            this.throwClock++;
                        } else {
                            if (this.lookDown.get()) {
                                player.setPitch(90.0F);
                            }

                            ActionResult result = interactionManager.interactItem(player, Hand.MAIN_HAND);
                            if (result.isAccepted()) {
                                player.swingHand(Hand.MAIN_HAND);
                            }

                            this.throwClock = 0;
                        }
                    } else if (!this.selectSplashPotion(client, player)) {
                        this.restoreState();
                        this.healing = false;
                    } else {
                        this.switchClock = 0;
                        this.throwClock = 0;
                    }
                }
            }
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("Heal below: " + this.minHealth.intValue() + " HP", "Switch back: " + this.goToPrevSlot.get(), "Look down: " + this.lookDown.get());
    }

    private boolean selectSplashPotion(MinecraftClient client, ClientPlayerEntity player) {
        int hotbarSlot = CombatSupport.findHotbarInstantHealthSplash(player);
        if (hotbarSlot >= 0) {
            return CombatSupport.selectHotbarSlot(player, hotbarSlot);
        } else {
            int inventorySlot = CombatSupport.findInventoryInstantHealthSplash(player);
            if (inventorySlot < 0) {
                return false;
            } else if (player.playerScreenHandler == null) {
                return false;
            } else {
                int selectedSlot = player.getInventory().getSelectedSlot();
                int screenSlot = CombatSupport.screenSlotFromInventory(inventorySlot);
                client.interactionManager.clickSlot(player.playerScreenHandler.syncId, screenSlot, selectedSlot, SlotActionType.SWAP, player);
                return true;
            }
        }
    }

    private void restoreState() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null) {
            this.reset();
        } else {
            if (this.goToPrevSlot.get() && this.previousSlot >= 0) {
                CombatSupport.selectHotbarSlot(player, this.previousSlot);
            }

            if (!Float.isNaN(this.previousPitch)) {
                player.setPitch(this.previousPitch);
            }

            this.reset();
        }
    }

    private void reset() {
        this.switchClock = 0;
        this.throwClock = 0;
        this.previousSlot = -1;
        this.previousPitch = Float.NaN;
    }
}
