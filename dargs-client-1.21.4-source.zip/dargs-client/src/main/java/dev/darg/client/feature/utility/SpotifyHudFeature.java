package dev.darg.client.feature.utility;

import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.spotify.SpotifyNowPlayingService;
import dev.darg.client.ui.clickgui.ClickGuiScreen;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public final class SpotifyHudFeature extends Feature {
    private static final int PANEL_COLOR = -652995564;
    private static final int SHADOW_COLOR = 1342177280;
    private static final int ACCENT = -3365;
    private static final int WHITE = -1;
    private static final int SOFT_GRAY = -6447715;
    private static final int DARK_TEXT = -15592942;
    private static final int BAR_COLOR = -14013910;
    private static final float WIDTH = 196.0F;
    private static final float HEIGHT = 66.0F;
    private static final float ART_FRAME_SIZE = 46.0F;
    private static final float ART_INNER_SIZE = 44.0F;
    private final SpotifyNowPlayingService spotifyService = new SpotifyNowPlayingService();
    private final ClientConfig config = ClientConfig.getInstance();
    private boolean dragging;
    private float dragOffsetX;
    private float dragOffsetY;

    public SpotifyHudFeature() {
        super("MediaWidget", Category.SETTINGS);
    }

    @Override
    public void onTick() {
        this.spotifyService.tick();
    }

    @Override
    public void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && !(client.currentScreen instanceof ClickGuiScreen)) {
            this.renderWidget(context, client.textRenderer, -1, -1, false);
        }
    }

    @Override
    public void onClickGuiRender(DrawContext context, int mouseX, int mouseY, float delta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (this.dragging) {
            this.updateDrag(mouseX, mouseY, client);
        }

        this.renderWidget(context, client.textRenderer, mouseX, mouseY, true);
    }

    @Override
    public boolean onClickGuiMouseClicked(double mouseX, double mouseY, int button) {
        if (!this.contains(mouseX, mouseY)) {
            return false;
        } else if (button == 0) {
            this.dragging = true;
            this.dragOffsetX = (float)mouseX - this.config.getSpotifyHudX();
            this.dragOffsetY = (float)mouseY - this.config.getSpotifyHudY();
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean onClickGuiMouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0 && this.dragging) {
            this.dragging = false;
            this.config.save();
            return true;
        } else {
            return false;
        }
    }

    @Override
    protected void onDisable() {
        this.dragging = false;
    }

    @Override
    public List<String> getClickGuiDetails() {
        SpotifyNowPlayingService.PlaybackState playbackState = this.spotifyService.getPlaybackState();
        String connectionState;
        if (playbackState.mode() == SpotifyNowPlayingService.Mode.TRACK) {
            connectionState = playbackState.playing() ? "Playing" : "Paused";
        } else if (playbackState.mode() == SpotifyNowPlayingService.Mode.IDLE) {
            connectionState = "Idle";
        } else if (playbackState.mode() == SpotifyNowPlayingService.Mode.UNSUPPORTED) {
            connectionState = "Unsupported";
        } else {
            connectionState = "Unavailable";
        }

        return List.of(
            "State: " + (this.isEnabled() ? "Enabled" : "Disabled"),
            "Source: " + (playbackState.sourceApp().isBlank() ? "None" : playbackState.sourceApp()),
            "Status: " + connectionState,
            "Widget: Uses system media session"
        );
    }

    @Override
    public List<Feature.ClickGuiAction> getClickGuiActions() {
        return List.of(new Feature.ClickGuiAction("media_refresh", "Refresh Session", false));
    }

    @Override
    public boolean handleClickGuiAction(String actionId, NotificationManager notificationManager) {
        byte var4 = -1;
        switch (actionId.hashCode()) {
            case -310016640:
                if (actionId.equals("media_refresh")) {
                    var4 = 0;
                }
            default:
                return switch (var4) {
                    case 0 -> {
                        this.spotifyService.requestImmediateRefresh();
                        notificationManager.push("Media session refresh queued", NotificationManager.Type.INFO);
                        yield true;
                    }
                    default -> false;
                };
        }
    }

    private void renderWidget(DrawContext context, TextRenderer textRenderer, int mouseX, int mouseY, boolean editing) {
        SpotifyNowPlayingService.PlaybackState playbackState = this.spotifyService.getPlaybackState();
        SpotifyNowPlayingService.ArtworkTexture artworkTexture = this.spotifyService.getArtworkTexture();
        float x = this.config.getSpotifyHudX();
        float y = this.config.getSpotifyHudY();
        boolean hovered = editing && this.contains((double)mouseX, (double)mouseY);
        RenderUtil.drawRoundedRect(context, x + 2.0F, y + 3.0F, 196.0F, 66.0F, 9.0F, 1342177280);
        RenderUtil.drawRoundedRect(context, x, y, 196.0F, 66.0F, 9.0F, -652995564);
        RenderUtil.drawRoundedRect(context, x + 10.0F, y + 10.0F, 46.0F, 46.0F, 8.0F, hovered ? 872413420 : 587199195);
        if (artworkTexture != null) {
            this.renderArtwork(context, artworkTexture, x + 11.0F, y + 11.0F);
        } else {
            RenderUtil.drawRoundedRect(context, x + 17.0F, y + 17.0F, 32.0F, 32.0F, 7.0F, -3365);
            RenderUtil.drawText(context, textRenderer, "M", x + 28.0F, y + 28.0F, -15592942);
        }

        String badge = editing
            ? (this.dragging ? "HOLD" : "MOVE")
            : fit(textRenderer, playbackState.sourceApp().isBlank() ? "MEDIA" : playbackState.sourceApp(), 54);
        int badgeWidth = textRenderer.getWidth(badge);
        RenderUtil.drawText(context, textRenderer, badge, x + 196.0F - (float)badgeWidth - 10.0F, y + 10.0F, -6447715);
        RenderUtil.drawText(context, textRenderer, fit(textRenderer, playbackState.title(), 120), x + 64.0F, y + 12.0F, -1);
        RenderUtil.drawText(context, textRenderer, fit(textRenderer, playbackState.subtitle(), 120), x + 64.0F, y + 25.0F, -6447715);
        this.renderProgress(context, textRenderer, x + 64.0F, y + 43.0F, 118.0F, playbackState);
    }

    private void renderArtwork(DrawContext context, SpotifyNowPlayingService.ArtworkTexture artworkTexture, float x, float y) {
        int textureWidth = Math.max(1, artworkTexture.width());
        int textureHeight = Math.max(1, artworkTexture.height());
        float scale = Math.min(44.0F / (float)textureWidth, 44.0F / (float)textureHeight);
        int drawWidth = Math.max(1, Math.round((float)textureWidth * scale));
        int drawHeight = Math.max(1, Math.round((float)textureHeight * scale));
        int drawX = Math.round(x + (44.0F - (float)drawWidth) * 0.5F);
        int drawY = Math.round(y + (44.0F - (float)drawHeight) * 0.5F);
        int clipLeft = Math.round(x);
        int clipTop = Math.round(y);
        int clipRight = Math.round(x + 44.0F);
        int clipBottom = Math.round(y + 44.0F);
        context.enableScissor(clipLeft, clipTop, clipRight, clipBottom);

        try {
            context.drawTexture(
                RenderPipelines.GUI_TEXTURED,
                artworkTexture.textureId(),
                drawX,
                drawY,
                0.0F,
                0.0F,
                drawWidth,
                drawHeight,
                textureWidth,
                textureHeight,
                textureWidth,
                textureHeight
            );
        } finally {
            context.disableScissor();
        }
    }

    private void renderProgress(
        DrawContext context, TextRenderer textRenderer, float x, float y, float width, SpotifyNowPlayingService.PlaybackState playbackState
    ) {
        long durationMs = Math.max(playbackState.durationMs(), 1L);
        long progressMs = resolveProgress(playbackState);
        float progress = playbackState.mode() == SpotifyNowPlayingService.Mode.TRACK
            ? Math.max(0.0F, Math.min(1.0F, (float)progressMs / (float)durationMs))
            : 0.0F;
        String leftTime = formatTime(progressMs);
        String rightTime = formatTime(playbackState.durationMs());
        RenderUtil.drawRoundedRect(context, x, y, width, 6.0F, 3.0F, -14013910);
        RenderUtil.drawRoundedRect(context, x, y, width * progress, 6.0F, 3.0F, -3365);
        RenderUtil.drawText(context, textRenderer, leftTime, x, y + 10.0F, -6447715);
        RenderUtil.drawText(context, textRenderer, rightTime, x + width - (float)textRenderer.getWidth(rightTime), y + 10.0F, -6447715);
    }

    private void updateDrag(int mouseX, int mouseY, MinecraftClient client) {
        float maxX = Math.max(6.0F, (float)client.getWindow().getScaledWidth() - 196.0F - 6.0F);
        float maxY = Math.max(6.0F, (float)client.getWindow().getScaledHeight() - 66.0F - 6.0F);
        float nextX = Math.max(6.0F, Math.min(maxX, (float)mouseX - this.dragOffsetX));
        float nextY = Math.max(6.0F, Math.min(maxY, (float)mouseY - this.dragOffsetY));
        this.config.setSpotifyHudPosition(nextX, nextY);
    }

    private boolean contains(double mouseX, double mouseY) {
        float x = this.config.getSpotifyHudX();
        float y = this.config.getSpotifyHudY();
        return mouseX >= (double)x && mouseX <= (double)(x + 196.0F) && mouseY >= (double)y && mouseY <= (double)(y + 66.0F);
    }

    private static long resolveProgress(SpotifyNowPlayingService.PlaybackState playbackState) {
        if (playbackState.mode() != SpotifyNowPlayingService.Mode.TRACK) {
            return 0L;
        } else if (!playbackState.playing()) {
            return playbackState.progressMs();
        } else {
            long elapsed = System.currentTimeMillis() - playbackState.fetchedAtMs();
            return Math.min(playbackState.durationMs(), playbackState.progressMs() + Math.max(0L, elapsed));
        }
    }

    private static String fit(TextRenderer textRenderer, String value, int maxWidth) {
        if (textRenderer.getWidth(value) <= maxWidth) {
            return value;
        } else {
            String ellipsis = "...";
            String trimmed = value;

            while (!trimmed.isEmpty() && textRenderer.getWidth(trimmed + ellipsis) > maxWidth) {
                trimmed = trimmed.substring(0, trimmed.length() - 1);
            }

            return trimmed + ellipsis;
        }
    }

    private static String formatTime(long milliseconds) {
        long totalSeconds = Math.max(0L, milliseconds / 1000L);
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%d:%02d", minutes, seconds);
    }
}
