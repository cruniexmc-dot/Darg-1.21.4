package dev.darg.client.config.local;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.google.gson.annotations.SerializedName;
import dev.darg.client.config.snapshot.ConfigSnapshot;
import dev.darg.client.config.snapshot.ConfigSnapshotSerializer;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Stream;
import net.fabricmc.loader.api.FabricLoader;

public final class LocalConfigProfileStore {
    private static final Path PROFILE_DIR = FabricLoader.getInstance().getConfigDir().resolve("dargsclient-profiles");
    private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create();
    private static final int MAX_PROFILE_NAME_LENGTH = 48;

    public synchronized List<LocalConfigProfile> listProfiles() {
        ArrayList<LocalConfigProfile> profiles = new ArrayList<>();
        if (!Files.isDirectory(PROFILE_DIR)) {
            return profiles;
        } else {
            try (Stream<Path> stream = Files.list(PROFILE_DIR)) {
                stream.filter(path -> path.getFileName().toString().endsWith(".json")).forEach(path -> {
                    LocalConfigProfile profile = this.readProfile(path);
                    if (profile != null) {
                        profiles.add(profile);
                    }
                });
            } catch (IOException var7) {
            }

            profiles.sort(Comparator.comparing(LocalConfigProfile::updatedAt).reversed());
            return List.copyOf(profiles);
        }
    }

    public synchronized LocalConfigProfile loadProfile(String id) {
        return this.readProfile(profilePath(id));
    }

    public synchronized LocalConfigProfile saveProfile(String name, ConfigSnapshot snapshot) {
        Instant now = Instant.now();
        LocalConfigProfile profile = new LocalConfigProfile(
            UUID.randomUUID().toString(), sanitizeProfileName(name), snapshot == null ? ConfigSnapshotSerializer.exportLocalSnapshot() : snapshot, now, now
        );
        this.writeProfile(profile);
        return profile;
    }

    public synchronized LocalConfigProfile overwriteProfile(String id, ConfigSnapshot snapshot) {
        LocalConfigProfile existing = this.loadProfile(id);
        if (existing == null) {
            return null;
        } else {
            LocalConfigProfile updated = new LocalConfigProfile(
                existing.id(),
                existing.name(),
                snapshot == null ? ConfigSnapshotSerializer.exportLocalSnapshot() : snapshot,
                existing.createdAt(),
                Instant.now()
            );
            this.writeProfile(updated);
            return updated;
        }
    }

    public synchronized LocalConfigProfile renameProfile(String id, String newName) {
        LocalConfigProfile existing = this.loadProfile(id);
        if (existing == null) {
            return null;
        } else {
            LocalConfigProfile renamed = new LocalConfigProfile(
                existing.id(), sanitizeProfileName(newName), existing.snapshot(), existing.createdAt(), Instant.now()
            );
            this.writeProfile(renamed);
            return renamed;
        }
    }

    public synchronized LocalConfigProfile duplicateProfile(String id, String newName) {
        LocalConfigProfile existing = this.loadProfile(id);
        return existing == null
            ? null
            : this.saveProfile(sanitizeProfileName(newName != null && !newName.isBlank() ? newName : existing.name() + " Copy"), existing.snapshot());
    }

    public synchronized boolean deleteProfile(String id) {
        if (id != null && !id.isBlank()) {
            try {
                return Files.deleteIfExists(profilePath(id));
            } catch (IOException var3) {
                return false;
            }
        } else {
            return false;
        }
    }

    public synchronized Path getProfileDirectory() {
        return PROFILE_DIR;
    }

    private LocalConfigProfile readProfile(Path path) {
        if (path != null && Files.exists(path)) {
            try {
                LocalConfigProfile var5;
                try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                    LocalConfigProfileStore.StoredProfile stored = (LocalConfigProfileStore.StoredProfile)GSON.fromJson(
                        reader, LocalConfigProfileStore.StoredProfile.class
                    );
                    if (stored == null) {
                        return null;
                    }

                    ConfigSnapshot snapshot = new ConfigSnapshot(
                        stored.schemaVersion <= 0 ? 1 : stored.schemaVersion,
                        stored.clientVersion != null && !stored.clientVersion.isBlank()
                            ? stored.clientVersion
                            : ConfigSnapshotSerializer.resolveClientVersion(),
                        stored.values == null ? Map.of() : stored.values
                    );
                    var5 = new LocalConfigProfile(
                        stored.id != null && !stored.id.isBlank() ? stored.id : stripJsonExtension(path.getFileName().toString()),
                        sanitizeProfileName(stored.name),
                        snapshot,
                        parseInstant(stored.createdAt),
                        parseInstant(stored.updatedAt)
                    );
                }

                return var5;
            } catch (JsonSyntaxException | IOException var8) {
                return null;
            }
        } else {
            return null;
        }
    }

    private void writeProfile(LocalConfigProfile profile) {
        if (profile != null && !profile.id().isBlank()) {
            try {
                Files.createDirectories(PROFILE_DIR);
                LocalConfigProfileStore.StoredProfile stored = new LocalConfigProfileStore.StoredProfile();
                stored.id = profile.id();
                stored.name = sanitizeProfileName(profile.name());
                stored.schemaVersion = profile.schemaVersion();
                stored.clientVersion = profile.clientVersion();
                stored.createdAt = profile.createdAt().toString();
                stored.updatedAt = profile.updatedAt().toString();
                stored.values = new LinkedHashMap<>(profile.snapshot().values());

                try (Writer writer = Files.newBufferedWriter(profilePath(profile.id()), StandardCharsets.UTF_8)) {
                    GSON.toJson(stored, writer);
                }
            } catch (IOException var8) {
            }
        }
    }

    private static Path profilePath(String id) {
        return PROFILE_DIR.resolve(sanitizeProfileId(id) + ".json");
    }

    private static String sanitizeProfileId(String id) {
        if (id != null && !id.isBlank()) {
            String sanitized = id.trim().replaceAll("[^a-zA-Z0-9._-]", "");
            return sanitized.isBlank() ? UUID.randomUUID().toString() : sanitized;
        } else {
            return UUID.randomUUID().toString();
        }
    }

    private static String sanitizeProfileName(String name) {
        String sanitized = name == null ? "" : name.trim().replaceAll("\\s+", " ");
        if (sanitized.isEmpty()) {
            sanitized = "New Profile";
        }

        if (sanitized.length() > 48) {
            sanitized = sanitized.substring(0, 48);
        }

        return sanitized;
    }

    private static String stripJsonExtension(String fileName) {
        return fileName != null && fileName.endsWith(".json") ? fileName.substring(0, fileName.length() - 5) : (fileName == null ? "" : fileName);
    }

    private static Instant parseInstant(String value) {
        if (value != null && !value.isBlank()) {
            try {
                return Instant.parse(value);
            } catch (DateTimeParseException var2) {
                return Instant.now();
            }
        } else {
            return Instant.now();
        }
    }

    private static final class StoredProfile {
        String id;
        String name;
        @SerializedName("schema_version")
        int schemaVersion;
        @SerializedName("client_version")
        String clientVersion;
        @SerializedName("created_at")
        String createdAt;
        @SerializedName("updated_at")
        String updatedAt;
        Map<String, String> values;
    }
}
