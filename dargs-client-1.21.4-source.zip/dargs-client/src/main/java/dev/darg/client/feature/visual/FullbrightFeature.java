package dev.darg.client.feature.visual;

import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import java.util.List;
import net.minecraft.client.MinecraftClient;

public final class FullbrightFeature extends Feature {
    private double savedGamma = 1.0;

    public FullbrightFeature() {
        super("Fullbright", Category.RENDER);
    }

    @Override
    protected void onEnable() {
        MinecraftClient client = MinecraftClient.getInstance();
        this.savedGamma = (Double)client.options.getGamma().getValue();
        client.options.getGamma().setValue(16.0);
    }

    @Override
    protected void onDisable() {
        MinecraftClient.getInstance().options.getGamma().setValue(this.savedGamma);
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("State: " + (this.isEnabled() ? "Enabled" : "Disabled"));
    }
}
