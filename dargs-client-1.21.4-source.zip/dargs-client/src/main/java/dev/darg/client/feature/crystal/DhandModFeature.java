package dev.darg.client.feature.crystal;

import dev.darg.client.DargsClient;
import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.clickgui.InlineControlRenderer;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.Items;

public final class DhandModFeature extends Feature {
    private static final float INLINE_HEIGHT = 66.0F;
    private static final int OPEN_DELAY = 1;
    private final ClientConfig config = ClientConfig.getInstance();
    private int totemSlot;
    private boolean draggingSlot;
    private boolean pendingOpen = false;
    private int delayRemaining = 0;

    public DhandModFeature() {
        super("DhandMod", Category.CRYSTAL);
        this.totemSlot = this.config.getDhandModTotemSlot();
    }

    @Override
    protected void onEnable() {
        this.pendingOpen = false;
        this.delayRemaining = 0;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.world != null) {
            if (mc.currentScreen != null) {
                this.pendingOpen = false;
            } else if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                this.pendingOpen = false;
            } else if (mc.player.getInventory().getSelectedSlot() != this.totemSlot) {
                this.pendingOpen = false;
            } else {
                if (!this.pendingOpen) {
                    this.pendingOpen = true;
                    this.delayRemaining = 1;
                }

                if (this.delayRemaining > 0) {
                    this.delayRemaining--;
                } else {
                    mc.setScreen(new InventoryScreen(mc.player));
                    this.pendingOpen = false;
                }
            }
        }
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 66.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        if (this.draggingSlot) {
            this.setSlotFromMouse((double)mouseX, x, width);
        }

        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        float cx = x + 10.0F;
        float cw = width - 20.0F;
        InlineControlRenderer.drawSlider(
            context, textRenderer, theme, "TOTEM SLOT", Integer.toString(this.totemSlot + 1), cx, y + 8.0F, cw, (float)this.totemSlot / 8.0F
        );
        float keybindY = y + 44.0F;
        float bindW = 70.0F;
        float bindX = x + width - bindW - 10.0F;
        boolean capturing = DargsClient.getInstance().getKeybindManager().isCapturing(this);
        boolean hoverBind = InlineControlRenderer.containsButton((double)mouseX, (double)mouseY, bindX, keybindY, bindW);
        String bindLabel = InlineControlRenderer.fitText(
            textRenderer, DargsClient.getInstance().getKeybindManager().getBindLabel(this).toUpperCase(Locale.ROOT), 58
        );
        RenderUtil.drawText(context, textRenderer, "KEYBIND", cx, keybindY + 2.0F, theme.white());
        InlineControlRenderer.drawButton(context, textRenderer, theme, bindLabel, capturing, hoverBind, bindX, keybindY, bindW);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (!this.containsInline(mouseX, mouseY, x, y, width)) {
            return false;
        } else {
            float cx = x + 10.0F;
            float cw = width - 20.0F;
            if (button == 0 && InlineControlRenderer.containsSlider(mouseX, mouseY, cx, y + 8.0F, cw)) {
                this.draggingSlot = true;
                this.setSlotFromMouse(mouseX, x, width);
                return true;
            } else {
                float keybindY = y + 44.0F;
                float bindX = x + width - 80.0F;
                if (button == 0 && InlineControlRenderer.containsButton(mouseX, mouseY, bindX, keybindY, 70.0F)) {
                    DargsClient.getInstance().getKeybindManager().beginCapture(this, notificationManager);
                    return true;
                } else if (button == 1 && InlineControlRenderer.containsButton(mouseX, mouseY, bindX, keybindY, 70.0F)) {
                    DargsClient.getInstance().getKeybindManager().clearBind(this, notificationManager);
                    return true;
                } else {
                    return false;
                }
            }
        }
    }

    @Override
    public boolean onCustomClickGuiMouseReleased(double mouseX, double mouseY, int button, float x, float y, float width) {
        if (button == 0 && this.draggingSlot) {
            this.draggingSlot = false;
            this.config.setDhandModTotemSlot(this.totemSlot);
            this.config.save();
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isClickGuiInteractionActive() {
        return this.draggingSlot;
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("Totem slot: " + (this.totemSlot + 1), "Pair with HoverTotem");
    }

    private void setSlotFromMouse(double mouseX, float x, float width) {
        float start = x + 10.0F;
        float trackW = width - 20.0F;
        float ratio = Math.max(0.0F, Math.min(1.0F, (float)((mouseX - (double)start) / (double)trackW)));
        this.totemSlot = Math.round(ratio * 8.0F);
        this.config.setDhandModTotemSlot(this.totemSlot);
    }

    private boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + 66.0F);
    }
}
