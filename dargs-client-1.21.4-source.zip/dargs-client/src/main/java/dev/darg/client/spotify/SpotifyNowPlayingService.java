package dev.darg.client.spotify;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

public final class SpotifyNowPlayingService {
    private static final String WINDOWS_PREFIX = "windows";
    private static final long SUCCESS_POLL_MS = 2000L;
    private static final long IDLE_POLL_MS = 3500L;
    private static final long ERROR_POLL_MS = 5000L;
    private static final long PROCESS_TIMEOUT_MS = 5000L;
    private static final String ENCODED_POWERSHELL_SCRIPT = Base64.getEncoder().encodeToString(buildPowershellScript().getBytes(StandardCharsets.UTF_16LE));
    private final ExecutorService executor = Executors.newSingleThreadExecutor(new SpotifyNowPlayingService.DaemonThreadFactory());
    private volatile SpotifyNowPlayingService.PlaybackState playbackState = isWindows()
        ? SpotifyNowPlayingService.PlaybackState.idle()
        : SpotifyNowPlayingService.PlaybackState.unsupported();
    private volatile SpotifyNowPlayingService.ArtworkTexture artworkTexture;
    private volatile boolean requestInFlight;
    private volatile long nextPollAt;
    private volatile String cachedArtworkBase64 = "";

    public void tick() {
        long now = System.currentTimeMillis();
        if (!isWindows()) {
            this.playbackState = SpotifyNowPlayingService.PlaybackState.unsupported();
        } else if (!this.requestInFlight && now >= this.nextPollAt) {
            this.requestInFlight = true;
            CompletableFuture.runAsync(() -> {
                try {
                    this.pollPlayback();
                } finally {
                    this.requestInFlight = false;
                }
            }, this.executor);
        }
    }

    public void requestImmediateRefresh() {
        this.nextPollAt = 0L;
    }

    public SpotifyNowPlayingService.PlaybackState getPlaybackState() {
        return this.playbackState;
    }

    public SpotifyNowPlayingService.ArtworkTexture getArtworkTexture() {
        return this.artworkTexture;
    }

    private void pollPlayback() {
        SpotifyNowPlayingService.QueryResult queryResult = this.queryCurrentMediaSession();
        String var2 = queryResult.state();
        switch (var2) {
            case "track":
                this.handleTrack(queryResult);
                break;
            case "idle":
                this.handleIdle();
                break;
            case "unsupported":
                this.clearArtworkTexture();
                this.playbackState = SpotifyNowPlayingService.PlaybackState.unsupported();
                this.nextPollAt = System.currentTimeMillis() + 5000L;
                break;
            default:
                this.clearArtworkTexture();
                this.playbackState = SpotifyNowPlayingService.PlaybackState.error(queryResult.message());
                this.nextPollAt = System.currentTimeMillis() + 5000L;
        }
    }

    private void handleTrack(SpotifyNowPlayingService.QueryResult queryResult) {
        String sourceApp = prettySourceApp(queryResult.sourceApp());
        String title = queryResult.title().isBlank() ? "Unknown Track" : queryResult.title();
        String subtitle = resolveSubtitle(queryResult, sourceApp);
        boolean playing = "Playing".equalsIgnoreCase(queryResult.status());
        long positionMs = Math.max(0L, queryResult.positionMs());
        long durationMs = Math.max(0L, queryResult.durationMs());
        this.updateArtworkTexture(queryResult.thumbnailBase64());
        this.playbackState = SpotifyNowPlayingService.PlaybackState.track(
            sourceApp, title, subtitle, positionMs, durationMs, playing, System.currentTimeMillis()
        );
        this.nextPollAt = System.currentTimeMillis() + 2000L;
    }

    private void handleIdle() {
        this.clearArtworkTexture();
        this.playbackState = SpotifyNowPlayingService.PlaybackState.idle();
        this.nextPollAt = System.currentTimeMillis() + 3500L;
    }

    private SpotifyNowPlayingService.QueryResult queryCurrentMediaSession() {
        Process process = null;
        CompletableFuture<String> outputFuture = null;

        SpotifyNowPlayingService.QueryResult var10;
        try {
            ProcessBuilder builder = new ProcessBuilder(
                "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-EncodedCommand", ENCODED_POWERSHELL_SCRIPT
            );
            builder.redirectErrorStream(true);
            process = builder.start();
            outputFuture = CompletableFuture.supplyAsync(() -> readProcessOutput(process), CompletableFuture.delayedExecutor(0L, TimeUnit.MILLISECONDS));
            if (!process.waitFor(5000L, TimeUnit.MILLISECONDS)) {
                process.destroyForcibly();
                return SpotifyNowPlayingService.QueryResult.error("Media session query timed out");
            }

            String output = outputFuture.get(1L, TimeUnit.SECONDS).trim();
            if (output.isBlank()) {
                return SpotifyNowPlayingService.QueryResult.error("Media session returned no data");
            }

            String jsonPayload = extractJsonPayload(output);
            if (jsonPayload.isBlank()) {
                return SpotifyNowPlayingService.QueryResult.error("Media session returned invalid data");
            }

            JsonReader jsonReader = new JsonReader(new StringReader(jsonPayload));
            jsonReader.setLenient(true);
            JsonObject json = JsonParser.parseReader(jsonReader).getAsJsonObject();
            String state = getString(json, "state", "error");
            if ("idle".equals(state)) {
                return SpotifyNowPlayingService.QueryResult.idle();
            }

            if ("unsupported".equals(state)) {
                return SpotifyNowPlayingService.QueryResult.unsupported();
            }

            if ("track".equals(state)) {
                return SpotifyNowPlayingService.QueryResult.track(
                    getString(json, "sourceApp", ""),
                    getString(json, "title", ""),
                    getString(json, "artist", ""),
                    getString(json, "subtitle", ""),
                    getString(json, "status", ""),
                    getLong(json, "positionMs"),
                    getLong(json, "durationMs"),
                    getString(json, "thumbnailBase64", "")
                );
            }

            var10 = SpotifyNowPlayingService.QueryResult.error(getString(json, "message", "Media session unavailable"));
        } catch (IOException var18) {
            return SpotifyNowPlayingService.QueryResult.error("Media session query failed");
        } catch (InterruptedException var19) {
            Thread.currentThread().interrupt();
            return SpotifyNowPlayingService.QueryResult.error("Media session query interrupted");
        } catch (ExecutionException var20) {
            return SpotifyNowPlayingService.QueryResult.error("Media session output failed");
        } catch (TimeoutException var21) {
            return SpotifyNowPlayingService.QueryResult.error("Media session output timed out");
        } catch (RuntimeException var22) {
            return SpotifyNowPlayingService.QueryResult.error("Media session parse error");
        } finally {
            if (process != null) {
                process.destroy();
            }

            if (outputFuture != null && !outputFuture.isDone()) {
                outputFuture.cancel(true);
            }
        }

        return var10;
    }

    private void updateArtworkTexture(String artworkBase64) {
        String nextArtwork = artworkBase64 == null ? "" : artworkBase64;
        if (!Objects.equals(this.cachedArtworkBase64, nextArtwork)) {
            this.cachedArtworkBase64 = nextArtwork;
            if (nextArtwork.isBlank()) {
                this.clearArtworkTexture();
            } else {
                try {
                    byte[] bytes = Base64.getDecoder().decode(nextArtwork);
                    MinecraftClient.getInstance().execute(() -> this.registerArtworkTexture(bytes));
                } catch (IllegalArgumentException var4) {
                    this.clearArtworkTexture();
                }
            }
        }
    }

    private void registerArtworkTexture(byte[] imageBytes) {
        this.clearArtworkTexture();

        try {
            NativeImage image = NativeImage.read(imageBytes);
            Identifier textureId = Identifier.of("dargsclient", "media/" + Integer.toHexString(image.hashCode()) + "_" + System.nanoTime());
            NativeImageBackedTexture texture = new NativeImageBackedTexture(() -> "media-cover", image);
            MinecraftClient.getInstance().getTextureManager().registerTexture(textureId, texture);
            this.artworkTexture = new SpotifyNowPlayingService.ArtworkTexture(textureId, image.getWidth(), image.getHeight(), texture);
        } catch (IOException var5) {
            this.clearArtworkTexture();
        }
    }

    private void clearArtworkTexture() {
        SpotifyNowPlayingService.ArtworkTexture previousTexture = this.artworkTexture;
        this.artworkTexture = null;
        this.cachedArtworkBase64 = "";
        if (previousTexture != null) {
            MinecraftClient client = MinecraftClient.getInstance();
            client.execute(() -> {
                client.getTextureManager().destroyTexture(previousTexture.textureId());
                previousTexture.texture().close();
            });
        }
    }

    private static String resolveSubtitle(SpotifyNowPlayingService.QueryResult queryResult, String sourceApp) {
        if (!queryResult.artist().isBlank()) {
            return queryResult.artist();
        } else if (!queryResult.subtitle().isBlank()) {
            return queryResult.subtitle();
        } else {
            return sourceApp.isBlank() ? "Media Session" : sourceApp;
        }
    }

    private static String prettySourceApp(String rawSourceApp) {
        if (rawSourceApp != null && !rawSourceApp.isBlank()) {
            String value = rawSourceApp;
            int bangIndex = rawSourceApp.lastIndexOf(33);
            if (bangIndex >= 0 && bangIndex + 1 < rawSourceApp.length()) {
                value = rawSourceApp.substring(bangIndex + 1);
            }

            int slashIndex = Math.max(value.lastIndexOf(47), value.lastIndexOf(92));
            if (slashIndex >= 0 && slashIndex + 1 < value.length()) {
                value = value.substring(slashIndex + 1);
            }

            if (value.endsWith(".exe")) {
                value = value.substring(0, value.length() - 4);
            }

            String var4 = value.toLowerCase(Locale.ROOT);

            return switch (var4) {
                case "spotify" -> "Spotify";
                case "chrome" -> "Chrome";
                case "msedge" -> "Edge";
                case "firefox" -> "Firefox";
                case "discord" -> "Discord";
                case "zunemusic", "microsoft.zunemusic" -> "Media Player";
                default -> value;
            };
        } else {
            return "";
        }
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).startsWith("windows");
    }

    private static String getString(JsonObject jsonObject, String key, String fallback) {
        return jsonObject.has(key) && !jsonObject.get(key).isJsonNull() ? jsonObject.get(key).getAsString() : fallback;
    }

    private static long getLong(JsonObject jsonObject, String key) {
        return jsonObject.has(key) && !jsonObject.get(key).isJsonNull() ? jsonObject.get(key).getAsLong() : 0L;
    }

    private static String readProcessOutput(Process process) {
        try {
            String var2;
            try (InputStream inputStream = process.getInputStream()) {
                var2 = new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
            }

            return var2;
        } catch (IOException var6) {
            return "";
        }
    }

    private static String extractJsonPayload(String output) {
        if (output != null && !output.isBlank()) {
            String normalized = output.replace("\ufeff", "").replace("\u0000", "").trim();
            int firstBrace = normalized.indexOf(123);
            int lastBrace = normalized.lastIndexOf(125);
            return firstBrace >= 0 && lastBrace >= firstBrace ? normalized.substring(firstBrace, lastBrace + 1).trim() : "";
        } else {
            return "";
        }
    }

    private static String buildPowershellScript() {
        return "$ErrorActionPreference = 'Stop'\n[Console]::OutputEncoding = [System.Text.Encoding]::UTF8\nAdd-Type -AssemblyName System.Runtime.WindowsRuntime\n$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType=WindowsRuntime]\nfunction AwaitOp($op, [Type]$resultType) {\n  $method = [System.WindowsRuntimeSystemExtensions].GetMethods() |\n    Where-Object { $_.Name -eq 'AsTask' -and $_.IsGenericMethodDefinition -and $_.GetGenericArguments().Count -eq 1 -and $_.GetParameters().Count -eq 1 } |\n    Select-Object -First 1\n  $generic = $method.MakeGenericMethod($resultType)\n  $task = $generic.Invoke($null, @($op))\n  $task.Wait()\n  return $task.Result\n}\ntry {\n  $manager = AwaitOp ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])\n  if ($null -eq $manager) {\n    [pscustomobject]@{ state = 'idle' } | ConvertTo-Json -Compress\n    exit 0\n  }\n  $sessions = @($manager.GetSessions())\n  $session = $sessions | Where-Object { [string]$_.SourceAppUserModelId -match '(?i)spotify' } | Select-Object -First 1\n  if ($null -eq $session) {\n    $session = $manager.GetCurrentSession()\n  }\n  if ($null -eq $session -and $sessions.Count -gt 0) {\n    $session = $sessions | Select-Object -First 1\n  }\n  if ($null -eq $session) {\n    [pscustomobject]@{ state = 'idle' } | ConvertTo-Json -Compress\n    exit 0\n  }\n  $props = AwaitOp ($session.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])\n  $timeline = $session.GetTimelineProperties()\n  $playbackInfo = $session.GetPlaybackInfo()\n  $thumbnailBase64 = ''\n  if ($null -ne $props.Thumbnail) {\n    try {\n      $stream = AwaitOp ($props.Thumbnail.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])\n      if ($null -ne $stream) {\n        $asStream = [System.IO.WindowsRuntimeStreamExtensions].GetMethod('AsStream', [Type[]]@([Windows.Storage.Streams.IRandomAccessStream]))\n        $netStream = $asStream.Invoke($null, @($stream))\n        $memory = New-Object System.IO.MemoryStream\n        $netStream.CopyTo($memory)\n        $netStream.Dispose()\n        $bytes = $memory.ToArray()\n        $memory.Dispose()\n        if ($bytes.Length -gt 0) {\n          $thumbnailBase64 = [Convert]::ToBase64String($bytes)\n        }\n      }\n    } catch {\n      $thumbnailBase64 = ''\n    }\n  }\n  [pscustomobject]@{\n    state = 'track'\n    sourceApp = [string]$session.SourceAppUserModelId\n    title = [string]$props.Title\n    artist = [string]$props.Artist\n    subtitle = [string]$props.Subtitle\n    status = [string]$playbackInfo.PlaybackStatus\n    positionMs = [int64]$timeline.Position.TotalMilliseconds\n    durationMs = [int64]$timeline.EndTime.TotalMilliseconds\n    thumbnailBase64 = $thumbnailBase64\n  } | ConvertTo-Json -Compress\n} catch {\n  [pscustomobject]@{\n    state = 'error'\n    message = [string]$_.Exception.Message\n  } | ConvertTo-Json -Compress\n}\n";
    }

    public static record ArtworkTexture(Identifier textureId, int width, int height, NativeImageBackedTexture texture) {
    }

    private static final class DaemonThreadFactory implements ThreadFactory {
        @Override
        public Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable, "dargs-media-session-worker");
            thread.setDaemon(true);
            return thread;
        }
    }

    public static enum Mode {
        TRACK,
        IDLE,
        UNSUPPORTED,
        ERROR;
    }

    public static record PlaybackState(
        SpotifyNowPlayingService.Mode mode,
        String sourceApp,
        String title,
        String subtitle,
        long progressMs,
        long durationMs,
        boolean playing,
        long fetchedAtMs
    ) {
        public static SpotifyNowPlayingService.PlaybackState unsupported() {
            return new SpotifyNowPlayingService.PlaybackState(
                SpotifyNowPlayingService.Mode.UNSUPPORTED,
                "",
                "Windows media only",
                "System media session is unavailable",
                0L,
                0L,
                false,
                System.currentTimeMillis()
            );
        }

        public static SpotifyNowPlayingService.PlaybackState idle() {
            return new SpotifyNowPlayingService.PlaybackState(
                SpotifyNowPlayingService.Mode.IDLE, "", "Nothing playing", "No active media session", 0L, 0L, false, System.currentTimeMillis()
            );
        }

        public static SpotifyNowPlayingService.PlaybackState error(String subtitle) {
            return new SpotifyNowPlayingService.PlaybackState(
                SpotifyNowPlayingService.Mode.ERROR,
                "",
                "Media session unavailable",
                subtitle != null && !subtitle.isBlank() ? subtitle : "Query failed",
                0L,
                0L,
                false,
                System.currentTimeMillis()
            );
        }

        public static SpotifyNowPlayingService.PlaybackState track(
            String sourceApp, String title, String subtitle, long progressMs, long durationMs, boolean playing, long fetchedAtMs
        ) {
            return new SpotifyNowPlayingService.PlaybackState(
                SpotifyNowPlayingService.Mode.TRACK, sourceApp, title, subtitle, progressMs, durationMs, playing, fetchedAtMs
            );
        }
    }

    private static record QueryResult(
        String state,
        String sourceApp,
        String title,
        String artist,
        String subtitle,
        String status,
        long positionMs,
        long durationMs,
        String thumbnailBase64,
        String message
    ) {
        private static SpotifyNowPlayingService.QueryResult track(
            String sourceApp, String title, String artist, String subtitle, String status, long positionMs, long durationMs, String thumbnailBase64
        ) {
            return new SpotifyNowPlayingService.QueryResult("track", sourceApp, title, artist, subtitle, status, positionMs, durationMs, thumbnailBase64, "");
        }

        private static SpotifyNowPlayingService.QueryResult idle() {
            return new SpotifyNowPlayingService.QueryResult("idle", "", "", "", "", "", 0L, 0L, "", "");
        }

        private static SpotifyNowPlayingService.QueryResult unsupported() {
            return new SpotifyNowPlayingService.QueryResult("unsupported", "", "", "", "", "", 0L, 0L, "", "");
        }

        private static SpotifyNowPlayingService.QueryResult error(String message) {
            return new SpotifyNowPlayingService.QueryResult("error", "", "", "", "", "", 0L, 0L, "", message);
        }
    }
}
