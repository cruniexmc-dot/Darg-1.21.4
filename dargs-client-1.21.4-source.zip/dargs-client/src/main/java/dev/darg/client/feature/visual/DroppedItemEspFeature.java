package dev.darg.client.feature.visual;

import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.font.TextRenderer.TextLayerType;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public final class DroppedItemEspFeature extends Feature {
    private static final int PRIMARY_TEXT = -3365;
    private static final int SECONDARY_TEXT = -1;
    private static final int TEXT_BACKGROUND = 1879706122;
    private static final double RANGE = 64.0;

    public DroppedItemEspFeature() {
        super("DroppedItemESP", Category.RENDER);
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity player = client.player;
        if (client.world != null && player != null) {
            float tickProgress = client.getRenderTickCounter().getTickProgress(false);
            Camera camera = client.gameRenderer.getCamera();
            Vec3d cameraPos = camera.getCameraPos();
            MatrixStack matrices = context.matrices();
            VertexConsumerProvider consumers = context.consumers();
            TextRenderer textRenderer = client.textRenderer;

            for (ItemEntity itemEntity : client.world
                .getEntitiesByClass(
                    ItemEntity.class,
                    player.getBoundingBox().expand(64.0),
                    itemEntityx -> itemEntityx.isAlive() && !itemEntityx.getStack().isEmpty()
                )) {
                this.renderNametag(itemEntity, tickProgress, camera, cameraPos, matrices, consumers, textRenderer);
            }
        }
    }

    private void renderNametag(
        ItemEntity itemEntity,
        float tickProgress,
        Camera camera,
        Vec3d cameraPos,
        MatrixStack matrices,
        VertexConsumerProvider consumers,
        TextRenderer textRenderer
    ) {
        Vec3d itemPos = itemEntity.getLerpedPos(tickProgress);
        String itemName = itemEntity.getStack().getName().getString();
        float textWidth = (float)textRenderer.getWidth(itemName) / 2.0F;
        double labelY = itemPos.y - cameraPos.y + (double)itemEntity.getHeight() + 0.35;
        matrices.push();
        matrices.translate(itemPos.x - cameraPos.x, labelY, itemPos.z - cameraPos.z);
        matrices.multiply(camera.getRotation());
        matrices.scale(0.025F, -0.025F, 0.025F);
        Matrix4f positionMatrix = matrices.peek().getPositionMatrix();
        textRenderer.draw(itemName, -textWidth, 0.0F, -1, false, positionMatrix, consumers, TextLayerType.SEE_THROUGH, 1879706122, 15728880);
        textRenderer.draw(itemName, -textWidth, 0.0F, -3365, false, positionMatrix, consumers, TextLayerType.NORMAL, 0, 15728880);
        matrices.pop();
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("State: " + (this.isEnabled() ? "Enabled" : "Disabled"), "Range: 64 blocks", "Label: Item stack name", "Anchor: Above item");
    }
}
