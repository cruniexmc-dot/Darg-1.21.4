package dev.darg.client.feature.radium;

import com.radium.client.client.KeybindManager;
import com.radium.client.client.RadiumClient;
import com.radium.client.events.event.AttackListener;
import com.radium.client.events.event.AttackListener2;
import com.radium.client.events.event.BlockBreakingListener;
import com.radium.client.events.event.GameRenderListener;
import com.radium.client.events.event.HandleInputListener;
import com.radium.client.events.event.ItemUseListener;
import com.radium.client.events.event.MouseMoveListener;
import com.radium.client.events.event.PacketSendListener;
import com.radium.client.events.event.TickListener;
import com.radium.client.gui.settings.BooleanSetting;
import com.radium.client.gui.settings.KeybindSetting;
import com.radium.client.gui.settings.MinMaxSetting;
import com.radium.client.gui.settings.ModeSetting;
import com.radium.client.gui.settings.NumberSetting;
import com.radium.client.gui.settings.Setting;
import com.radium.client.modules.Module;
import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.feature.combat.CombatFeatureHooks;
import dev.darg.client.ui.clickgui.InlineControlRenderer;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.Packet;

public final class RadiumModuleFeature
    extends Feature
    implements CombatFeatureHooks.AttackHook,
    CombatFeatureHooks.ItemUseHook,
    CombatFeatureHooks.BlockBreakingHook,
    CombatFeatureHooks.PacketSendHook {
    private static final float CONTENT_PADDING = 10.0F;
    private static final float SETTING_GAP = 8.0F;
    private static final float MIN_MAX_GAP = 4.0F;
    private final Module module;
    private final ClientConfig config = ClientConfig.getInstance();
    private NumberSetting draggingNumberSetting;
    private MinMaxSetting draggingMinMaxSetting;
    private boolean draggingMinMaxLowerBound;
    private KeybindSetting capturingKeybindSetting;
    private boolean bindMouseCaptureArmed;

    public RadiumModuleFeature(Module module, Category category) {
        super(module.getName(), category);
        this.module = module;
        this.restorePersistedSettings();
    }

    @Override
    public List<String> getClickGuiDetails() {
        List<String> details = new ArrayList<>();
        if (this.module.getDescription() != null && !this.module.getDescription().isBlank()) {
            details.add(this.module.getDescription());
        }

        details.add("State: " + (this.module.isEnabled() ? "Enabled" : "Disabled"));
        details.add("Category: " + this.getCategory().displayName());
        int shown = 0;

        for (Setting<?> setting : this.module.getSettings()) {
            if (shown >= 4) {
                break;
            }

            details.add(setting.getName() + ": " + formatSettingValue(setting));
            shown++;
        }

        return details;
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return !this.module.getSettings().isEmpty();
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        if (this.module.getSettings().isEmpty()) {
            return 0.0F;
        } else {
            float height = 10.0F;
            List<Setting<?>> settings = this.module.getSettings();

            for (int index = 0; index < settings.size(); index++) {
                height += this.getSettingHeight(settings.get(index));
                if (index + 1 < settings.size()) {
                    height += 8.0F;
                }
            }

            return height + 10.0F;
        }
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        if (!this.module.getSettings().isEmpty()) {
            ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
            float contentX = x + 10.0F;
            float contentWidth = width - 20.0F;
            float cursorY = y + 10.0F;
            if (this.draggingNumberSetting != null) {
                this.setNumberFromMouse(this.draggingNumberSetting, (double)mouseX, contentX, contentWidth);
            }

            if (this.draggingMinMaxSetting != null) {
                this.setMinMaxFromMouse(this.draggingMinMaxSetting, (double)mouseX, contentX, contentWidth, this.draggingMinMaxLowerBound);
            }

            for (Setting<?> setting : this.module.getSettings()) {
                if (setting instanceof BooleanSetting booleanSetting) {
                    boolean hovered = InlineControlRenderer.containsToggle((double)mouseX, (double)mouseY, contentX, cursorY, contentWidth);
                    InlineControlRenderer.drawToggle(
                        context,
                        textRenderer,
                        theme,
                        booleanSetting.getName(),
                        Boolean.TRUE.equals(booleanSetting.getValue()),
                        hovered,
                        contentX,
                        cursorY,
                        contentWidth
                    );
                } else if (setting instanceof NumberSetting numberSetting) {
                    InlineControlRenderer.drawSlider(
                        context,
                        textRenderer,
                        theme,
                        numberSetting.getName(),
                        formatNumber(numberSetting.getValue(), numberSetting.getIncrement()),
                        contentX,
                        cursorY,
                        contentWidth,
                        getNumberRatio(numberSetting)
                    );
                } else if (setting instanceof MinMaxSetting minMaxSetting) {
                    float secondRowY = cursorY + 20.0F + 4.0F;
                    InlineControlRenderer.drawSlider(
                        context,
                        textRenderer,
                        theme,
                        minMaxSetting.getName() + " Min",
                        formatNumber(minMaxSetting.getMinValue(), minMaxSetting.getIncrement()),
                        contentX,
                        cursorY,
                        contentWidth,
                        getMinMaxRatio(minMaxSetting, true)
                    );
                    InlineControlRenderer.drawSlider(
                        context,
                        textRenderer,
                        theme,
                        "Max",
                        formatNumber(minMaxSetting.getMaxValue(), minMaxSetting.getIncrement()),
                        contentX,
                        secondRowY,
                        contentWidth,
                        getMinMaxRatio(minMaxSetting, false)
                    );
                } else if (setting instanceof ModeSetting<?> modeSetting) {
                    String value = prettifyEnumValue(modeSetting.getValue());
                    float buttonWidth = Math.max(78.0F, (float)RenderUtil.getTextWidth(textRenderer, value) + 18.0F);
                    float buttonX = contentX + contentWidth - buttonWidth;
                    boolean hovered = InlineControlRenderer.containsButton((double)mouseX, (double)mouseY, buttonX, cursorY, buttonWidth);
                    RenderUtil.drawText(context, textRenderer, modeSetting.getName(), contentX, cursorY + 2.0F, theme.white());
                    InlineControlRenderer.drawButton(context, textRenderer, theme, value, false, hovered, buttonX, cursorY, buttonWidth);
                } else if (setting instanceof KeybindSetting keybindSetting) {
                    String value = this.capturingKeybindSetting == keybindSetting
                        ? "LISTENING"
                        : InlineControlRenderer.fitText(textRenderer, keybindSetting.getDisplayText().toUpperCase(Locale.ROOT), 92);
                    float buttonWidth = Math.max(86.0F, (float)RenderUtil.getTextWidth(textRenderer, value) + 18.0F);
                    float buttonX = contentX + contentWidth - buttonWidth;
                    boolean hovered = InlineControlRenderer.containsButton((double)mouseX, (double)mouseY, buttonX, cursorY, buttonWidth);
                    RenderUtil.drawText(context, textRenderer, keybindSetting.getName(), contentX, cursorY + 2.0F, theme.white());
                    InlineControlRenderer.drawButton(
                        context, textRenderer, theme, value, this.capturingKeybindSetting == keybindSetting, hovered, buttonX, cursorY, buttonWidth
                    );
                } else {
                    RenderUtil.drawText(context, textRenderer, setting.getName(), contentX, cursorY, theme.white());
                    String value = InlineControlRenderer.fitText(textRenderer, formatSettingValue(setting), Math.round(contentWidth * 0.42F));
                    RenderUtil.drawText(
                        context, textRenderer, value, contentX + contentWidth - (float)RenderUtil.getTextWidth(textRenderer, value), cursorY, theme.softGray()
                    );
                }

                cursorY += this.getSettingHeight(setting) + 8.0F;
            }
        }
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (this.capturingKeybindSetting != null && this.bindMouseCaptureArmed) {
            this.applyKeybindCapture(KeybindManager.getMouseButtonKeyCode(button));
            return true;
        } else if (!this.containsInline(mouseX, mouseY, x, y, width)) {
            return false;
        } else {
            float contentX = x + 10.0F;
            float contentWidth = width - 20.0F;
            float cursorY = y + 10.0F;

            for (Setting<?> setting : this.module.getSettings()) {
                if (setting instanceof BooleanSetting booleanSetting) {
                    if (button == 0 && InlineControlRenderer.containsToggle(mouseX, mouseY, contentX, cursorY, contentWidth)) {
                        booleanSetting.toggle();
                        this.persistSetting(booleanSetting);
                        return true;
                    }
                } else if (setting instanceof NumberSetting numberSetting) {
                    if (button == 0 && InlineControlRenderer.containsSlider(mouseX, mouseY, contentX, cursorY, contentWidth)) {
                        this.draggingNumberSetting = numberSetting;
                        this.setNumberFromMouse(numberSetting, mouseX, contentX, contentWidth);
                        return true;
                    }
                } else if (setting instanceof MinMaxSetting minMaxSetting) {
                    float secondRowY = cursorY + 20.0F + 4.0F;
                    if (button == 0 && InlineControlRenderer.containsSlider(mouseX, mouseY, contentX, cursorY, contentWidth)) {
                        this.draggingMinMaxSetting = minMaxSetting;
                        this.draggingMinMaxLowerBound = true;
                        this.setMinMaxFromMouse(minMaxSetting, mouseX, contentX, contentWidth, true);
                        return true;
                    }

                    if (button == 0 && InlineControlRenderer.containsSlider(mouseX, mouseY, contentX, secondRowY, contentWidth)) {
                        this.draggingMinMaxSetting = minMaxSetting;
                        this.draggingMinMaxLowerBound = false;
                        this.setMinMaxFromMouse(minMaxSetting, mouseX, contentX, contentWidth, false);
                        return true;
                    }
                } else if (setting instanceof ModeSetting<?> modeSetting) {
                    String value = prettifyEnumValue(modeSetting.getValue());
                    float buttonWidth = Math.max(78.0F, (float)RenderUtil.getTextWidth(MinecraftClient.getInstance().textRenderer, value) + 18.0F);
                    float buttonX = contentX + contentWidth - buttonWidth;
                    if (InlineControlRenderer.containsButton(mouseX, mouseY, buttonX, cursorY, buttonWidth)) {
                        if (button == 0) {
                            modeSetting.cycleMode();
                        } else {
                            if (button != 1) {
                                cursorY += this.getSettingHeight(setting) + 8.0F;
                                continue;
                            }

                            cycleModeBackward(modeSetting);
                        }

                        this.persistSetting(modeSetting);
                        return true;
                    }
                } else if (setting instanceof KeybindSetting keybindSetting) {
                    String value = this.capturingKeybindSetting == keybindSetting ? "LISTENING" : keybindSetting.getDisplayText().toUpperCase(Locale.ROOT);
                    float buttonWidth = Math.max(86.0F, (float)RenderUtil.getTextWidth(MinecraftClient.getInstance().textRenderer, value) + 18.0F);
                    float buttonX = contentX + contentWidth - buttonWidth;
                    if (InlineControlRenderer.containsButton(mouseX, mouseY, buttonX, cursorY, buttonWidth)) {
                        if (button == 1) {
                            keybindSetting.clearKey();
                            this.persistSetting(keybindSetting);
                            if (notificationManager != null) {
                                notificationManager.push(this.module.getName() + " " + keybindSetting.getName() + " cleared", NotificationManager.Type.INFO);
                            }
                        } else {
                            if (button != 0) {
                                cursorY += this.getSettingHeight(setting) + 8.0F;
                                continue;
                            }

                            this.capturingKeybindSetting = keybindSetting;
                            this.bindMouseCaptureArmed = false;
                            keybindSetting.setListening(true);
                            if (notificationManager != null) {
                                notificationManager.push(
                                    "Press a key or mouse button for " + this.module.getName() + " " + keybindSetting.getName(), NotificationManager.Type.INFO
                                );
                            }
                        }

                        return true;
                    }
                }

                cursorY += this.getSettingHeight(setting) + 8.0F;
            }

            return true;
        }
    }

    @Override
    public boolean onCustomClickGuiMouseReleased(double mouseX, double mouseY, int button, float x, float y, float width) {
        if (button == 0 && this.draggingNumberSetting != null) {
            this.draggingNumberSetting = null;
            this.config.save();
            return true;
        } else if (button == 0 && this.draggingMinMaxSetting != null) {
            this.draggingMinMaxSetting = null;
            this.config.save();
            return true;
        } else {
            if (button == 0 && this.capturingKeybindSetting != null) {
                this.bindMouseCaptureArmed = true;
            }

            return false;
        }
    }

    @Override
    public boolean onClickGuiKeyPressed(KeyInput keyInput) {
        if (this.capturingKeybindSetting == null) {
            return false;
        } else {
            int keyCode = keyInput.key();
            if (keyCode == 256) {
                this.capturingKeybindSetting.setListening(false);
                this.capturingKeybindSetting = null;
                this.bindMouseCaptureArmed = false;
                return true;
            } else if (keyCode == 261 || keyCode == 259) {
                this.capturingKeybindSetting.clearKey();
                this.persistSetting(this.capturingKeybindSetting);
                this.capturingKeybindSetting = null;
                this.bindMouseCaptureArmed = false;
                return true;
            } else if (keyCode == -1) {
                return true;
            } else {
                this.applyKeybindCapture(keyCode);
                return true;
            }
        }
    }

    @Override
    public boolean isClickGuiInteractionActive() {
        return this.draggingNumberSetting != null || this.draggingMinMaxSetting != null || this.capturingKeybindSetting != null;
    }

    @Override
    protected void onEnable() {
        syncClient();
        this.module.setEnabled(true);
        this.module.onEnable();
    }

    @Override
    protected void onDisable() {
        this.draggingNumberSetting = null;
        this.draggingMinMaxSetting = null;
        if (this.capturingKeybindSetting != null) {
            this.capturingKeybindSetting.setListening(false);
        }

        this.capturingKeybindSetting = null;
        this.bindMouseCaptureArmed = false;
        syncClient();
        this.module.setEnabled(false);
        this.module.onDisable();
    }

    @Override
    public void onTick() {
        syncClient();
        this.module.onTick();
        if (this.module instanceof TickListener listener) {
            listener.onTick2();
        }

        if (this.module instanceof HandleInputListener listener) {
            listener.onHandleInput();
        }
    }

    @Override
    public void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        syncClient();
        if (this.module instanceof GameRenderListener listener) {
            listener.onGameRender(new GameRenderListener.GameRenderEvent(null, 0.0F));
        }
    }

    @Override
    public void onMouseMove(double deltaX, double deltaY) {
        syncClient();
        if (this.module instanceof MouseMoveListener listener) {
            listener.onMouseMove(new MouseMoveListener.MouseMoveEvent(deltaX, deltaY));
        }
    }

    @Override
    public void onAttackEntity(Entity entity) {
        syncClient();
        if (this.module instanceof AttackListener2 listener) {
            listener.onAttack(new AttackListener2.AttackEvent2(entity));
        }
    }

    @Override
    public boolean onBeforeAttack(MinecraftClient client) {
        syncClient();
        if (this.module instanceof AttackListener listener) {
            AttackListener.AttackEvent event = new AttackListener.AttackEvent();
            listener.onAttack(event);
            return event.isCancelled();
        } else {
            return false;
        }
    }

    @Override
    public boolean onBeforeItemUse(MinecraftClient client) {
        syncClient();
        if (this.module instanceof ItemUseListener listener) {
            ItemUseListener.ItemUseEvent event = new ItemUseListener.ItemUseEvent();
            listener.onItemUse(event);
            return event.isCancelled();
        } else {
            return false;
        }
    }

    @Override
    public boolean onBeforeBlockBreaking(MinecraftClient client, boolean breaking) {
        syncClient();
        if (this.module instanceof BlockBreakingListener listener) {
            BlockBreakingListener.BlockBreakingEvent event = new BlockBreakingListener.BlockBreakingEvent();
            listener.onBlockBreaking(event);
            return event.isCancelled();
        } else {
            return false;
        }
    }

    @Override
    public boolean onSendPacket(MinecraftClient client, Packet<?> packet) {
        syncClient();
        if (this.module instanceof PacketSendListener listener) {
            PacketSendListener.PacketSendEvent event = new PacketSendListener.PacketSendEvent(packet);
            listener.onPacketSend(event);
            return event.isCancelled();
        } else {
            return false;
        }
    }

    private void restorePersistedSettings() {
        for (Setting<?> setting : this.module.getSettings()) {
            this.restoreSetting(setting);
        }
    }

    private void restoreSetting(Setting<?> setting) {
        String savedValue = this.config.getFeatureSetting(this.getConfigKey(), getSettingConfigKey(setting));
        if (!savedValue.isBlank()) {
            if (setting instanceof BooleanSetting booleanSetting) {
                booleanSetting.setValue(Boolean.valueOf(parseBoolean(savedValue, Boolean.TRUE.equals(booleanSetting.getDefaultValue()))));
            } else if (setting instanceof NumberSetting numberSetting) {
                numberSetting.setValue(parseDouble(savedValue, numberSetting.getDefaultValue()));
            } else if (setting instanceof MinMaxSetting minMaxSetting) {
                String[] parts = savedValue.split(",", 2);
                if (parts.length == 2) {
                    minMaxSetting.setMinValue(parseDouble(parts[0], minMaxSetting.getMinValue()));
                    minMaxSetting.setMaxValue(parseDouble(parts[1], minMaxSetting.getMaxValue()));
                }
            } else if (setting instanceof ModeSetting<?> modeSetting) {
                applyModeValue(modeSetting, savedValue);
            } else if (setting instanceof KeybindSetting keybindSetting) {
                keybindSetting.setValue(Integer.valueOf(parseInt(savedValue, keybindSetting.getDefaultValue())));
                keybindSetting.setListening(false);
            }
        }
    }

    private void persistSetting(Setting<?> setting) {
        this.config.setFeatureSetting(this.getConfigKey(), getSettingConfigKey(setting), this.serializeSetting(setting));
        this.config.save();
    }

    private String serializeSetting(Setting<?> setting) {
        if (setting instanceof BooleanSetting booleanSetting) {
            return Boolean.toString(Boolean.TRUE.equals(booleanSetting.getValue()));
        } else if (setting instanceof NumberSetting numberSetting) {
            return formatStoredNumber(numberSetting.getValue(), numberSetting.getIncrement());
        } else if (setting instanceof MinMaxSetting minMaxSetting) {
            return formatStoredNumber(minMaxSetting.getMinValue(), minMaxSetting.getIncrement())
                + ","
                + formatStoredNumber(minMaxSetting.getMaxValue(), minMaxSetting.getIncrement());
        } else if (setting instanceof ModeSetting<?> modeSetting) {
            Object value = modeSetting.getValue();
            return value instanceof Enum<?> enumValue ? enumValue.name() : String.valueOf(value);
        } else if (setting instanceof KeybindSetting keybindSetting) {
            return Integer.toString(keybindSetting.getValue());
        } else {
            Object value = setting.getValue();
            return value == null ? "" : value.toString();
        }
    }

    private void applyKeybindCapture(int keyCode) {
        if (this.capturingKeybindSetting != null) {
            this.capturingKeybindSetting.setKey(keyCode);
            this.persistSetting(this.capturingKeybindSetting);
            this.capturingKeybindSetting = null;
            this.bindMouseCaptureArmed = false;
        }
    }

    private static void syncClient() {
        RadiumClient.mc = MinecraftClient.getInstance();
        Module.mc = RadiumClient.mc;
    }

    private float getSettingHeight(Setting<?> setting) {
        if (setting instanceof MinMaxSetting) {
            return 44.0F;
        } else if (setting instanceof NumberSetting) {
            return 20.0F;
        } else {
            return setting instanceof BooleanSetting ? 12.0F : 16.0F;
        }
    }

    private boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        float height = this.getCustomClickGuiHeight(width);
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + height);
    }

    private void setNumberFromMouse(NumberSetting setting, double mouseX, float x, float width) {
        double ratio = clamp((mouseX - (double)x) / (double)Math.max(1.0F, width - 2.0F), 0.0, 1.0);
        double rawValue = setting.getMin() + (setting.getMax() - setting.getMin()) * ratio;
        double snapped = snapValue(rawValue, setting.getIncrement(), setting.getMin(), setting.getMax());
        setting.setValue(snapped);
    }

    private void setMinMaxFromMouse(MinMaxSetting setting, double mouseX, float x, float width, boolean lowerBound) {
        double ratio = clamp((mouseX - (double)x) / (double)Math.max(1.0F, width - 2.0F), 0.0, 1.0);
        double rawValue = setting.getMin() + (setting.getMax() - setting.getMin()) * ratio;
        double snapped = snapValue(rawValue, setting.getIncrement(), setting.getMin(), setting.getMax());
        if (lowerBound) {
            setting.setMinValue(snapped);
        } else {
            setting.setMaxValue(snapped);
        }
    }

    private static float getNumberRatio(NumberSetting setting) {
        return (float)((setting.getValue() - setting.getMin()) / Math.max(1.0E-4, setting.getMax() - setting.getMin()));
    }

    private static float getMinMaxRatio(MinMaxSetting setting, boolean lowerBound) {
        double value = lowerBound ? setting.getMinValue() : setting.getMaxValue();
        return (float)((value - setting.getMin()) / Math.max(1.0E-4, setting.getMax() - setting.getMin()));
    }

    private static double snapValue(double value, double increment, double min, double max) {
        if (increment <= 0.0) {
            return clamp(value, min, max);
        } else {
            double snapped = (double)Math.round(value / increment) * increment;
            return clamp(snapped, min, max);
        }
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private static String getSettingConfigKey(Setting<?> setting) {
        return normalizeKey(setting.getName());
    }

    private static String normalizeKey(String value) {
        String lower = value == null ? "" : value.toLowerCase(Locale.ROOT);
        StringBuilder key = new StringBuilder();

        for (int index = 0; index < lower.length(); index++) {
            char character = lower.charAt(index);
            if ((character < 'a' || character > 'z') && (character < '0' || character > '9')) {
                if (!key.isEmpty() && key.charAt(key.length() - 1) != '_') {
                    key.append('_');
                }
            } else {
                key.append(character);
            }
        }

        if (!key.isEmpty() && key.charAt(key.length() - 1) == '_') {
            key.setLength(key.length() - 1);
        }

        return key.isEmpty() ? "setting" : key.toString();
    }

    private static boolean parseBoolean(String value, boolean fallback) {
        String var2 = value.toLowerCase(Locale.ROOT);

        return switch (var2) {
            case "true", "1", "yes", "on" -> true;
            case "false", "0", "no", "off" -> false;
            default -> fallback;
        };
    }

    private static double parseDouble(String value, double fallback) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException var4) {
            return fallback;
        }
    }

    private static int parseInt(String value, int fallback) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException var3) {
            return fallback;
        }
    }

    private static String formatStoredNumber(double value, double increment) {
        int decimals = countDecimals(increment);
        return decimals <= 0 ? Integer.toString((int)Math.round(value)) : String.format(Locale.ROOT, "%." + decimals + "f", value);
    }

    private static String formatNumber(double value, double increment) {
        int decimals = countDecimals(increment);
        return decimals <= 0 ? Integer.toString((int)Math.round(value)) : String.format(Locale.ROOT, "%." + decimals + "f", value);
    }

    private static int countDecimals(double increment) {
        BigDecimal decimal = BigDecimal.valueOf(increment).stripTrailingZeros();
        return Math.max(0, decimal.scale());
    }

    private static String prettifyEnumValue(Object value) {
        if (value instanceof Enum<?> enumValue) {
            String name = enumValue.name().toLowerCase(Locale.ROOT).replace('_', ' ');
            return Character.toUpperCase(name.charAt(0)) + name.substring(1);
        } else {
            return value == null ? "None" : value.toString();
        }
    }

    private static void cycleModeBackward(ModeSetting<?> setting) {
        // $VF: Couldn't be decompiled
        // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
        // java.lang.NullPointerException: Cannot invoke "org.jetbrains.java.decompiler.struct.gen.VarType.isGeneric()" because "newRet" is null
        //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.getInferredExprType(InvocationExprent.java:634)
        //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:966)
        //   at org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent.toJava(AssignmentExprent.java:154)
        //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:895)
        //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:90)
        //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:833)
        //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
        //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
        //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1283)
        //
        // Bytecode:
        // 00: aload 0
        // 01: invokevirtual com/radium/client/gui/settings/ModeSetting.getModes ()[Ljava/lang/Enum;
        // 04: astore 1
        // 05: aload 0
        // 06: invokevirtual com/radium/client/gui/settings/ModeSetting.getValue ()Ljava/lang/Object;
        // 09: astore 2
        // 0a: bipush 0
        // 0b: istore 3
        // 0c: iload 3
        // 0d: aload 1
        // 0e: arraylength
        // 0f: if_icmpge 3e
        // 12: aload 1
        // 13: iload 3
        // 14: aaload
        // 15: aload 2
        // 16: if_acmpeq 1c
        // 19: goto 38
        // 1c: iload 3
        // 1d: bipush 1
        // 1e: isub
        // 1f: istore 4
        // 21: iload 4
        // 23: ifge 2c
        // 26: aload 1
        // 27: arraylength
        // 28: bipush 1
        // 29: isub
        // 2a: istore 4
        // 2c: aload 0
        // 2d: aload 1
        // 2e: iload 4
        // 30: aaload
        // 31: invokestatic java/lang/String.valueOf (Ljava/lang/Object;)Ljava/lang/String;
        // 34: invokestatic dev/darg/client/feature/radium/RadiumModuleFeature.applyModeValue (Lcom/radium/client/gui/settings/ModeSetting;Ljava/lang/String;)V
        // 37: return
        // 38: iinc 3 1
        // 3b: goto 0c
        // 3e: aload 1
        // 3f: arraylength
        // 40: ifle 4d
        // 43: aload 0
        // 44: aload 1
        // 45: bipush 0
        // 46: aaload
        // 47: invokestatic java/lang/String.valueOf (Ljava/lang/Object;)Ljava/lang/String;
        // 4a: invokestatic dev/darg/client/feature/radium/RadiumModuleFeature.applyModeValue (Lcom/radium/client/gui/settings/ModeSetting;Ljava/lang/String;)V
        // 4d: return
    }

    private static void applyModeValue(ModeSetting<?> setting, String value) {
        setting.setValue(value);
    }

    private static String formatSettingValue(Setting<?> setting) {
        if (setting instanceof BooleanSetting booleanSetting) {
            return Boolean.TRUE.equals(booleanSetting.getValue()) ? "On" : "Off";
        } else if (setting instanceof NumberSetting numberSetting) {
            return formatNumber(numberSetting.getValue(), numberSetting.getIncrement());
        } else if (setting instanceof MinMaxSetting minMaxSetting) {
            return formatNumber(minMaxSetting.getMinValue(), minMaxSetting.getIncrement())
                + "-"
                + formatNumber(minMaxSetting.getMaxValue(), minMaxSetting.getIncrement());
        } else if (setting instanceof ModeSetting<?> modeSetting) {
            return prettifyEnumValue(modeSetting.getValue());
        } else if (setting instanceof KeybindSetting keybindSetting) {
            return keybindSetting.getDisplayText();
        } else {
            Object value = setting.getValue();
            return value == null ? "null" : value.toString();
        }
    }
}
