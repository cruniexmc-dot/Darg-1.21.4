package dev.darg.client.render;

import dev.darg.client.DargsClient;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.AfterEntities;

public final class ClientRenderHooks {
    private ClientRenderHooks() {
    }

    public static void register() {
        HudRenderCallback.EVENT.register((HudRenderCallback)(context, tickCounter) -> {
            DargsClient client = DargsClient.getInstance();
            if (client != null) {
                client.getFeatureManager().renderHud(context, tickCounter);
            }
        });
        WorldRenderEvents.AFTER_ENTITIES.register((AfterEntities)context -> {
            DargsClient client = DargsClient.getInstance();
            if (client != null) {
                client.getFeatureManager().renderWorld(context);
            }
        });
    }
}
