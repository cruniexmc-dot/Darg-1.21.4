package dev.darg.client.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import dev.darg.client.mixin.RenderLayerInvoker;
import java.util.Collection;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.OutputTarget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;

public final class ChunkMarkerRenderUtil {
    private static final int ROUNDED_CORNER_STRIPS = 56;
    private static final float OUTER_GLOW_EXPAND = 0.42F;
    private static final float OUTER_GLOW_EXPAND_FAR = 0.82F;
    private static final float INNER_GLOSS_INSET = 0.58F;
    private static final float INNER_GLOSS_RADIUS_OFFSET = 0.34F;
    private static volatile RenderLayer quadLayer;
    private static volatile RenderLayer lineLayer;
    private static final Object LAYER_LOCK = new Object();

    private ChunkMarkerRenderUtil() {
    }

    public static void render(
        MinecraftClient client,
        WorldRenderContext context,
        float tracerStartOffset,
        Collection<ChunkPos> scannedChunks,
        ChunkMarkerRenderUtil.ScanPlateStyle scanPlateStyle,
        Collection<ChunkMarkerRenderUtil.ChunkMarker> markers
    ) {
        if (client.world != null && client.player != null) {
            MatrixStack matrices = context.matrices();
            if (matrices != null) {
                boolean hasScannedChunks = scannedChunks != null
                    && !scannedChunks.isEmpty()
                    && scanPlateStyle != null
                    && WorldRenderUtil.alpha(scanPlateStyle.color()) > 0;
                boolean hasMarkers = markers != null && !markers.isEmpty();
                if (hasScannedChunks || hasMarkers) {
                    Camera camera = client.gameRenderer.getCamera();
                    Vec3d cameraPos = camera.getCameraPos();
                    float tickProgress = client.getRenderTickCounter().getTickProgress(false);
                    Vec3d tracerStart = WorldRenderUtil.getTracerStart(camera, tickProgress, tracerStartOffset);
                    if (hasScannedChunks) {
                        context.commandQueue().submitCustom(matrices, getQuadLayer(), (entry, buf) -> {
                            float scanY = scanPlateStyle.worldY() + scanPlateStyle.yOffset() - (float)cameraPos.y;

                            for (ChunkPos chunkPos : scannedChunks) {
                                float minX = (float)((double)(chunkPos.x << 4) - cameraPos.x);
                                float minZ = (float)((double)(chunkPos.z << 4) - cameraPos.z);
                                drawQuad(entry, buf, minX, scanY, minZ, minX + 16.0F, scanY, minZ + 16.0F, scanPlateStyle.color());
                            }
                        });
                    }

                    if (hasMarkers) {
                        context.commandQueue()
                            .submitCustom(
                                matrices,
                                getQuadLayer(),
                                (entry, buf) -> {
                                    for (ChunkMarkerRenderUtil.ChunkMarker markerx : markers) {
                                        float minX = (float)((double)(markerx.pos().x << 4) - cameraPos.x);
                                        float minZ = (float)((double)(markerx.pos().z << 4) - cameraPos.z);
                                        float maxX = minX + 16.0F;
                                        float maxZ = minZ + 16.0F;
                                        if (WorldRenderUtil.alpha(markerx.outerPlateColor()) > 0) {
                                            float outerY = markerx.outerPlateWorldY() - (float)cameraPos.y;
                                            int glowColor = WorldRenderUtil.withAlpha(
                                                WorldRenderUtil.brighten(markerx.outerPlateColor(), 0.32F),
                                                Math.max(12, Math.round((float)WorldRenderUtil.alpha(markerx.outerPlateColor()) * 0.36F))
                                            );
                                            int farGlowColor = WorldRenderUtil.withAlpha(
                                                WorldRenderUtil.brighten(markerx.outerPlateColor(), 0.48F),
                                                Math.max(6, Math.round((float)WorldRenderUtil.alpha(markerx.outerPlateColor()) * 0.18F))
                                            );
                                            drawPlate(
                                                entry,
                                                buf,
                                                minX - 0.82F,
                                                outerY - 0.012F,
                                                minZ - 0.82F,
                                                maxX + 0.82F,
                                                maxZ + 0.82F,
                                                markerx.outerPlateCornerRadius() + 0.82F,
                                                farGlowColor
                                            );
                                            drawPlate(
                                                entry,
                                                buf,
                                                minX - 0.42F,
                                                outerY - 0.008F,
                                                minZ - 0.42F,
                                                maxX + 0.42F,
                                                maxZ + 0.42F,
                                                markerx.outerPlateCornerRadius() + 0.42F,
                                                glowColor
                                            );
                                            drawPlate(entry, buf, minX, outerY, minZ, maxX, maxZ, markerx.outerPlateCornerRadius(), markerx.outerPlateColor());
                                        }

                                        if (WorldRenderUtil.alpha(markerx.innerPlateColor()) > 0) {
                                            float inset = Math.max(0.0F, markerx.innerPlateInset());
                                            float innerY = markerx.innerPlateWorldY() - (float)cameraPos.y;
                                            drawPlate(
                                                entry,
                                                buf,
                                                minX + inset,
                                                innerY,
                                                minZ + inset,
                                                maxX - inset,
                                                maxZ - inset,
                                                markerx.innerPlateCornerRadius(),
                                                markerx.innerPlateColor()
                                            );
                                            int glossColor = WorldRenderUtil.withAlpha(
                                                WorldRenderUtil.brighten(markerx.innerPlateColor(), 0.18F),
                                                Math.max(8, Math.round((float)WorldRenderUtil.alpha(markerx.innerPlateColor()) * 0.22F))
                                            );
                                            drawPlate(
                                                entry,
                                                buf,
                                                minX + inset + 0.58F,
                                                innerY + 0.01F,
                                                minZ + inset + 0.58F,
                                                maxX - inset - 0.58F,
                                                maxZ - inset - 0.58F,
                                                Math.max(0.0F, markerx.innerPlateCornerRadius() - 0.34F),
                                                glossColor
                                            );
                                        }
                                    }
                                }
                            );
                        context.commandQueue()
                            .submitCustom(
                                matrices,
                                getLineLayer(),
                                (entry, buf) -> {
                                    for (ChunkMarkerRenderUtil.ChunkMarker markerx : markers) {
                                        float minX = (float)((double)(markerx.pos().x << 4) - cameraPos.x);
                                        float minZ = (float)((double)(markerx.pos().z << 4) - cameraPos.z);
                                        float maxX = minX + 16.0F;
                                        float maxZ = minZ + 16.0F;
                                        float cx = minX + 8.0F;
                                        float cz = minZ + 8.0F;
                                        if (WorldRenderUtil.alpha(markerx.outlineColor()) > 0 && markerx.outlineWidth() > 0.0F) {
                                            drawChunkOutline(
                                                entry,
                                                buf,
                                                minX,
                                                markerx.outlineWorldY() - (float)cameraPos.y,
                                                minZ,
                                                maxX,
                                                maxZ,
                                                markerx.outlineColor(),
                                                markerx.outlineWidth()
                                            );
                                        }

                                        if (WorldRenderUtil.alpha(markerx.stemColor()) > 0 && markerx.stemTopWorldY() > markerx.outlineWorldY()) {
                                            float outlineY = markerx.outlineWorldY() - (float)cameraPos.y;
                                            float topY = markerx.stemTopWorldY() - (float)cameraPos.y;
                                            WorldRenderUtil.drawLine(entry, buf, cx, outlineY, cz, cx, topY, cz, markerx.stemColor(), markerx.outlineWidth());
                                        }

                                        if (WorldRenderUtil.alpha(markerx.tracerColor()) > 0 && markerx.tracerWidth() > 0.0F) {
                                            WorldRenderUtil.drawLine(
                                                entry,
                                                buf,
                                                tracerStart,
                                                new Vec3d((double)cx, (double)markerx.tracerTargetWorldY() - cameraPos.y, (double)cz),
                                                markerx.tracerColor(),
                                                markerx.tracerWidth()
                                            );
                                        }
                                    }
                                }
                            );
                        ItemRenderState itemState = new ItemRenderState();

                        for (ChunkMarkerRenderUtil.ChunkMarker marker : markers) {
                            List<ItemStack> icons = marker.icons();
                            if (icons != null && !icons.isEmpty()) {
                                Vec3d relPos = new Vec3d(
                                    (double)((marker.pos().x << 4) + 8) - cameraPos.x,
                                    (double)marker.iconWorldY() - cameraPos.y,
                                    (double)((marker.pos().z << 4) + 8) - cameraPos.z
                                );
                                if (marker.flatIcons()) {
                                    ItemBillboardRenderUtil.renderFlatItemRow(
                                        client, matrices, context.commandQueue(), camera, relPos, icons, itemState, marker.iconScale(), marker.iconSpacing()
                                    );
                                } else {
                                    ItemBillboardRenderUtil.renderItemRow(
                                        client, matrices, context.commandQueue(), camera, relPos, icons, itemState, marker.iconScale(), marker.iconSpacing()
                                    );
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private static void drawChunkOutline(Entry entry, VertexConsumer buffer, float minX, float y, float minZ, float maxX, float maxZ, int argb, float lineWidth) {
        WorldRenderUtil.drawLine(entry, buffer, minX, y, minZ, maxX, y, minZ, argb, lineWidth);
        WorldRenderUtil.drawLine(entry, buffer, maxX, y, minZ, maxX, y, maxZ, argb, lineWidth);
        WorldRenderUtil.drawLine(entry, buffer, maxX, y, maxZ, minX, y, maxZ, argb, lineWidth);
        WorldRenderUtil.drawLine(entry, buffer, minX, y, maxZ, minX, y, minZ, argb, lineWidth);
    }

    private static void drawQuad(Entry entry, VertexConsumer buffer, float x1, float y1, float z1, float x2, float y2, float z2, int argb) {
        int alpha = WorldRenderUtil.alpha(argb);
        int red = WorldRenderUtil.red(argb);
        int green = WorldRenderUtil.green(argb);
        int blue = WorldRenderUtil.blue(argb);
        buffer.vertex(entry, x1, y1, z1).color(red, green, blue, alpha);
        buffer.vertex(entry, x2, y1, z1).color(red, green, blue, alpha);
        buffer.vertex(entry, x2, y2, z2).color(red, green, blue, alpha);
        buffer.vertex(entry, x1, y2, z2).color(red, green, blue, alpha);
    }

    private static void drawPlate(Entry entry, VertexConsumer buffer, float minX, float y, float minZ, float maxX, float maxZ, float cornerRadius, int argb) {
        float width = maxX - minX;
        float depth = maxZ - minZ;
        float radius = Math.max(0.0F, Math.min(cornerRadius, Math.min(width, depth) * 0.5F - 0.01F));
        if (radius <= 0.05F) {
            drawQuad(entry, buffer, minX, y, minZ, maxX, y, maxZ, argb);
        } else {
            float middleMinZ = minZ + radius;
            float middleMaxZ = maxZ - radius;
            if (middleMaxZ > middleMinZ) {
                drawQuad(entry, buffer, minX, y, middleMinZ, maxX, y, middleMaxZ, argb);
            }

            float stripDepth = radius / 56.0F;

            for (int index = 0; index < 56; index++) {
                float topZ1 = minZ + (float)index * stripDepth;
                float topZ2 = topZ1 + stripDepth;
                float topInset = roundedInset(radius, (topZ1 + topZ2) * 0.5F - minZ);
                drawQuad(entry, buffer, minX + topInset, y, topZ1, maxX - topInset, y, topZ2, argb);
                float bottomZ2 = maxZ - (float)index * stripDepth;
                float bottomZ1 = bottomZ2 - stripDepth;
                float bottomInset = roundedInset(radius, maxZ - (bottomZ1 + bottomZ2) * 0.5F);
                drawQuad(entry, buffer, minX + bottomInset, y, bottomZ1, maxX - bottomInset, y, bottomZ2, argb);
            }
        }
    }

    private static float roundedInset(float radius, float distanceFromEdge) {
        float clamped = Math.max(0.0F, Math.min(radius, distanceFromEdge));
        float delta = radius - clamped;
        float chord = (float)Math.sqrt((double)Math.max(0.0F, radius * radius - delta * delta));
        return radius - chord;
    }

    private static RenderLayer getQuadLayer() {
        RenderLayer layer = quadLayer;
        if (layer != null) {
            return layer;
        } else {
            synchronized (LAYER_LOCK) {
                if (quadLayer == null) {
                    quadLayer = RenderLayerInvoker.dargsclient$invokeOf(
                        "dargsclient_chunk_marker_quads",
                        RenderSetup.builder(
                                RenderPipelines.register(
                                    RenderPipeline.builder(new Snippet[]{RenderPipelines.POSITION_COLOR_SNIPPET})
                                        .withLocation("pipeline/dargsclient_chunk_marker_quads")
                                        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                                        .withDepthWrite(false)
                                        .withCull(false)
                                        .build()
                                )
                            )
                            .layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
                            .translucent()
                            .build()
                    );
                }

                return quadLayer;
            }
        }
    }

    private static RenderLayer getLineLayer() {
        RenderLayer layer = lineLayer;
        if (layer != null) {
            return layer;
        } else {
            synchronized (LAYER_LOCK) {
                if (lineLayer == null) {
                    lineLayer = RenderLayerInvoker.dargsclient$invokeOf(
                        "dargsclient_chunk_marker_lines",
                        RenderSetup.builder(
                                RenderPipelines.register(
                                    RenderPipeline.builder(new Snippet[]{RenderPipelines.RENDERTYPE_LINES_SNIPPET})
                                        .withLocation("pipeline/dargsclient_chunk_marker_lines")
                                        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                                        .withDepthWrite(false)
                                        .build()
                                )
                            )
                            .layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
                            .outputTarget(OutputTarget.ITEM_ENTITY_TARGET)
                            .build()
                    );
                }

                return lineLayer;
            }
        }
    }

    public static record ChunkMarker(
        ChunkPos pos,
        int outerPlateColor,
        float outerPlateWorldY,
        float outerPlateCornerRadius,
        int innerPlateColor,
        float innerPlateWorldY,
        float innerPlateInset,
        float innerPlateCornerRadius,
        int outlineColor,
        float outlineWorldY,
        float outlineWidth,
        int stemColor,
        float stemTopWorldY,
        int tracerColor,
        float tracerTargetWorldY,
        float tracerWidth,
        List<ItemStack> icons,
        float iconWorldY,
        float iconScale,
        float iconSpacing,
        boolean flatIcons
    ) {
    }

    public static record ScanPlateStyle(float worldY, float yOffset, int color) {
    }
}
