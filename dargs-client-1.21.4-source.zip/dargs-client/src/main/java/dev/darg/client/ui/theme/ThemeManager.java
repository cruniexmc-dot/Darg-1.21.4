package dev.darg.client.ui.theme;

public final class ThemeManager {
    private static final ThemeManager INSTANCE = new ThemeManager();
    private static final ClientTheme THEME = ClientTheme.of();

    private ThemeManager() {
    }

    public static ThemeManager getInstance() {
        return INSTANCE;
    }

    public ClientTheme getCurrentTheme() {
        return THEME;
    }
}
