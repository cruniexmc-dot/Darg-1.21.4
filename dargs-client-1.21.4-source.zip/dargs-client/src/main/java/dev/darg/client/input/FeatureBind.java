package dev.darg.client.input;

import java.util.Locale;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.Window;
import org.lwjgl.glfw.GLFW;

public final class FeatureBind {
    private static final FeatureBind NONE = new FeatureBind(FeatureBind.Type.NONE, -1);
    private final FeatureBind.Type type;
    private final int code;

    private FeatureBind(FeatureBind.Type type, int code) {
        this.type = type;
        this.code = code;
    }

    public static FeatureBind none() {
        return NONE;
    }

    public static FeatureBind keyboard(int keyCode) {
        return new FeatureBind(FeatureBind.Type.KEYBOARD, keyCode);
    }

    public static FeatureBind mouse(int mouseButton) {
        return new FeatureBind(FeatureBind.Type.MOUSE, mouseButton);
    }

    public static FeatureBind parse(String value) {
        if (value != null && !value.isBlank() && !value.equalsIgnoreCase("NONE")) {
            String[] parts = value.split(":", 2);
            if (parts.length != 2) {
                return none();
            } else {
                try {
                    FeatureBind.Type type = FeatureBind.Type.fromToken(parts[0]);
                    if (type == null) {
                        return none();
                    } else {
                        int code = Integer.parseInt(parts[1].trim());

                        return switch (type) {
                            case NONE -> none();
                            case KEYBOARD -> keyboard(code);
                            case MOUSE -> mouse(code);
                        };
                    }
                } catch (IllegalArgumentException var4) {
                    return none();
                }
            }
        } else {
            return none();
        }
    }

    public FeatureBind.Type type() {
        return this.type;
    }

    public int code() {
        return this.code;
    }

    public boolean isNone() {
        return this.type == FeatureBind.Type.NONE;
    }

    public boolean isPressed(Window window) {
        return switch (this.type) {
            case NONE -> false;
            case KEYBOARD -> InputUtil.isKeyPressed(window, this.code);
            case MOUSE -> GLFW.glfwGetMouseButton(window.getHandle(), this.code) == 1;
        };
    }

    public String serialize() {
        return this.isNone() ? FeatureBind.Type.NONE.token() : this.type.token() + ":" + this.code;
    }

    public String getDisplayName() {
        return switch (this.type) {
            case NONE -> "None";
            case KEYBOARD -> getKeyboardName(this.code);
            case MOUSE -> getMouseName(this.code);
        };
    }

    private static String getKeyboardName(int keyCode) {
        String glfwName = GLFW.glfwGetKeyName(keyCode, 0);
        if (glfwName != null && !glfwName.isBlank()) {
            return glfwName.toUpperCase(Locale.ROOT);
        } else {
            return switch (keyCode) {
                case 32 -> "SPACE";
                case 256 -> "ESCAPE";
                case 257 -> "ENTER";
                case 258 -> "TAB";
                case 259 -> "BACKSPACE";
                case 260 -> "INSERT";
                case 261 -> "DELETE";
                case 262 -> "ARROW RIGHT";
                case 263 -> "ARROW LEFT";
                case 264 -> "ARROW DOWN";
                case 265 -> "ARROW UP";
                case 266 -> "PAGE UP";
                case 267 -> "PAGE DOWN";
                case 268 -> "HOME";
                case 269 -> "END";
                case 340 -> "LEFT SHIFT";
                case 341 -> "LEFT CTRL";
                case 342 -> "LEFT ALT";
                case 344 -> "RIGHT SHIFT";
                case 345 -> "RIGHT CTRL";
                case 346 -> "RIGHT ALT";
                default -> "KEY " + keyCode;
            };
        }
    }

    private static String getMouseName(int mouseButton) {
        return switch (mouseButton) {
            case 0 -> "MOUSE LEFT";
            case 1 -> "MOUSE RIGHT";
            case 2 -> "MOUSE MIDDLE";
            default -> "MOUSE " + (mouseButton + 1);
        };
    }

    public static enum Type {
        NONE("NONE"),
        KEYBOARD("KEYBOARD"),
        MOUSE("MOUSE");

        private final String token;

        private Type(String token) {
            this.token = token;
        }

        private String token() {
            return this.token;
        }

        private static FeatureBind.Type fromToken(String value) {
            String normalized = value == null ? "" : value.trim().toUpperCase(Locale.ROOT);

            for (FeatureBind.Type type : values()) {
                if (type.token.equals(normalized)) {
                    return type;
                }
            }

            return null;
        }
    }
}
