package dev.darg.client.feature.crystal;

import dev.darg.client.feature.Category;
import dev.darg.client.feature.combat.CombatSupport;
import dev.darg.client.feature.combat.ConfigurableCombatFeature;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;

public final class TotemOffhandFeature extends ConfigurableCombatFeature {
    private final ConfigurableCombatFeature.NumberSetting switchDelay = this.intSetting("switch_delay", "Switch Delay", 0, 0, 5);
    private final ConfigurableCombatFeature.NumberSetting equipDelay = this.intSetting("equip_delay", "Equip Delay", 1, 1, 5);
    private final ConfigurableCombatFeature.BooleanSetting switchBack = this.booleanSetting("switch_back", "Switch Back", false);
    private int switchClock;
    private int equipClock;
    private int switchBackClock;
    private int previousSlot = -1;
    private boolean sentSwap;
    private boolean active;

    public TotemOffhandFeature() {
        super("TotemOffhand", Category.CRYSTAL);
    }

    @Override
    protected void onEnable() {
        this.reset();
    }

    @Override
    protected void onDisable() {
        this.reset();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player != null && mc.currentScreen == null) {
            if (player.getOffHandStack().getItem() != Items.TOTEM_OF_UNDYING) {
                this.active = true;
            }

            if (this.active) {
                if (this.switchClock < this.switchDelay.intValue()) {
                    this.switchClock++;
                } else {
                    if (this.previousSlot == -1) {
                        this.previousSlot = player.getInventory().getSelectedSlot();
                    }

                    if (!CombatSupport.selectHotbarItem(player, Items.TOTEM_OF_UNDYING)) {
                        this.reset();
                    } else if (this.equipClock < this.equipDelay.intValue()) {
                        this.equipClock++;
                    } else if (!this.sentSwap) {
                        CombatSupport.swapWithOffhand(player);
                        this.sentSwap = true;
                    } else if (this.switchBackClock < this.switchDelay.intValue()) {
                        this.switchBackClock++;
                    } else {
                        if (this.switchBack.get() && this.previousSlot >= 0) {
                            CombatSupport.selectHotbarSlot(player, this.previousSlot);
                        }

                        this.reset();
                    }
                }
            }
        }
    }

    private void reset() {
        this.switchClock = 0;
        this.equipClock = 0;
        this.switchBackClock = 0;
        this.previousSlot = -1;
        this.sentSwap = false;
        this.active = false;
    }
}
