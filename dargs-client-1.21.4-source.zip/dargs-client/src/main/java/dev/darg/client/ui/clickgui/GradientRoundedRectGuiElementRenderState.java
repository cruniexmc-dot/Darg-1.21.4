package dev.darg.client.ui.clickgui;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.joml.Matrix3x2f;

final class GradientRoundedRectGuiElementRenderState implements SimpleGuiElementRenderState {
    private static final RenderPipeline PIPELINE = RenderPipelines.GUI;
    private static final TextureSetup TEXTURE_SETUP = TextureSetup.empty();
    private static final int CORNER_SAMPLE_GRID = 24;
    private static final int CORNER_ALPHA_LEVELS = 48;
    private static final Map<Integer, int[][]> CORNER_ALPHA_CACHE = new HashMap<>();
    private final Matrix3x2f pose;
    private final int left;
    private final int top;
    private final int right;
    private final int bottom;
    private final int radius;
    private final int colorTop;
    private final int colorBottom;
    private final ScreenRect scissorArea;
    private final ScreenRect bounds;

    GradientRoundedRectGuiElementRenderState(
        Matrix3x2f pose, int left, int top, int right, int bottom, int radius, int colorTop, int colorBottom, ScreenRect scissorArea
    ) {
        this.pose = pose;
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
        this.radius = radius;
        this.colorTop = colorTop;
        this.colorBottom = colorBottom;
        this.scissorArea = scissorArea;
        ScreenRect transformed = new ScreenRect(left, top, right - left, bottom - top).transformEachVertex(pose);
        this.bounds = scissorArea != null ? scissorArea.intersection(transformed) : transformed;
    }

    public void setupVertices(VertexConsumer consumer) {
        if (this.right > this.left && this.bottom > this.top && (alpha(this.colorTop) > 0 || alpha(this.colorBottom) > 0)) {
            if (this.radius <= 0) {
                this.emitGradientQuad(consumer, (float)this.left, (float)this.top, (float)this.right, (float)this.bottom);
            } else {
                this.emitGradientQuad(consumer, (float)(this.left + this.radius), (float)this.top, (float)(this.right - this.radius), (float)this.bottom);
                this.emitGradientQuad(
                    consumer, (float)this.left, (float)(this.top + this.radius), (float)(this.left + this.radius), (float)(this.bottom - this.radius)
                );
                this.emitGradientQuad(
                    consumer, (float)(this.right - this.radius), (float)(this.top + this.radius), (float)this.right, (float)(this.bottom - this.radius)
                );
                int[][] cornerAlpha = getCornerAlpha(this.radius);

                for (int row = 0; row < this.radius; row++) {
                    int yTop = this.top + row;
                    int yBottom = this.bottom - row - 1;
                    this.emitCornerRow(consumer, this.left, yTop, cornerAlpha[row], false);
                    this.emitCornerRow(consumer, this.right - this.radius, yTop, cornerAlpha[row], true);
                    this.emitCornerRow(consumer, this.left, yBottom, cornerAlpha[row], false);
                    this.emitCornerRow(consumer, this.right - this.radius, yBottom, cornerAlpha[row], true);
                }
            }
        }
    }

    public RenderPipeline pipeline() {
        return PIPELINE;
    }

    public TextureSetup textureSetup() {
        return TEXTURE_SETUP;
    }

    public ScreenRect scissorArea() {
        return this.scissorArea;
    }

    public ScreenRect bounds() {
        return this.bounds;
    }

    private void emitGradientQuad(VertexConsumer consumer, float x1, float y1, float x2, float y2) {
        if (!(x2 <= x1) && !(y2 <= y1)) {
            int cTop = this.lerpColor(y1);
            int cBottom = this.lerpColor(y2);
            if (alpha(cTop) > 0 || alpha(cBottom) > 0) {
                consumer.vertex(this.pose, x1, y1).color(cTop);
                consumer.vertex(this.pose, x1, y2).color(cBottom);
                consumer.vertex(this.pose, x2, y2).color(cBottom);
                consumer.vertex(this.pose, x2, y1).color(cTop);
            }
        }
    }

    private void emitCornerRow(VertexConsumer consumer, int originX, int y, int[] rowAlpha, boolean mirror) {
        int rowColor = this.lerpColor((float)y);
        int rgb = rowColor & 16777215;
        int baseAlpha = alpha(rowColor);
        int rowWidth = rowAlpha.length;
        int runStart = -1;
        int runAlpha = 0;

        for (int index = 0; index <= rowWidth; index++) {
            int maskAlpha = index < rowWidth ? rowAlpha[index] : -1;
            int pixelAlpha = maskAlpha <= 0 ? 0 : quantizeAlpha((baseAlpha * maskAlpha + 127) / 255);
            if (pixelAlpha == 0) {
                if (runStart >= 0) {
                    this.emitCornerRun(consumer, originX, y, runStart, index, rowWidth, mirror, runAlpha << 24 | rgb);
                    runStart = -1;
                }
            } else if (runStart < 0) {
                runStart = index;
                runAlpha = pixelAlpha;
            } else if (pixelAlpha != runAlpha) {
                this.emitCornerRun(consumer, originX, y, runStart, index, rowWidth, mirror, runAlpha << 24 | rgb);
                runStart = index;
                runAlpha = pixelAlpha;
            }
        }
    }

    private void emitCornerRun(VertexConsumer consumer, int originX, int y, int start, int end, int rowWidth, boolean mirror, int color) {
        int runLeft = mirror ? originX + (rowWidth - end) : originX + start;
        int runRight = mirror ? originX + (rowWidth - start) : originX + end;
        this.emitFlatQuad(consumer, (float)runLeft, (float)y, (float)runRight, (float)(y + 1), color);
    }

    private void emitFlatQuad(VertexConsumer consumer, float x1, float y1, float x2, float y2, int color) {
        if (!(x2 <= x1) && !(y2 <= y1) && alpha(color) > 0) {
            consumer.vertex(this.pose, x1, y1).color(color);
            consumer.vertex(this.pose, x1, y2).color(color);
            consumer.vertex(this.pose, x2, y2).color(color);
            consumer.vertex(this.pose, x2, y1).color(color);
        }
    }

    private int lerpColor(float y) {
        int span = this.bottom - this.top;
        if (span <= 0) {
            return this.colorTop;
        } else {
            float t = Math.max(0.0F, Math.min(1.0F, (y - (float)this.top) / (float)span));
            int a = Math.round((float)alpha(this.colorTop) + (float)(alpha(this.colorBottom) - alpha(this.colorTop)) * t);
            int r = Math.round((float)red(this.colorTop) + (float)(red(this.colorBottom) - red(this.colorTop)) * t);
            int g = Math.round((float)green(this.colorTop) + (float)(green(this.colorBottom) - green(this.colorTop)) * t);
            int b = Math.round((float)blue(this.colorTop) + (float)(blue(this.colorBottom) - blue(this.colorTop)) * t);
            return a << 24 | r << 16 | g << 8 | b;
        }
    }

    private static int[][] getCornerAlpha(int radius) {
        return CORNER_ALPHA_CACHE.computeIfAbsent(radius, GradientRoundedRectGuiElementRenderState::buildCornerAlpha);
    }

    private static int[][] buildCornerAlpha(int radius) {
        int[][] alpha = new int[radius][radius];
        double radiusSquared = (double)(radius * radius);
        double sampleStride = 0.041666666666666664;
        double sampleScale = 0.4427083333333333;

        for (int row = 0; row < radius; row++) {
            for (int column = 0; column < radius; column++) {
                int covered = 0;

                for (int sy = 0; sy < 24; sy++) {
                    double sampleY = (double)row + ((double)sy + 0.5) * sampleStride;
                    double distanceY = (double)radius - sampleY;

                    for (int sx = 0; sx < 24; sx++) {
                        double sampleX = (double)column + ((double)sx + 0.5) * sampleStride;
                        double distanceX = (double)radius - sampleX;
                        if (distanceX * distanceX + distanceY * distanceY <= radiusSquared) {
                            covered++;
                        }
                    }
                }

                alpha[row][column] = (int)Math.round((double)covered * sampleScale);
            }
        }

        return alpha;
    }

    private static int alpha(int color) {
        return color >>> 24 & 0xFF;
    }

    private static int red(int color) {
        return color >>> 16 & 0xFF;
    }

    private static int green(int color) {
        return color >>> 8 & 0xFF;
    }

    private static int blue(int color) {
        return color & 0xFF;
    }

    private static int quantizeAlpha(int alpha) {
        if (alpha <= 2) {
            return 0;
        } else if (alpha >= 253) {
            return 255;
        } else {
            float step = 5.3125F;
            return Math.max(0, Math.min(255, Math.round((float)Math.round((float)alpha / step) * step)));
        }
    }
}
