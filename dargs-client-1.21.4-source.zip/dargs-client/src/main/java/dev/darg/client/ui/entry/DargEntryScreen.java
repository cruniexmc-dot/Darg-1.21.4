package dev.darg.client.ui.entry;

import dev.darg.client.ui.clickgui.RenderUtil;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

public final class DargEntryScreen extends Screen {
    private static final AnimatedGifBackground BACKGROUND = new AnimatedGifBackground("/assets/dargsclient/textures/gui/entry_background.gif");
    private static final String TITLE = "Darg's Client";
    private static final int TYPEWRITER_STEP_MS = 320;
    private static final int TYPEWRITER_HOLD_MS = 1600;
    private static final int TYPEWRITER_ERASE_STEP_MS = 220;
    private static final int TYPEWRITER_RESTART_DELAY_MS = 420;
    private static final int BACKDROP_OVERLAY = 1510412836;
    private static final int TITLE_SHADOW = Integer.MIN_VALUE;
    private static final int TITLE_COLOR = -854017;
    private static final int TITLE_ACCENT = -6572289;
    private static final int BUTTON_FILL = -582196252;
    private static final int BUTTON_FILL_HOVER = -294625793;
    private static final int BUTTON_BORDER = -4665345;
    private static final int BUTTON_SHADOW = 1426063360;
    private static final int BUTTON_TEXT = -722689;
    private static final int BUTTON_TEXT_MUTED = -3220495;
    private static final int BUTTON_HIGHLIGHT = 1442840575;
    private long openedAtMs;

    public DargEntryScreen() {
        super(Text.literal("Darg's Client"));
    }

    protected void init() {
        this.openedAtMs = Util.getMeasuringTimeMs();
    }

    public boolean shouldPause() {
        return false;
    }

    public boolean shouldCloseOnEsc() {
        return false;
    }

    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        TextRenderer textRenderer = this.textRenderer();
        long now = Util.getMeasuringTimeMs();
        BACKGROUND.render(context, this.width, this.height, now);
        context.fill(0, 0, this.width, this.height, 1510412836);
        context.fill(0, 0, this.width, this.height / 3, 973211406);
        context.fill(0, this.height - this.height / 4, this.width, this.height, 1241646862);
        float titleScale = Math.max(
            2.7F, Math.min(5.4F, (float)this.width * 0.6F / Math.max(1.0F, (float)RenderUtil.getTextWidth(textRenderer, "Darg's Client")))
        );
        String titleText = this.visibleTitle(now);
        int titleWidth = Math.round((float)RenderUtil.getTextWidth(textRenderer, "Darg's Client|") * titleScale);
        float titleX = (float)(this.width - titleWidth) * 0.5F;
        float titleY = Math.max(34.0F, (float)this.height * 0.16F);
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(titleX + 3.0F, titleY + 4.0F);
        context.getMatrices().scale(titleScale, titleScale);
        RenderUtil.drawText(context, textRenderer, titleText, 0.0F, 0.0F, Integer.MIN_VALUE);
        context.getMatrices().popMatrix();
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(titleX, titleY);
        context.getMatrices().scale(titleScale, titleScale);
        RenderUtil.drawText(context, textRenderer, titleText, 0.0F, 0.0F, -854017);
        context.getMatrices().popMatrix();
        float accentWidth = Math.min(220.0F, (float)this.width * 0.3F);
        float accentX = ((float)this.width - accentWidth) * 0.5F;
        float accentY = titleY + 10.0F * titleScale + 8.0F;
        RenderUtil.drawRoundedRect(context, accentX, accentY, accentWidth, 2.0F, 1.0F, -6572289);

        for (DargEntryScreen.EntryButton button : this.layoutButtons()) {
            this.renderButton(context, textRenderer, button, mouseX, mouseY);
        }
    }

    public boolean mouseClicked(Click click, boolean doubleClick) {
        if (click.button() != 0) {
            return super.mouseClicked(click, doubleClick);
        } else {
            double mouseX = click.x();
            double mouseY = click.y();

            for (DargEntryScreen.EntryButton button : this.layoutButtons()) {
                if (contains(mouseX, mouseY, (float)button.x(), (float)button.y(), (float)button.width(), (float)button.height())) {
                    button.action().run();
                    return true;
                }
            }

            return true;
        }
    }

    private void renderButton(DrawContext context, TextRenderer textRenderer, DargEntryScreen.EntryButton button, int mouseX, int mouseY) {
        boolean hovered = contains((double)mouseX, (double)mouseY, (float)button.x(), (float)button.y(), (float)button.width(), (float)button.height());
        int fill = hovered ? -294625793 : -582196252;
        int textColor = button.primary() ? -722689 : -3220495;
        RenderUtil.drawRoundedRectClassic(
            context, (float)button.x() + 1.0F, (float)button.y() + 3.0F, (float)button.width(), (float)button.height(), 11.0F, 1426063360
        );
        RenderUtil.drawRoundedRectClassic(context, (float)button.x(), (float)button.y(), (float)button.width(), (float)button.height(), 11.0F, -4665345);
        RenderUtil.drawRoundedRectClassic(
            context, (float)button.x() + 1.0F, (float)button.y() + 1.0F, (float)button.width() - 2.0F, (float)button.height() - 2.0F, 10.0F, fill
        );
        RenderUtil.drawRoundedRectClassic(context, (float)button.x() + 2.0F, (float)button.y() + 2.0F, (float)button.width() - 4.0F, 1.0F, 0.5F, 1442840575);
        int labelWidth = RenderUtil.getTextWidth(textRenderer, button.label());
        float labelX = (float)button.x() + (float)(button.width() - labelWidth) * 0.5F;
        float labelY = (float)button.y() + ((float)button.height() - 8.0F) * 0.5F;
        RenderUtil.drawText(context, textRenderer, button.label(), labelX, labelY, textColor);
    }

    private List<DargEntryScreen.EntryButton> layoutButtons() {
        MinecraftClient client = MinecraftClient.getInstance();
        int primaryWidth = Math.min(236, Math.max(176, this.width / 3));
        int utilityWidth = Math.max(84, (primaryWidth - 8) / 2);
        int buttonHeight = 24;
        int baseX = (this.width - primaryWidth) / 2;
        int baseY = Math.max(112, this.height / 2 - 8);
        return List.of(
            new DargEntryScreen.EntryButton(
                "Singleplayer", baseX, baseY, primaryWidth, buttonHeight, true, () -> client.setScreen(new SelectWorldScreen(this))
            ),
            new DargEntryScreen.EntryButton(
                "Multiplayer", baseX, baseY + 30, primaryWidth, buttonHeight, true, () -> client.setScreen(new MultiplayerScreen(this))
            ),
            new DargEntryScreen.EntryButton(
                "Options", baseX, baseY + 64, utilityWidth, buttonHeight, false, () -> client.setScreen(new OptionsScreen(this, client.options))
            ),
            new DargEntryScreen.EntryButton("Quit Game", baseX + utilityWidth + 8, baseY + 64, utilityWidth, buttonHeight, false, client::scheduleStop)
        );
    }

    private String visibleTitle(long now) {
        long elapsed = Math.max(0L, now - this.openedAtMs);
        int characters = visibleTitleLength(elapsed);
        StringBuilder builder = new StringBuilder("Darg's Client".substring(0, characters));
        boolean showCursor = elapsed / 350L % 2L == 0L;
        if (characters < "Darg's Client".length() || showCursor) {
            builder.append('|');
        }

        return builder.toString();
    }

    private static int visibleTitleLength(long elapsed) {
        int fullLength = "Darg's Client".length();
        long typingDuration = (long)fullLength * 320L;
        long erasingDuration = (long)fullLength * 220L;
        long cycleDuration = typingDuration + 1600L + erasingDuration + 420L;
        long cyclePosition = cycleDuration > 0L ? elapsed % cycleDuration : 0L;
        if (cyclePosition < typingDuration) {
            return Math.min(fullLength, (int)(cyclePosition / 320L));
        } else if (cyclePosition < typingDuration + 1600L) {
            return fullLength;
        } else {
            long eraseStart = typingDuration + 1600L;
            if (cyclePosition < eraseStart + erasingDuration) {
                int removed = Math.min(fullLength, (int)((cyclePosition - eraseStart) / 220L));
                return Math.max(0, fullLength - removed);
            } else {
                return 0;
            }
        }
    }

    private TextRenderer textRenderer() {
        return MinecraftClient.getInstance().textRenderer;
    }

    private static boolean contains(double mouseX, double mouseY, float x, float y, float width, float height) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + height);
    }

    private static record EntryButton(String label, int x, int y, int width, int height, boolean primary, Runnable action) {
    }
}
