package dev.darg.client.feature.crystal;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.clickgui.InlineControlRenderer;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;

public final class KeyPearlFeature extends Feature {
    private static final float INLINE_HEIGHT = 32.0F;
    private static final int THROW_DELAY = 1;
    private static final int SWITCH_BACK_DELAY = 1;
    private boolean hasThrown = false;
    private int clock = 0;
    private int switchClock = 0;
    private int previousSlot = -1;

    public KeyPearlFeature() {
        super("KeyPearl", Category.CRYSTAL);
    }

    @Override
    public boolean shouldPersistEnabledState() {
        return false;
    }

    @Override
    protected void onEnable() {
        this.reset();
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            this.restorePreviousSlot(mc.player);
        }

        this.reset();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player != null && mc.interactionManager != null && mc.currentScreen == null) {
            if (this.previousSlot < 0) {
                this.previousSlot = player.getInventory().getSelectedSlot();
            }

            if (!player.getMainHandStack().isOf(Items.ENDER_PEARL) && !selectFromHotbar(player, Items.ENDER_PEARL)) {
                this.setEnabled(false);
            } else if (this.clock < 1) {
                this.clock++;
            } else if (!this.hasThrown) {
                mc.interactionManager.interactItem(player, Hand.MAIN_HAND);
                player.swingHand(Hand.MAIN_HAND);
                this.hasThrown = true;
                this.switchClock = 0;
            } else if (this.switchClock < 1) {
                this.switchClock++;
            } else {
                this.restorePreviousSlot(player);
                this.setEnabled(false);
            }
        } else {
            this.setEnabled(false);
        }
    }

    private static boolean selectFromHotbar(ClientPlayerEntity player, Item item) {
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getStack(i).isOf(item)) {
                player.getInventory().setSelectedSlot(i);
                player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(i));
                return true;
            }
        }

        return false;
    }

    private void restorePreviousSlot(ClientPlayerEntity player) {
        if (this.previousSlot >= 0) {
            if (player.getInventory().getSelectedSlot() != this.previousSlot) {
                player.getInventory().setSelectedSlot(this.previousSlot);
                player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(this.previousSlot));
            }
        }
    }

    private void reset() {
        this.hasThrown = false;
        this.clock = 0;
        this.switchClock = 0;
        this.previousSlot = -1;
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 32.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        float cx = x + 10.0F;
        float keybindY = y + 8.0F;
        float bindW = 70.0F;
        float bindX = x + width - bindW - 10.0F;
        boolean capturing = DargsClient.getInstance().getKeybindManager().isCapturing(this);
        boolean hoverBind = InlineControlRenderer.containsButton((double)mouseX, (double)mouseY, bindX, keybindY, bindW);
        String bindLabel = InlineControlRenderer.fitText(
            textRenderer, DargsClient.getInstance().getKeybindManager().getBindLabel(this).toUpperCase(Locale.ROOT), 58
        );
        RenderUtil.drawText(context, textRenderer, "KEYBIND", cx, keybindY + 2.0F, theme.white());
        InlineControlRenderer.drawButton(context, textRenderer, theme, bindLabel, capturing, hoverBind, bindX, keybindY, bindW);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (!this.containsInline(mouseX, mouseY, x, y, width)) {
            return false;
        } else {
            float keybindY = y + 8.0F;
            float bindX = x + width - 80.0F;
            if (button == 0 && InlineControlRenderer.containsButton(mouseX, mouseY, bindX, keybindY, 70.0F)) {
                DargsClient.getInstance().getKeybindManager().beginCapture(this, notificationManager);
                return true;
            } else if (button == 1 && InlineControlRenderer.containsButton(mouseX, mouseY, bindX, keybindY, 70.0F)) {
                DargsClient.getInstance().getKeybindManager().clearBind(this, notificationManager);
                return true;
            } else {
                return false;
            }
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("Press keybind to throw pearl", "Auto-switches back to previous slot");
    }

    private boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + 32.0F);
    }
}
