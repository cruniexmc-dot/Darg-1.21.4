package dev.darg.client.feature.basefinding;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.mixin.RenderLayerInvoker;
import dev.darg.client.render.WorldRenderUtil;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.OutputTarget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.chunk.WorldChunk;

public final class LightFinderFeature extends Feature {
    private static final int MIN_LIGHT_LEVEL = 5;
    private static final int SCAN_RADIUS_CHUNKS = 2;
    private static final int SCAN_INTERVAL_TICKS = 40;
    private static final int OPTIMIZATION_INTERVAL_TICKS = 20;
    private static final float LINE_WIDTH = 1.4F;
    private static volatile RenderLayer lineLayer;
    private static final Object LAYER_LOCK = new Object();
    private final ConcurrentHashMap<BlockPos, Integer> groupedLights = new ConcurrentHashMap<>();
    private final AtomicBoolean scanInProgress = new AtomicBoolean(false);
    private int scanTimer = 0;
    private int optimizationTimer = 0;
    private volatile int lastScannedChunks;
    private volatile int lastRenderedBoxes;

    public LightFinderFeature() {
        super("LightFinder", Category.BASEFINDING);
    }

    @Override
    protected void onDisable() {
        this.groupedLights.clear();
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world != null && client.player != null) {
            if (++this.scanTimer >= 40) {
                this.scanTimer = 0;
                this.triggerBackgroundScan(client);
            }

            if (++this.optimizationTimer >= 20) {
                this.optimizationTimer = 0;
                this.runOptimization();
            }
        } else {
            this.groupedLights.clear();
        }
    }

    private void triggerBackgroundScan(MinecraftClient client) {
        if (this.scanInProgress.compareAndSet(false, true)) {
            PlayerEntity player = client.player;
            ClientWorld world = client.world;
            if (player != null && world != null) {
                int centerX = player.getChunkPos().x;
                int centerZ = player.getChunkPos().z;
                CompletableFuture.runAsync(() -> {
                    try {
                        ConcurrentHashMap<BlockPos, Integer> newLights = new ConcurrentHashMap<>();
                        Mutable mutablePos = new Mutable();
                        int scannedChunks = 0;

                        for (int cx = centerX - 2; cx <= centerX + 2; cx++) {
                            for (int cz = centerZ - 2; cz <= centerZ + 2; cz++) {
                                WorldChunk chunk = world.getChunk(cx, cz);
                                if (chunk != null && !chunk.isEmpty()) {
                                    scannedChunks++;
                                    int baseX = cx << 4;
                                    int baseZ = cz << 4;

                                    for (int localX = 0; localX < 16; localX++) {
                                        for (int localZ = 0; localZ < 16; localZ++) {
                                            for (int y = -63; y <= -1; y++) {
                                                mutablePos.set(baseX + localX, y, baseZ + localZ);
                                                BlockState state = world.getBlockState(mutablePos);
                                                int luminance = state.getLuminance();
                                                if (luminance >= 5 && !shouldSkipBlock(state.getBlock())) {
                                                    newLights.put(mutablePos.toImmutable(), luminance);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        this.groupedLights.clear();
                        this.groupedLights.putAll(newLights);
                        this.lastScannedChunks = scannedChunks;
                    } catch (Exception var20) {
                    } finally {
                        this.scanInProgress.set(false);
                    }
                });
            } else {
                this.scanInProgress.set(false);
            }
        }
    }

    private static boolean shouldSkipBlock(Block block) {
        return false;
    }

    private void runOptimization() {
        this.groupedLights.entrySet().removeIf(entry -> {
            int level = entry.getValue();
            return level > 7 ? false : this.hasHigherLevelLightIn3x3Area(entry.getKey(), level);
        });
    }

    private boolean hasHigherLevelLightIn3x3Area(BlockPos pos, int level) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx != 0 || dz != 0) {
                    Integer neighborLevel = this.groupedLights.get(pos.add(dx, 0, dz));
                    if (neighborLevel != null && neighborLevel > level) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of(
            "State: " + (this.isEnabled() ? "Enabled" : "Disabled"),
            "Highlights: " + this.groupedLights.size(),
            "Rendered: " + this.lastRenderedBoxes,
            "Scan: " + (this.scanInProgress.get() ? "Running" : "Idle") + " (" + this.lastScannedChunks + " chunks)",
            "Interval: 40 ticks"
        );
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        if (this.groupedLights.isEmpty()) {
            this.lastRenderedBoxes = 0;
        } else {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.world != null && client.player != null) {
                MatrixStack matrices = context.matrices();
                if (matrices != null) {
                    Camera camera = client.gameRenderer.getCamera();
                    if (camera != null && camera.isReady()) {
                        Vec3d cameraPos = camera.getCameraPos();
                        Map<BlockPos, Integer> snapshot = Map.copyOf(this.groupedLights);
                        context.commandQueue().submitCustom(matrices, getLineLayer(), (entry, buffer) -> {
                            int rendered = 0;

                            for (Entry<BlockPos, Integer> mapEntry : snapshot.entrySet()) {
                                BlockPos pos = mapEntry.getKey();
                                int lightLevel = mapEntry.getValue();
                                float alpha = (float)(0.3 + 0.7 * ((double)lightLevel / 15.0));
                                float intensity = (float)lightLevel / 15.0F;
                                int r = 255;
                                int g = (int)(180.0F + 75.0F * intensity);
                                int b = (int)(80.0F * intensity);
                                int a = Math.min(255, (int)(alpha * 255.0F));
                                int color = WorldRenderUtil.argb(a, r, g, b);
                                float minX = (float)((double)pos.getX() - cameraPos.x);
                                float minY = (float)((double)pos.getY() - cameraPos.y);
                                float minZ = (float)((double)pos.getZ() - cameraPos.z);
                                float maxX = minX + 1.0F;
                                float maxY = minY + 1.0F;
                                float maxZ = minZ + 1.0F;
                                WorldRenderUtil.drawWireBox(entry, buffer, minX, minY, minZ, maxX, maxY, maxZ, color, 1.4F);
                                rendered++;
                            }

                            this.lastRenderedBoxes = rendered;
                        });
                    }
                }
            }
        }
    }

    private static RenderLayer getLineLayer() {
        RenderLayer layer = lineLayer;
        if (layer != null) {
            return layer;
        } else {
            synchronized (LAYER_LOCK) {
                if (lineLayer == null) {
                    lineLayer = RenderLayerInvoker.dargsclient$invokeOf(
                        "dargsclient_light_finder_lines",
                        RenderSetup.builder(
                                RenderPipelines.register(
                                    RenderPipeline.builder(new Snippet[]{RenderPipelines.RENDERTYPE_LINES_SNIPPET})
                                        .withLocation("pipeline/dargsclient_light_finder_lines")
                                        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                                        .withDepthWrite(false)
                                        .build()
                                )
                            )
                            .layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
                            .outputTarget(OutputTarget.ITEM_ENTITY_TARGET)
                            .build()
                    );
                }

                return lineLayer;
            }
        }
    }
}
