package dev.darg.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import net.minecraft.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({SplashOverlay.class})
public abstract class SplashOverlayMixin {
    @Unique
    private static final String dargsclient$TITLE = "darg";
    @Unique
    private long dargsclient$animationStart = -1L;
    @Unique
    private static final float[][] dargsclient$ORBITS = new float[][]{
        {48.0F, 3.0F, 1800.0F, 0.5F, 3.0F}, {80.0F, 5.0F, 3200.0F, 0.42F, 2.2F}, {116.0F, 7.0F, 5200.0F, 0.32F, 1.6F}
    };

    @Inject(
        method = {"render"},
        at = {@At("TAIL")}
    )
    private void dargsclient$renderCustomSplash(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.getWindow() != null) {
            TextRenderer textRenderer = client.textRenderer;
            if (textRenderer != null) {
                long now = Util.getMeasuringTimeMs();
                if (this.dargsclient$animationStart < 0L) {
                    this.dargsclient$animationStart = now;
                }

                long elapsed = now - this.dargsclient$animationStart;
                int sw = client.getWindow().getScaledWidth();
                int sh = client.getWindow().getScaledHeight();
                float cx = (float)sw * 0.5F;
                float cy = (float)sh * 0.5F;
                context.fill(0, 0, sw, sh, -16777216);
                float fadeAlpha = Math.min(1.0F, (float)elapsed / 700.0F);
                int particleRgb = 15790320;

                for (float[] orbit : dargsclient$ORBITS) {
                    float radius = orbit[0];
                    int count = (int)orbit[1];
                    float period = orbit[2];
                    float tiltY = orbit[3];
                    float pSize = orbit[4];

                    for (int i = 0; i < count; i++) {
                        float angle = (float)((Math.PI * 2) * (double)i / (double)count + (Math.PI * 2) * (double)elapsed / (double)period);
                        float px = cx + (float)Math.cos((double)angle) * radius;
                        float py = cy + (float)Math.sin((double)angle) * radius * tiltY;
                        float depth = ((float)Math.sin((double)angle) + 1.0F) * 0.5F;
                        float alphaMult = (0.35F + depth * 0.65F) * fadeAlpha;
                        float size = pSize * (0.55F + depth * 0.45F);

                        for (int g = 3; g >= 1; g--) {
                            int ga = (int)(alphaMult * 255.0F * 0.28F / (float)g);
                            int gs = Math.round(size * (float)(g + 1));
                            context.fill(Math.round(px) - gs, Math.round(py) - gs, Math.round(px) + gs, Math.round(py) + gs, ga << 24 | particleRgb);
                        }

                        int ca = (int)(alphaMult * 255.0F);
                        int cs = Math.max(1, Math.round(size * 0.5F));
                        context.fill(Math.round(px) - cs, Math.round(py) - cs, Math.round(px) + cs, Math.round(py) + cs, ca << 24 | particleRgb);
                    }
                }

                float pulse = 1.0F + 0.03F * (float)Math.sin((double)elapsed / 750.0);
                float textScale = 3.6F * pulse;
                float scaledW = (float)textRenderer.getWidth("darg") * textScale;
                float scaledH = 9.0F * textScale;
                float textX = cx - scaledW * 0.5F;
                float textY = cy - scaledH * 0.5F;
                int textAlpha = (int)(fadeAlpha * 255.0F);
                int textColor = textAlpha << 24 | 15263976;
                context.getMatrices().pushMatrix();
                context.getMatrices().translate(textX, textY);
                context.getMatrices().scale(textScale, textScale);
                context.drawText(textRenderer, "darg", 0, 0, textColor, false);
                context.getMatrices().popMatrix();
            }
        }
    }
}
