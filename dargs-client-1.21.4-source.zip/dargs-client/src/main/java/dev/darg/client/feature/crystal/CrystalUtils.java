package dev.darg.client.feature.crystal;

import java.util.List;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

public final class CrystalUtils {
    private CrystalUtils() {
    }

    public static boolean canPlaceCrystal(BlockPos pos, World world) {
        return !world.getBlockState(pos).isOf(Blocks.OBSIDIAN) && !world.getBlockState(pos).isOf(Blocks.BEDROCK)
            ? false
            : canPlaceCrystalAssumeBase(pos, world);
    }

    public static boolean canPlaceCrystalAssumeBase(BlockPos pos, World world) {
        BlockPos above = pos.up();
        if (!world.isAir(above)) {
            return false;
        } else {
            double x = (double)above.getX();
            double y = (double)above.getY();
            double z = (double)above.getZ();
            List<Entity> blocking = world.getOtherEntities(null, new Box(x, y, z, x + 1.0, y + 2.0, z + 1.0));
            return blocking.isEmpty();
        }
    }
}
