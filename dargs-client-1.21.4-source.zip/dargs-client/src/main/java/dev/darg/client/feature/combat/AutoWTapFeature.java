package dev.darg.client.feature.combat;

import dev.darg.client.feature.Category;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket.Handler;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public final class AutoWTapFeature extends ConfigurableCombatFeature implements CombatFeatureHooks.PacketSendHook {
    private final ConfigurableCombatFeature.NumberSetting delayMin = this.intSetting("delay_min", "Delay Min", 230, 0, 1000);
    private final ConfigurableCombatFeature.NumberSetting delayMax = this.intSetting("delay_max", "Delay Max", 270, 0, 1000);
    private final ConfigurableCombatFeature.BooleanSetting inAir = this.booleanSetting("in_air", "In Air", false);
    private boolean holdingForward;
    private boolean sprinting;
    private int releaseTicks;
    private int sprintTicks;
    private int currentDelayTicks;
    private boolean jumpedWhileHitting;

    public AutoWTapFeature() {
        super("AutoWTap", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        this.reset();
        this.currentDelayTicks = this.randomDelayTicks();
    }

    @Override
    protected void onDisable() {
        this.resetForwardKey();
        this.reset();
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null) {
            this.resetForwardKey();
            this.reset();
        } else if (GLFW.glfwGetKey(client.getWindow().getHandle(), 87) != 1) {
            this.resetForwardKey();
            this.reset();
        } else if (this.inAir.get() || player.isOnGround()) {
            if (this.holdingForward) {
                if (this.releaseTicks > 0) {
                    this.releaseTicks--;
                } else {
                    client.options.forwardKey.setPressed(false);
                    this.sprinting = true;
                    this.holdingForward = false;
                    this.sprintTicks = 0;
                    this.currentDelayTicks = this.randomDelayTicks();
                }
            } else {
                if (this.sprinting) {
                    this.sprintTicks++;
                    if (this.sprintTicks >= this.currentDelayTicks) {
                        client.options.forwardKey.setPressed(true);
                        this.sprinting = false;
                        this.sprintTicks = 0;
                        this.currentDelayTicks = this.randomDelayTicks();
                    }
                }
            }
        }
    }

    @Override
    public boolean onSendPacket(MinecraftClient client, Packet<?> packet) {
        if (packet instanceof PlayerInteractEntityC2SPacket interactPacket) {
            final ClientPlayerEntity player = client.player;
            if (player == null) {
                return false;
            } else {
                interactPacket.handle(new Handler() {
                    public void interact(Hand hand) {
                    }

                    public void interactAt(Hand hand, Vec3d pos) {
                    }

                    public void attack() {
                        if (GLFW.glfwGetKey(client.getWindow().getHandle(), 32) == 1 && !AutoWTapFeature.this.inAir.get()) {
                            AutoWTapFeature.this.jumpedWhileHitting = true;
                        }

                        if (AutoWTapFeature.this.inAir.get() || player.isOnGround()) {
                            if (!AutoWTapFeature.this.jumpedWhileHitting && client.options.forwardKey.isPressed() && player.isSprinting()) {
                                AutoWTapFeature.this.holdingForward = true;
                                AutoWTapFeature.this.releaseTicks = 1;
                                AutoWTapFeature.this.sprintTicks = 0;
                            }
                        }
                    }
                });
                return false;
            }
        } else {
            return false;
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("Delay: " + this.delayMin.intValue() + "-" + this.delayMax.intValue() + " ms", "In air: " + this.inAir.get());
    }

    private int randomDelayTicks() {
        int min = Math.min(this.delayMin.intValue(), this.delayMax.intValue());
        int max = Math.max(this.delayMin.intValue(), this.delayMax.intValue());
        int delayMs = ThreadLocalRandom.current().nextInt(min, max + 1);
        return Math.max(1, (int)Math.ceil((double)delayMs / 50.0));
    }

    private void resetForwardKey() {
        MinecraftClient client = MinecraftClient.getInstance();
        client.options.forwardKey.setPressed(false);
    }

    private void reset() {
        this.holdingForward = false;
        this.sprinting = false;
        this.releaseTicks = 0;
        this.sprintTicks = 0;
        this.jumpedWhileHitting = false;
    }
}
