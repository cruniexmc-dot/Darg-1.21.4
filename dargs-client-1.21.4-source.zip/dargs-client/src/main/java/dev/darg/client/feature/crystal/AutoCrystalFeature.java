package dev.darg.client.feature.crystal;

import dev.darg.client.feature.Category;
import dev.darg.client.feature.combat.CombatFeatureHooks;
import dev.darg.client.feature.combat.CombatSupport;
import dev.darg.client.feature.combat.ConfigurableCombatFeature;
import dev.darg.client.input.FeatureBind;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;

public final class AutoCrystalFeature extends ConfigurableCombatFeature implements CombatFeatureHooks.ItemUseHook {
    private final ConfigurableCombatFeature.BindSetting activateKey = this.bindSetting("activate_key", "Activate Key", FeatureBind.mouse(1));
    private final ConfigurableCombatFeature.NumberSetting placeDelay = this.intSetting("place_delay", "Place Delay", 0, 0, 20);
    private final ConfigurableCombatFeature.NumberSetting breakDelay = this.intSetting("break_delay", "Break Delay", 0, 0, 20);
    private final ConfigurableCombatFeature.NumberSetting placeChance = this.intSetting("place_chance", "Place Chance", 100, 0, 100);
    private final ConfigurableCombatFeature.NumberSetting breakChance = this.intSetting("break_chance", "Break Chance", 100, 0, 100);
    private final ConfigurableCombatFeature.BooleanSetting stopOnKill = this.booleanSetting("stop_on_kill", "Stop On Kill", false);
    private final ConfigurableCombatFeature.BooleanSetting fakePunch = this.booleanSetting("fake_punch", "Fake Punch", false);
    private final ConfigurableCombatFeature.BooleanSetting clickSimulation = this.booleanSetting("click_simulation", "Click Simulation", false);
    private final ConfigurableCombatFeature.BooleanSetting damageTick = this.booleanSetting("damage_tick", "Damage Tick", false);
    private final ConfigurableCombatFeature.BooleanSetting antiWeakness = this.booleanSetting("anti_weakness", "Anti Weakness", false);
    private final ConfigurableCombatFeature.NumberSetting particleChance = this.intSetting("particle_chance", "Particle Chance", 20, 0, 100);
    private int placeClock;
    private int breakClock;
    public boolean crystalling;

    public AutoCrystalFeature() {
        super("AutoCrystal", Category.CRYSTAL);
    }

    @Override
    protected void onEnable() {
        this.placeClock = 0;
        this.breakClock = 0;
        this.crystalling = false;
    }

    @Override
    protected void onDisable() {
        this.crystalling = false;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        ClientPlayerInteractionManager im = mc.interactionManager;
        if (player == null || im == null || mc.world == null || mc.currentScreen != null) {
            this.crystalling = false;
        } else if (!player.isDead() && !player.isSpectator() && !player.isCreative()) {
            boolean keyHeld = this.activateKey.isPressed(mc.getWindow());
            if (!keyHeld) {
                this.placeClock = 0;
                this.breakClock = 0;
                this.crystalling = false;
            } else if (!player.getMainHandStack().isOf(Items.END_CRYSTAL)) {
                this.crystalling = false;
            } else {
                this.crystalling = true;
                if (this.stopOnKill.get()) {
                    for (AbstractClientPlayerEntity other : mc.world.getPlayers()) {
                        if (other != player && !other.isAlive() && other.squaredDistanceTo(player) < 256.0) {
                            return;
                        }
                    }
                }

                if (this.placeClock > 0) {
                    this.placeClock--;
                }

                if (this.breakClock > 0) {
                    this.breakClock--;
                }

                if (!this.damageTick.get() || player.hurtTime <= 0 || player.isOnGround()) {
                    if (this.placeClock == 0 && mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == Type.BLOCK) {
                        boolean base = CombatSupport.isCrystalBase(mc.world.getBlockState(hit.getBlockPos()));
                        if (base
                            && CrystalUtils.canPlaceCrystalAssumeBase(hit.getBlockPos(), mc.world)
                            && Math.random() * 100.0 <= this.placeChance.doubleValue()) {
                            im.interactBlock(player, Hand.MAIN_HAND, hit);
                            player.swingHand(Hand.MAIN_HAND);
                            this.placeClock = this.placeDelay.intValue() + (int)(Math.random() * 2.0);
                        }
                    }

                    if (this.breakClock == 0 && mc.crosshairTarget instanceof EntityHitResult entityHit) {
                        Entity entity = entityHit.getEntity();
                        if ((entity instanceof EndCrystalEntity || entity instanceof SlimeEntity)
                            && CombatSupport.canBreakCrystalWithCurrentItem(player)
                            && Math.random() * 100.0 <= this.breakChance.doubleValue()) {
                            im.attackEntity(player, entity);
                            player.swingHand(Hand.MAIN_HAND);
                            this.breakClock = this.breakDelay.intValue() + (int)(Math.random() * 2.0);
                        }
                    }
                }
            }
        } else {
            this.crystalling = false;
        }
    }

    public boolean shouldCancelItemUse() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (this.crystalling && mc.player != null && mc.world != null) {
            if (!mc.player.getMainHandStack().isOf(Items.END_CRYSTAL)) {
                return false;
            } else {
                if (mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == Type.BLOCK) {
                    return CombatSupport.isCrystalBase(mc.world.getBlockState(hit.getBlockPos()));
                }

                return false;
            }
        } else {
            return false;
        }
    }

    @Override
    public boolean onBeforeItemUse(MinecraftClient client) {
        return this.shouldCancelItemUse();
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of(
            "Trigger: hold right-click with crystals",
            "Place delay: " + this.placeDelay.intValue() + " ticks",
            "Break delay: " + this.breakDelay.intValue() + " ticks",
            "Crystalling: " + this.crystalling
        );
    }
}
