package dev.darg.client.feature.combat;

import dev.darg.client.feature.Category;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.ShieldItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;
import org.lwjgl.glfw.GLFW;

public final class TriggerBotFeature extends ConfigurableCombatFeature implements CombatFeatureHooks.AttackHook {
    private final ConfigurableCombatFeature.BooleanSetting inScreen = this.booleanSetting("in_screen", "Work In Screen", false);
    private final ConfigurableCombatFeature.BooleanSetting whileUse = this.booleanSetting("while_use", "While Use", false);
    private final ConfigurableCombatFeature.BooleanSetting onLeftClick = this.booleanSetting("on_left_click", "On Left Click", false);
    private final ConfigurableCombatFeature.BooleanSetting allItems = this.booleanSetting("all_items", "All Items", false);
    private final ConfigurableCombatFeature.NumberSetting swordDelay = this.intSetting("sword_delay", "Sword Delay", 550, 0, 1000);
    private final ConfigurableCombatFeature.NumberSetting axeDelay = this.intSetting("axe_delay", "Axe Delay", 800, 0, 1000);
    private final ConfigurableCombatFeature.BooleanSetting checkShield = this.booleanSetting("check_shield", "Check Shield", false);
    private final ConfigurableCombatFeature.BooleanSetting onlyCritSword = this.booleanSetting("only_crit_sword", "Only Crit Sword", false);
    private final ConfigurableCombatFeature.BooleanSetting onlyCritAxe = this.booleanSetting("only_crit_axe", "Only Crit Axe", false);
    private final ConfigurableCombatFeature.BooleanSetting swing = this.booleanSetting("swing_hand", "Swing Hand", true);
    private final ConfigurableCombatFeature.BooleanSetting whileAscend = this.booleanSetting("while_ascend", "While Ascending", false);
    private final ConfigurableCombatFeature.BooleanSetting clickSimulation = this.booleanSetting("click_simulation", "Click Simulation", false);
    private final ConfigurableCombatFeature.BooleanSetting strayBypass = this.booleanSetting("stray_bypass", "Stray Bypass", false);
    private final ConfigurableCombatFeature.BooleanSetting allEntities = this.booleanSetting("all_entities", "All Entities", false);
    private final ConfigurableCombatFeature.BooleanSetting useShield = this.booleanSetting("use_shield", "Use Shield", false);
    private final ConfigurableCombatFeature.NumberSetting shieldTime = this.intSetting("shield_time", "Shield Time", 350, 0, 1000);
    private final ConfigurableCombatFeature.BooleanSetting sticky = this.booleanSetting("sticky", "Same Player", false);
    private int currentSwordDelay;
    private int currentAxeDelay;
    private Entity lastTarget;

    public TriggerBotFeature() {
        super("TriggerBot", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        this.currentSwordDelay = this.randomDelay(this.swordDelay.intValue());
        this.currentAxeDelay = this.randomDelay(this.axeDelay.intValue());
        this.lastTarget = null;
    }

    @Override
    protected void onDisable() {
        this.lastTarget = null;
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player != null && client.world != null) {
            if (this.inScreen.get() || client.currentScreen == null) {
                if (!this.onLeftClick.get() || GLFW.glfwGetMouseButton(client.getWindow().getHandle(), 0) == 1) {
                    if (this.whileUse.get()
                        || !CombatSupport.isUsingFoodOrShield(player)
                        || GLFW.glfwGetMouseButton(client.getWindow().getHandle(), 1) != 1) {
                        if (this.whileAscend.get() || player.isOnGround() || !(player.getVelocity().y > 0.0) && !(player.fallDistance <= 0.0)) {
                            if (client.crosshairTarget instanceof EntityHitResult entityHit && client.crosshairTarget.getType() == Type.ENTITY) {
                                Entity target = entityHit.getEntity();
                                if (!this.canAttackEntity(player, target)) {
                                    return;
                                }

                                if (this.sticky.get() && this.lastTarget != null && target != this.lastTarget) {
                                    return;
                                }

                                if (target instanceof PlayerEntity targetPlayer
                                    && this.checkShield.get()
                                    && targetPlayer.isBlocking()
                                    && !CombatSupport.isShieldFacingAway(targetPlayer, player)) {
                                    return;
                                }

                                if (target instanceof PlayerEntity
                                    && this.onlyCritSword.get()
                                    && this.isSword(player.getMainHandStack().getItem())
                                    && player.fallDistance <= 0.0) {
                                    return;
                                }

                                if (target instanceof PlayerEntity
                                    && this.onlyCritAxe.get()
                                    && player.getMainHandStack().getItem() instanceof AxeItem
                                    && player.fallDistance <= 0.0) {
                                    return;
                                }

                                if (!this.readyForAttack(player)) {
                                    return;
                                }

                                this.attack(client, player, target);
                                return;
                            }
                        }
                    }
                }
            }
        }
    }

    @Override
    public boolean onBeforeAttack(MinecraftClient client) {
        return this.onLeftClick.get() && GLFW.glfwGetMouseButton(client.getWindow().getHandle(), 0) != 1;
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of(
            "Sword delay: " + this.swordDelay.intValue() + " ms", "Axe delay: " + this.axeDelay.intValue() + " ms", "Sticky target: " + this.sticky.get()
        );
    }

    private boolean readyForAttack(ClientPlayerEntity player) {
        Item item = player.getMainHandStack().getItem();
        if (!this.allItems.get() && !this.isSword(item) && !(item instanceof AxeItem)) {
            return false;
        } else if (this.isSword(item)) {
            if (this.currentSwordDelay > 0) {
                this.currentSwordDelay--;
                return false;
            } else {
                return true;
            }
        } else if (item instanceof AxeItem) {
            if (this.currentAxeDelay > 0) {
                this.currentAxeDelay--;
                return false;
            } else {
                return true;
            }
        } else {
            return this.allItems.get();
        }
    }

    private void attack(MinecraftClient client, ClientPlayerEntity player, Entity target) {
        client.interactionManager.attackEntity(player, target);
        if (this.swing.get()) {
            player.swingHand(Hand.MAIN_HAND);
        }

        if (this.clickSimulation.get()) {
            client.options.attackKey.setPressed(true);
            client.options.attackKey.setPressed(false);
        }

        if (this.isSword(player.getMainHandStack().getItem())) {
            this.currentSwordDelay = this.randomDelay(this.swordDelay.intValue());
        } else if (player.getMainHandStack().getItem() instanceof AxeItem) {
            this.currentAxeDelay = this.randomDelay(this.axeDelay.intValue());
        } else {
            this.currentSwordDelay = this.randomDelay(this.swordDelay.intValue());
        }

        if (this.useShield.get() && player.getOffHandStack().getItem() instanceof ShieldItem) {
            client.options.useKey.setPressed(true);
            client.options.useKey.setPressed(false);
        }

        if (target instanceof PlayerEntity) {
            this.lastTarget = target;
        }
    }

    private boolean canAttackEntity(ClientPlayerEntity player, Entity target) {
        return target instanceof PlayerEntity ? true : this.strayBypass.get() && target instanceof ZombieEntity || this.allEntities.get();
    }

    private int randomDelay(int baseDelay) {
        int jitter = ThreadLocalRandom.current().nextInt(-20, 21);
        return Math.max(0, (int)Math.ceil((double)(baseDelay + jitter) / 50.0));
    }

    private boolean isSword(Item item) {
        return item == Items.WOODEN_SWORD
            || item == Items.STONE_SWORD
            || item == Items.IRON_SWORD
            || item == Items.GOLDEN_SWORD
            || item == Items.DIAMOND_SWORD
            || item == Items.NETHERITE_SWORD;
    }
}
