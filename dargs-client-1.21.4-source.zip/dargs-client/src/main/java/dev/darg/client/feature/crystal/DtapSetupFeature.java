package dev.darg.client.feature.crystal;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.clickgui.InlineControlRenderer;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.List;
import java.util.Locale;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import org.lwjgl.glfw.GLFW;

public final class DtapSetupFeature extends Feature {
    private static final float INLINE_HEIGHT = 32.0F;
    private static final int SWITCH_DELAY = 0;
    private static final int PLACE_DELAY = 0;
    private int switchClock = 0;
    private int placeClock = 0;
    private boolean active = false;
    private boolean crystalling = false;
    private boolean crystalSelected = false;

    public DtapSetupFeature() {
        super("DtapSetup", Category.CRYSTAL);
    }

    @Override
    protected void onEnable() {
        this.reset();
    }

    @Override
    protected void onDisable() {
        this.reset();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        ClientPlayerInteractionManager im = mc.interactionManager;
        if (player != null && im != null && mc.world != null && mc.currentScreen == null) {
            boolean keyHeld = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), 1) == 1;
            if (!keyHeld) {
                this.reset();
            } else {
                Item held = player.getMainHandStack().getItem();
                boolean isMeleeWeapon = player.getMainHandStack().contains(DataComponentTypes.TOOL)
                    && (
                        held == Items.DIAMOND_SWORD
                            || held == Items.NETHERITE_SWORD
                            || held == Items.IRON_SWORD
                            || held == Items.STONE_SWORD
                            || held == Items.GOLDEN_SWORD
                            || held == Items.WOODEN_SWORD
                            || held == Items.DIAMOND_AXE
                            || held == Items.NETHERITE_AXE
                    );
                boolean validItem = isMeleeWeapon || held == Items.END_CRYSTAL || held == Items.TOTEM_OF_UNDYING;
                if (!validItem && !this.active) {
                    this.reset();
                } else {
                    this.active = true;
                    if (!this.crystalling) {
                        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() == Type.MISS) {
                            this.reset();
                            return;
                        }

                        boolean onBase = mc.world.getBlockState(hit.getBlockPos()).isOf(Blocks.OBSIDIAN)
                            || mc.world.getBlockState(hit.getBlockPos()).isOf(Blocks.BEDROCK);
                        if (onBase) {
                            this.crystalling = true;
                            return;
                        }

                        mc.options.useKey.setPressed(false);
                        if (!player.isHolding(Items.OBSIDIAN)) {
                            if (this.switchClock > 0) {
                                this.switchClock--;
                                return;
                            }

                            if (selectFromHotbar(player, Items.OBSIDIAN)) {
                                this.switchClock = 0;
                            }

                            return;
                        }

                        if (this.placeClock > 0) {
                            this.placeClock--;
                            return;
                        }

                        im.interactBlock(player, Hand.MAIN_HAND, hit);
                        player.swingHand(Hand.MAIN_HAND);
                        this.placeClock = 0 + (int)(Math.random() * 2.0);
                        this.crystalling = true;
                    }

                    if (this.crystalling && !player.isHolding(Items.END_CRYSTAL) && !this.crystalSelected) {
                        if (this.switchClock > 0) {
                            this.switchClock--;
                            return;
                        }

                        this.crystalSelected = selectFromHotbar(player, Items.END_CRYSTAL);
                        this.switchClock = 0;
                    }
                }
            }
        } else {
            this.reset();
        }
    }

    private static boolean selectFromHotbar(ClientPlayerEntity player, Item item) {
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getStack(i).isOf(item)) {
                player.getInventory().setSelectedSlot(i);
                player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(i));
                return true;
            }
        }

        return false;
    }

    private void reset() {
        this.placeClock = 0;
        this.switchClock = 0;
        this.active = false;
        this.crystalling = false;
        this.crystalSelected = false;
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 32.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        float cx = x + 10.0F;
        float keybindY = y + 8.0F;
        float bindW = 70.0F;
        float bindX = x + width - bindW - 10.0F;
        boolean capturing = DargsClient.getInstance().getKeybindManager().isCapturing(this);
        boolean hoverBind = InlineControlRenderer.containsButton((double)mouseX, (double)mouseY, bindX, keybindY, bindW);
        String bindLabel = InlineControlRenderer.fitText(
            textRenderer, DargsClient.getInstance().getKeybindManager().getBindLabel(this).toUpperCase(Locale.ROOT), 58
        );
        RenderUtil.drawText(context, textRenderer, "KEYBIND", cx, keybindY + 2.0F, theme.white());
        InlineControlRenderer.drawButton(context, textRenderer, theme, bindLabel, capturing, hoverBind, bindX, keybindY, bindW);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (!this.containsInline(mouseX, mouseY, x, y, width)) {
            return false;
        } else {
            float keybindY = y + 8.0F;
            float bindX = x + width - 80.0F;
            if (button == 0 && InlineControlRenderer.containsButton(mouseX, mouseY, bindX, keybindY, 70.0F)) {
                DargsClient.getInstance().getKeybindManager().beginCapture(this, notificationManager);
                return true;
            } else if (button == 1 && InlineControlRenderer.containsButton(mouseX, mouseY, bindX, keybindY, 70.0F)) {
                DargsClient.getInstance().getKeybindManager().clearBind(this, notificationManager);
                return true;
            } else {
                return false;
            }
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("Hold right-click with sword/crystal/totem", "Places obsidian, switches to crystals");
    }

    private boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + 32.0F);
    }
}
