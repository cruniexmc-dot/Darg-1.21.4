package dev.darg.client.mixin;

import dev.darg.client.DargsClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockBreakingProgressS2CPacket;
import net.minecraft.network.packet.s2c.play.BlockEventS2CPacket;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDeltaUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.DeathMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.EntitiesDestroyS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityAnimationS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityEquipmentUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundFromEntityS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.network.packet.s2c.play.WorldEventS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientPlayNetworkHandler.class})
public abstract class ClientPlayNetworkHandlerMixin {
    private static void dispatch(Packet<?> packet) {
        DargsClient client = DargsClient.getInstance();
        if (client != null) {
            client.getFeatureManager().onReceivePacket(MinecraftClient.getInstance(), packet);
        }
    }

    @Inject(
        method = {"onEntitySpawn"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onEntitySpawn(EntitySpawnS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }

    @Inject(
        method = {"onEntityStatus"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onEntityStatus(EntityStatusS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }

    @Inject(
        method = {"onEntityAnimation"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onEntityAnimation(EntityAnimationS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }

    @Inject(
        method = {"onEntityEquipmentUpdate"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onEntityEquipmentUpdate(EntityEquipmentUpdateS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }

    @Inject(
        method = {"onEntityDamage"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onEntityDamage(EntityDamageS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }

    @Inject(
        method = {"onEntitiesDestroy"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onEntitiesDestroy(EntitiesDestroyS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }

    @Inject(
        method = {"onEntityVelocityUpdate"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onEntityVelocityUpdate(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }

    @Inject(
        method = {"onBlockUpdate"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onBlockUpdate(BlockUpdateS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }

    @Inject(
        method = {"onChunkDeltaUpdate"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onChunkDeltaUpdate(ChunkDeltaUpdateS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }

    @Inject(
        method = {"onBlockBreakingProgress"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onBlockBreakingProgress(BlockBreakingProgressS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }

    @Inject(
        method = {"onBlockEvent"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onBlockEvent(BlockEventS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }

    @Inject(
        method = {"onExplosion"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onExplosion(ExplosionS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }

    @Inject(
        method = {"onWorldEvent"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onWorldEvent(WorldEventS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }

    @Inject(
        method = {"onPlaySound"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onPlaySound(PlaySoundS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }

    @Inject(
        method = {"onPlaySoundFromEntity"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onPlaySoundFromEntity(PlaySoundFromEntityS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }

    @Inject(
        method = {"onDeathMessage"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onDeathMessage(DeathMessageS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }

    @Inject(
        method = {"onGameMessage"},
        at = {@At("HEAD")},
        require = 0
    )
    private void dargsclient$onGameMessage(GameMessageS2CPacket packet, CallbackInfo ci) {
        dispatch(packet);
    }
}
