package dev.darg.client.feature.utility;

import dev.darg.client.DargsClient;
import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.clickgui.ClickGuiScreen;
import dev.darg.client.ui.clickgui.InlineControlRenderer;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.awt.Color;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;

public final class HudFeature extends Feature {
    private static final float CUSTOM_HEIGHT = 186.0F;
    private static final float TOGGLE_BOX_SIZE = 10.0F;
    private static final float NOTIFICATION_FADE_IN_MS = 140.0F;
    private static final float NOTIFICATION_FADE_OUT_MS = 360.0F;
    private static final float MODULE_MIN_WIDTH = 74.0F;
    private static final float MODULE_ANIMATION_SPEED = 0.32F;
    private static final float MODULE_CARD_PAD_H = 8.0F;
    private static final float MODULE_CARD_HEIGHT = 17.0F;
    private static final float MODULE_CARD_RADIUS = 6.0F;
    private static final float MODULE_CARD_GAP = 3.0F;
    private static final float MODULE_CARD_SLIDE_PX = 24.0F;
    private static final float TOP_LEFT_DOCK_GAP = 3.0F;
    private static final float TOP_LEFT_DOCK_SEGMENT_GAP = 8.0F;
    private static final float TOP_LEFT_DOCK_PANEL_PADDING = 18.0F;
    private static final DateTimeFormatter CLOCK_FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final float MINI_BOX_HEIGHT = 17.0F;
    private static final float ARMOR_PANEL_WIDTH = 92.0F;
    private static final float ARMOR_PANEL_HEIGHT = 42.0F;
    private static final float INVENTORY_PANEL_WIDTH = 182.0F;
    private static final float INVENTORY_PANEL_HEIGHT = 78.0F;
    private static final float EDITOR_WIDTH = 408.0F;
    private static final float EDITOR_HEIGHT = 256.0F;
    private static final float EDITOR_MARGIN = 24.0F;
    private static final float EDITOR_TOGGLE_HEIGHT = 18.0F;
    private static final float EDITOR_TOGGLE_GAP = 6.0F;
    private static final EquipmentSlot[] ARMOR_SLOTS = new EquipmentSlot[]{
        EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };
    private final ClientConfig config = ClientConfig.getInstance();
    private final List<HudFeature.HudToast> notifications = new ArrayList<>();
    private final Map<String, Float> moduleAnimationProgress = new HashMap<>();
    private final Map<String, HudFeature.ModuleHudEntry> moduleDisplayCache = new HashMap<>();
    private boolean watermark;
    private boolean info;
    private boolean modules;
    private boolean time;
    private boolean coordinates;
    private boolean potions;
    private boolean notificationToasts;
    private boolean rainbow;
    private boolean armorPreview;
    private boolean inventoryPreview;
    private int opacity;
    private float rainbowSpeed;
    private int notificationDurationMs;
    private HudFeature.SortMode sortMode;
    private float scale;
    private boolean editorOpen;
    private HudFeature.ActiveEditorSlider activeEditorSlider = HudFeature.ActiveEditorSlider.NONE;
    private HudFeature.ActiveSlider activeSlider = HudFeature.ActiveSlider.NONE;
    private boolean draggingArmor;
    private boolean draggingInventory;
    private float armorDragOffsetX;
    private float armorDragOffsetY;
    private float inventoryDragOffsetX;
    private float inventoryDragOffsetY;

    public HudFeature() {
        super("Hud", Category.SETTINGS);
        this.watermark = this.config.isHudWatermarkEnabled();
        this.info = this.config.isHudInfoEnabled();
        this.modules = this.config.isHudModulesEnabled();
        this.time = this.config.isHudTimeEnabled();
        this.coordinates = this.config.isHudCoordinatesEnabled();
        this.potions = this.config.isHudPotionsEnabled();
        this.notificationToasts = this.config.isHudNotificationsEnabled();
        this.rainbow = this.config.isHudRainbowEnabled();
        this.armorPreview = this.config.isHudArmorPreviewEnabled();
        this.inventoryPreview = this.config.isHudInventoryPreviewEnabled();
        this.opacity = this.config.getHudOpacity();
        this.rainbowSpeed = this.config.getHudRainbowSpeed();
        this.notificationDurationMs = this.config.getHudNotificationDurationMs();
        this.sortMode = HudFeature.SortMode.parse(this.config.getHudSortMode());
        this.scale = this.config.getHudScale();
    }

    @Override
    public boolean onClickGuiSecondaryClick(NotificationManager notificationManager) {
        this.editorOpen = true;
        this.activeEditorSlider = HudFeature.ActiveEditorSlider.NONE;
        return true;
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 186.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        if (this.activeSlider != HudFeature.ActiveSlider.NONE) {
            this.updateSliderFromMouse((double)mouseX, x, width, this.activeSlider);
        }

        ClientTheme theme = currentTheme();
        float leftColumnX = x + 10.0F;
        float rightColumnX = x + width * 0.5F;
        float columnWidth = (width - 30.0F) * 0.5F;
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "WATERMARK", this.watermark, false, leftColumnX, y + 10.0F, columnWidth);
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "INFO", this.info, false, rightColumnX, y + 10.0F, columnWidth);
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "MODULES", this.modules, false, leftColumnX, y + 24.0F, columnWidth);
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "TIME", this.time, false, rightColumnX, y + 24.0F, columnWidth);
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "COORDS", this.coordinates, false, leftColumnX, y + 38.0F, columnWidth);
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "POTIONS", this.potions, false, rightColumnX, y + 38.0F, columnWidth);
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "NOTIFY", this.notificationToasts, false, leftColumnX, y + 52.0F, columnWidth);
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "RAINBOW", this.rainbow, false, rightColumnX, y + 52.0F, columnWidth);
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "ARMOR", this.armorPreview, false, leftColumnX, y + 66.0F, columnWidth);
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "INVENTORY", this.inventoryPreview, false, rightColumnX, y + 66.0F, columnWidth);
        InlineControlRenderer.drawSlider(
            context, textRenderer, theme, "OPACITY", Integer.toString(this.opacity), x + 10.0F, y + 86.0F, width - 20.0F, this.opacityToRatio()
        );
        this.renderModeRow(context, textRenderer, x, y + 104.0F, width, mouseX, mouseY);
        InlineControlRenderer.drawSlider(
            context,
            textRenderer,
            theme,
            "RAINBOW SPEED",
            String.format(Locale.ROOT, "%.2f", this.rainbowSpeed),
            x + 10.0F,
            y + 124.0F,
            width - 20.0F,
            this.rainbowSpeedToRatio()
        );
        InlineControlRenderer.drawSlider(
            context,
            textRenderer,
            theme,
            "NOTIFY DURATION",
            String.format(Locale.ROOT, "%.1fs", (float)this.notificationDurationMs / 1000.0F),
            x + 10.0F,
            y + 142.0F,
            width - 20.0F,
            this.notificationDurationToRatio()
        );
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (!contains(mouseX, mouseY, x, y, width, 186.0F)) {
            return false;
        } else if (button != 0) {
            return true;
        } else {
            float leftColumnX = x + 10.0F;
            float rightColumnX = x + width * 0.5F;
            float columnWidth = (width - 30.0F) * 0.5F;
            if (contains(mouseX, mouseY, leftColumnX, y + 10.0F, columnWidth, 12.0F)) {
                this.watermark = !this.watermark;
                this.saveSettings();
                return true;
            } else if (contains(mouseX, mouseY, rightColumnX, y + 10.0F, columnWidth, 12.0F)) {
                this.info = !this.info;
                this.saveSettings();
                return true;
            } else if (contains(mouseX, mouseY, leftColumnX, y + 24.0F, columnWidth, 12.0F)) {
                this.modules = !this.modules;
                this.saveSettings();
                return true;
            } else if (contains(mouseX, mouseY, rightColumnX, y + 24.0F, columnWidth, 12.0F)) {
                this.time = !this.time;
                this.saveSettings();
                return true;
            } else if (contains(mouseX, mouseY, leftColumnX, y + 38.0F, columnWidth, 12.0F)) {
                this.coordinates = !this.coordinates;
                this.saveSettings();
                return true;
            } else if (contains(mouseX, mouseY, rightColumnX, y + 38.0F, columnWidth, 12.0F)) {
                this.potions = !this.potions;
                this.saveSettings();
                return true;
            } else if (contains(mouseX, mouseY, leftColumnX, y + 52.0F, columnWidth, 12.0F)) {
                this.notificationToasts = !this.notificationToasts;
                this.saveSettings();
                return true;
            } else if (contains(mouseX, mouseY, rightColumnX, y + 52.0F, columnWidth, 12.0F)) {
                this.rainbow = !this.rainbow;
                this.saveSettings();
                return true;
            } else if (contains(mouseX, mouseY, leftColumnX, y + 66.0F, columnWidth, 12.0F)) {
                this.armorPreview = !this.armorPreview;
                this.saveSettings();
                return true;
            } else if (contains(mouseX, mouseY, rightColumnX, y + 66.0F, columnWidth, 12.0F)) {
                this.inventoryPreview = !this.inventoryPreview;
                this.saveSettings();
                return true;
            } else if (InlineControlRenderer.containsSlider(mouseX, mouseY, x + 10.0F, y + 86.0F, width - 20.0F)) {
                this.activeSlider = HudFeature.ActiveSlider.OPACITY;
                this.updateSliderFromMouse(mouseX, x, width, this.activeSlider);
                return true;
            } else if (contains(mouseX, mouseY, x + 10.0F, y + 104.0F, 74.0F, 16.0F)) {
                this.sortMode = this.sortMode.next();
                this.saveSettings();
                return true;
            } else if (contains(mouseX, mouseY, x + width - 80.0F, y + 104.0F, 70.0F, 16.0F)) {
                if (DargsClient.getInstance().getKeybindManager().isCapturing(this)) {
                    DargsClient.getInstance().getKeybindManager().cancelCapture(notificationManager);
                } else {
                    DargsClient.getInstance().getKeybindManager().beginCapture(this, notificationManager);
                }

                return true;
            } else if (InlineControlRenderer.containsSlider(mouseX, mouseY, x + 10.0F, y + 124.0F, width - 20.0F)) {
                this.activeSlider = HudFeature.ActiveSlider.RAINBOW_SPEED;
                this.updateSliderFromMouse(mouseX, x, width, this.activeSlider);
                return true;
            } else if (InlineControlRenderer.containsSlider(mouseX, mouseY, x + 10.0F, y + 142.0F, width - 20.0F)) {
                this.activeSlider = HudFeature.ActiveSlider.NOTIFICATION_DURATION;
                this.updateSliderFromMouse(mouseX, x, width, this.activeSlider);
                return true;
            } else {
                return true;
            }
        }
    }

    @Override
    public boolean onCustomClickGuiMouseReleased(double mouseX, double mouseY, int button, float x, float y, float width) {
        if (button == 0 && this.activeSlider != HudFeature.ActiveSlider.NONE) {
            this.activeSlider = HudFeature.ActiveSlider.NONE;
            this.saveSettings();
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && client.world != null && !(client.currentScreen instanceof ClickGuiScreen)) {
            float hudScale = this.hudScaleFactor();
            float hudWidth = (float)client.getWindow().getScaledWidth() / hudScale;
            float hudHeight = (float)client.getWindow().getScaledHeight() / hudScale;
            TextRenderer textRenderer = client.textRenderer;
            context.getMatrices().pushMatrix();
            context.getMatrices().scale(hudScale, hudScale);

            try {
                this.renderTopLeftCluster(context, textRenderer, client, hudWidth);
                this.renderModules(context, textRenderer, hudWidth);
                this.renderPotions(context, textRenderer, client, hudHeight);
                this.renderNotifications(context, textRenderer, client, hudWidth, hudHeight);
                this.renderArmorPanel(context, textRenderer, client, -1, -1, false, hudScale);
                this.renderInventoryPanel(context, textRenderer, client, -1, -1, false, hudScale);
            } finally {
                context.getMatrices().popMatrix();
            }
        }
    }

    @Override
    public void onClickGuiRender(DrawContext context, int mouseX, int mouseY, float delta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.player != null) {
            if (this.draggingArmor) {
                this.updateArmorDrag(mouseX, mouseY, client);
            }

            if (this.draggingInventory) {
                this.updateInventoryDrag(mouseX, mouseY, client);
            }

            float hudScale = this.hudScaleFactor();
            int hudMouseX = Math.round((float)mouseX / Math.max(0.001F, hudScale));
            int hudMouseY = Math.round((float)mouseY / Math.max(0.001F, hudScale));
            TextRenderer textRenderer = client.textRenderer;
            context.getMatrices().pushMatrix();
            context.getMatrices().scale(hudScale, hudScale);

            try {
                this.renderArmorPanel(context, textRenderer, client, hudMouseX, hudMouseY, true, hudScale);
                this.renderInventoryPanel(context, textRenderer, client, hudMouseX, hudMouseY, true, hudScale);
            } finally {
                context.getMatrices().popMatrix();
            }

            if (this.editorOpen) {
                this.renderEditor(context, textRenderer, client, mouseX, mouseY);
            }
        }
    }

    @Override
    public boolean onClickGuiMouseClicked(double mouseX, double mouseY, int button) {
        if (this.editorOpen) {
            return this.handleEditorMouseClicked(mouseX, mouseY, button);
        } else if (button != 0) {
            return false;
        } else {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null && client.player != null) {
                float hudScale = this.hudScaleFactor();
                if (this.armorPreview && contains(mouseX, mouseY, this.config.getHudArmorX(), this.config.getHudArmorY(), 92.0F * hudScale, 42.0F * hudScale)) {
                    this.draggingArmor = true;
                    this.armorDragOffsetX = (float)mouseX - this.config.getHudArmorX();
                    this.armorDragOffsetY = (float)mouseY - this.config.getHudArmorY();
                    return true;
                } else if (this.inventoryPreview
                    && contains(mouseX, mouseY, this.config.getHudInventoryX(), this.config.getHudInventoryY(), 182.0F * hudScale, 78.0F * hudScale)) {
                    this.draggingInventory = true;
                    this.inventoryDragOffsetX = (float)mouseX - this.config.getHudInventoryX();
                    this.inventoryDragOffsetY = (float)mouseY - this.config.getHudInventoryY();
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
    }

    @Override
    public boolean onClickGuiMouseReleased(double mouseX, double mouseY, int button) {
        if (this.editorOpen) {
            if (button == 0 && this.activeEditorSlider != HudFeature.ActiveEditorSlider.NONE) {
                this.activeEditorSlider = HudFeature.ActiveEditorSlider.NONE;
                this.saveSettings();
                return true;
            } else {
                return this.containsEditor(mouseX, mouseY);
            }
        } else if (button != 0) {
            return false;
        } else {
            boolean handled = this.draggingArmor || this.draggingInventory;
            this.draggingArmor = false;
            this.draggingInventory = false;
            if (handled) {
                this.config.save();
            }

            return handled;
        }
    }

    @Override
    public boolean isClickGuiInteractionActive() {
        return this.editorOpen || this.draggingArmor || this.draggingInventory || this.activeSlider != HudFeature.ActiveSlider.NONE;
    }

    @Override
    protected void onDisable() {
        this.activeSlider = HudFeature.ActiveSlider.NONE;
        this.draggingArmor = false;
        this.draggingInventory = false;
        this.editorOpen = false;
        this.activeEditorSlider = HudFeature.ActiveEditorSlider.NONE;
        this.notifications.clear();
        this.moduleAnimationProgress.clear();
        this.moduleDisplayCache.clear();
    }

    public void pushToggleNotification(Feature feature) {
        this.pushNotification(
            feature.getName() + (feature.isEnabled() ? " enabled" : " disabled"),
            feature.isEnabled() ? HudFeature.ToastType.SUCCESS : HudFeature.ToastType.INFO
        );
    }

    public void pushNotification(String message, boolean success) {
        this.pushNotification(message, success ? HudFeature.ToastType.SUCCESS : HudFeature.ToastType.INFO);
    }

    public void pushWarningNotification(String message) {
        this.pushNotification(message, HudFeature.ToastType.WARNING);
    }

    public void pushNotification(String message, HudFeature.ToastType type) {
        if (this.isEnabled() && this.notificationToasts) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player != null) {
                this.notifications.add(new HudFeature.HudToast(message, type, System.currentTimeMillis()));
                if (this.notifications.size() > 6) {
                    this.notifications.remove(0);
                }
            }
        }
    }

    private void renderTopLeftCluster(DrawContext context, TextRenderer textRenderer, MinecraftClient client, float hudWidth) {
        ClientTheme theme = currentTheme();
        List<HudFeature.TopLeftBadge> badges = new ArrayList<>();
        if (this.watermark) {
            badges.add(new HudFeature.TopLeftBadge("Darg's Client", this.getHudTextColor(0.0F, this.themeAccent()), true));
        }

        if (this.info) {
            badges.add(new HudFeature.TopLeftBadge(client.getCurrentFps() + " fps", this.getHudTextColor(0.06F, this.themeAccent()), false));
            badges.add(new HudFeature.TopLeftBadge(Math.max(0, this.getPing(client)) + " ms", this.getHudTextColor(0.12F, theme.hudInfoAccent()), false));
            long usedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
            long maxMemory = Math.max(1L, Runtime.getRuntime().maxMemory());
            int memoryPercent = Math.max(0, Math.min(100, Math.round((float)usedMemory * 100.0F / (float)maxMemory)));
            badges.add(new HudFeature.TopLeftBadge(memoryPercent + "% mem", this.getHudTextColor(0.18F, theme.hudWarningAccent()), false));
        }

        if (this.time) {
            badges.add(new HudFeature.TopLeftBadge(this.buildTimeDockValue(client), this.getHudTextColor(0.22F, theme.white()), false));
        }

        if (this.coordinates) {
            badges.add(new HudFeature.TopLeftBadge(this.buildCoordinateDockValue(client), this.getHudTextColor(0.28F, theme.white()), false));
        }

        if (!badges.isEmpty()) {
            float x = 6.0F;
            float y = 6.0F;
            float maxWidth = Math.max(168.0F, hudWidth * 0.48F);

            for (HudFeature.TopLeftDockRow row : this.buildTopLeftDockRows(textRenderer, badges, maxWidth - 18.0F)) {
                this.renderTopLeftDockRow(context, textRenderer, row, x, y);
                y += 20.0F;
            }
        }
    }

    private void renderArmorPanel(
        DrawContext context, TextRenderer textRenderer, MinecraftClient client, int mouseX, int mouseY, boolean editing, float hudScale
    ) {
        if (this.armorPreview && client.player != null) {
            float screenX = clamp(this.config.getHudArmorX(), 6.0F, Math.max(6.0F, (float)client.getWindow().getScaledWidth() - 92.0F * hudScale - 6.0F));
            float screenY = clamp(this.config.getHudArmorY(), 6.0F, Math.max(6.0F, (float)client.getWindow().getScaledHeight() - 42.0F * hudScale - 6.0F));
            float x = screenX / hudScale;
            float y = screenY / hudScale;
            boolean hovered = editing && contains((double)mouseX, (double)mouseY, x, y, 92.0F, 42.0F);
            this.drawMiniPanel(context, x, y, 92.0F, 42.0F, hovered);
            this.renderMiniPanelHeader(context, textRenderer, "Armor", x, y, 92.0F, hovered ? (this.draggingArmor ? "HOLD" : "MOVE") : null);

            for (int index = 0; index < 4; index++) {
                ItemStack stack = client.player.getEquippedStack(ARMOR_SLOTS[index]);
                float slotX = x + 8.0F + (float)index * 19.0F;
                float slotY = y + 18.0F;
                this.drawItemSlot(context, textRenderer, stack, slotX, slotY);
                this.renderDurabilityBar(context, stack, slotX, slotY + 18.0F, 16.0F);
            }
        }
    }

    private void renderInventoryPanel(
        DrawContext context, TextRenderer textRenderer, MinecraftClient client, int mouseX, int mouseY, boolean editing, float hudScale
    ) {
        if (this.inventoryPreview && client.player != null) {
            float screenX = clamp(this.config.getHudInventoryX(), 6.0F, Math.max(6.0F, (float)client.getWindow().getScaledWidth() - 182.0F * hudScale - 6.0F));
            float screenY = clamp(this.config.getHudInventoryY(), 6.0F, Math.max(6.0F, (float)client.getWindow().getScaledHeight() - 78.0F * hudScale - 6.0F));
            float x = screenX / hudScale;
            float y = screenY / hudScale;
            boolean hovered = editing && contains((double)mouseX, (double)mouseY, x, y, 182.0F, 78.0F);
            this.drawMiniPanel(context, x, y, 182.0F, 78.0F, hovered);
            this.renderMiniPanelHeader(context, textRenderer, "Inventory", x, y, 182.0F, hovered ? (this.draggingInventory ? "HOLD" : "MOVE") : null);
            PlayerInventory inventory = client.player.getInventory();

            for (int row = 0; row < 3; row++) {
                for (int column = 0; column < 9; column++) {
                    int slot = 9 + row * 9 + column;
                    ItemStack stack = inventory.getStack(slot);
                    float slotX = x + 8.0F + (float)column * 19.0F;
                    float slotY = y + 18.0F + (float)row * 18.0F;
                    this.drawItemSlot(context, textRenderer, stack, slotX, slotY);
                }
            }
        }
    }

    private void renderModules(DrawContext context, TextRenderer textRenderer, float hudWidth) {
        if (!this.modules) {
            this.moduleAnimationProgress.clear();
            this.moduleDisplayCache.clear();
        } else {
            List<HudFeature.ModuleHudEntry> activeFeatures = new ArrayList<>();

            for (Feature feature : DargsClient.getInstance().getFeatureManager().getFeatures()) {
                if (feature.isEnabled() && feature != this && !"ClickGUI".equals(feature.getName())) {
                    String suffix = feature.getHudSuffix();
                    activeFeatures.add(
                        new HudFeature.ModuleHudEntry(feature, feature.getName(), suffix, this.measureModuleWidth(textRenderer, feature.getName(), suffix))
                    );
                }
            }

            if (activeFeatures.isEmpty() && this.moduleAnimationProgress.isEmpty()) {
                this.moduleDisplayCache.clear();
            } else {
                this.updateModuleAnimations(activeFeatures);
                List<HudFeature.ModuleHudEntry> visible = new ArrayList<>();

                for (Entry<String, Float> e : this.moduleAnimationProgress.entrySet()) {
                    if (!(e.getValue() <= 0.02F)) {
                        HudFeature.ModuleHudEntry cached = this.moduleDisplayCache.get(e.getKey());
                        if (cached != null) {
                            visible.add(cached);
                        }
                    }
                }

                if (!visible.isEmpty()) {
                    Comparator<HudFeature.ModuleHudEntry> comparator = Comparator.comparingInt(entryx -> Math.round(entryx.measuredWidth()));
                    if (this.sortMode == HudFeature.SortMode.LONGEST) {
                        comparator = comparator.reversed();
                    }

                    visible.sort(comparator.thenComparing(entryx -> entryx.feature().getName(), String.CASE_INSENSITIVE_ORDER));
                    ClientTheme theme = currentTheme();
                    float y = 6.0F;
                    float maxRight = hudWidth - 6.0F;

                    for (int index = 0; index < visible.size(); index++) {
                        HudFeature.ModuleHudEntry entry = visible.get(index);
                        float anim = this.moduleAnimationProgress.getOrDefault(entry.feature().getName(), 1.0F);
                        float eased = expoOut(anim);
                        float fullW = this.measureModuleWidth(textRenderer, entry.label(), entry.suffix());
                        float x = maxRight - fullW + (1.0F - eased) * 24.0F;
                        this.drawHudModuleEntry(context, textRenderer, theme, entry, x, y, fullW, anim, index);
                        y += 20.0F;
                    }
                }
            }
        }
    }

    private void drawHudModuleEntry(
        DrawContext context,
        TextRenderer textRenderer,
        ClientTheme theme,
        HudFeature.ModuleHudEntry entry,
        float x,
        float y,
        float width,
        float visibility,
        int index
    ) {
        int accentBase = this.rainbow ? this.getHudTextColor((float)index * 0.04F, theme.accent()) : theme.accent();
        int fillBase = RenderUtil.mixColor(theme.hudModuleFill(), theme.hudModuleFillActive(), 0.18F);
        int fillColor = withScaledAlpha(withRgb(Math.max(88, Math.min(255, this.opacity - 10)), fillBase), visibility);
        int accentColor = withScaledAlpha(accentBase, visibility);
        int labelColor = withScaledAlpha(theme.white(), visibility);
        int suffixColor = withScaledAlpha(theme.softGray(), visibility);
        this.drawHudSurface(context, x, y, width, 17.0F, 6.0F, fillColor, withScaledAlpha(theme.white(), 0.06F * visibility));
        RenderUtil.drawRoundedRect(context, x + 5.0F, y + 3.0F, 1.0F, 11.0F, 0.5F, accentColor);
        float labelX = x + 10.0F;
        float labelY = y + 5.0F;
        String suffix = entry.suffix();
        if (suffix != null && !suffix.isBlank()) {
            String suffixText = fit(textRenderer, suffix, 64);
            float suffixX = x + width - 8.0F - (float)RenderUtil.getTextWidth(textRenderer, suffixText);
            RenderUtil.drawRoundedRect(context, suffixX - 6.0F, y + 4.0F, 1.0F, 9.0F, 0.5F, withScaledAlpha(theme.hudChipBorder(), 0.72F * visibility));
            RenderUtil.drawTextWithGlow(context, textRenderer, suffixText, suffixX, labelY, suffixColor, accentBase, Math.round(18.0F * visibility));
            RenderUtil.drawTextWithGlow(
                context,
                textRenderer,
                fit(textRenderer, entry.label(), Math.max(28, Math.round(suffixX - labelX - 12.0F))),
                labelX,
                labelY,
                labelColor,
                accentBase,
                Math.round(34.0F * visibility)
            );
        } else {
            RenderUtil.drawTextWithGlow(
                context,
                textRenderer,
                fit(textRenderer, entry.label(), Math.max(28, Math.round(width - 16.0F - 6.0F))),
                labelX,
                labelY,
                labelColor,
                accentBase,
                Math.round(34.0F * visibility)
            );
        }
    }

    private void renderPotions(DrawContext context, TextRenderer textRenderer, MinecraftClient client, float hudHeight) {
        if (this.potions) {
            ClientTheme theme = currentTheme();
            Collection<StatusEffectInstance> effects = client.player.getStatusEffects();
            if (!effects.isEmpty()) {
                List<HudFeature.PotionHudEntry> entries = new ArrayList<>();
                float maxLabelWidth = 0.0F;
                float maxDurationWidth = 0.0F;

                for (StatusEffectInstance effect : effects) {
                    HudFeature.PotionHudEntry entry = this.buildPotionEntry(effect);
                    entries.add(entry);
                    maxLabelWidth = Math.max(maxLabelWidth, (float)RenderUtil.getTextWidth(textRenderer, entry.label()));
                    maxDurationWidth = Math.max(maxDurationWidth, (float)RenderUtil.getTextWidth(textRenderer, entry.duration()));
                }

                entries.sort(Comparator.comparing(HudFeature.PotionHudEntry::label, String.CASE_INSENSITIVE_ORDER));
                float panelWidth = Math.max(122.0F, maxLabelWidth + maxDurationWidth + 24.0F);
                float panelHeight = 18.0F + (float)entries.size() * 10.0F;
                float x = 6.0F;
                float y = hudHeight - panelHeight - 6.0F;
                this.drawHudSurface(
                    context,
                    x,
                    y,
                    panelWidth,
                    panelHeight,
                    7.0F,
                    withRgb(Math.max(88, Math.min(255, this.opacity - 8)), theme.hudPanelRgb()),
                    withScaledAlpha(theme.white(), 0.06F)
                );
                RenderUtil.drawTextWithGlow(context, textRenderer, "POTIONS", x + 7.0F, y + 5.0F, theme.softGray(), theme.accent(), 24);
                RenderUtil.drawRoundedRect(context, x + 7.0F, y + 12.0F, panelWidth - 14.0F, 1.0F, 0.5F, withScaledAlpha(theme.hudChipBorder(), 0.36F));
                float textY = y + 15.0F;

                for (HudFeature.PotionHudEntry entry : entries) {
                    RenderUtil.drawText(context, textRenderer, entry.label(), x + 7.0F, textY, theme.white());
                    float durationX = x + panelWidth - 7.0F - (float)RenderUtil.getTextWidth(textRenderer, entry.duration());
                    RenderUtil.drawText(context, textRenderer, entry.duration(), durationX, textY, theme.softGray());
                    textY += 10.0F;
                }
            }
        }
    }

    private void renderNotifications(DrawContext context, TextRenderer textRenderer, MinecraftClient client, float hudWidth, float hudHeight) {
        if (!this.notificationToasts) {
            this.notifications.clear();
        } else {
            long now = System.currentTimeMillis();
            this.notifications.removeIf(toastx -> now - toastx.createdAt() >= (long)this.notificationDurationMs);
            int index = 0;

            for (int toastIndex = this.notifications.size() - 1; toastIndex >= 0; toastIndex--) {
                HudFeature.HudToast toast = this.notifications.get(toastIndex);
                float visibility = this.getNotificationVisibility(now - toast.createdAt());
                if (!(visibility <= 0.0F)) {
                    HudFeature.ToastStyle style = this.getToastStyle(toast.type());
                    float panelWidth = Math.max(152.0F, (float)RenderUtil.getTextWidth(textRenderer, toast.message()) + 40.0F);
                    float panelHeight = 40.0F;
                    float animation = easeOutCubic(visibility);
                    float x = hudWidth - panelWidth - 10.0F + (1.0F - animation) * 16.0F;
                    float y = hudHeight - 10.0F - (float)(index + 1) * (panelHeight + 8.0F);
                    ClientTheme theme = currentTheme();
                    int accentBase = this.getHudTextColor(0.0F, style.accentColor());
                    int panelColor = withScaledAlpha(withRgb(this.opacity, RenderUtil.mixColor(theme.hudPanelRgb(), style.accentColor(), 0.08F)), visibility);
                    int accentColor = withScaledAlpha(accentBase, visibility);
                    int auraColor = withScaledAlpha(RenderUtil.mixColor(accentBase, theme.white(), 0.18F), 0.24F * visibility);
                    int labelColor = withScaledAlpha(accentBase, visibility);
                    int textColor = withScaledAlpha(RenderUtil.mixColor(theme.white(), style.accentColor(), 0.14F), visibility);
                    float progress = 1.0F - clamp((float)(now - toast.createdAt()) / (float)this.notificationDurationMs, 0.0F, 1.0F);
                    RenderUtil.drawRoundedRect(context, x - 1.0F, y - 1.0F, panelWidth + 2.0F, panelHeight + 2.0F, 9.0F, auraColor);
                    this.drawHudPanelSurface(context, x, y, panelWidth, panelHeight, 8.0F, panelColor, withScaledAlpha(theme.white(), 0.08F * visibility), true);
                    RenderUtil.drawRoundedRect(context, x + 7.0F, y + 7.0F, 4.0F, panelHeight - 14.0F, 2.0F, withScaledAlpha(accentBase, 0.26F * visibility));
                    RenderUtil.drawRoundedRect(context, x + 8.0F, y + 8.0F, 2.0F, panelHeight - 16.0F, 1.0F, accentColor);
                    RenderUtil.drawTextWithGlow(
                        context, textRenderer, style.label(), x + 16.0F, y + 8.0F, labelColor, accentBase, Math.round(54.0F * visibility)
                    );
                    RenderUtil.drawTextWithGlow(
                        context, textRenderer, toast.message(), x + 16.0F, y + 20.0F, textColor, accentBase, Math.round(24.0F * visibility)
                    );
                    RenderUtil.drawRoundedRect(
                        context, x + 10.0F, y + panelHeight - 7.0F, panelWidth - 20.0F, 2.0F, 1.0F, withScaledAlpha(theme.hudTrackFill(), visibility)
                    );
                    RenderUtil.drawRoundedRect(
                        context, x + 10.0F, y + panelHeight - 7.0F, Math.max(6.0F, (panelWidth - 20.0F) * progress), 2.0F, 1.0F, accentColor
                    );
                    index++;
                }
            }
        }
    }

    private void renderModeRow(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        ClientTheme theme = currentTheme();
        boolean hoverSort = contains((double)mouseX, (double)mouseY, x + 10.0F, y, 74.0F, 16.0F);
        boolean hoverBind = contains((double)mouseX, (double)mouseY, x + width - 80.0F, y, 70.0F, 16.0F);
        boolean capturing = DargsClient.getInstance().getKeybindManager().isCapturing(this);
        String bindLabel = fit(textRenderer, DargsClient.getInstance().getKeybindManager().getBindLabel(this).toUpperCase(Locale.ROOT), 58);
        RenderUtil.drawText(context, textRenderer, "SORT", x + 10.0F, y - 9.0F, theme.softGray());
        RenderUtil.drawText(context, textRenderer, "BIND", x + width - 80.0F, y - 9.0F, theme.softGray());
        this.drawFlatButton(context, textRenderer, x + 10.0F, y, 74.0F, this.sortMode.label(), hoverSort, false, theme);
        this.drawFlatButton(context, textRenderer, x + width - 80.0F, y, 70.0F, bindLabel, hoverBind || capturing, capturing, theme);
    }

    private void drawFlatButton(
        DrawContext context, TextRenderer textRenderer, float x, float y, float w, String label, boolean hovered, boolean active, ClientTheme theme
    ) {
        int border = active
            ? RenderUtil.mixColor(theme.accent(), theme.white(), 0.12F)
            : (hovered ? RenderUtil.mixColor(theme.hudChipBorder(), theme.white(), 0.22F) : theme.hudChipBorder());
        int fill = active ? RenderUtil.mixColor(theme.hudActionFill(), theme.accent(), 0.18F) : (hovered ? theme.hudActionHover() : theme.hudActionFill());
        int text = active ? theme.accent() : (hovered ? theme.white() : theme.softGray());
        RenderUtil.drawRoundedRect(context, x, y, w, 16.0F, 6.0F, border);
        RenderUtil.drawRoundedRect(context, x + 1.0F, y + 1.0F, w - 2.0F, 14.0F, 5.0F, fill);
        RenderUtil.drawRoundedRect(context, x + 2.0F, y + 2.0F, w - 4.0F, 1.0F, 0.5F, withScaledAlpha(theme.white(), 0.1F));
        int lw = RenderUtil.getTextWidth(textRenderer, label);
        RenderUtil.drawText(context, textRenderer, label, x + (w - (float)lw) / 2.0F, y + 4.0F, text);
    }

    private List<HudFeature.TopLeftDockRow> buildTopLeftDockRows(TextRenderer textRenderer, List<HudFeature.TopLeftBadge> badges, float maxContentWidth) {
        List<HudFeature.TopLeftDockRow> rows = new ArrayList<>();
        List<HudFeature.TopLeftBadge> current = new ArrayList<>();
        float currentWidth = 0.0F;

        for (HudFeature.TopLeftBadge badge : badges) {
            float badgeWidth = this.measureTopLeftBadgeWidth(textRenderer, badge);
            float nextWidth = current.isEmpty() ? badgeWidth : currentWidth + 8.0F + badgeWidth;
            if (!current.isEmpty() && nextWidth > maxContentWidth) {
                rows.add(new HudFeature.TopLeftDockRow(List.copyOf(current), currentWidth));
                current = new ArrayList<>();
                currentWidth = 0.0F;
                nextWidth = badgeWidth;
            }

            current.add(badge);
            currentWidth = nextWidth;
        }

        if (!current.isEmpty()) {
            rows.add(new HudFeature.TopLeftDockRow(List.copyOf(current), currentWidth));
        }

        return rows;
    }

    private float measureTopLeftBadgeWidth(TextRenderer textRenderer, HudFeature.TopLeftBadge badge) {
        return (float)RenderUtil.getTextWidth(textRenderer, badge.text()) + (badge.accentDot() ? 8.0F : 0.0F);
    }

    private void renderTopLeftDockRow(DrawContext context, TextRenderer textRenderer, HudFeature.TopLeftDockRow row, float x, float y) {
        ClientTheme theme = currentTheme();
        float width = row.width() + 18.0F;
        int fill = withRgb(Math.max(86, Math.min(255, this.opacity - 10)), theme.hudChipFill());
        this.drawHudSurface(context, x, y, width, 17.0F, 6.0F, fill, withScaledAlpha(theme.white(), 0.06F));
        int railColor = row.badges().isEmpty() ? theme.accent() : withScaledAlpha(row.badges().get(0).accentColor(), 0.92F);
        RenderUtil.drawRoundedRect(context, x + 5.0F, y + 4.0F, 1.0F, 9.0F, 0.5F, railColor);
        float cursorX = x + 10.0F;
        float textY = y + 5.0F;

        for (int index = 0; index < row.badges().size(); index++) {
            HudFeature.TopLeftBadge badge = row.badges().get(index);
            if (index > 0) {
                float separatorX = cursorX - 4.0F;
                RenderUtil.drawRoundedRect(context, separatorX, y + 4.0F, 1.0F, 9.0F, 0.5F, withScaledAlpha(theme.hudChipBorder(), 0.42F));
            }

            float badgeX = cursorX;
            if (badge.accentDot()) {
                RenderUtil.drawRoundedRect(context, cursorX, y + 6.0F, 4.0F, 4.0F, 2.0F, withScaledAlpha(badge.accentColor(), 0.96F));
                badgeX = cursorX + 8.0F;
            }

            int textColor = badge.accentDot() ? RenderUtil.mixColor(theme.white(), badge.accentColor(), 0.18F) : withScaledAlpha(theme.white(), 0.94F);
            RenderUtil.drawTextWithGlow(context, textRenderer, badge.text(), badgeX, textY, textColor, badge.accentColor(), badge.accentDot() ? 42 : 18);
            cursorX += this.measureTopLeftBadgeWidth(textRenderer, badge) + 8.0F;
        }
    }

    private void drawMiniPanel(DrawContext context, float x, float y, float width, float height, boolean hovered) {
        ClientTheme theme = currentTheme();
        int fill = withRgb(hovered ? Math.min(255, this.opacity + 18) : this.opacity, theme.hudPanelRgb());
        this.drawHudPanelSurface(context, x, y, width, height, 9.0F, fill, withScaledAlpha(theme.white(), hovered ? 0.12F : 0.08F), hovered);
    }

    private void renderMiniPanelHeader(DrawContext context, TextRenderer textRenderer, String label, float x, float y, float width, String badgeText) {
        ClientTheme theme = currentTheme();
        RenderUtil.drawRoundedRect(context, x + 7.0F, y + 7.0F, 6.0F, 6.0F, 3.0F, withScaledAlpha(theme.accent(), 0.26F));
        RenderUtil.drawRoundedRect(context, x + 8.0F, y + 8.0F, 4.0F, 4.0F, 2.0F, theme.accent());
        RenderUtil.drawTextWithGlow(context, textRenderer, label, x + 18.0F, y + 6.0F, withScaledAlpha(theme.white(), 0.96F), theme.accent(), 38);
        RenderUtil.drawRoundedRect(context, x + 8.0F, y + 16.0F, width - 16.0F, 1.0F, 0.5F, withScaledAlpha(theme.hudChipBorder(), 0.34F));
        if (badgeText != null && !badgeText.isBlank()) {
            float badgeWidth = (float)RenderUtil.getTextWidth(textRenderer, badgeText) + 10.0F;
            float badgeX = x + width - badgeWidth - 8.0F;
            int badgeFill = withRgb(Math.min(255, this.opacity + 10), theme.hudActionFill());
            int badgeAccent = badgeText.equals("HOLD") ? theme.hudSuccessAccent() : theme.accent();
            RenderUtil.drawRoundedRect(context, badgeX, y + 4.0F, badgeWidth, 12.0F, 5.0F, badgeFill);
            RenderUtil.drawRoundedRect(context, badgeX + 4.0F, y + 6.0F, 2.0F, 4.0F, 1.0F, badgeAccent);
            RenderUtil.drawTextWithGlow(
                context, textRenderer, badgeText, badgeX + 5.0F, y + 6.0F, badgeText.equals("MOVE") ? theme.softGray() : badgeAccent, badgeAccent, 28
            );
        } else {
            RenderUtil.drawRoundedRect(context, x + width - 14.0F, y + 6.0F, 7.0F, 7.0F, 3.5F, withScaledAlpha(theme.accent(), 0.24F));
            RenderUtil.drawRoundedRect(context, x + width - 13.0F, y + 7.0F, 5.0F, 5.0F, 2.5F, withScaledAlpha(theme.accent(), 0.95F));
        }
    }

    private void drawItemSlot(DrawContext context, TextRenderer textRenderer, ItemStack stack, float x, float y) {
        ClientTheme theme = currentTheme();
        RenderUtil.drawRoundedRect(context, x, y, 16.0F, 16.0F, 4.0F, theme.hudSlotFill());
        RenderUtil.drawRoundedRect(context, x, y, 16.0F, 1.0F, 0.5F, theme.hudSlotEdge());
        RenderUtil.drawRoundedRect(context, x - 0.5F, y - 0.5F, 17.0F, 1.0F, 0.5F, withScaledAlpha(theme.hudSlotEdge(), 0.3F));
        if (stack != null && !stack.isEmpty()) {
            context.drawItem(stack, Math.round(x), Math.round(y));
            context.drawStackOverlay(textRenderer, stack, Math.round(x), Math.round(y));
        }
    }

    private void renderDurabilityBar(DrawContext context, ItemStack stack, float x, float y, float width) {
        if (stack != null && !stack.isEmpty() && stack.isDamageable()) {
            ClientTheme theme = currentTheme();
            float remaining = 1.0F - (float)stack.getDamage() / Math.max(1.0F, (float)stack.getMaxDamage());
            int durabilityColor = remaining > 0.66F ? theme.hudSuccessAccent() : (remaining > 0.33F ? theme.hudWarningAccent() : -36238);
            int glowColor = withScaledAlpha(durabilityColor, 0.4F);
            RenderUtil.drawRoundedRect(context, x - 1.0F, y + 1.0F, width + 2.0F, 4.0F, 1.5F, glowColor);
            RenderUtil.drawRoundedRect(context, x, y, width, 2.0F, 1.0F, theme.hudDurabilityBg());
            RenderUtil.drawRoundedRect(context, x, y, Math.max(2.0F, width * remaining), 2.0F, 1.0F, durabilityColor);
        }
    }

    private String buildTimeDockValue(MinecraftClient client) {
        return LocalTime.now().format(CLOCK_FORMAT);
    }

    private String buildCoordinateDockValue(MinecraftClient client) {
        return String.format(
            Locale.ROOT, "%d %d %d", (int)client.player.getX(), (int)client.player.getY(), (int)client.player.getZ()
        );
    }

    private void updateArmorDrag(int mouseX, int mouseY, MinecraftClient client) {
        float hudScale = this.hudScaleFactor();
        float maxX = Math.max(6.0F, (float)client.getWindow().getScaledWidth() - 92.0F * hudScale - 6.0F);
        float maxY = Math.max(6.0F, (float)client.getWindow().getScaledHeight() - 42.0F * hudScale - 6.0F);
        float nextX = Math.max(6.0F, Math.min(maxX, (float)mouseX - this.armorDragOffsetX));
        float nextY = Math.max(6.0F, Math.min(maxY, (float)mouseY - this.armorDragOffsetY));
        this.config.setHudArmorPosition(nextX, nextY);
    }

    private void updateInventoryDrag(int mouseX, int mouseY, MinecraftClient client) {
        float hudScale = this.hudScaleFactor();
        float maxX = Math.max(6.0F, (float)client.getWindow().getScaledWidth() - 182.0F * hudScale - 6.0F);
        float maxY = Math.max(6.0F, (float)client.getWindow().getScaledHeight() - 78.0F * hudScale - 6.0F);
        float nextX = Math.max(6.0F, Math.min(maxX, (float)mouseX - this.inventoryDragOffsetX));
        float nextY = Math.max(6.0F, Math.min(maxY, (float)mouseY - this.inventoryDragOffsetY));
        this.config.setHudInventoryPosition(nextX, nextY);
    }

    private void updateModuleAnimations(List<HudFeature.ModuleHudEntry> activeFeatures) {
        Set<String> activeNames = new HashSet<>();

        for (HudFeature.ModuleHudEntry entry : activeFeatures) {
            String name = entry.feature().getName();
            activeNames.add(name);
            this.moduleDisplayCache.put(name, entry);
        }

        Set<String> keys = new HashSet<>(this.moduleAnimationProgress.keySet());
        keys.addAll(activeNames);

        for (String name : keys) {
            float target = activeNames.contains(name) ? 1.0F : 0.0F;
            float current = this.moduleAnimationProgress.getOrDefault(name, 0.0F);
            float next = this.animateTowards(current, target, 0.32F);
            if (next < 0.02F && target == 0.0F) {
                this.moduleAnimationProgress.remove(name);
                this.moduleDisplayCache.remove(name);
            } else {
                this.moduleAnimationProgress.put(name, next);
            }
        }
    }

    private static float expoOut(float t) {
        if (t >= 1.0F) {
            return 1.0F;
        } else {
            return t <= 0.0F ? 0.0F : 1.0F - (float)Math.pow(2.0, -10.0 * (double)t);
        }
    }

    private float measureModuleWidth(TextRenderer textRenderer, String label, String suffix) {
        float width = (float)RenderUtil.getTextWidth(textRenderer, label) + 22.0F;
        if (suffix != null && !suffix.isBlank()) {
            width += Math.max(28.0F, (float)RenderUtil.getTextWidth(textRenderer, fit(textRenderer, suffix, 64)) + 10.0F) + 8.0F;
        }

        return Math.max(74.0F, width);
    }

    private float animateTowards(float current, float target, float speed) {
        return Math.abs(target - current) <= 0.001F ? target : clamp(current + (target - current) * speed, 0.0F, 1.0F);
    }

    private HudFeature.ToastStyle getToastStyle(HudFeature.ToastType type) {
        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();

        return switch (type) {
            case SUCCESS -> new HudFeature.ToastStyle("DONE", "+", theme.hudSuccessAccent(), 12.0F, 5.0F);
            case INFO -> new HudFeature.ToastStyle("INFO", "i", theme.hudInfoAccent(), 12.0F, 5.0F);
            case WARNING -> new HudFeature.ToastStyle("WARN", "!", theme.hudWarningAccent(), 14.0F, 3.0F);
        };
    }

    private HudFeature.PotionHudEntry buildPotionEntry(StatusEffectInstance effect) {
        String name = ((StatusEffect)effect.getEffectType().value()).getName().getString();
        int amplifier = effect.getAmplifier() + 1;
        String amplifierSuffix = amplifier > 1 ? " " + toRoman(amplifier) : "";
        String duration = effect.isInfinite() ? "*" : formatTicks(effect.getDuration());
        return new HudFeature.PotionHudEntry(name + amplifierSuffix, duration);
    }

    private int getPing(MinecraftClient client) {
        if (client.player != null && client.getNetworkHandler() != null) {
            PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
            return entry == null ? 0 : Math.max(0, entry.getLatency());
        } else {
            return 0;
        }
    }

    private void saveSettings() {
        this.config.setHudWatermarkEnabled(this.watermark);
        this.config.setHudInfoEnabled(this.info);
        this.config.setHudModulesEnabled(this.modules);
        this.config.setHudTimeEnabled(this.time);
        this.config.setHudCoordinatesEnabled(this.coordinates);
        this.config.setHudPotionsEnabled(this.potions);
        this.config.setHudNotificationsEnabled(this.notificationToasts);
        this.config.setHudRainbowEnabled(this.rainbow);
        this.config.setHudArmorPreviewEnabled(this.armorPreview);
        this.config.setHudInventoryPreviewEnabled(this.inventoryPreview);
        this.config.setHudOpacity(this.opacity);
        this.config.setHudRainbowSpeed(this.rainbowSpeed);
        this.config.setHudNotificationDurationMs(this.notificationDurationMs);
        this.config.setHudSortMode(this.sortMode.label());
        this.config.setHudScale(this.scale);
        this.config.save();
    }

    private int getEnabledHudWidgetCount() {
        int count = 0;
        if (this.watermark) {
            count++;
        }

        if (this.info) {
            count++;
        }

        if (this.modules) {
            count++;
        }

        if (this.time) {
            count++;
        }

        if (this.coordinates) {
            count++;
        }

        if (this.potions) {
            count++;
        }

        if (this.notificationToasts) {
            count++;
        }

        if (this.armorPreview) {
            count++;
        }

        if (this.inventoryPreview) {
            count++;
        }

        return count;
    }

    private void renderEditor(DrawContext context, TextRenderer textRenderer, MinecraftClient client, int mouseX, int mouseY) {
        ClientTheme theme = currentTheme();
        HudFeature.EditorModalLayout layout = this.createEditorLayout(client);
        float screenWidth = (float)client.getWindow().getScaledWidth();
        float screenHeight = (float)client.getWindow().getScaledHeight();
        float localMouseX = layout.toLocalX((double)mouseX);
        float localMouseY = layout.toLocalY((double)mouseY);
        int overlayColor = withScaledAlpha(theme.shadowStrong(), 0.32F);
        int modalBorder = withRgb(232, RenderUtil.mixColor(theme.hudPanelSoftEdge(), theme.accent(), 0.18F));
        int modalFill = withRgb(236, RenderUtil.mixColor(theme.hudPanelRgb(), theme.shadowStrong(), 0.1F));
        context.fill(0, 0, (int)screenWidth, (int)screenHeight, overlayColor);
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(layout.x(), layout.y());
        context.getMatrices().scale(layout.scale(), layout.scale());

        try {
            float contentX = 14.0F;
            float contentWidth = 380.0F;
            float scaleCardY = 42.0F;
            float scaleCardHeight = 52.0F;
            float visibilityCardY = scaleCardY + scaleCardHeight + 10.0F;
            float visibilityCardHeight = 96.0F;
            if (this.activeEditorSlider == HudFeature.ActiveEditorSlider.SCALE) {
                this.updateEditorSliderFromMouse((double)localMouseX, contentX + 12.0F, contentWidth - 24.0F);
            }

            RenderUtil.drawRoundedRect(context, 5.0F, 8.0F, 408.0F, 256.0F, 12.0F, withRgb(Math.max(70, this.opacity / 2), theme.shadowStrong()));
            RenderUtil.drawRoundedRect(context, 0.0F, 0.0F, 408.0F, 256.0F, 12.0F, modalBorder);
            RenderUtil.drawRoundedRect(context, 1.0F, 1.0F, 406.0F, 254.0F, 11.0F, modalFill);
            RenderUtil.drawRoundedRect(context, 1.0F, 1.0F, 406.0F, 28.0F, 11.0F, withRgb(250, theme.hudPanelSoftEdge()));
            RenderUtil.drawRoundedRect(context, 14.0F, 11.0F, 36.0F, 4.0F, 2.0F, theme.accent());
            RenderUtil.drawText(context, textRenderer, "HUD CONTROL", 14.0F, 10.0F, theme.white());
            RenderUtil.drawText(
                context, textRenderer, "Edit overlay widgets, scale and drag panels in place.", 14.0F, 21.0F, withScaledAlpha(theme.softGray(), 0.92F)
            );
            this.drawEditorBadge(context, textRenderer, this.getEnabledHudWidgetCount() + " widgets", 390.0F, 8.0F, false, theme);
            this.drawEditorBadge(context, textRenderer, String.format(Locale.ROOT, "%.2fx", this.scale), 316.0F, 8.0F, true, theme);
            this.drawEditorSection(context, contentX, scaleCardY, contentWidth, scaleCardHeight, theme);
            this.drawEditorSection(context, contentX, visibilityCardY, contentWidth, visibilityCardHeight, theme);
            boolean scaleHovered = contains((double)localMouseX, (double)localMouseY, contentX + 12.0F, scaleCardY + 28.0F, contentWidth - 24.0F, 12.0F);
            String scaleValue = String.format(Locale.ROOT, "%.2fx", this.scale);
            float sliderX = contentX + 12.0F;
            float sliderWidth = contentWidth - 24.0F;
            float sliderTrackY = scaleCardY + 32.0F;
            float sliderFillWidth = sliderWidth * this.scaleToRatio();
            float knobX = sliderX + sliderFillWidth - 4.0F;
            RenderUtil.drawText(context, textRenderer, "HUD SCALE", contentX + 12.0F, scaleCardY + 10.0F, theme.white());
            RenderUtil.drawText(
                context, textRenderer, "Resize overlay panels and badges.", contentX + 12.0F, scaleCardY + 20.0F, withScaledAlpha(theme.softGray(), 0.92F)
            );
            RenderUtil.drawText(
                context,
                textRenderer,
                scaleValue,
                382.0F - (float)RenderUtil.getTextWidth(textRenderer, scaleValue),
                scaleCardY + 10.0F,
                scaleHovered ? theme.accent() : theme.softGray()
            );
            RenderUtil.drawRoundedRect(context, sliderX, sliderTrackY, sliderWidth, 4.0F, 2.0F, theme.hudTrackFill());
            RenderUtil.drawRoundedRect(context, sliderX, sliderTrackY, Math.max(4.0F, sliderFillWidth), 4.0F, 2.0F, theme.accent());
            RenderUtil.drawRoundedRect(
                context,
                knobX,
                sliderTrackY - 3.0F,
                8.0F,
                10.0F,
                4.0F,
                scaleHovered ? RenderUtil.mixColor(theme.accent(), theme.white(), 0.28F) : theme.accent()
            );
            this.renderVisibilitySection(context, textRenderer, contentX, visibilityCardY, contentWidth, localMouseX, localMouseY, theme);
            float footerY = 228.0F;
            RenderUtil.drawRoundedRect(context, 14.0F, footerY, 380.0F, 16.0F, 6.0F, withRgb(150, theme.hudActionFill()));
            RenderUtil.drawText(
                context, textRenderer, "Drag armor and inventory panels directly in ClickGUI. Esc closes.", 22.0F, footerY + 4.0F, theme.softGray()
            );
        } finally {
            context.getMatrices().popMatrix();
        }
    }

    private void drawEditorSection(DrawContext context, float x, float y, float width, float height, ClientTheme theme) {
        int fill = withRgb(176, RenderUtil.mixColor(theme.hudPanelSoft(), theme.hudPanelRgb(), 0.35F));
        this.drawHudPanelSurface(context, x, y, width, height, 8.0F, fill, withScaledAlpha(theme.white(), 0.08F), false);
    }

    private void drawEditorBadge(DrawContext context, TextRenderer textRenderer, String label, float rightX, float y, boolean accent, ClientTheme theme) {
        float badgeWidth = Math.max(40.0F, (float)RenderUtil.getTextWidth(textRenderer, label) + 10.0F);
        float x = rightX - badgeWidth;
        int fill = accent ? RenderUtil.mixColor(theme.hudActionFill(), theme.accent(), 0.18F) : theme.hudActionFill();
        int textColor = accent ? theme.accent() : theme.softGray();
        RenderUtil.drawRoundedRect(context, x, y, badgeWidth, 14.0F, 6.0F, fill);
        RenderUtil.drawRoundedRect(context, x + 1.0F, y + 1.0F, badgeWidth - 2.0F, 1.0F, 0.5F, withScaledAlpha(theme.white(), 0.1F));
        RenderUtil.drawText(context, textRenderer, label, x + (badgeWidth - (float)RenderUtil.getTextWidth(textRenderer, label)) * 0.5F, y + 3.0F, textColor);
    }

    private boolean handleEditorMouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return this.containsEditor(mouseX, mouseY);
        } else {
            MinecraftClient client = MinecraftClient.getInstance();
            HudFeature.EditorModalLayout layout = this.createEditorLayout(client);
            float localMouseX = layout.toLocalX(mouseX);
            float localMouseY = layout.toLocalY(mouseY);
            if (!contains((double)localMouseX, (double)localMouseY, 0.0F, 0.0F, 408.0F, 256.0F)) {
                this.editorOpen = false;
                this.activeEditorSlider = HudFeature.ActiveEditorSlider.NONE;
                return true;
            } else {
                float contentX = 14.0F;
                float contentWidth = 380.0F;
                float scaleCardY = 42.0F;
                float visibilityCardY = scaleCardY + 52.0F + 10.0F;
                if (contains((double)localMouseX, (double)localMouseY, contentX + 12.0F, scaleCardY + 28.0F, contentWidth - 24.0F, 12.0F)) {
                    this.activeEditorSlider = HudFeature.ActiveEditorSlider.SCALE;
                    this.updateEditorSliderFromMouse((double)localMouseX, contentX + 12.0F, contentWidth - 24.0F);
                    return true;
                } else {
                    return this.toggleVisibilitySetting((double)localMouseX, (double)localMouseY, contentX, visibilityCardY, contentWidth) ? true : true;
                }
            }
        }
    }

    private boolean containsEditor(double mouseX, double mouseY) {
        MinecraftClient client = MinecraftClient.getInstance();
        HudFeature.EditorModalLayout layout = this.createEditorLayout(client);
        return contains((double)layout.toLocalX(mouseX), (double)layout.toLocalY(mouseY), 0.0F, 0.0F, 408.0F, 256.0F);
    }

    private HudFeature.EditorModalLayout createEditorLayout(MinecraftClient client) {
        float screenWidth = (float)client.getWindow().getScaledWidth();
        float screenHeight = (float)client.getWindow().getScaledHeight();
        float availableWidth = Math.max(1.0F, screenWidth - 24.0F);
        float availableHeight = Math.max(1.0F, screenHeight - 24.0F);
        float scale = Math.min(1.0F, Math.min(availableWidth / 408.0F, availableHeight / 256.0F));
        float scaledWidth = 408.0F * scale;
        float scaledHeight = 256.0F * scale;
        return new HudFeature.EditorModalLayout((screenWidth - scaledWidth) * 0.5F, (screenHeight - scaledHeight) * 0.5F, scale);
    }

    private void updateEditorSliderFromMouse(double mouseX, float sliderX, float sliderWidth) {
        float ratio = clamp((float)((mouseX - (double)sliderX) / (double)sliderWidth), 0.0F, 1.0F);
        this.scale = 0.75F + ratio * 0.75F;
    }

    private void renderVisibilitySection(
        DrawContext context, TextRenderer textRenderer, float contentX, float sectionY, float contentWidth, float mouseX, float mouseY, ClientTheme theme
    ) {
        float toggleX = contentX + 12.0F;
        float toggleY = sectionY + 30.0F;
        float toggleWidth = (contentWidth - 24.0F - 6.0F) * 0.5F;
        float rightX = toggleX + toggleWidth + 6.0F;
        float rowStep = 22.0F;
        RenderUtil.drawText(context, textRenderer, "VISIBILITY", contentX + 12.0F, sectionY + 10.0F, theme.white());
        RenderUtil.drawText(
            context,
            textRenderer,
            "Turn HUD parts on or off without leaving the editor.",
            contentX + 12.0F,
            sectionY + 20.0F,
            withScaledAlpha(theme.softGray(), 0.92F)
        );
        this.renderEditorToggleChip(
            context,
            textRenderer,
            "WATERMARK",
            this.watermark,
            toggleX,
            toggleY,
            toggleWidth,
            contains((double)mouseX, (double)mouseY, toggleX, toggleY, toggleWidth, 18.0F),
            theme
        );
        this.renderEditorToggleChip(
            context,
            textRenderer,
            "INFO",
            this.info,
            rightX,
            toggleY,
            toggleWidth,
            contains((double)mouseX, (double)mouseY, rightX, toggleY, toggleWidth, 18.0F),
            theme
        );
        this.renderEditorToggleChip(
            context,
            textRenderer,
            "MODULES",
            this.modules,
            toggleX,
            toggleY + rowStep,
            toggleWidth,
            contains((double)mouseX, (double)mouseY, toggleX, toggleY + rowStep, toggleWidth, 18.0F),
            theme
        );
        this.renderEditorToggleChip(
            context,
            textRenderer,
            "TIME",
            this.time,
            rightX,
            toggleY + rowStep,
            toggleWidth,
            contains((double)mouseX, (double)mouseY, rightX, toggleY + rowStep, toggleWidth, 18.0F),
            theme
        );
        this.renderEditorToggleChip(
            context,
            textRenderer,
            "COORDS",
            this.coordinates,
            toggleX,
            toggleY + rowStep * 2.0F,
            toggleWidth,
            contains((double)mouseX, (double)mouseY, toggleX, toggleY + rowStep * 2.0F, toggleWidth, 18.0F),
            theme
        );
        this.renderEditorToggleChip(
            context,
            textRenderer,
            "POTIONS",
            this.potions,
            rightX,
            toggleY + rowStep * 2.0F,
            toggleWidth,
            contains((double)mouseX, (double)mouseY, rightX, toggleY + rowStep * 2.0F, toggleWidth, 18.0F),
            theme
        );
        this.renderEditorToggleChip(
            context,
            textRenderer,
            "NOTIFICATIONS",
            this.notificationToasts,
            toggleX,
            toggleY + rowStep * 3.0F,
            toggleWidth,
            contains((double)mouseX, (double)mouseY, toggleX, toggleY + rowStep * 3.0F, toggleWidth, 18.0F),
            theme
        );
        this.renderEditorToggleChip(
            context,
            textRenderer,
            "RAINBOW",
            this.rainbow,
            rightX,
            toggleY + rowStep * 3.0F,
            toggleWidth,
            contains((double)mouseX, (double)mouseY, rightX, toggleY + rowStep * 3.0F, toggleWidth, 18.0F),
            theme
        );
        this.renderEditorToggleChip(
            context,
            textRenderer,
            "ARMOR",
            this.armorPreview,
            toggleX,
            toggleY + rowStep * 4.0F,
            toggleWidth,
            contains((double)mouseX, (double)mouseY, toggleX, toggleY + rowStep * 4.0F, toggleWidth, 18.0F),
            theme
        );
        this.renderEditorToggleChip(
            context,
            textRenderer,
            "INVENTORY",
            this.inventoryPreview,
            rightX,
            toggleY + rowStep * 4.0F,
            toggleWidth,
            contains((double)mouseX, (double)mouseY, rightX, toggleY + rowStep * 4.0F, toggleWidth, 18.0F),
            theme
        );
    }

    private void renderEditorToggleChip(
        DrawContext context, TextRenderer textRenderer, String label, boolean enabled, float x, float y, float width, boolean hovered, ClientTheme theme
    ) {
        int border = enabled
            ? RenderUtil.mixColor(theme.accent(), theme.white(), 0.16F)
            : RenderUtil.mixColor(theme.hudChipBorder(), theme.hudPanelSoftEdge(), hovered ? 0.22F : 0.08F);
        int fill = enabled ? RenderUtil.mixColor(theme.hudActionFill(), theme.accent(), 0.14F) : (hovered ? theme.hudActionHover() : theme.hudActionFill());
        int textColor = enabled ? theme.accent() : (hovered ? theme.white() : theme.softGray());
        int dotColor = enabled ? theme.accent() : theme.hudChipBorder();
        RenderUtil.drawRoundedRect(context, x, y, width, 18.0F, 6.0F, border);
        RenderUtil.drawRoundedRect(context, x + 1.0F, y + 1.0F, width - 2.0F, 16.0F, 5.0F, fill);
        RenderUtil.drawRoundedRect(context, x + 7.0F, y + 5.0F, 8.0F, 8.0F, 3.0F, withScaledAlpha(dotColor, enabled ? 1.0F : 0.55F));
        RenderUtil.drawText(context, textRenderer, fit(textRenderer, label, Math.max(24, Math.round(width - 26.0F))), x + 21.0F, y + 6.0F, textColor);
    }

    private boolean toggleVisibilitySetting(double mouseX, double mouseY, float contentX, float sectionY, float contentWidth) {
        float toggleX = contentX + 12.0F;
        float toggleY = sectionY + 30.0F;
        float toggleWidth = (contentWidth - 24.0F - 6.0F) * 0.5F;
        float rightX = toggleX + toggleWidth + 6.0F;
        float rowStep = 22.0F;
        if (contains(mouseX, mouseY, toggleX, toggleY, toggleWidth, 18.0F)) {
            this.watermark = !this.watermark;
            this.saveSettings();
            return true;
        } else if (contains(mouseX, mouseY, rightX, toggleY, toggleWidth, 18.0F)) {
            this.info = !this.info;
            this.saveSettings();
            return true;
        } else if (contains(mouseX, mouseY, toggleX, toggleY + rowStep, toggleWidth, 18.0F)) {
            this.modules = !this.modules;
            this.saveSettings();
            return true;
        } else if (contains(mouseX, mouseY, rightX, toggleY + rowStep, toggleWidth, 18.0F)) {
            this.time = !this.time;
            this.saveSettings();
            return true;
        } else if (contains(mouseX, mouseY, toggleX, toggleY + rowStep * 2.0F, toggleWidth, 18.0F)) {
            this.coordinates = !this.coordinates;
            this.saveSettings();
            return true;
        } else if (contains(mouseX, mouseY, rightX, toggleY + rowStep * 2.0F, toggleWidth, 18.0F)) {
            this.potions = !this.potions;
            this.saveSettings();
            return true;
        } else if (contains(mouseX, mouseY, toggleX, toggleY + rowStep * 3.0F, toggleWidth, 18.0F)) {
            this.notificationToasts = !this.notificationToasts;
            this.saveSettings();
            return true;
        } else if (contains(mouseX, mouseY, rightX, toggleY + rowStep * 3.0F, toggleWidth, 18.0F)) {
            this.rainbow = !this.rainbow;
            this.saveSettings();
            return true;
        } else if (contains(mouseX, mouseY, toggleX, toggleY + rowStep * 4.0F, toggleWidth, 18.0F)) {
            this.armorPreview = !this.armorPreview;
            this.saveSettings();
            return true;
        } else if (contains(mouseX, mouseY, rightX, toggleY + rowStep * 4.0F, toggleWidth, 18.0F)) {
            this.inventoryPreview = !this.inventoryPreview;
            this.saveSettings();
            return true;
        } else {
            return false;
        }
    }

    private float scaleToRatio() {
        return clamp((this.scale - 0.75F) / 0.75F, 0.0F, 1.0F);
    }

    private float hudScaleFactor() {
        return clamp(this.scale, 0.75F, 1.5F);
    }

    private void updateSliderFromMouse(double mouseX, float x, float width, HudFeature.ActiveSlider slider) {
        float sliderStart = x + 10.0F;
        float sliderWidth = width - 20.0F;
        float ratio = clamp((float)((mouseX - (double)sliderStart) / (double)sliderWidth), 0.0F, 1.0F);
        switch (slider) {
            case NONE:
            default:
                break;
            case OPACITY:
                this.opacity = Math.max(60, Math.min(255, Math.round(60.0F + ratio * 195.0F)));
                break;
            case RAINBOW_SPEED:
                this.rainbowSpeed = 0.25F + ratio * 3.75F;
                break;
            case NOTIFICATION_DURATION:
                this.notificationDurationMs = Math.max(1000, Math.min(8000, Math.round(1000.0F + ratio * 7000.0F)));
        }
    }

    private float opacityToRatio() {
        return ((float)this.opacity - 60.0F) / 195.0F;
    }

    private float rainbowSpeedToRatio() {
        return (this.rainbowSpeed - 0.25F) / 3.75F;
    }

    private float notificationDurationToRatio() {
        return ((float)this.notificationDurationMs - 1000.0F) / 7000.0F;
    }

    private void drawHudPanel(DrawContext context, float x, float y, float width, float height) {
        ClientTheme theme = currentTheme();
        int bodyFill = withRgb(this.opacity, theme.hudPanelRgb());
        this.drawHudPanelSurface(context, x, y, width, height, 8.0F, bodyFill, withScaledAlpha(theme.white(), (float)this.opacity / 255.0F * 0.08F), false);
    }

    private void drawHudPanelSurface(
        DrawContext context, float x, float y, float width, float height, float radius, int fill, int highlight, boolean emphasized
    ) {
        ClientTheme theme = currentTheme();
        int tonedFill = RenderUtil.mixColor(fill, withRgb(fill >>> 24, theme.shadowStrong()), emphasized ? 0.18F : 0.12F);
        float fillOpacity = (float)(tonedFill >>> 24) / 255.0F;
        int aura = withScaledAlpha(theme.hudGlowColor(), fillOpacity * (emphasized ? 0.42F : 0.24F));
        int shadow = withRgb(emphasized ? Math.max(26, this.opacity / 3) : Math.max(16, this.opacity / 5), theme.shadowStrong());
        if (aura >>> 24 > 0) {
            RenderUtil.drawRoundedRect(context, x - 1.0F, y - 1.0F, width + 2.0F, height + 2.0F, radius + 1.0F, aura);
        }

        RenderUtil.drawRoundedRect(context, x + 1.0F, y + 2.0F, width, height, radius, shadow);
        RenderUtil.drawGradientRoundedRect(context, x, y, width, height, radius, tonedFill, RenderUtil.darken(tonedFill, 0.2F));
        RenderUtil.drawRoundedRect(context, x + 1.0F, y + 1.0F, width - 2.0F, 1.0F, 0.5F, highlight);
        if (emphasized) {
            RenderUtil.drawRoundedRect(context, x + 1.0F, y + 1.0F, width - 2.0F, 1.0F, 0.5F, withScaledAlpha(theme.accent(), 0.08F));
        }
    }

    private void drawHudSurface(DrawContext context, float x, float y, float width, float height, float radius, int fill, int highlight) {
        ClientTheme theme = currentTheme();
        int tonedFill = RenderUtil.mixColor(fill, withRgb(fill >>> 24, theme.shadowStrong()), 0.1F);
        float fillOpacity = (float)(tonedFill >>> 24) / 255.0F;
        int aura = withScaledAlpha(theme.hudGlowColor(), fillOpacity * 0.2F);
        if (aura >>> 24 > 0) {
            RenderUtil.drawRoundedRect(context, x - 1.0F, y - 1.0F, width + 2.0F, height + 2.0F, radius + 1.0F, aura);
        }

        RenderUtil.drawGradientRoundedRect(context, x, y, width, height, radius, tonedFill, RenderUtil.darken(tonedFill, 0.16F));
        RenderUtil.drawRoundedRect(context, x + 1.0F, y + 1.0F, width - 2.0F, 1.0F, 0.5F, highlight);
    }

    private int getHudTextColor(float offset, int fallback) {
        if (!this.rainbow) {
            return fallback;
        } else {
            float hue = ((float)System.currentTimeMillis() / 1000.0F * this.rainbowSpeed * 0.18F + offset) % 1.0F;
            int rgb = Color.HSBtoRGB(hue, 0.64F, 1.0F);
            return 0xFF000000 | rgb & 16777215;
        }
    }

    private float getNotificationVisibility(long ageMs) {
        if (ageMs <= 0L) {
            return 0.0F;
        } else if ((float)ageMs < 140.0F) {
            return clamp((float)ageMs / 140.0F, 0.0F, 1.0F);
        } else {
            float fadeOutStart = Math.max(140.0F, (float)this.notificationDurationMs - 360.0F);
            if ((float)ageMs < fadeOutStart) {
                return 1.0F;
            } else {
                return ageMs < (long)this.notificationDurationMs ? 1.0F - clamp(((float)ageMs - fadeOutStart) / 360.0F, 0.0F, 1.0F) : 0.0F;
            }
        }
    }

    private static String fit(TextRenderer textRenderer, String value, int maxWidth) {
        if (RenderUtil.getTextWidth(textRenderer, value) <= maxWidth) {
            return value;
        } else {
            String ellipsis = "...";
            String trimmed = value;

            while (!trimmed.isEmpty() && RenderUtil.getTextWidth(textRenderer, trimmed + ellipsis) > maxWidth) {
                trimmed = trimmed.substring(0, trimmed.length() - 1);
            }

            return trimmed + ellipsis;
        }
    }

    private static String formatTicks(int ticks) {
        int totalSeconds = Math.max(0, ticks / 20);
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format(Locale.ROOT, "%d:%02d", minutes, seconds);
    }

    private static String toRoman(int value) {
        return switch (value) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            case 6 -> "VI";
            case 7 -> "VII";
            case 8 -> "VIII";
            case 9 -> "IX";
            case 10 -> "X";
            default -> Integer.toString(value);
        };
    }

    private static int withRgb(int alpha, int rgb) {
        return Math.max(0, Math.min(255, alpha)) << 24 | rgb & 16777215;
    }

    private static int withScaledAlpha(int color, float alphaScale) {
        int alpha = color >>> 24;
        int scaledAlpha = Math.max(0, Math.min(255, Math.round((float)alpha * clamp(alphaScale, 0.0F, 1.0F))));
        return scaledAlpha << 24 | color & 16777215;
    }

    private int themeAccent() {
        return currentTheme().accent();
    }

    private static ClientTheme currentTheme() {
        return ThemeManager.getInstance().getCurrentTheme();
    }

    private static boolean contains(double mouseX, double mouseY, float x, float y, float width, float height) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + height);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static float easeOutCubic(float value) {
        float inverse = 1.0F - clamp(value, 0.0F, 1.0F);
        return 1.0F - inverse * inverse * inverse;
    }

    private static enum ActiveEditorSlider {
        NONE,
        SCALE;
    }

    private static enum ActiveSlider {
        NONE,
        OPACITY,
        RAINBOW_SPEED,
        NOTIFICATION_DURATION;
    }

    private static record EditorModalLayout(float x, float y, float scale) {
        private float toLocalX(double mouseX) {
            return (float)((mouseX - (double)this.x) / (double)Math.max(0.001F, this.scale));
        }

        private float toLocalY(double mouseY) {
            return (float)((mouseY - (double)this.y) / (double)Math.max(0.001F, this.scale));
        }
    }

    private static record HudToast(String message, HudFeature.ToastType type, long createdAt) {
    }

    private static record ModuleHudEntry(Feature feature, String label, String suffix, float measuredWidth) {
    }

    private static record PotionHudEntry(String label, String duration) {
    }

    private static enum SortMode {
        LONGEST("LONGEST"),
        SHORTEST("SHORTEST");

        private final String label;

        private SortMode(String label) {
            this.label = label;
        }

        private String label() {
            return this.label;
        }

        private HudFeature.SortMode next() {
            return this == LONGEST ? SHORTEST : LONGEST;
        }

        private static HudFeature.SortMode parse(String value) {
            for (HudFeature.SortMode sortMode : values()) {
                if (sortMode.label.equalsIgnoreCase(value)) {
                    return sortMode;
                }
            }

            return LONGEST;
        }
    }

    private static record ToastStyle(String label, String icon, int accentColor, float badgeHeight, float badgeRadius) {
    }

    private static enum ToastType {
        SUCCESS,
        INFO,
        WARNING;
    }

    private static record TopLeftBadge(String text, int accentColor, boolean accentDot) {
    }

    private static record TopLeftDockRow(List<HudFeature.TopLeftBadge> badges, float width) {
    }
}
