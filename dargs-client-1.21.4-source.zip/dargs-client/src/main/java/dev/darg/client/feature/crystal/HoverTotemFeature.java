package dev.darg.client.feature.crystal;

import dev.darg.client.feature.Category;
import dev.darg.client.feature.combat.CombatSupport;
import dev.darg.client.feature.combat.ConfigurableCombatFeature;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.Items;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

public final class HoverTotemFeature extends ConfigurableCombatFeature {
    private final ConfigurableCombatFeature.NumberSetting delay = this.intSetting("delay", "Delay", 0, 0, 20);
    private final ConfigurableCombatFeature.BooleanSetting hotbar = this.booleanSetting("hotbar", "Hotbar", true);
    private final ConfigurableCombatFeature.NumberSetting slot = this.intSetting("totem_slot", "Totem Slot", 1, 1, 9);
    private final ConfigurableCombatFeature.BooleanSetting autoSwitch = this.booleanSetting("auto_switch", "Auto Switch", false);
    private int clock;

    public HoverTotemFeature() {
        super("HoverTotem", Category.CRYSTAL);
    }

    @Override
    protected void onEnable() {
        this.clock = 0;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            if (mc.currentScreen instanceof InventoryScreen inv) {
                Slot var5 = CombatSupport.getFocusedSlot(inv);
                if (this.autoSwitch.get()) {
                    CombatSupport.selectHotbarSlot(mc.player, this.slot.intValue() - 1);
                }

                if (var5 != null && var5.getIndex() <= 35) {
                    if (var5.getStack().isOf(Items.TOTEM_OF_UNDYING)) {
                        if (this.clock > 0) {
                            this.clock--;
                        } else {
                            int totemSlot = this.slot.intValue() - 1;
                            if (this.hotbar.get() && mc.player.getInventory().getStack(totemSlot).getItem() != Items.TOTEM_OF_UNDYING) {
                                mc.interactionManager
                                    .clickSlot(
                                        ((PlayerScreenHandler)inv.getScreenHandler()).syncId,
                                        var5.getIndex(),
                                        totemSlot,
                                        SlotActionType.SWAP,
                                        mc.player
                                    );
                            } else if (!mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                                mc.interactionManager
                                    .clickSlot(
                                        ((PlayerScreenHandler)inv.getScreenHandler()).syncId, var5.getIndex(), 40, SlotActionType.SWAP, mc.player
                                    );
                            }

                            this.clock = this.delay.intValue();
                        }
                    }
                }
            } else {
                this.clock = this.delay.intValue();
            }
        }
    }
}
