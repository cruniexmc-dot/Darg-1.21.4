package dev.darg.client.feature.utility;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.clickgui.NotificationManager;
import java.util.List;
import net.minecraft.client.MinecraftClient;

public final class ConfigManagerFeature extends Feature {
    public ConfigManagerFeature() {
        super("Configs", Category.SETTINGS);
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of(
            "Open local config profiles", "Save and load current module states", "Stores values, binds and positions locally", "Left click opens the manager"
        );
    }

    @Override
    public boolean shouldPersistEnabledState() {
        return false;
    }

    @Override
    public boolean onClickGuiPrimaryClick(NotificationManager notificationManager) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) {
            return true;
        } else {
            client.setScreen(DargsClient.getInstance().getUiManager().createConfigManagerScreen(client.currentScreen));
            notificationManager.push("Config manager opened", NotificationManager.Type.INFO);
            return true;
        }
    }
}
