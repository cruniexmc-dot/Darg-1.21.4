package dev.darg.client.feature.combat;

import dev.darg.client.feature.Category;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

public final class AutoPotRefillFeature extends ConfigurableCombatFeature {
    private final ConfigurableCombatFeature.EnumSetting<AutoPotRefillFeature.Mode> mode = this.enumSetting(
        "mode", "Mode", AutoPotRefillFeature.Mode.Auto, AutoPotRefillFeature.Mode.class
    );
    private final ConfigurableCombatFeature.NumberSetting delay = this.intSetting("delay", "Delay", 0, 0, 10);
    private int clock;

    public AutoPotRefillFeature() {
        super("AutoPotRefill", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        this.clock = 0;
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player != null && client.interactionManager != null) {
            if (client.currentScreen instanceof InventoryScreen inventoryScreen) {
                int emptySlot = this.findEmptyHotbarSlot(player.getInventory());
                if (emptySlot >= 0) {
                    if (this.clock < this.delay.intValue()) {
                        this.clock++;
                    } else if (this.mode.get() == AutoPotRefillFeature.Mode.Hover) {
                        Slot focusedSlot = CombatSupport.getFocusedSlot(inventoryScreen);
                        if (focusedSlot != null && CombatSupport.isSplashInstantHealth(focusedSlot.getStack())) {
                            client.interactionManager
                                .clickSlot(
                                    ((PlayerScreenHandler)inventoryScreen.getScreenHandler()).syncId,
                                    focusedSlot.getIndex(),
                                    emptySlot,
                                    SlotActionType.SWAP,
                                    player
                                );
                            this.clock = 0;
                        }
                    } else {
                        int inventorySlot = CombatSupport.findInventoryInstantHealthSplash(player);
                        if (inventorySlot >= 0) {
                            client.interactionManager
                                .clickSlot(
                                    ((PlayerScreenHandler)inventoryScreen.getScreenHandler()).syncId,
                                    CombatSupport.screenSlotFromInventory(inventorySlot),
                                    emptySlot,
                                    SlotActionType.SWAP,
                                    player
                                );
                            this.clock = 0;
                        }
                    }
                }
            } else {
                this.clock = 0;
            }
        } else {
            this.clock = 0;
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("Mode: " + this.mode.displayValue(), "Delay: " + this.delay.intValue() + " ticks", "Refills splash health potions");
    }

    private int findEmptyHotbarSlot(PlayerInventory inventory) {
        for (int slot = 0; slot < PlayerInventory.getHotbarSize(); slot++) {
            ItemStack stack = inventory.getStack(slot);
            if (stack.isEmpty()) {
                return slot;
            }
        }

        return -1;
    }

    public static enum Mode {
        Auto,
        Hover;
    }
}
