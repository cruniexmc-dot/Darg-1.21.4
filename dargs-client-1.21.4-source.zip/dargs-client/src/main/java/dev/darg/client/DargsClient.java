package dev.darg.client;

import dev.darg.client.feature.FeatureManager;
import dev.darg.client.input.KeybindManager;
import dev.darg.client.ui.UiManager;
import net.fabricmc.api.ClientModInitializer;

public final class DargsClient implements ClientModInitializer {
    public static final String MOD_ID = "dargsclient";
    public static final String NAME = "Darg's Client";
    private static DargsClient instance;
    private final FeatureManager featureManager = new FeatureManager();
    private final KeybindManager keybindManager = new KeybindManager();
    private final UiManager uiManager = new UiManager();

    public static DargsClient getInstance() {
        return instance;
    }

    public void onInitializeClient() {
        instance = this;
        ClientBootstrap.run(this);
    }

    public FeatureManager getFeatureManager() {
        return this.featureManager;
    }

    public KeybindManager getKeybindManager() {
        return this.keybindManager;
    }

    public UiManager getUiManager() {
        return this.uiManager;
    }
}
