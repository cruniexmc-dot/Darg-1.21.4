package dev.darg.client.ui.theme;

public final class ClientTheme {
    private final int accent;
    private final int white;
    private final int softGray;
    private final int darkText;
    private final int mutedGray;
    private final int shadowStrong;
    private final int clickGuiBackdrop;
    private final int clickGuiHudPanel;
    private final int clickGuiHudShadow;
    private final int clickGuiPanelBorder;
    private final int clickGuiPanelHeader;
    private final int clickGuiPanelFill;
    private final int clickGuiNotificationPanel;
    private final int clickGuiNotificationShadow;
    private final int clickGuiNotificationSuccessAccent;
    private final int clickGuiNotificationInfoAccent;
    private final int moduleButtonFill;
    private final int moduleButtonFillHover;
    private final int moduleButtonExpandedFill;
    private final int moduleButtonShadow;
    private final int moduleButtonBorder;
    private final int moduleButtonActionFill;
    private final int moduleButtonActionHoverFill;
    private final int moduleButtonTooltipFill;
    private final int moduleButtonTooltipBorder;
    private final int moduleButtonTooltipShadow;
    private final int moduleButtonTooltipDetail;
    private final int moduleButtonTooltipMuted;
    private final int hudPanelRgb;
    private final int hudPanelEdge;
    private final int hudPanelSheen;
    private final int hudPanelSoft;
    private final int hudPanelSoftEdge;
    private final int hudChipFill;
    private final int hudChipBorder;
    private final int hudModuleFill;
    private final int hudModuleFillActive;
    private final int hudSuccessAccent;
    private final int hudInfoAccent;
    private final int hudWarningAccent;
    private final int hudActionFill;
    private final int hudActionHover;
    private final int hudTrackFill;
    private final int hudToggleFill;
    private final int hudSlotFill;
    private final int hudSlotEdge;
    private final int hudDurabilityBg;
    private final int hudGlowColor;

    private ClientTheme(
        int accent,
        int white,
        int softGray,
        int darkText,
        int mutedGray,
        int shadowStrong,
        int clickGuiBackdrop,
        int clickGuiHudPanel,
        int clickGuiHudShadow,
        int clickGuiPanelBorder,
        int clickGuiPanelHeader,
        int clickGuiPanelFill,
        int clickGuiNotificationPanel,
        int clickGuiNotificationShadow,
        int clickGuiNotificationSuccessAccent,
        int clickGuiNotificationInfoAccent,
        int moduleButtonFill,
        int moduleButtonFillHover,
        int moduleButtonExpandedFill,
        int moduleButtonShadow,
        int moduleButtonBorder,
        int moduleButtonActionFill,
        int moduleButtonActionHoverFill,
        int moduleButtonTooltipFill,
        int moduleButtonTooltipBorder,
        int moduleButtonTooltipShadow,
        int moduleButtonTooltipDetail,
        int moduleButtonTooltipMuted,
        int hudPanelRgb,
        int hudPanelEdge,
        int hudPanelSheen,
        int hudPanelSoft,
        int hudPanelSoftEdge,
        int hudChipFill,
        int hudChipBorder,
        int hudModuleFill,
        int hudModuleFillActive,
        int hudSuccessAccent,
        int hudInfoAccent,
        int hudWarningAccent,
        int hudActionFill,
        int hudActionHover,
        int hudTrackFill,
        int hudToggleFill,
        int hudSlotFill,
        int hudSlotEdge,
        int hudDurabilityBg,
        int hudGlowColor
    ) {
        this.accent = accent;
        this.white = white;
        this.softGray = softGray;
        this.darkText = darkText;
        this.mutedGray = mutedGray;
        this.shadowStrong = shadowStrong;
        this.clickGuiBackdrop = clickGuiBackdrop;
        this.clickGuiHudPanel = clickGuiHudPanel;
        this.clickGuiHudShadow = clickGuiHudShadow;
        this.clickGuiPanelBorder = clickGuiPanelBorder;
        this.clickGuiPanelHeader = clickGuiPanelHeader;
        this.clickGuiPanelFill = clickGuiPanelFill;
        this.clickGuiNotificationPanel = clickGuiNotificationPanel;
        this.clickGuiNotificationShadow = clickGuiNotificationShadow;
        this.clickGuiNotificationSuccessAccent = clickGuiNotificationSuccessAccent;
        this.clickGuiNotificationInfoAccent = clickGuiNotificationInfoAccent;
        this.moduleButtonFill = moduleButtonFill;
        this.moduleButtonFillHover = moduleButtonFillHover;
        this.moduleButtonExpandedFill = moduleButtonExpandedFill;
        this.moduleButtonShadow = moduleButtonShadow;
        this.moduleButtonBorder = moduleButtonBorder;
        this.moduleButtonActionFill = moduleButtonActionFill;
        this.moduleButtonActionHoverFill = moduleButtonActionHoverFill;
        this.moduleButtonTooltipFill = moduleButtonTooltipFill;
        this.moduleButtonTooltipBorder = moduleButtonTooltipBorder;
        this.moduleButtonTooltipShadow = moduleButtonTooltipShadow;
        this.moduleButtonTooltipDetail = moduleButtonTooltipDetail;
        this.moduleButtonTooltipMuted = moduleButtonTooltipMuted;
        this.hudPanelRgb = hudPanelRgb;
        this.hudPanelEdge = hudPanelEdge;
        this.hudPanelSheen = hudPanelSheen;
        this.hudPanelSoft = hudPanelSoft;
        this.hudPanelSoftEdge = hudPanelSoftEdge;
        this.hudChipFill = hudChipFill;
        this.hudChipBorder = hudChipBorder;
        this.hudModuleFill = hudModuleFill;
        this.hudModuleFillActive = hudModuleFillActive;
        this.hudSuccessAccent = hudSuccessAccent;
        this.hudInfoAccent = hudInfoAccent;
        this.hudWarningAccent = hudWarningAccent;
        this.hudActionFill = hudActionFill;
        this.hudActionHover = hudActionHover;
        this.hudTrackFill = hudTrackFill;
        this.hudToggleFill = hudToggleFill;
        this.hudSlotFill = hudSlotFill;
        this.hudSlotEdge = hudSlotEdge;
        this.hudDurabilityBg = hudDurabilityBg;
        this.hudGlowColor = hudGlowColor;
    }

    public int accent() {
        return this.accent;
    }

    public int white() {
        return this.white;
    }

    public int softGray() {
        return this.softGray;
    }

    public int darkText() {
        return this.darkText;
    }

    public int mutedGray() {
        return this.mutedGray;
    }

    public int shadowStrong() {
        return this.shadowStrong;
    }

    public int clickGuiBackdrop() {
        return this.clickGuiBackdrop;
    }

    public int clickGuiHudPanel() {
        return this.clickGuiHudPanel;
    }

    public int clickGuiHudShadow() {
        return this.clickGuiHudShadow;
    }

    public int clickGuiPanelBorder() {
        return this.clickGuiPanelBorder;
    }

    public int clickGuiPanelHeader() {
        return this.clickGuiPanelHeader;
    }

    public int clickGuiPanelFill() {
        return this.clickGuiPanelFill;
    }

    public int clickGuiNotificationPanel() {
        return this.clickGuiNotificationPanel;
    }

    public int clickGuiNotificationShadow() {
        return this.clickGuiNotificationShadow;
    }

    public int clickGuiNotificationSuccessAccent() {
        return this.clickGuiNotificationSuccessAccent;
    }

    public int clickGuiNotificationInfoAccent() {
        return this.clickGuiNotificationInfoAccent;
    }

    public int moduleButtonFill() {
        return this.moduleButtonFill;
    }

    public int moduleButtonFillHover() {
        return this.moduleButtonFillHover;
    }

    public int moduleButtonExpandedFill() {
        return this.moduleButtonExpandedFill;
    }

    public int moduleButtonShadow() {
        return this.moduleButtonShadow;
    }

    public int moduleButtonBorder() {
        return this.moduleButtonBorder;
    }

    public int moduleButtonActionFill() {
        return this.moduleButtonActionFill;
    }

    public int moduleButtonActionHoverFill() {
        return this.moduleButtonActionHoverFill;
    }

    public int moduleButtonTooltipFill() {
        return this.moduleButtonTooltipFill;
    }

    public int moduleButtonTooltipBorder() {
        return this.moduleButtonTooltipBorder;
    }

    public int moduleButtonTooltipShadow() {
        return this.moduleButtonTooltipShadow;
    }

    public int moduleButtonTooltipDetail() {
        return this.moduleButtonTooltipDetail;
    }

    public int moduleButtonTooltipMuted() {
        return this.moduleButtonTooltipMuted;
    }

    public int hudPanelRgb() {
        return this.hudPanelRgb;
    }

    public int hudPanelEdge() {
        return this.hudPanelEdge;
    }

    public int hudPanelSheen() {
        return this.hudPanelSheen;
    }

    public int hudPanelSoft() {
        return this.hudPanelSoft;
    }

    public int hudPanelSoftEdge() {
        return this.hudPanelSoftEdge;
    }

    public int hudChipFill() {
        return this.hudChipFill;
    }

    public int hudChipBorder() {
        return this.hudChipBorder;
    }

    public int hudModuleFill() {
        return this.hudModuleFill;
    }

    public int hudModuleFillActive() {
        return this.hudModuleFillActive;
    }

    public int hudSuccessAccent() {
        return this.hudSuccessAccent;
    }

    public int hudInfoAccent() {
        return this.hudInfoAccent;
    }

    public int hudWarningAccent() {
        return this.hudWarningAccent;
    }

    public int hudActionFill() {
        return this.hudActionFill;
    }

    public int hudActionHover() {
        return this.hudActionHover;
    }

    public int hudTrackFill() {
        return this.hudTrackFill;
    }

    public int hudToggleFill() {
        return this.hudToggleFill;
    }

    public int hudSlotFill() {
        return this.hudSlotFill;
    }

    public int hudSlotEdge() {
        return this.hudSlotEdge;
    }

    public int hudDurabilityBg() {
        return this.hudDurabilityBg;
    }

    public int hudGlowColor() {
        return this.hudGlowColor;
    }

    public static ClientTheme of() {
        int accent = -7350529;
        int white = -722945;
        int softGray = -4865046;
        int darkText = -15657957;
        int mutedGray = -8220232;
        int shadowStrong = -16777216;
        return new ClientTheme(
            accent,
            white,
            softGray,
            darkText,
            mutedGray,
            shadowStrong,
            1979910676,
            -533183132,
            637534208,
            1132828144,
            -649835646,
            -786883024,
            -518447828,
            838860800,
            -8456449,
            -4419585,
            -802935470,
            -516208220,
            -686219718,
            637534208,
            -8613121,
            -13878671,
            -11837478,
            -518710745,
            -11047766,
            872415232,
            -2498049,
            -6575927,
            922144,
            accent,
            748671999,
            -636480222,
            -9531393,
            -15064252,
            -8676097,
            -434428338,
            -264614176,
            -8717825,
            accent,
            -16782,
            -14471074,
            -12098578,
            -14735038,
            -14405547,
            -434626500,
            -8017921,
            -1442116076,
            1552933119
        );
    }
}
