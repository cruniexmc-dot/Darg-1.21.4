package dev.darg.client.config.local;

import dev.darg.client.config.snapshot.ConfigSnapshot;
import java.time.Instant;
import java.util.Map;

public record LocalConfigProfile(String id, String name, ConfigSnapshot snapshot, Instant createdAt, Instant updatedAt) {
    public LocalConfigProfile(String id, String name, ConfigSnapshot snapshot, Instant createdAt, Instant updatedAt) {
        id = id == null ? "" : id.trim();
        name = name == null ? "" : name.trim();
        snapshot = snapshot == null ? new ConfigSnapshot(1, "", Map.of()) : snapshot;
        createdAt = createdAt == null ? Instant.now() : createdAt;
        updatedAt = updatedAt == null ? createdAt : updatedAt;
        this.id = id;
        this.name = name;
        this.snapshot = snapshot;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public int schemaVersion() {
        return this.snapshot.schemaVersion();
    }

    public String clientVersion() {
        return this.snapshot.clientVersion();
    }
}
