package dev.darg.client.feature.combat;

import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.input.FeatureBind;
import dev.darg.client.ui.clickgui.InlineControlRenderer;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.util.Window;

public abstract class ConfigurableCombatFeature extends Feature {
    private static final float CONTENT_PADDING = 10.0F;
    private static final float SETTING_GAP = 8.0F;
    protected final ClientConfig config = ClientConfig.getInstance();
    private final List<ConfigurableCombatFeature.ModuleSetting<?>> settings = new ArrayList<>();
    private ConfigurableCombatFeature.NumberSetting draggingNumberSetting;
    private ConfigurableCombatFeature.BindSetting capturingBindSetting;
    private boolean bindMouseCaptureArmed;

    protected ConfigurableCombatFeature(String name, Category category) {
        super(name, category);
    }

    protected final ConfigurableCombatFeature.BooleanSetting booleanSetting(String key, String label, boolean defaultValue) {
        ConfigurableCombatFeature.BooleanSetting setting = new ConfigurableCombatFeature.BooleanSetting(
            this.config, this.getConfigKey(), key, label, defaultValue
        );
        this.settings.add(setting);
        return setting;
    }

    protected final ConfigurableCombatFeature.NumberSetting intSetting(String key, String label, int defaultValue, int min, int max) {
        ConfigurableCombatFeature.NumberSetting setting = new ConfigurableCombatFeature.NumberSetting(
            this.config, this.getConfigKey(), key, label, (double)defaultValue, (double)min, (double)max, 1.0, 0
        );
        this.settings.add(setting);
        return setting;
    }

    protected final ConfigurableCombatFeature.NumberSetting floatSetting(
        String key, String label, double defaultValue, double min, double max, double step, int decimals
    ) {
        ConfigurableCombatFeature.NumberSetting setting = new ConfigurableCombatFeature.NumberSetting(
            this.config, this.getConfigKey(), key, label, defaultValue, min, max, step, decimals
        );
        this.settings.add(setting);
        return setting;
    }

    protected final <E extends Enum<E>> ConfigurableCombatFeature.EnumSetting<E> enumSetting(String key, String label, E defaultValue, Class<E> enumClass) {
        ConfigurableCombatFeature.EnumSetting<E> setting = new ConfigurableCombatFeature.EnumSetting<>(
            this.config, this.getConfigKey(), key, label, defaultValue, enumClass
        );
        this.settings.add(setting);
        return setting;
    }

    protected final ConfigurableCombatFeature.BindSetting bindSetting(String key, String label, FeatureBind defaultValue) {
        ConfigurableCombatFeature.BindSetting setting = new ConfigurableCombatFeature.BindSetting(this.config, this.getConfigKey(), key, label, defaultValue);
        this.settings.add(setting);
        return setting;
    }

    protected final List<ConfigurableCombatFeature.ModuleSetting<?>> settings() {
        return this.settings;
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return !this.settings.isEmpty();
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        if (this.settings.isEmpty()) {
            return 0.0F;
        } else {
            float height = 10.0F;

            for (int index = 0; index < this.settings.size(); index++) {
                height += this.settings.get(index).height();
                if (index + 1 < this.settings.size()) {
                    height += 8.0F;
                }
            }

            return height + 10.0F;
        }
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        float contentX = x + 10.0F;
        float contentWidth = width - 20.0F;
        float cursorY = y + 10.0F;
        if (this.draggingNumberSetting != null) {
            this.draggingNumberSetting.setFromMouse((double)mouseX, contentX, contentWidth);
        }

        for (ConfigurableCombatFeature.ModuleSetting<?> setting : this.settings) {
            if (setting instanceof ConfigurableCombatFeature.BooleanSetting booleanSetting) {
                boolean hovered = InlineControlRenderer.containsToggle((double)mouseX, (double)mouseY, contentX, cursorY, contentWidth);
                InlineControlRenderer.drawToggle(
                    context, textRenderer, theme, booleanSetting.label(), booleanSetting.get(), hovered, contentX, cursorY, contentWidth
                );
            } else if (setting instanceof ConfigurableCombatFeature.NumberSetting numberSetting) {
                InlineControlRenderer.drawSlider(
                    context, textRenderer, theme, numberSetting.label(), numberSetting.formattedValue(), contentX, cursorY, contentWidth, numberSetting.ratio()
                );
            } else if (setting instanceof ConfigurableCombatFeature.EnumSetting<?> enumSetting) {
                String value = enumSetting.displayValue();
                float buttonWidth = Math.max(72.0F, (float)textRenderer.getWidth(value) + 18.0F);
                float buttonX = contentX + contentWidth - buttonWidth;
                boolean hovered = InlineControlRenderer.containsButton((double)mouseX, (double)mouseY, buttonX, cursorY, buttonWidth);
                RenderUtil.drawText(context, textRenderer, enumSetting.label(), contentX, cursorY + 2.0F, theme.white());
                InlineControlRenderer.drawButton(context, textRenderer, theme, value, false, hovered, buttonX, cursorY, buttonWidth);
            } else if (setting instanceof ConfigurableCombatFeature.BindSetting bindSetting) {
                String value = this.capturingBindSetting == bindSetting
                    ? "LISTENING"
                    : InlineControlRenderer.fitText(textRenderer, bindSetting.displayValue().toUpperCase(Locale.ROOT), 58);
                float buttonWidth = 82.0F;
                float buttonX = contentX + contentWidth - buttonWidth;
                boolean hovered = InlineControlRenderer.containsButton((double)mouseX, (double)mouseY, buttonX, cursorY, buttonWidth);
                RenderUtil.drawText(context, textRenderer, bindSetting.label(), contentX, cursorY + 2.0F, theme.white());
                InlineControlRenderer.drawButton(
                    context, textRenderer, theme, value, this.capturingBindSetting == bindSetting, hovered, buttonX, cursorY, buttonWidth
                );
            }

            cursorY += setting.height() + 8.0F;
        }
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (this.capturingBindSetting != null && this.bindMouseCaptureArmed) {
            this.applyBindCapture(FeatureBind.mouse(button), notificationManager);
            this.bindMouseCaptureArmed = false;
            return true;
        } else if (!this.containsInline(mouseX, mouseY, x, y, width)) {
            return false;
        } else {
            float contentX = x + 10.0F;
            float contentWidth = width - 20.0F;
            float cursorY = y + 10.0F;
            Iterator var13 = this.settings.iterator();

            while (true) {
                if (!var13.hasNext()) {
                    return true;
                }

                ConfigurableCombatFeature.ModuleSetting<?> setting = (ConfigurableCombatFeature.ModuleSetting<?>)var13.next();
                if (setting instanceof ConfigurableCombatFeature.BooleanSetting booleanSetting) {
                    if (button == 0 && InlineControlRenderer.containsToggle(mouseX, mouseY, contentX, cursorY, contentWidth)) {
                        booleanSetting.toggle();
                        this.config.save();
                        return true;
                    }
                } else if (setting instanceof ConfigurableCombatFeature.NumberSetting numberSetting) {
                    if (button == 0 && InlineControlRenderer.containsSlider(mouseX, mouseY, contentX, cursorY, contentWidth)) {
                        this.draggingNumberSetting = numberSetting;
                        numberSetting.setFromMouse(mouseX, contentX, contentWidth);
                        return true;
                    }
                } else if (setting instanceof ConfigurableCombatFeature.EnumSetting<?> enumSetting) {
                    String value = enumSetting.displayValue();
                    float buttonWidth = estimateButtonWidth(value);
                    float buttonX = contentX + contentWidth - buttonWidth;
                    if (InlineControlRenderer.containsButton(mouseX, mouseY, buttonX, cursorY, buttonWidth)) {
                        if (button == 0) {
                            enumSetting.cycleForward();
                            break;
                        }

                        if (button == 1) {
                            enumSetting.cycleBackward();
                            break;
                        }

                        cursorY += setting.height() + 8.0F;
                        continue;
                    }
                } else if (setting instanceof ConfigurableCombatFeature.BindSetting bindSetting) {
                    float buttonWidth = 82.0F;
                    float buttonX = contentX + contentWidth - buttonWidth;
                    if (InlineControlRenderer.containsButton(mouseX, mouseY, buttonX, cursorY, buttonWidth)) {
                        if (button == 1) {
                            bindSetting.set(FeatureBind.none());
                            this.config.save();
                            if (notificationManager != null) {
                                notificationManager.push(this.getName() + " " + bindSetting.label() + " cleared", NotificationManager.Type.INFO);
                            }
                        } else if (button == 0) {
                            this.capturingBindSetting = bindSetting;
                            this.bindMouseCaptureArmed = false;
                            if (notificationManager != null) {
                                notificationManager.push(
                                    "Press a key or mouse button for " + this.getName() + " " + bindSetting.label(), NotificationManager.Type.INFO
                                );
                            }
                        }

                        return true;
                    }
                }

                cursorY += setting.height() + 8.0F;
            }

            this.config.save();
            return true;
        }
    }

    @Override
    public boolean onCustomClickGuiMouseReleased(double mouseX, double mouseY, int button, float x, float y, float width) {
        if (button == 0 && this.draggingNumberSetting != null) {
            this.draggingNumberSetting = null;
            this.config.save();
            return true;
        } else {
            if (this.capturingBindSetting != null) {
                this.bindMouseCaptureArmed = true;
            }

            return false;
        }
    }

    @Override
    public boolean onClickGuiKeyPressed(KeyInput keyInput) {
        if (this.capturingBindSetting == null) {
            return false;
        } else {
            int keyCode = keyInput.key();
            if (keyCode == 256) {
                this.capturingBindSetting = null;
                this.bindMouseCaptureArmed = false;
                return true;
            } else if (keyCode == 261 || keyCode == 259) {
                this.capturingBindSetting.set(FeatureBind.none());
                this.capturingBindSetting = null;
                this.bindMouseCaptureArmed = false;
                this.config.save();
                return true;
            } else if (keyCode == -1) {
                return true;
            } else {
                this.applyBindCapture(FeatureBind.keyboard(keyCode), null);
                return true;
            }
        }
    }

    @Override
    public boolean isClickGuiInteractionActive() {
        return this.draggingNumberSetting != null || this.capturingBindSetting != null;
    }

    @Override
    public List<String> getClickGuiDetails() {
        if (this.settings.isEmpty()) {
            return super.getClickGuiDetails();
        } else {
            List<String> details = new ArrayList<>();

            for (ConfigurableCombatFeature.ModuleSetting<?> setting : this.settings) {
                details.add(setting.label() + ": " + setting.detailValue());
                if (details.size() >= 6) {
                    break;
                }
            }

            return details;
        }
    }

    private void applyBindCapture(FeatureBind bind, NotificationManager notificationManager) {
        if (this.capturingBindSetting != null) {
            this.capturingBindSetting.set(bind == null ? FeatureBind.none() : bind);
            ConfigurableCombatFeature.BindSetting completed = this.capturingBindSetting;
            this.capturingBindSetting = null;
            this.bindMouseCaptureArmed = false;
            this.config.save();
            if (notificationManager != null) {
                notificationManager.push(this.getName() + " " + completed.label() + " set to " + completed.displayValue(), NotificationManager.Type.SUCCESS);
            }
        }
    }

    private boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        float height = this.getCustomClickGuiHeight(width);
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + height);
    }

    private static float estimateButtonWidth(String value) {
        return Math.max(72.0F, (float)(value == null ? 0 : value.length()) * 6.5F + 18.0F);
    }

    protected static final class BindSetting extends ConfigurableCombatFeature.ModuleSetting<FeatureBind> {
        private BindSetting(ClientConfig config, String featureKey, String key, String label, FeatureBind defaultValue) {
            super(config, featureKey, key, label, defaultValue == null ? FeatureBind.none() : defaultValue);
            this.restore(defaultValue == null ? FeatureBind.none() : defaultValue);
        }

        public FeatureBind get() {
            return this.getValue();
        }

        public boolean isPressed(Window window) {
            return this.get().isPressed(window);
        }

        public String displayValue() {
            return this.get().getDisplayName();
        }

        @Override
        public float height() {
            return 16.0F;
        }

        @Override
        public String detailValue() {
            return this.displayValue();
        }

        protected FeatureBind load(String serialized, FeatureBind fallback) {
            try {
                return FeatureBind.parse(serialized);
            } catch (IllegalArgumentException var4) {
                return fallback;
            }
        }

        protected String serialize(FeatureBind value) {
            return value == null ? FeatureBind.none().serialize() : value.serialize();
        }
    }

    protected static final class BooleanSetting extends ConfigurableCombatFeature.ModuleSetting<Boolean> {
        private BooleanSetting(ClientConfig config, String featureKey, String key, String label, boolean defaultValue) {
            super(config, featureKey, key, label, defaultValue);
            this.restore(Boolean.valueOf(defaultValue));
        }

        public boolean get() {
            return this.getValue();
        }

        public void toggle() {
            this.set(Boolean.valueOf(!this.get()));
        }

        @Override
        public float height() {
            return 12.0F;
        }

        @Override
        public String detailValue() {
            return this.get() ? "On" : "Off";
        }

        protected Boolean load(String serialized, Boolean fallback) {
            String var3 = serialized.toLowerCase(Locale.ROOT);

            return switch (var3) {
                case "true", "1", "yes", "on" -> true;
                case "false", "0", "no", "off" -> false;
                default -> fallback;
            };
        }

        protected String serialize(Boolean value) {
            return Boolean.toString(Boolean.TRUE.equals(value));
        }
    }

    protected static final class EnumSetting<E extends Enum<E>> extends ConfigurableCombatFeature.ModuleSetting<E> {
        private final E[] values;

        private EnumSetting(ClientConfig config, String featureKey, String key, String label, E defaultValue, Class<E> enumClass) {
            super(config, featureKey, key, label, defaultValue);
            this.values = enumClass.getEnumConstants();
            this.restore(defaultValue);
        }

        public E get() {
            return this.getValue();
        }

        public void cycleForward() {
            this.set(this.values[(this.get().ordinal() + 1) % this.values.length]);
        }

        public void cycleBackward() {
            int nextIndex = this.get().ordinal() - 1;
            if (nextIndex < 0) {
                nextIndex = this.values.length - 1;
            }

            this.set(this.values[nextIndex]);
        }

        public String displayValue() {
            String name = this.get().name().toLowerCase(Locale.ROOT).replace('_', ' ');
            return Character.toUpperCase(name.charAt(0)) + name.substring(1);
        }

        @Override
        public float height() {
            return 16.0F;
        }

        @Override
        public String detailValue() {
            return this.displayValue();
        }

        protected E load(String serialized, E fallback) {
            for (E candidate : this.values) {
                if (candidate.name().equalsIgnoreCase(serialized)) {
                    return candidate;
                }
            }

            return fallback;
        }

        protected String serialize(E value) {
            return value.name();
        }
    }

    protected abstract static class ModuleSetting<T> {
        protected final ClientConfig config;
        private final String featureKey;
        private final String key;
        private final String label;
        protected T value;

        protected ModuleSetting(ClientConfig config, String featureKey, String key, String label, T defaultValue) {
            this.config = config;
            this.featureKey = featureKey;
            this.key = key;
            this.label = label;
            this.value = defaultValue;
        }

        public final String label() {
            return this.label;
        }

        public abstract float height();

        public abstract String detailValue();

        protected final void persist(String serialized) {
            this.config.setFeatureSetting(this.featureKey, this.key, serialized);
        }

        protected abstract T load(String var1, T var2);

        protected abstract String serialize(T var1);

        public final void set(T value) {
            this.value = value;
            this.persist(this.serialize(value));
        }

        public final T getValue() {
            return this.value;
        }

        protected final void restore(T defaultValue) {
            String serialized = this.config.getFeatureSetting(this.featureKey, this.key);
            this.value = serialized.isBlank() ? defaultValue : this.load(serialized, defaultValue);
        }
    }

    protected static final class NumberSetting extends ConfigurableCombatFeature.ModuleSetting<Double> {
        private final double min;
        private final double max;
        private final double step;
        private final int decimals;

        private NumberSetting(
            ClientConfig config, String featureKey, String key, String label, double defaultValue, double min, double max, double step, int decimals
        ) {
            super(config, featureKey, key, label, defaultValue);
            this.min = min;
            this.max = max;
            this.step = step;
            this.decimals = Math.max(0, decimals);
            this.restore(Double.valueOf(defaultValue));
        }

        public int intValue() {
            return (int)Math.round(this.getValue());
        }

        public float floatValue() {
            return this.getValue().floatValue();
        }

        public double doubleValue() {
            return this.getValue();
        }

        public float ratio() {
            return (float)((this.doubleValue() - this.min) / Math.max(1.0E-4, this.max - this.min));
        }

        public String formattedValue() {
            return this.decimals <= 0 ? Integer.toString(this.intValue()) : String.format(Locale.ROOT, "%." + this.decimals + "f", this.doubleValue());
        }

        public void setFromMouse(double mouseX, float x, float width) {
            float ratio = Math.max(0.0F, Math.min(1.0F, (float)((mouseX - (double)x) / (double)width)));
            double raw = this.min + (this.max - this.min) * (double)ratio;
            double quantized = (double)Math.round(raw / this.step) * this.step;
            double clamped = Math.max(this.min, Math.min(this.max, quantized));
            this.set(Double.valueOf(clamped));
        }

        @Override
        public float height() {
            return 20.0F;
        }

        @Override
        public String detailValue() {
            return this.formattedValue();
        }

        protected Double load(String serialized, Double fallback) {
            try {
                double parsed = Double.parseDouble(serialized);
                return Math.max(this.min, Math.min(this.max, parsed));
            } catch (NumberFormatException var5) {
                return fallback;
            }
        }

        protected String serialize(Double value) {
            return this.decimals <= 0 ? Integer.toString((int)Math.round(value)) : String.format(Locale.ROOT, "%." + this.decimals + "f", value);
        }
    }
}
