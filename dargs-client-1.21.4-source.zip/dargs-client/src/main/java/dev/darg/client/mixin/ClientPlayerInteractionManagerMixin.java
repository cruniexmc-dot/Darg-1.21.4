package dev.darg.client.mixin;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.visual.TargetHudFeature;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientPlayerInteractionManager.class})
public abstract class ClientPlayerInteractionManagerMixin {
    @Inject(
        method = {"attackEntity"},
        at = {@At("HEAD")}
    )
    private void dargsclient$trackTargetHudAttack(PlayerEntity player, Entity target, CallbackInfo ci) {
        DargsClient client = DargsClient.getInstance();
        if (client != null) {
            client.getFeatureManager().attackEntity(target);
        }

        if (target instanceof PlayerEntity targetPlayer) {
            if (client != null) {
                TargetHudFeature feature = client.getFeatureManager().getFeature(TargetHudFeature.class);
                if (feature != null && feature.isEnabled()) {
                    feature.onPlayerAttack(targetPlayer);
                }
            }
        }
    }
}
