package dev.darg.client.mixin;

import dev.darg.client.feature.utility.DisplaySpoofController;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({EntityRenderer.class})
public abstract class EntityRendererNameSpoofMixin {
    @Inject(
        method = {"getDisplayName"},
        at = {@At("RETURN")},
        cancellable = true
    )
    private void dargsclient$spoofEntityDisplayName(Entity entity, CallbackInfoReturnable<Text> cir) {
        cir.setReturnValue(DisplaySpoofController.spoofEntityName(entity, (Text)cir.getReturnValue()));
    }
}
