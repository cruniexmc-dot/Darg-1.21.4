package dev.darg.client.mixin;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.FeatureManager;
import dev.darg.client.feature.utility.FreecamController;
import dev.darg.client.feature.visual.BlockEspFeature;
import dev.darg.client.feature.visual.NoRenderFeature;
import dev.darg.client.feature.visual.PlayerEspFeature;
import dev.darg.client.feature.visual.ZoomFeature;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({GameRenderer.class})
public abstract class GameRendererMixin {
    @Shadow
    private MinecraftClient client;

    @Inject(
        method = {"bobView"},
        at = {@At("HEAD")},
        cancellable = true
    )
    private void dargsclient$disableViewBobbingDuringFreecam(MatrixStack matrices, float tickProgress, CallbackInfo callbackInfo) {
        if (FreecamController.getInstance().isActive() || dargsclient$hasActiveTracers()) {
            callbackInfo.cancel();
        }
    }

    @Inject(
        method = {"tiltViewWhenHurt"},
        at = {@At("HEAD")},
        cancellable = true
    )
    private void dargsclient$noRenderHurtCam(MatrixStack matrices, float tickProgress, CallbackInfo ci) {
        DargsClient instance = DargsClient.getInstance();
        if (instance != null) {
            NoRenderFeature noRender = instance.getFeatureManager().getFeature(NoRenderFeature.class);
            if (noRender != null && noRender.isEnabled() && !noRender.shouldRenderHurtCam()) {
                ci.cancel();
            }
        }
    }

    @Inject(
        method = {"showFloatingItem"},
        at = {@At("HEAD")},
        cancellable = true
    )
    private void dargsclient$noRenderTotemPop(ItemStack floatingItem, CallbackInfo ci) {
        DargsClient instance = DargsClient.getInstance();
        if (instance != null) {
            NoRenderFeature noRender = instance.getFeatureManager().getFeature(NoRenderFeature.class);
            if (noRender != null && noRender.isEnabled() && !noRender.shouldRenderTotemAnimation()) {
                ci.cancel();
            }
        }
    }

    @Inject(
        method = {"updateCrosshairTarget"},
        at = {@At("TAIL")}
    )
    private void dargsclient$updateFreecamCrosshair(float tickProgress, CallbackInfo callbackInfo) {
        FreecamController controller = FreecamController.getInstance();
        if (controller.usesCameraActionSource() && this.client.player != null) {
            HitResult cameraTarget = controller.getCameraActionTarget(tickProgress);
            this.client.crosshairTarget = cameraTarget;
            this.client.targetedEntity = cameraTarget instanceof EntityHitResult entityHitResult ? entityHitResult.getEntity() : null;
        }
    }

    @Inject(
        method = {"getFov"},
        at = {@At("RETURN")},
        cancellable = true
    )
    private void dargsclient$applyZoom(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Float> cir) {
        DargsClient instance = DargsClient.getInstance();
        if (instance != null) {
            ZoomFeature zoom = instance.getFeatureManager().getFeature(ZoomFeature.class);
            if (zoom != null && zoom.isEnabled()) {
                cir.setReturnValue((Float)cir.getReturnValue() / zoom.getZoomFactor());
            }
        }
    }

    private static boolean dargsclient$hasActiveTracers() {
        DargsClient dargsClient = DargsClient.getInstance();
        if (dargsClient == null) {
            return false;
        } else {
            FeatureManager featureManager = dargsClient.getFeatureManager();
            if (featureManager == null) {
                return false;
            } else {
                BlockEspFeature blockEspFeature = featureManager.getFeature(BlockEspFeature.class);
                if (blockEspFeature != null && blockEspFeature.hasTracersEnabled()) {
                    return true;
                } else {
                    PlayerEspFeature playerEspFeature = featureManager.getFeature(PlayerEspFeature.class);
                    return playerEspFeature != null && playerEspFeature.hasTracersEnabled();
                }
            }
        }
    }
}
