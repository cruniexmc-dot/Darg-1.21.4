package dev.darg.client.feature.crystal;

import dev.darg.client.feature.Category;
import dev.darg.client.feature.combat.CombatFeatureHooks;
import dev.darg.client.feature.combat.CombatSupport;
import dev.darg.client.feature.combat.ConfigurableCombatFeature;
import dev.darg.client.input.FeatureBind;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;

public final class AutoHitCrystalFeature extends ConfigurableCombatFeature implements CombatFeatureHooks.ItemUseHook, CombatFeatureHooks.AttackHook {
    private final ConfigurableCombatFeature.BindSetting activateKey = this.bindSetting("activate_key", "Activate Key", FeatureBind.mouse(1));
    private final ConfigurableCombatFeature.BooleanSetting checkPlace = this.booleanSetting("check_place", "Check Place", false);
    private final ConfigurableCombatFeature.NumberSetting switchDelay = this.intSetting("switch_delay", "Switch Delay", 0, 0, 20);
    private final ConfigurableCombatFeature.NumberSetting switchChance = this.intSetting("switch_chance", "Switch Chance", 100, 0, 100);
    private final ConfigurableCombatFeature.NumberSetting placeDelay = this.intSetting("place_delay", "Place Delay", 0, 0, 20);
    private final ConfigurableCombatFeature.NumberSetting placeChance = this.intSetting("place_chance", "Place Chance", 100, 0, 100);
    private final ConfigurableCombatFeature.BooleanSetting workWithTotem = this.booleanSetting("work_with_totem", "Work With Totem", false);
    private final ConfigurableCombatFeature.BooleanSetting workWithCrystal = this.booleanSetting("work_with_crystal", "Work With Crystal", false);
    private final ConfigurableCombatFeature.BooleanSetting clickSimulation = this.booleanSetting("click_simulation", "Click Simulation", false);
    private final ConfigurableCombatFeature.BooleanSetting swordSwap = this.booleanSetting("sword_swap", "Sword Swap", true);
    private int placeClock;
    private int switchClock;
    private boolean active;
    private boolean crystalling;
    private boolean crystalSelected;

    public AutoHitCrystalFeature() {
        super("AutoHitCrystal", Category.CRYSTAL);
    }

    @Override
    protected void onEnable() {
        this.reset();
    }

    @Override
    protected void onDisable() {
        this.reset();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        ClientPlayerInteractionManager im = mc.interactionManager;
        if (player != null && im != null && mc.world != null && mc.currentScreen == null) {
            if (!this.activateKey.isPressed(mc.getWindow())) {
                this.reset();
            } else {
                ItemStack mainHandStack = player.getMainHandStack();
                boolean validTool = CombatSupport.isHoldingWeapon(player)
                    || this.workWithTotem.get() && mainHandStack.isOf(Items.TOTEM_OF_UNDYING)
                    || this.workWithCrystal.get() && mainHandStack.isOf(Items.END_CRYSTAL)
                    || this.swordSwap.get() && mainHandStack.isOf(Items.OBSIDIAN);
                if (validTool || this.active) {
                    this.active = true;
                    if (this.placeClock > 0) {
                        this.placeClock--;
                    }

                    if (this.switchClock > 0) {
                        this.switchClock--;
                    }

                    if (mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == Type.BLOCK) {
                        BlockPos pos = hit.getBlockPos();
                        BlockState state = mc.world.getBlockState(pos);
                        if (this.checkPlace.get() && !state.isOf(Blocks.OBSIDIAN) && !state.isOf(Blocks.BEDROCK) && !state.isAir()
                            )
                         {
                            return;
                        }

                        if (!this.crystalling) {
                            if (!state.isOf(Blocks.OBSIDIAN) && !state.isOf(Blocks.BEDROCK)) {
                                if (!mainHandStack.isOf(Items.OBSIDIAN)) {
                                    if (this.switchClock > 0) {
                                        return;
                                    }

                                    if (Math.random() * 100.0 <= (double)this.switchChance.intValue()) {
                                        if (!CombatSupport.selectHotbarItem(player, Items.OBSIDIAN)) {
                                            this.reset();
                                            return;
                                        }

                                        this.switchClock = this.switchDelay.intValue();
                                    }

                                    return;
                                }

                                if (this.placeClock > 0) {
                                    return;
                                }

                                if (Math.random() * 100.0 <= (double)this.placeChance.intValue()) {
                                    mc.options.useKey.setPressed(false);
                                    if (this.clickSimulation.get()) {
                                        player.swingHand(Hand.MAIN_HAND);
                                    }

                                    im.interactBlock(player, Hand.MAIN_HAND, hit);
                                    player.swingHand(Hand.MAIN_HAND);
                                    this.placeClock = this.placeDelay.intValue() + ThreadLocalRandom.current().nextInt(0, 2);
                                    this.crystalling = true;
                                }

                                return;
                            }

                            this.crystalling = true;
                            return;
                        }

                        if (!mainHandStack.isOf(Items.END_CRYSTAL) && !this.crystalSelected) {
                            if (this.switchClock > 0) {
                                return;
                            }

                            if (Math.random() * 100.0 <= (double)this.switchChance.intValue()) {
                                this.crystalSelected = CombatSupport.selectHotbarItem(player, Items.END_CRYSTAL);
                                this.switchClock = this.switchDelay.intValue();
                            }

                            return;
                        }

                        if (!mainHandStack.isOf(Items.END_CRYSTAL)) {
                            return;
                        }

                        if (this.placeClock > 0) {
                            return;
                        }

                        if (CombatSupport.isCrystalBase(state) && CrystalUtils.canPlaceCrystalAssumeBase(pos, mc.world)) {
                            if (Math.random() * 100.0 <= (double)this.placeChance.intValue()) {
                                mc.options.useKey.setPressed(false);
                                im.interactBlock(player, Hand.MAIN_HAND, hit);
                                player.swingHand(Hand.MAIN_HAND);
                                this.placeClock = this.placeDelay.intValue() + ThreadLocalRandom.current().nextInt(0, 2);
                            }

                            return;
                        }

                        return;
                    }
                }
            }
        } else {
            this.reset();
        }
    }

    @Override
    public boolean onBeforeItemUse(MinecraftClient client) {
        if (client.player == null) {
            return false;
        } else {
            Item item = client.player.getMainHandStack().getItem();
            return (item == Items.END_CRYSTAL || item == Items.OBSIDIAN) && !this.activateKey.isPressed(client.getWindow());
        }
    }

    @Override
    public boolean onBeforeAttack(MinecraftClient client) {
        return client.player == null
            ? false
            : client.player.getMainHandStack().isOf(Items.END_CRYSTAL) && !this.activateKey.isPressed(client.getWindow());
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("Hold right-click with sword or crystal", "Places obsidian, switches to crystals");
    }

    private void reset() {
        this.placeClock = 0;
        this.switchClock = 0;
        this.active = false;
        this.crystalling = false;
        this.crystalSelected = false;
    }
}
