package dev.darg.client.ui.clickgui;

import dev.darg.client.mixin.DrawContextAccessor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.StyleSpriteSource.Font;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2f;

public final class RenderUtil {
    private static final Identifier UI_FONT = Identifier.of("dargsclient", "ui");
    private static final Style UI_FONT_STYLE = Style.EMPTY.withFont(new Font(UI_FONT));
    private static final Field DRAW_CONTEXT_SCISSOR_STACK_FIELD = resolveScissorStackField();
    private static final Method SCISSOR_STACK_PEEK_LAST_METHOD = resolveScissorPeekLastMethod();
    private static final int CORNER_SAMPLE_GRID = 8;
    private static final int CORNER_ALPHA_LEVELS = 12;
    private static final int CORNER_RUN_TOLERANCE = 10;
    private static final int FAST_HEIGHT_THRESHOLD = 34;
    private static final Map<Integer, int[][]> CORNER_ALPHA_CACHE = new HashMap<>();
    private static final Map<Integer, int[]> CORNER_INSET_CACHE = new HashMap<>();

    private RenderUtil() {
    }

    public static void drawRoundedRect(DrawContext context, float x, float y, float width, float height, float radius, int color) {
        drawRoundedRectInternal(context, x, y, width, height, radius, color, true);
    }

    public static void drawRoundedRectClassic(DrawContext context, float x, float y, float width, float height, float radius, int color) {
        drawRoundedRectInternal(context, x, y, width, height, radius, color, false);
    }

    public static void drawGradientRoundedRect(DrawContext context, float x, float y, float width, float height, float radius, int colorTop, int colorBottom) {
        if (!(width <= 0.0F) && !(height <= 0.0F)) {
            int left = Math.round(x);
            int top = Math.round(y);
            int right = Math.round(x + width);
            int bottom = Math.round(y + height);
            if (right > left && bottom > top) {
                float clampedRadius = Math.max(0.0F, Math.min(radius, Math.min(width, height) * 0.5F));
                int rounded = Math.max(0, Math.min(Math.round(clampedRadius), Math.min((right - left) / 2, (bottom - top) / 2)));
                if (!tryDrawGradientSmoothRoundedRect(context, left, top, right, bottom, rounded, colorTop, colorBottom)) {
                    context.fillGradient(left, top, right, bottom, colorTop, colorBottom);
                }
            }
        }
    }

    public static int darken(int color, float factor) {
        float f = 1.0F - Math.max(0.0F, Math.min(1.0F, factor));
        int a = color >>> 24 & 0xFF;
        int r = Math.round((float)(color >>> 16 & 0xFF) * f);
        int g = Math.round((float)(color >>> 8 & 0xFF) * f);
        int b = Math.round((float)(color & 0xFF) * f);
        return a << 24 | r << 16 | g << 8 | b;
    }

    private static void drawRoundedRectInternal(DrawContext context, float x, float y, float width, float height, float radius, int color, boolean allowShader) {
        if (!(width <= 0.0F) && !(height <= 0.0F)) {
            float clampedRadius = Math.max(0.0F, Math.min(radius, Math.min(width, height) * 0.5F));
            if (clampedRadius <= 0.0F) {
                fill(context, Math.round(x), Math.round(y), Math.round(x + width), Math.round(y + height), color);
            } else if (!allowShader
                || !RoundedRectShaderRenderer.shouldUseShader(width, height, clampedRadius, alpha(color))
                || !RoundedRectShaderRenderer.drawRoundedRect(context, x, y, width, height, clampedRadius, color)) {
                int left = Math.round(x);
                int top = Math.round(y);
                int right = Math.round(x + width);
                int bottom = Math.round(y + height);
                if (right > left && bottom > top) {
                    int rounded = Math.max(0, Math.min(Math.round(clampedRadius), Math.min((right - left) / 2, (bottom - top) / 2)));
                    if (rounded == 0) {
                        fill(context, left, top, right, bottom, color);
                    } else if (!shouldUseSmoothRoundedRect(right - left, bottom - top, rounded, alpha(color))
                        || !tryDrawSmoothRoundedRect(context, left, top, right, bottom, rounded, color)) {
                        if (shouldUseFastRoundedRect(right - left, bottom - top, rounded, alpha(color))) {
                            drawFastRoundedRect(context, left, top, right, bottom, rounded, color);
                        } else {
                            fill(context, left + rounded, top, right - rounded, bottom, color);
                            fill(context, left, top + rounded, right, bottom - rounded, color);
                            int[][] corner = getCornerAlpha(rounded);
                            int baseAlpha = alpha(color);
                            int rgb = color & 16777215;

                            for (int row = 0; row < rounded; row++) {
                                int yTop = top + row;
                                int yBottom = bottom - row - 1;
                                drawCornerRow(context, left, yTop, corner[row], false, rgb, baseAlpha);
                                drawCornerRow(context, right - rounded, yTop, corner[row], true, rgb, baseAlpha);
                                drawCornerRow(context, left, yBottom, corner[row], false, rgb, baseAlpha);
                                drawCornerRow(context, right - rounded, yBottom, corner[row], true, rgb, baseAlpha);
                            }
                        }
                    }
                }
            }
        }
    }

    public static void drawText(DrawContext context, TextRenderer textRenderer, String text, float x, float y, int color) {
        context.drawText(textRenderer, asUiText(text), Math.round(x), Math.round(y), color, false);
    }

    public static int getTextWidth(TextRenderer textRenderer, String text) {
        return textRenderer.getWidth(asUiText(text));
    }

    public static void drawGlassHudChip(DrawContext context, float x, float y, float width, float height, float radius, int fillArgb, int shadowRgb24) {
        drawSoftHudBloom(context, x, y, width, height, radius, shadowRgb24, 3, 40);
        int fillA = fillArgb >>> 24 & 0xFF;
        int haloA = Math.min(52, Math.max(12, fillA / 4));
        drawRoundedRect(context, x - 1.0F, y - 1.0F, width + 2.0F, height + 2.0F, radius + 1.0F, haloA << 24);
        drawRoundedRect(context, x, y, width, height, radius, fillArgb);
    }

    public static void drawGlassHudPanelBody(DrawContext context, float x, float y, float width, float height, float radius, int fillArgb, int shadowRgb24) {
        drawSoftHudBloom(context, x, y, width, height, radius, shadowRgb24, 4, 34);
        int fillA = fillArgb >>> 24 & 0xFF;
        int haloA = Math.min(48, Math.max(10, fillA / 6));
        drawRoundedRect(context, x - 1.0F, y - 1.0F, width + 2.0F, height + 2.0F, radius + 1.0F, haloA << 24);
        drawRoundedRect(context, x, y, width, height, radius, fillArgb);
    }

    private static void drawSoftHudBloom(
        DrawContext context, float x, float y, float width, float height, float radius, int shadowRgb24, int rings, int peakAlpha
    ) {
        int rgb = shadowRgb24 & 16777215;

        for (int s = rings; s >= 1; s--) {
            int a = Math.round((float)peakAlpha * (1.0F - (float)s / (float)(rings + 1)));
            if (a > 0) {
                drawRoundedRect(context, x - (float)s, y - (float)s, width + (float)(s * 2), height + (float)(s * 2), radius + (float)s, a << 24 | rgb);
            }
        }
    }

    public static void drawTextWithGlow(
        DrawContext context, TextRenderer textRenderer, String text, float x, float y, int textColor, int glowColor, int glowAlpha
    ) {
        Text renderedText = asUiText(text);
        if (glowAlpha > 0) {
            int base = glowColor & 16777215;
            int rx = Math.round(x);
            int ry = Math.round(y);
            int aCard = Math.round((float)glowAlpha * 0.26F);
            if (aCard > 0) {
                context.drawText(textRenderer, renderedText, rx - 1, ry, aCard << 24 | base, false);
                context.drawText(textRenderer, renderedText, rx + 1, ry, aCard << 24 | base, false);
                context.drawText(textRenderer, renderedText, rx, ry - 1, aCard << 24 | base, false);
                context.drawText(textRenderer, renderedText, rx, ry + 1, aCard << 24 | base, false);
            }

            int aDiag = Math.round((float)glowAlpha * 0.16F);
            if (aDiag > 0) {
                context.drawText(textRenderer, renderedText, rx - 1, ry - 1, aDiag << 24 | base, false);
                context.drawText(textRenderer, renderedText, rx + 1, ry - 1, aDiag << 24 | base, false);
                context.drawText(textRenderer, renderedText, rx - 1, ry + 1, aDiag << 24 | base, false);
                context.drawText(textRenderer, renderedText, rx + 1, ry + 1, aDiag << 24 | base, false);
            }

            int aFar = Math.round((float)glowAlpha * 0.09F);
            if (aFar > 0) {
                context.drawText(textRenderer, renderedText, rx - 2, ry, aFar << 24 | base, false);
                context.drawText(textRenderer, renderedText, rx + 2, ry, aFar << 24 | base, false);
                context.drawText(textRenderer, renderedText, rx, ry - 2, aFar << 24 | base, false);
                context.drawText(textRenderer, renderedText, rx, ry + 2, aFar << 24 | base, false);
            }
        }

        context.drawText(textRenderer, renderedText, Math.round(x), Math.round(y), textColor, false);
    }

    public static int mixColor(int from, int to, float progress) {
        float clamped = Math.max(0.0F, Math.min(1.0F, progress));
        int alpha = Math.round((float)alpha(from) + (float)(alpha(to) - alpha(from)) * clamped);
        int red = Math.round((float)red(from) + (float)(red(to) - red(from)) * clamped);
        int green = Math.round((float)green(from) + (float)(green(to) - green(from)) * clamped);
        int blue = Math.round((float)blue(from) + (float)(blue(to) - blue(from)) * clamped);
        return alpha << 24 | red << 16 | green << 8 | blue;
    }

    public static int withAlpha(int color, int alpha) {
        return (alpha & 0xFF) << 24 | color & 16777215;
    }

    private static void drawCornerRow(DrawContext context, int originX, int y, int[] rowAlpha, boolean mirror, int rgb, int baseAlpha) {
        int rowWidth = rowAlpha.length;
        int runStart = -1;
        int runAlpha = 0;

        for (int index = 0; index <= rowWidth; index++) {
            int maskAlpha = index < rowWidth ? rowAlpha[index] : -1;
            int pixelAlpha = maskAlpha <= 0 ? 0 : quantizeAlpha((baseAlpha * maskAlpha + 127) / 255);
            if (pixelAlpha == 0) {
                if (runStart >= 0) {
                    fillCornerRun(context, originX, y, runStart, index, rowWidth, mirror, runAlpha << 24 | rgb);
                    runStart = -1;
                }
            } else if (runStart < 0) {
                runStart = index;
                runAlpha = pixelAlpha;
            } else if (Math.abs(pixelAlpha - runAlpha) > 10) {
                fillCornerRun(context, originX, y, runStart, index, rowWidth, mirror, runAlpha << 24 | rgb);
                runStart = index;
                runAlpha = pixelAlpha;
            }
        }
    }

    private static void fillCornerRun(DrawContext context, int originX, int y, int start, int end, int rowWidth, boolean mirror, int color) {
        int left = mirror ? originX + (rowWidth - end) : originX + start;
        int right = mirror ? originX + (rowWidth - start) : originX + end;
        fill(context, left, y, right, y + 1, color);
    }

    private static int[][] getCornerAlpha(int radius) {
        return CORNER_ALPHA_CACHE.computeIfAbsent(radius, RenderUtil::buildCornerAlpha);
    }

    private static int[][] buildCornerAlpha(int radius) {
        int[][] alpha = new int[radius][radius];
        double radiusSquared = (double)(radius * radius);
        double sampleStride = 0.125;
        double sampleScale = 3.984375;

        for (int row = 0; row < radius; row++) {
            for (int column = 0; column < radius; column++) {
                int covered = 0;

                for (int sy = 0; sy < 8; sy++) {
                    double sampleY = (double)row + ((double)sy + 0.5) * sampleStride;
                    double distanceY = (double)radius - sampleY;

                    for (int sx = 0; sx < 8; sx++) {
                        double sampleX = (double)column + ((double)sx + 0.5) * sampleStride;
                        double distanceX = (double)radius - sampleX;
                        if (distanceX * distanceX + distanceY * distanceY <= radiusSquared) {
                            covered++;
                        }
                    }
                }

                alpha[row][column] = (int)Math.round((double)covered * sampleScale);
            }
        }

        return alpha;
    }

    private static boolean shouldUseFastRoundedRect(int width, int height, int radius, int alpha) {
        return alpha <= 48 || height <= 34 || radius <= 3;
    }

    private static boolean shouldUseSmoothRoundedRect(int width, int height, int radius, int alpha) {
        return alpha > 0 && radius >= 4 && width >= 8 && height >= 8;
    }

    private static boolean tryDrawGradientSmoothRoundedRect(
        DrawContext context, int left, int top, int right, int bottom, int radius, int colorTop, int colorBottom
    ) {
        if (context instanceof DrawContextAccessor accessor) {
            accessor.dargsclient$getState()
                .addSimpleElement(
                    new GradientRoundedRectGuiElementRenderState(
                        new Matrix3x2f(context.getMatrices()), left, top, right, bottom, radius, colorTop, colorBottom, getScissorArea(context)
                    )
                );
            return true;
        } else {
            return false;
        }
    }

    private static boolean tryDrawSmoothRoundedRect(DrawContext context, int left, int top, int right, int bottom, int radius, int color) {
        if (context instanceof DrawContextAccessor accessor) {
            accessor.dargsclient$getState()
                .addSimpleElement(
                    new SmoothRoundedRectGuiElementRenderState(
                        new Matrix3x2f(context.getMatrices()), left, top, right, bottom, radius, color, getScissorArea(context)
                    )
                );
            return true;
        } else {
            return false;
        }
    }

    private static void drawFastRoundedRect(DrawContext context, int left, int top, int right, int bottom, int radius, int color) {
        int[] insets = getCornerInsets(radius);
        fill(context, left, top + radius, right, bottom - radius, color);

        for (int row = 0; row < radius; row++) {
            int inset = insets[row];
            fill(context, left + inset, top + row, right - inset, top + row + 1, color);
            fill(context, left + inset, bottom - row - 1, right - inset, bottom - row, color);
        }
    }

    private static int[] getCornerInsets(int radius) {
        return CORNER_INSET_CACHE.computeIfAbsent(radius, RenderUtil::buildCornerInsets);
    }

    private static int[] buildCornerInsets(int radius) {
        int[] insets = new int[radius];
        double radiusSquared = (double)(radius * radius);

        for (int row = 0; row < radius; row++) {
            double distanceY = (double)(radius - row) - 0.5;
            double distanceX = Math.sqrt(Math.max(0.0, radiusSquared - distanceY * distanceY));
            insets[row] = Math.max(0, radius - (int)Math.ceil(distanceX));
        }

        return insets;
    }

    private static void fill(DrawContext context, int left, int top, int right, int bottom, int color) {
        if (right > left && bottom > top) {
            context.fill(left, top, right, bottom, color);
        }
    }

    private static int alpha(int color) {
        return color >> 24 & 0xFF;
    }

    private static int red(int color) {
        return color >> 16 & 0xFF;
    }

    private static int green(int color) {
        return color >> 8 & 0xFF;
    }

    private static int blue(int color) {
        return color & 0xFF;
    }

    private static int quantizeAlpha(int alpha) {
        if (alpha <= 6) {
            return 0;
        } else if (alpha >= 249) {
            return 255;
        } else {
            float step = 21.25F;
            return Math.max(0, Math.min(255, Math.round((float)Math.round((float)alpha / step) * step)));
        }
    }

    private static Text asUiText(String text) {
        return Text.literal(text).setStyle(UI_FONT_STYLE);
    }

    private static Field resolveScissorStackField() {
        try {
            Field field = DrawContext.class.getDeclaredField("scissorStack");
            field.setAccessible(true);
            return field;
        } catch (ReflectiveOperationException var1) {
            return null;
        }
    }

    private static Method resolveScissorPeekLastMethod() {
        try {
            Class<?> scissorStackClass = Class.forName("net.minecraft.client.gui.DrawContext$ScissorStack");
            Method method = scissorStackClass.getDeclaredMethod("peekLast");
            method.setAccessible(true);
            return method;
        } catch (ReflectiveOperationException var2) {
            return null;
        }
    }

    private static ScreenRect getScissorArea(DrawContext context) {
        if (DRAW_CONTEXT_SCISSOR_STACK_FIELD != null && SCISSOR_STACK_PEEK_LAST_METHOD != null) {
            try {
                Object scissorStack = DRAW_CONTEXT_SCISSOR_STACK_FIELD.get(context);
                return scissorStack == null ? null : (ScreenRect)SCISSOR_STACK_PEEK_LAST_METHOD.invoke(scissorStack);
            } catch (ReflectiveOperationException var2) {
                return null;
            }
        } else {
            return null;
        }
    }
}
