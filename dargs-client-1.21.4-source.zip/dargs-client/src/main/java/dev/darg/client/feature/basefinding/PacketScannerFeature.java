package dev.darg.client.feature.basefinding;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.feature.combat.CombatFeatureHooks;
import dev.darg.client.mixin.RenderLayerInvoker;
import dev.darg.client.render.WorldRenderUtil;
import it.unimi.dsi.fastutil.ints.IntListIterator;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentLinkedDeque;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.OutputTarget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockBreakingProgressS2CPacket;
import net.minecraft.network.packet.s2c.play.BlockEventS2CPacket;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDeltaUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.DeathMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.EntitiesDestroyS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityAnimationS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityEquipmentUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundFromEntityS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.network.packet.s2c.play.WorldEventS2CPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;

public final class PacketScannerFeature extends Feature implements CombatFeatureHooks.PacketReceiveHook {
    private static final int[] EVENT_WEIGHTS;
    private static final int MAX_EVENTS = 500;
    private static final int MAX_RENDERED = 300;
    private static final int HUD_MAX_LINES = 12;
    private static final double HUD_RANGE_SQ = 16384.0;
    private static final int CLUSTER_INTERVAL = 40;
    private static final double BASE_MIN_SCORE = 5.0;
    private static final int MAX_BASES = 10;
    private static final float BOX_LINE_WIDTH = 1.5F;
    private static final float PILLAR_LINE_WIDTH = 2.0F;
    private static final float TRACER_LINE_WIDTH = 1.5F;
    private static final float TRACER_OFFSET = 0.15F;
    private static final int PILLAR_COLOR = -22016;
    private static final int TRACER_COLOR = -1426085376;
    private static final int HUD_BG_COLOR = -1442840576;
    private static final int HUD_BG_DRAG_COLOR = -870704594;
    private static final int HUD_HEADER_COLOR = -1;
    private static final int HUD_PANEL_W = 220;
    private static final int BASES_PANEL_W = 240;
    private static volatile RenderLayer noDepthLineLayer;
    private final ConcurrentLinkedDeque<PacketScannerFeature.ScanEvent> events = new ConcurrentLinkedDeque<>();
    private long gameTick = 0L;
    private int clusterTick = 0;
    private volatile List<PacketScannerFeature.SuspectedBase> suspectedBases = List.of();
    private int hudX = 4;
    private int hudY = 4;
    private boolean dragging = false;
    private int dragOffsetX = 0;
    private int dragOffsetY = 0;
    private int basesHudX = 230;
    private int basesHudY = 4;
    private boolean draggingBases = false;
    private int dragBasesOffX = 0;
    private int dragBasesOffY = 0;

    private static RenderLayer getNoDepthLineLayer() {
        RenderLayer layer = noDepthLineLayer;
        if (layer != null) {
            return layer;
        } else {
            synchronized (PacketScannerFeature.class) {
                if (noDepthLineLayer == null) {
                    noDepthLineLayer = RenderLayerInvoker.dargsclient$invokeOf(
                        "dargsclient_pktscanner_lines",
                        RenderSetup.builder(
                                RenderPipelines.register(
                                    RenderPipeline.builder(new Snippet[]{RenderPipelines.RENDERTYPE_LINES_SNIPPET})
                                        .withLocation("pipeline/dargsclient_pktscanner_lines")
                                        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                                        .withDepthWrite(false)
                                        .build()
                                )
                            )
                            .layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
                            .outputTarget(OutputTarget.ITEM_ENTITY_TARGET)
                            .build()
                    );
                }

                return noDepthLineLayer;
            }
        }
    }

    public PacketScannerFeature() {
        super("Packet Scanner", Category.BASEFINDING);
    }

    @Override
    protected void onEnable() {
        this.events.clear();
        this.suspectedBases = List.of();
        this.gameTick = 0L;
        this.clusterTick = 0;
    }

    @Override
    protected void onDisable() {
        this.events.clear();
        this.suspectedBases = List.of();
    }

    @Override
    public void onTick() {
        this.gameTick++;
        this.events.removeIf(e -> this.gameTick - e.tick > (long)e.type.expiryTicks);
        if (++this.clusterTick >= 40) {
            this.clusterTick = 0;
            this.recalcBases();
        }
    }

    @Override
    public void onReceivePacket(MinecraftClient client, Packet<?> packet) {
        if (client.world != null && client.player != null) {
            int localId = client.player.getId();
            if (packet instanceof EntitySpawnS2CPacket p) {
                double y = p.getY();
                EntityType<?> type = p.getEntityType();
                String name = EntityType.getId(type).getPath();
                String category;
                if (type == EntityType.PLAYER) {
                    category = "Player";
                } else if (type == EntityType.TNT) {
                    category = "Primed TNT";
                } else if (type == EntityType.ARROW || type == EntityType.TRIDENT || type == EntityType.SPECTRAL_ARROW) {
                    category = "Projectile";
                } else if (type == EntityType.ITEM) {
                    category = "Dropped Item";
                } else if (type == EntityType.FALLING_BLOCK) {
                    category = "Falling Block";
                } else {
                    if (type != EntityType.FIREBALL && type != EntityType.SMALL_FIREBALL) {
                        return;
                    }

                    category = "Fireball";
                }

                PacketScannerFeature.EventType evType = type == EntityType.PLAYER
                    ? PacketScannerFeature.EventType.PLAYER_SPOTTED
                    : PacketScannerFeature.EventType.ENTITY_SPAWN;
                this.record(
                    new Vec3d(p.getX(), y, p.getZ()),
                    evType,
                    category + " (" + name + ") spawned at " + fmt(p.getX(), y, p.getZ())
                );
            } else if (packet instanceof EntityStatusS2CPacket p) {
                Entity entity = p.getEntity(client.world);
                if (entity == null || entity.getId() == localId) {
                    return;
                }

                byte status = p.getStatus();
                if (status == 3) {
                    String name = entityName(entity);
                    this.record(
                        new Vec3d(entity.getX(), entity.getY(), entity.getZ()),
                        PacketScannerFeature.EventType.DEATH,
                        name + " died at " + fmt(entity.getX(), entity.getY(), entity.getZ())
                    );
                } else if (status == 35) {
                    String name = entityName(entity);
                    this.record(
                        new Vec3d(entity.getX(), entity.getY(), entity.getZ()),
                        PacketScannerFeature.EventType.TOTEM_POP,
                        name + " popped totem at " + fmt(entity.getX(), entity.getY(), entity.getZ())
                    );
                }
            } else if (packet instanceof EntityAnimationS2CPacket p) {
                Entity entityx = client.world.getEntityById(p.getEntityId());
                if (entityx == null || entityx.getId() == localId) {
                    return;
                }

                int anim = p.getAnimationId();
                if (anim == 0 || anim == 3 || anim == 4 || anim == 5) {
                    String animName = switch (anim) {
                        case 0 -> "main hand swing";
                        default -> "anim " + anim;
                        case 3 -> "offhand swing";
                        case 4 -> "crit";
                        case 5 -> "magic crit";
                    };
                    this.record(
                        new Vec3d(entityx.getX(), entityx.getY(), entityx.getZ()),
                        PacketScannerFeature.EventType.SWING,
                        entityName(entityx) + " " + animName + " at " + fmt(entityx.getX(), entityx.getY(), entityx.getZ())
                    );
                }
            } else if (packet instanceof EntityEquipmentUpdateS2CPacket p) {
                Entity entityxx = client.world.getEntityById(p.getEntityId());
                if (entityxx == null || entityxx.getId() == localId) {
                    return;
                }

                this.record(
                    new Vec3d(entityxx.getX(), entityxx.getY(), entityxx.getZ()),
                    PacketScannerFeature.EventType.EQUIPMENT,
                    entityName(entityxx) + " equipment changed at " + fmt(entityxx.getX(), entityxx.getY(), entityxx.getZ())
                );
            } else if (packet instanceof EntityDamageS2CPacket p) {
                Entity entityxx = client.world.getEntityById(p.entityId());
                if (entityxx == null || entityxx.getId() == localId) {
                    return;
                }

                String dmgType = p.sourceType().getKey().map(k -> k.getValue().getPath()).orElse("unknown");
                this.record(
                    new Vec3d(entityxx.getX(), entityxx.getY(), entityxx.getZ()),
                    PacketScannerFeature.EventType.ENTITY_HURT,
                    entityName(entityxx) + " damaged (" + dmgType + ") at " + fmt(entityxx.getX(), entityxx.getY(), entityxx.getZ())
                );
            } else if (packet instanceof EntityVelocityUpdateS2CPacket p) {
                Entity entityxx = client.world.getEntityById(p.getEntityId());
                if (entityxx == null || entityxx.getId() == localId) {
                    return;
                }

                Vec3d vel = p.getVelocity();
                double speed = Math.sqrt(vel.x * vel.x + vel.y * vel.y + vel.z * vel.z);
                if (speed < 0.3) {
                    return;
                }

                this.record(
                    new Vec3d(entityxx.getX(), entityxx.getY(), entityxx.getZ()),
                    PacketScannerFeature.EventType.KNOCKBACK,
                    entityName(entityxx)
                        + " knockback (v="
                        + String.format("%.2f", speed)
                        + ") at "
                        + fmt(entityxx.getX(), entityxx.getY(), entityxx.getZ())
                );
            } else if (packet instanceof EntitiesDestroyS2CPacket p) {
                IntListIterator var32 = p.getEntityIds().iterator();

                while (var32.hasNext()) {
                    int id = (Integer)var32.next();
                    if (id != localId) {
                        Entity entityxxx = client.world.getEntityById(id);
                        if (entityxxx instanceof PlayerEntity || entityxxx instanceof LivingEntity) {
                            this.record(
                                new Vec3d(entityxxx.getX(), entityxxx.getY(), entityxxx.getZ()),
                                PacketScannerFeature.EventType.ENTITY_REMOVED,
                                entityName(entityxxx)
                                    + " removed/despawned at "
                                    + fmt(entityxxx.getX(), entityxxx.getY(), entityxxx.getZ())
                            );
                        }
                    }
                }
            } else if (packet instanceof BlockUpdateS2CPacket p) {
                BlockPos pos = p.getPos();
                Block newBlock = p.getState().getBlock();
                if (newBlock != Blocks.AIR && newBlock != Blocks.CAVE_AIR) {
                    this.record(Vec3d.ofCenter(pos), PacketScannerFeature.EventType.BLOCK_PLACED, blockName(newBlock) + " placed at " + fmtPos(pos));
                } else {
                    this.record(Vec3d.ofCenter(pos), PacketScannerFeature.EventType.BLOCK_BROKEN, "Block removed at " + fmtPos(pos));
                }
            } else if (packet instanceof ChunkDeltaUpdateS2CPacket px) {
                Mutable lowestPos = new Mutable(0, Integer.MAX_VALUE, 0);
                int[] count = new int[]{0};
                px.visitUpdates((pos, state) -> {
                    count[0]++;
                    if (pos.getY() < lowestPos.getY()) {
                        lowestPos.set(pos.getX(), pos.getY(), pos.getZ());
                    }
                });
                if (count[0] > 0) {
                    this.record(
                        Vec3d.ofCenter(lowestPos), PacketScannerFeature.EventType.CHUNK_DELTA, count[0] + " blocks changed near " + fmtPos(lowestPos)
                    );
                }
            } else if (packet instanceof BlockBreakingProgressS2CPacket pxx) {
                BlockPos pos = pxx.getPos();
                if (pxx.getEntityId() == localId) {
                    return;
                }

                this.record(Vec3d.ofCenter(pos), PacketScannerFeature.EventType.MINING, "Mining at " + fmtPos(pos) + " (stage " + pxx.getProgress() + ")");
            } else if (packet instanceof BlockEventS2CPacket pxx) {
                BlockPos pos = pxx.getPos();
                if (pxx.getType() == 1 && pxx.getData() > 0) {
                    Block block = client.world.getBlockState(pos).getBlock();
                    this.record(
                        Vec3d.ofCenter(pos),
                        PacketScannerFeature.EventType.CHEST_OPEN,
                        blockName(block) + " opened at " + fmtPos(pos) + " (" + pxx.getData() + " viewer(s))"
                    );
                }
            } else if (packet instanceof ExplosionS2CPacket pxxx) {
                Vec3d center = pxxx.center();
                this.record(center, PacketScannerFeature.EventType.EXPLOSION, "Explosion at " + fmt(center));
            } else if (packet instanceof WorldEventS2CPacket pxxx) {
                BlockPos pos = pxxx.getPos();
                int eventId = pxxx.getEventId();

                String evName = switch (eventId) {
                    case 1005 -> "Record Play (1005)";
                    case 1010 -> "Record Stop (1010)";
                    case 2001 -> "Block Break (2001)";
                    case 2002 -> "Splash Potion (2002)";
                    default -> "World Event " + eventId;
                };
                this.record(Vec3d.ofCenter(pos), PacketScannerFeature.EventType.WORLD_EVENT, evName + " at " + fmtPos(pos));
            } else if (packet instanceof PlaySoundS2CPacket pxxx) {
                double y = pxxx.getY();
                RegistryEntry<SoundEvent> soundEntry = pxxx.getSound();
                String soundId = soundEntry.getKey().map(k -> k.getValue().getPath()).orElse("unknown");
                if (!isSuspiciousSound(soundId)) {
                    return;
                }

                this.record(
                    new Vec3d(pxxx.getX(), y, pxxx.getZ()),
                    PacketScannerFeature.EventType.SOUND,
                    "Sound: " + soundId + " at " + fmt(pxxx.getX(), y, pxxx.getZ())
                );
            } else if (packet instanceof PlaySoundFromEntityS2CPacket pxxx) {
                Entity entityxxx = client.world.getEntityById(pxxx.getEntityId());
                if (entityxxx == null || entityxxx.getId() == localId) {
                    return;
                }

                RegistryEntry<SoundEvent> soundEntry = pxxx.getSound();
                String soundId = soundEntry.getKey().map(k -> k.getValue().getPath()).orElse("unknown");
                if (!isSuspiciousSound(soundId)) {
                    return;
                }

                this.record(
                    new Vec3d(entityxxx.getX(), entityxxx.getY(), entityxxx.getZ()),
                    PacketScannerFeature.EventType.SOUND_ENTITY,
                    entityName(entityxxx) + " sound: " + soundId + " at " + fmt(entityxxx.getX(), entityxxx.getY(), entityxxx.getZ())
                );
            } else if (packet instanceof DeathMessageS2CPacket pxxx) {
                this.record(Vec3d.ZERO, PacketScannerFeature.EventType.DEATH_MSG, "Death message: " + pxxx.message().getString());
            } else if (packet instanceof GameMessageS2CPacket pxxx) {
                String msg = pxxx.content().getString();
                if (isDeath(msg)) {
                    this.record(Vec3d.ZERO, PacketScannerFeature.EventType.DEATH_MSG, "Death msg: " + msg);
                }
            }
        }
    }

    private static boolean isSuspiciousSound(String id) {
        return id.contains("player.hurt")
            || id.contains("player.death")
            || id.contains("player.levelup")
            || id.contains("experience_orb.pickup")
            || id.contains("chest.open")
            || id.contains("barrel.open")
            || id.contains("shulker_box.open")
            || id.contains("anvil.use")
            || id.contains("anvil.land")
            || id.contains("enchantment_table.use")
            || id.contains("tnt.primed")
            || id.contains("generic.explode")
            || id.contains("totem")
            || id.contains("respawn_anchor");
    }

    private static boolean isDeath(String msg) {
        String lower = msg.toLowerCase();
        return lower.contains(" was ")
            || lower.contains(" died")
            || lower.contains("drowned")
            || lower.contains("fell")
            || lower.contains("slain")
            || lower.contains("blew up")
            || lower.contains("burned")
            || lower.contains("froze")
            || lower.contains("starved")
            || lower.contains("withered");
    }

    private void record(Vec3d pos, PacketScannerFeature.EventType type, String detail) {
        if (this.events.size() >= 500) {
            this.events.pollFirst();
        }

        this.events.addLast(new PacketScannerFeature.ScanEvent(pos, type, detail, this.gameTick));
    }

    private void recalcBases() {
        List<PacketScannerFeature.ScanEvent> snapshot = new ArrayList<>(this.events);
        if (snapshot.isEmpty()) {
            this.suspectedBases = List.of();
        } else {
            HashMap<Long, double[]> raw = new HashMap<>();

            for (PacketScannerFeature.ScanEvent e : snapshot) {
                if (!e.pos.equals(Vec3d.ZERO)) {
                    int weight = EVENT_WEIGHTS[e.type.ordinal()];
                    if (weight != 0) {
                        int cx = (int)Math.floor(e.pos.x / 16.0);
                        int cz = (int)Math.floor(e.pos.z / 16.0);
                        long key = (long)cx << 32 | (long)cz & 4294967295L;
                        long age = this.gameTick - e.tick;
                        double halfLife = (double)e.type.expiryTicks * 0.5;
                        double decay = Math.pow(0.5, (double)age / halfLife);
                        double contribution = (double)weight * decay;
                        double[] cell = raw.computeIfAbsent(key, kx -> new double[]{0.0, 0.0, 0.0});
                        cell[0] += contribution;
                        cell[1]++;
                        if (e.tick > (long)cell[2]) {
                            cell[2] = (double)e.tick;
                        }
                    }
                }
            }

            if (raw.isEmpty()) {
                this.suspectedBases = List.of();
            } else {
                HashMap<Long, double[]> blended = new HashMap<>(raw.size() * 9);

                for (Entry<Long, double[]> entry : raw.entrySet()) {
                    blended.computeIfAbsent(entry.getKey(), kx -> new double[]{0.0, 0.0, 0.0})[0] += ((double[])entry.getValue())[0];
                }

                for (Entry<Long, double[]> entry : raw.entrySet()) {
                    long k = entry.getKey();
                    int cx = (int)(k >> 32);
                    int cz = (int)(k & 4294967295L);
                    double spread = entry.getValue()[0] * 0.1;

                    for (int dx = -1; dx <= 1; dx++) {
                        for (int dz = -1; dz <= 1; dz++) {
                            if (dx != 0 || dz != 0) {
                                long nk = (long)(cx + dx) << 32 | (long)(cz + dz) & 4294967295L;
                                blended.computeIfAbsent(nk, x -> new double[]{0.0, 0.0, 0.0})[0] += spread;
                            }
                        }
                    }
                }

                List<PacketScannerFeature.SuspectedBase> list = new ArrayList<>();

                for (Entry<Long, double[]> entry : blended.entrySet()) {
                    double blendedScore = entry.getValue()[0];
                    if (!(blendedScore < 5.0)) {
                        long k = entry.getKey();
                        int cx = (int)(k >> 32);
                        int cz = (int)(k & 4294967295L);
                        double[] rawCell = raw.getOrDefault(k, new double[]{0.0, 0.0, 0.0});
                        list.add(new PacketScannerFeature.SuspectedBase(cx, cz, blendedScore, (int)rawCell[1], (long)rawCell[2]));
                    }
                }

                list.sort((a, b) -> Double.compare(b.score, a.score));
                if (list.size() > 10) {
                    list = list.subList(0, 10);
                }

                this.suspectedBases = List.copyOf(list);
            }
        }
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world != null && client.player != null) {
            MatrixStack matrices = context.matrices();
            VertexConsumerProvider consumers = context.consumers();
            if (matrices != null && consumers != null) {
                Vec3d cam = client.gameRenderer.getCamera().getCameraPos();
                float tickDelta = client.getRenderTickCounter().getTickProgress(false);
                Vec3d tracerOrigin = WorldRenderUtil.getTracerStart(client.gameRenderer.getCamera(), tickDelta, 0.15F);
                double px = client.player.getX();
                double py = client.player.getY();
                double pz = client.player.getZ();
                matrices.push();

                try {
                    net.minecraft.client.util.math.MatrixStack.Entry entry = matrices.peek();
                    VertexConsumer buf = consumers.getBuffer(getNoDepthLineLayer());
                    if (!this.events.isEmpty()) {
                        List<PacketScannerFeature.ScanEvent> snapshot = new ArrayList<>(this.events);
                        snapshot.sort(Comparator.comparingDouble(ex -> {
                            double dx = ex.pos.x - px;
                            double dy = ex.pos.y - py;
                            double dz = ex.pos.z - pz;
                            return dx * dx + dy * dy + dz * dz;
                        }));
                        int rendered = 0;

                        for (PacketScannerFeature.ScanEvent e : snapshot) {
                            if (rendered >= 300) {
                                break;
                            }

                            if (!e.pos.equals(Vec3d.ZERO)) {
                                float minX = (float)(e.pos.x - 0.5 - cam.x);
                                float minY = (float)(e.pos.y - 0.5 - cam.y);
                                float minZ = (float)(e.pos.z - 0.5 - cam.z);
                                WorldRenderUtil.drawWireBox(entry, buf, minX, minY, minZ, minX + 1.0F, minY + 1.0F, minZ + 1.0F, e.type.color, 1.5F);
                                rendered++;
                            }
                        }
                    }

                    for (PacketScannerFeature.SuspectedBase base : this.suspectedBases) {
                        this.drawBasePillar(entry, buf, base, cam, tracerOrigin);
                    }
                } finally {
                    matrices.pop();
                }
            }
        }
    }

    private void drawBasePillar(
        net.minecraft.client.util.math.MatrixStack.Entry entry, VertexConsumer buf, PacketScannerFeature.SuspectedBase base, Vec3d cam, Vec3d tracerOrigin
    ) {
        float minX = (float)((double)base.chunkX * 16.0 - cam.x);
        float minZ = (float)((double)base.chunkZ * 16.0 - cam.z);
        float maxX = minX + 16.0F;
        float maxZ = minZ + 16.0F;
        float minY = (float)(-64.0 - cam.y);
        float maxY = (float)(320.0 - cam.y);
        WorldRenderUtil.drawWireBox(entry, buf, minX, minY, minZ, maxX, maxY, maxZ, -22016, 2.0F);
        float centerX = minX + 8.0F;
        float centerZ = minZ + 8.0F;
        float centerY = (float)(64.0 - cam.y);
        WorldRenderUtil.drawLine(entry, buf, tracerOrigin, new Vec3d((double)centerX, (double)centerY, (double)centerZ), -1426085376, 1.5F);
    }

    @Override
    public void onHudRender(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            List<PacketScannerFeature.ScanEvent> nearby = this.nearbyEvents(client);
            if (!nearby.isEmpty()) {
                this.drawEventsPanel(ctx, client.textRenderer, nearby, this.hudX, this.hudY, false);
            }

            List<PacketScannerFeature.SuspectedBase> bases = this.suspectedBases;
            if (!bases.isEmpty()) {
                this.drawBasesPanel(ctx, client.textRenderer, bases, this.basesHudX, this.basesHudY, false);
            }
        }
    }

    @Override
    public void onClickGuiRender(DrawContext ctx, int mouseX, int mouseY, float delta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            if (this.dragging) {
                this.hudX = mouseX - this.dragOffsetX;
                this.hudY = mouseY - this.dragOffsetY;
                this.clampEventsPanel(client);
            }

            if (this.draggingBases) {
                this.basesHudX = mouseX - this.dragBasesOffX;
                this.basesHudY = mouseY - this.dragBasesOffY;
                this.clampBasesPanel(client);
            }

            List<PacketScannerFeature.ScanEvent> nearby = this.nearbyEvents(client);
            if (!nearby.isEmpty()) {
                boolean hov = this.dragging || this.isHoveredEvents(mouseX, mouseY, client.textRenderer, nearby);
                this.drawEventsPanel(ctx, client.textRenderer, nearby, this.hudX, this.hudY, hov);
            }

            List<PacketScannerFeature.SuspectedBase> bases = this.suspectedBases;
            if (!bases.isEmpty()) {
                boolean hov = this.draggingBases || this.isHoveredBases(mouseX, mouseY, client.textRenderer, bases);
                this.drawBasesPanel(ctx, client.textRenderer, bases, this.basesHudX, this.basesHudY, hov);
            }
        }
    }

    @Override
    public boolean onClickGuiMouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return false;
        } else {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null && client.player != null) {
                List<PacketScannerFeature.ScanEvent> nearby = this.nearbyEvents(client);
                if (!nearby.isEmpty()) {
                    int ph = this.eventsPanelHeight(client.textRenderer, nearby);
                    if (mouseX >= (double)this.hudX && mouseX <= (double)(this.hudX + 220) && mouseY >= (double)this.hudY && mouseY <= (double)(this.hudY + ph)
                        )
                     {
                        this.dragging = true;
                        this.dragOffsetX = (int)mouseX - this.hudX;
                        this.dragOffsetY = (int)mouseY - this.hudY;
                        return true;
                    }
                }

                List<PacketScannerFeature.SuspectedBase> bases = this.suspectedBases;
                if (!bases.isEmpty()) {
                    int bh = this.basesPanelHeight(client.textRenderer, bases);
                    if (mouseX >= (double)this.basesHudX
                        && mouseX <= (double)(this.basesHudX + 240)
                        && mouseY >= (double)this.basesHudY
                        && mouseY <= (double)(this.basesHudY + bh)) {
                        this.draggingBases = true;
                        this.dragBasesOffX = (int)mouseX - this.basesHudX;
                        this.dragBasesOffY = (int)mouseY - this.basesHudY;
                        return true;
                    }
                }

                return false;
            } else {
                return false;
            }
        }
    }

    @Override
    public boolean onClickGuiMouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            if (this.dragging) {
                this.dragging = false;
                return true;
            }

            if (this.draggingBases) {
                this.draggingBases = false;
                return true;
            }
        }

        return false;
    }

    private List<PacketScannerFeature.ScanEvent> nearbyEvents(MinecraftClient client) {
        if (!this.events.isEmpty() && client.player != null) {
            double px = client.player.getX();
            double py = client.player.getY();
            double pz = client.player.getZ();
            List<PacketScannerFeature.ScanEvent> nearby = new ArrayList<>();

            for (PacketScannerFeature.ScanEvent e : this.events) {
                if (e.pos.equals(Vec3d.ZERO)) {
                    nearby.add(e);
                } else {
                    double dx = e.pos.x - px;
                    double dy = e.pos.y - py;
                    double dz = e.pos.z - pz;
                    if (dx * dx + dy * dy + dz * dz <= 16384.0) {
                        nearby.add(e);
                    }
                }
            }

            nearby.sort((a, b) -> Long.compare(b.tick, a.tick));
            if (nearby.size() > 12) {
                nearby = nearby.subList(0, 12);
            }

            return nearby;
        } else {
            return List.of();
        }
    }

    private int eventsPanelHeight(TextRenderer tr, List<PacketScannerFeature.ScanEvent> nearby) {
        int lineH = 9 + 2;
        return lineH + nearby.size() * lineH + 4;
    }

    private boolean isHoveredEvents(int mx, int my, TextRenderer tr, List<PacketScannerFeature.ScanEvent> nearby) {
        int h = this.eventsPanelHeight(tr, nearby);
        return mx >= this.hudX && mx <= this.hudX + 220 && my >= this.hudY && my <= this.hudY + h;
    }

    private void clampEventsPanel(MinecraftClient client) {
        if (client.getWindow() != null) {
            int sw = client.getWindow().getScaledWidth();
            int sh = client.getWindow().getScaledHeight();
            this.hudX = Math.max(0, Math.min(this.hudX, sw - 220));
            this.hudY = Math.max(0, Math.min(this.hudY, sh - 20));
        }
    }

    private void drawEventsPanel(DrawContext ctx, TextRenderer tr, List<PacketScannerFeature.ScanEvent> nearby, int x0, int y0, boolean highlighted) {
        int lineH = 9 + 2;
        int panelH = this.eventsPanelHeight(tr, nearby);
        int bg = highlighted ? -870704594 : -1442840576;
        ctx.fill(x0, y0, x0 + 220, y0 + panelH, bg);
        if (highlighted) {
            ctx.fill(x0, y0, x0 + 220, y0 + lineH + 2, 1442840575);
        }

        ctx.drawText(tr, "§fPacket Scanner §7(" + this.events.size() + ")", x0 + 3, y0 + 2, -1, false);
        int y = y0 + lineH + 2;

        for (PacketScannerFeature.ScanEvent e : nearby) {
            long ageSeconds = (this.gameTick - e.tick) / 20L;
            String line = "§7[" + ageSeconds + "s] " + colorTag(e.type) + e.type.label + " §7- " + e.detail;
            if (tr.getWidth(line) > 214) {
                line = line.substring(0, Math.min(line.length(), 40)) + "…";
            }

            ctx.drawText(tr, line, x0 + 3, y, -1, false);
            y += lineH;
        }
    }

    private int basesPanelHeight(TextRenderer tr, List<PacketScannerFeature.SuspectedBase> bases) {
        int lineH = 9 + 2;
        return lineH + bases.size() * (lineH + 1) + 4;
    }

    private boolean isHoveredBases(int mx, int my, TextRenderer tr, List<PacketScannerFeature.SuspectedBase> bases) {
        int h = this.basesPanelHeight(tr, bases);
        return mx >= this.basesHudX && mx <= this.basesHudX + 240 && my >= this.basesHudY && my <= this.basesHudY + h;
    }

    private void clampBasesPanel(MinecraftClient client) {
        if (client.getWindow() != null) {
            int sw = client.getWindow().getScaledWidth();
            int sh = client.getWindow().getScaledHeight();
            this.basesHudX = Math.max(0, Math.min(this.basesHudX, sw - 240));
            this.basesHudY = Math.max(0, Math.min(this.basesHudY, sh - 20));
        }
    }

    private void drawBasesPanel(DrawContext ctx, TextRenderer tr, List<PacketScannerFeature.SuspectedBase> bases, int x0, int y0, boolean highlighted) {
        int lineH = 9 + 2;
        int panelH = this.basesPanelHeight(tr, bases);
        int bg = highlighted ? -870704594 : -1442840576;
        ctx.fill(x0, y0, x0 + 240, y0 + panelH, bg);
        if (highlighted) {
            ctx.fill(x0, y0, x0 + 240, y0 + lineH + 2, 1442840575);
        }

        ctx.drawText(tr, "§6Suspected Bases §7(" + bases.size() + ")", x0 + 3, y0 + 2, -1, false);
        int y = y0 + lineH + 2;
        int rank = 1;

        for (PacketScannerFeature.SuspectedBase b : bases) {
            long ageS = (this.gameTick - b.lastSeenTick) / 20L;
            int blockX = b.chunkX * 16 + 8;
            int blockZ = b.chunkZ * 16 + 8;
            String line = "§e#"
                + rank
                + " §f["
                + blockX
                + ", "
                + blockZ
                + "] §7score:"
                + String.format("%.0f", b.score)
                + " ev:"
                + b.eventCount
                + " §8"
                + ageS
                + "s ago";
            if (tr.getWidth(line) > 234) {
                line = "§e#" + rank + " §f" + blockX + "," + blockZ + " §7s:" + String.format("%.0f", b.score) + " §8" + ageS + "s";
            }

            ctx.drawText(tr, line, x0 + 3, y, -1, false);
            y += lineH + 1;
            rank++;
        }
    }

    private static String colorTag(PacketScannerFeature.EventType type) {
        int r = type.color >> 16 & 0xFF;
        int g = type.color >> 8 & 0xFF;
        int b = type.color & 0xFF;
        if (r > 200 && g < 100) {
            return "§c";
        } else if (r > 200 && g > 150 && b < 50) {
            return "§e";
        } else if (r > 200 && g > 80 && b < 80) {
            return "§6";
        } else if (b > 200 && r < 100) {
            return "§b";
        } else if (b > 200 && r > 100) {
            return "§d";
        } else {
            return g > 200 && r < 100 ? "§a" : "§f";
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        int[] counts = new int[PacketScannerFeature.EventType.values().length];

        for (PacketScannerFeature.ScanEvent e : this.events) {
            counts[e.type.ordinal()]++;
        }

        List<String> lines = new ArrayList<>();
        lines.add("State: " + (this.isEnabled() ? "Enabled" : "Disabled"));
        lines.add("Total events: " + this.events.size() + " / 500");
        lines.add("Suspected bases: " + this.suspectedBases.size());

        for (PacketScannerFeature.EventType t : PacketScannerFeature.EventType.values()) {
            if (counts[t.ordinal()] > 0) {
                lines.add(t.label + ": " + counts[t.ordinal()]);
            }
        }

        return lines;
    }

    private static String fmt(double x, double y, double z) {
        return (int)x + ", " + (int)y + ", " + (int)z;
    }

    private static String fmt(Vec3d pos) {
        return fmt(pos.x, pos.y, pos.z);
    }

    private static String fmtPos(BlockPos p) {
        return p.getX() + ", " + p.getY() + ", " + p.getZ();
    }

    private static String entityName(Entity e) {
        return e.getType().getName().getString();
    }

    private static String blockName(Block b) {
        return b.getName().getString();
    }

    static {
        PacketScannerFeature.EventType[] types = PacketScannerFeature.EventType.values();
        EVENT_WEIGHTS = new int[types.length];

        for (PacketScannerFeature.EventType t : types) {
            EVENT_WEIGHTS[t.ordinal()] = switch (t) {
                case PLAYER_SPOTTED -> 15;
                case DEATH -> 25;
                case TOTEM_POP -> 30;
                case ENTITY_HURT -> 3;
                case SWING -> 2;
                case ENTITY_SPAWN -> 4;
                case ENTITY_REMOVED -> 3;
                case KNOCKBACK -> 3;
                case EQUIPMENT -> 6;
                case BLOCK_PLACED -> 12;
                case BLOCK_BROKEN -> 10;
                case MINING -> 5;
                case CHUNK_DELTA -> 8;
                case CHEST_OPEN -> 20;
                case EXPLOSION -> 18;
                case SOUND -> 2;
                case SOUND_ENTITY -> 2;
                case WORLD_EVENT -> 1;
                case DEATH_MSG -> 20;
            };
        }
    }

    public static enum EventType {
        PLAYER_SPOTTED(-855690445, "Player Spotted", 600),
        DEATH(-855703552, "Death", 4800),
        TOTEM_POP(-855681792, "Totem Pop", 4800),
        ENTITY_HURT(-855664384, "Entity Hurt", 200),
        SWING(-855651328, "Swing/Attack", 200),
        ENTITY_SPAWN(-861273857, "Entity Spawned", 800),
        ENTITY_REMOVED(-865730424, "Entity Removed", 400),
        KNOCKBACK(-855638272, "Knockback", 200),
        EQUIPMENT(-872362753, "Equipment Change", 600),
        BLOCK_PLACED(-872371457, "Block Placed", 9000),
        BLOCK_BROKEN(-872349748, "Block Broken", 9000),
        MINING(-867893368, "Mining", 300),
        CHUNK_DELTA(-872380161, "Multi-Block Change", 4800),
        CHEST_OPEN(-855646976, "Chest Opened", 4800),
        EXPLOSION(-855686144, "Explosion", 9000),
        SOUND(-867893436, "Sound", 200),
        SOUND_ENTITY(-870134716, "Entity Sound", 200),
        WORLD_EVENT(-861230422, "World Event", 600),
        DEATH_MSG(-855694814, "Death Message", 9000);

        public final int color;
        public final String label;
        public final int expiryTicks;

        private EventType(int color, String label, int expiryTicks) {
            this.color = color;
            this.label = label;
            this.expiryTicks = expiryTicks;
        }
    }

    public static final class ScanEvent {
        public final Vec3d pos;
        public final PacketScannerFeature.EventType type;
        public final String detail;
        public final long tick;

        ScanEvent(Vec3d pos, PacketScannerFeature.EventType type, String detail, long tick) {
            this.pos = pos;
            this.type = type;
            this.detail = detail;
            this.tick = tick;
        }
    }

    public static final class SuspectedBase {
        public final int chunkX;
        public final int chunkZ;
        public final double score;
        public final int eventCount;
        public final long lastSeenTick;

        SuspectedBase(int chunkX, int chunkZ, double score, int eventCount, long lastSeenTick) {
            this.chunkX = chunkX;
            this.chunkZ = chunkZ;
            this.score = score;
            this.eventCount = eventCount;
            this.lastSeenTick = lastSeenTick;
        }
    }
}
