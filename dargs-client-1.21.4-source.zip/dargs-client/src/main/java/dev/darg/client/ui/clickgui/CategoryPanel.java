package dev.darg.client.ui.clickgui;

import dev.darg.client.ui.theme.ClientTheme;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;

public final class CategoryPanel {
    private static final float HEADER_HEIGHT = 42.0F;
    private static final float PANEL_RADIUS = 14.0F;
    private static final float EXPAND_HIT_R = 10.0F;
    static final float MIN_WIDTH = 150.0F;
    static final float MAX_WIDTH = 360.0F;
    private static final float RESIZE_STRIP = 8.0F;
    private static final float TITLE_PAD_LEFT = 12.0F;
    private static final float CATEGORY_ICON_SZ = 18.0F;
    private static final float TITLE_GRID_GAP = 10.0F;
    float x;
    float y;
    float width;
    float height;
    final List<ModuleButton> modules = new ArrayList<>();
    final String key;
    final String name;
    final ItemStack icon;
    private final String emptyMessage;
    private boolean expanded = false;

    public CategoryPanel(String key, String name, ItemStack icon, float x, float y, float width) {
        this(key, name, icon, x, y, width, "No features");
    }

    public CategoryPanel(String key, String name, ItemStack icon, float x, float y, float width, String emptyMessage) {
        this.key = key;
        this.name = name;
        this.icon = icon;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = 42.0F;
        this.emptyMessage = emptyMessage;
    }

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public void addModule(ModuleButton moduleButton) {
        this.modules.add(moduleButton);
    }

    public String getKey() {
        return this.key;
    }

    public void toggleExpanded() {
        this.expanded = !this.expanded;
    }

    public void setExpanded(boolean value) {
        this.expanded = value;
    }

    public boolean isExpanded() {
        return this.expanded;
    }

    public List<ModuleButton> getModules() {
        return Collections.unmodifiableList(this.modules);
    }

    public void setWidth(float newWidth) {
        this.width = Math.max(150.0F, Math.min(360.0F, newWidth));
    }

    public void layout() {
        if (!this.expanded) {
            this.height = 42.0F;
        } else {
            float offsetY = this.y + 42.0F;

            for (ModuleButton module : this.modules) {
                module.setPosition(this.x, offsetY, this.width);
                offsetY += module.getRenderHeight();
            }

            this.height = (this.modules.isEmpty() ? offsetY + 20.0F : offsetY + 6.0F) - this.y;
        }
    }

    public void render(DrawContext context, TextRenderer textRenderer, ClientTheme theme, int mouseX, int mouseY) {
        int shadow = RenderUtil.withAlpha(theme.shadowStrong(), 28);
        int edge = RenderUtil.withAlpha(theme.white(), this.expanded ? 18 : 12);
        int enabledCount = this.getEnabledCount();
        RenderUtil.drawRoundedRect(context, this.x + 2.0F, this.y + 3.0F, this.width, this.height, 14.0F, shadow);
        RenderUtil.drawRoundedRect(context, this.x - 1.0F, this.y - 1.0F, this.width + 2.0F, this.height + 2.0F, 15.0F, edge);
        RenderUtil.drawGradientRoundedRect(
            context, this.x, this.y, this.width, this.height, 14.0F, theme.clickGuiPanelHeader(), RenderUtil.darken(theme.clickGuiPanelHeader(), 0.22F)
        );
        if (this.expanded) {
            context.fillGradient(
                Math.round(this.x + 1.0F),
                Math.round(this.y + 42.0F - 1.0F),
                Math.round(this.x + this.width - 1.0F),
                Math.round(this.y + this.height - 1.0F),
                theme.clickGuiPanelFill(),
                RenderUtil.darken(theme.clickGuiPanelFill(), 0.18F)
            );
            context.fill(
                Math.round(this.x + 12.0F),
                Math.round(this.y + 42.0F - 1.0F),
                Math.round(this.x + this.width - 12.0F),
                Math.round(this.y + 42.0F),
                RenderUtil.withAlpha(theme.white(), 18)
            );
        }

        float iconBoxX = this.x + 12.0F;
        float iconBoxY = this.y + 9.0F;
        float iconBoxSize = 24.0F;
        RenderUtil.drawRoundedRect(context, iconBoxX, iconBoxY, iconBoxSize, iconBoxSize, 8.0F, theme.moduleButtonFill());
        if (enabledCount > 0) {
            RenderUtil.drawRoundedRect(context, iconBoxX + 16.0F, iconBoxY + 16.0F, 6.0F, 6.0F, 3.0F, theme.accent());
        }

        if (!this.icon.isEmpty()) {
            int iconX = Math.round(iconBoxX + (iconBoxSize - 18.0F) / 2.0F);
            int iconY = Math.round(iconBoxY + (iconBoxSize - 18.0F) / 2.0F);
            context.drawItemWithoutEntity(this.icon, iconX, iconY);
        }

        float titleX = iconBoxX + iconBoxSize + 10.0F;
        String subtitle = this.modules.isEmpty()
            ? this.emptyMessage
            : (enabledCount > 0 ? enabledCount + " active · " + this.modules.size() + " modules" : this.modules.size() + " modules");
        RenderUtil.drawText(context, textRenderer, this.name, titleX, this.y + 11.0F, theme.white());
        RenderUtil.drawText(context, textRenderer, subtitle, titleX, this.y + 24.0F, theme.softGray());
        this.drawExpandIcon(context, textRenderer, theme);
        if (this.expanded) {
            if (this.modules.isEmpty()) {
                RenderUtil.drawText(context, textRenderer, this.emptyMessage, this.x + 12.0F, this.y + 42.0F + 12.0F, theme.softGray());
            } else {
                for (ModuleButton module : this.modules) {
                    module.render(context, textRenderer, theme, mouseX, mouseY);
                }
            }
        }
    }

    private void drawExpandIcon(DrawContext context, TextRenderer textRenderer, ClientTheme theme) {
        float boxSize = 18.0F;
        float boxX = this.x + this.width - 12.0F - boxSize;
        float boxY = this.y + (42.0F - boxSize) / 2.0F;
        RenderUtil.drawRoundedRect(context, boxX, boxY, boxSize, boxSize, 6.0F, theme.moduleButtonFill());
        RenderUtil.drawText(context, textRenderer, this.expanded ? "v" : ">", boxX + 6.0F, boxY + 5.0F, theme.white());
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button, NotificationManager notificationManager) {
        if (!this.expanded) {
            return this.contains(mouseX, mouseY);
        } else {
            for (ModuleButton module : this.modules) {
                if (module.mouseClicked(mouseX, mouseY, button, notificationManager)) {
                    return true;
                }
            }

            return this.contains(mouseX, mouseY);
        }
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (!this.expanded) {
            return this.contains(mouseX, mouseY);
        } else {
            for (ModuleButton module : this.modules) {
                if (module.mouseReleased(mouseX, mouseY, button)) {
                    return true;
                }
            }

            return this.contains(mouseX, mouseY);
        }
    }

    public boolean containsHeader(double mouseX, double mouseY) {
        return mouseX >= (double)this.x && mouseX <= (double)(this.x + this.width) && mouseY >= (double)this.y && mouseY <= (double)(this.y + 42.0F);
    }

    public boolean containsExpandButton(double mouseX, double mouseY) {
        float cx = this.x + this.width - 12.0F - 9.0F;
        float cy = this.y + 21.0F;
        return mouseX >= (double)(cx - 10.0F) && mouseX <= (double)(cx + 10.0F) && mouseY >= (double)(cy - 10.0F) && mouseY <= (double)(cy + 10.0F);
    }

    public boolean containsResizeHandle(double mouseX, double mouseY) {
        return mouseX >= (double)(this.x + this.width - 8.0F)
            && mouseX <= (double)(this.x + this.width)
            && mouseY >= (double)this.y
            && mouseY <= (double)(this.y + this.height);
    }

    private boolean contains(double mouseX, double mouseY) {
        return mouseX >= (double)this.x && mouseX <= (double)(this.x + this.width) && mouseY >= (double)this.y && mouseY <= (double)(this.y + this.height);
    }

    public boolean intersects(float viewLeft, float viewTop, float viewRight, float viewBottom) {
        return this.x < viewRight && this.x + this.width > viewLeft && this.y < viewBottom && this.y + this.height > viewTop;
    }

    public boolean isHovered(double mouseX, double mouseY) {
        return this.contains(mouseX, mouseY);
    }

    boolean hasExpandedModule() {
        if (!this.expanded) {
            return false;
        } else {
            for (ModuleButton module : this.modules) {
                if (module.isExpanded()) {
                    return true;
                }
            }

            return false;
        }
    }

    private int getEnabledCount() {
        int enabledCount = 0;

        for (ModuleButton module : this.modules) {
            if (module.getFeature().isEnabled()) {
                enabledCount++;
            }
        }

        return enabledCount;
    }
}
