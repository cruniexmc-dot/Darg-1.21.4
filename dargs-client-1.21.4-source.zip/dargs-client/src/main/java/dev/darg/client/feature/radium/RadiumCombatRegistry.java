package dev.darg.client.feature.radium;

import com.radium.client.client.ModuleManager;
import com.radium.client.client.RadiumClient;
import com.radium.client.modules.Module;
import com.radium.client.modules.client.ClickGUI;
import com.radium.client.modules.combat.AimAssist;
import com.radium.client.modules.combat.AnchorMacro;
import com.radium.client.modules.combat.AnchorMacrov2;
import com.radium.client.modules.combat.AutoCrystal;
import com.radium.client.modules.combat.AutoDoubleHand;
import com.radium.client.modules.combat.AutoFirework;
import com.radium.client.modules.combat.AutoJumpReset;
import com.radium.client.modules.combat.AutoLog;
import com.radium.client.modules.combat.AutoTotem;
import com.radium.client.modules.combat.AutoWeapon;
import com.radium.client.modules.combat.Blink;
import com.radium.client.modules.combat.CrystalMacro;
import com.radium.client.modules.combat.CrystalOptimizer;
import com.radium.client.modules.combat.DoubleAnchor;
import com.radium.client.modules.combat.HoverTotem;
import com.radium.client.modules.combat.InvTotem;
import com.radium.client.modules.combat.ItemSwap;
import com.radium.client.modules.combat.MaceSwap;
import com.radium.client.modules.combat.MaceTrigger;
import com.radium.client.modules.combat.NoInteract;
import com.radium.client.modules.combat.PearlThrow;
import com.radium.client.modules.combat.PlacementOptimizer;
import com.radium.client.modules.combat.SafeAnchorMacro;
import com.radium.client.modules.combat.TriggerBot;
import com.radium.client.modules.donut.TunnelBaseFinder;
import com.radium.client.modules.misc.AutoReconnect;
import com.radium.client.modules.misc.BaseDigger;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public final class RadiumCombatRegistry {
    private static final Set<Class<? extends Module>> CRYSTAL_MODULES = Set.of(
        AnchorMacro.class,
        AnchorMacrov2.class,
        AutoCrystal.class,
        AutoDoubleHand.class,
        AutoTotem.class,
        CrystalMacro.class,
        CrystalOptimizer.class,
        DoubleAnchor.class,
        HoverTotem.class,
        InvTotem.class,
        PlacementOptimizer.class,
        SafeAnchorMacro.class
    );

    private RadiumCombatRegistry() {
    }

    public static List<Feature> createFeatures() {
        ModuleManager moduleManager = new ModuleManager();
        RadiumClient.moduleManager = moduleManager;
        moduleManager.register(new ClickGUI());
        moduleManager.register(new AutoReconnect());
        moduleManager.register(new BaseDigger());
        moduleManager.register(new TunnelBaseFinder());
        List<Module> modules = List.of(
            new AimAssist(),
            new AnchorMacro(),
            new AnchorMacrov2(),
            new AutoCrystal(),
            new AutoDoubleHand(),
            new AutoFirework(),
            new AutoJumpReset(),
            new AutoLog(),
            new AutoTotem(),
            new AutoWeapon(),
            new Blink(),
            new CrystalMacro(),
            new CrystalOptimizer(),
            new DoubleAnchor(),
            new HoverTotem(),
            new InvTotem(),
            new ItemSwap(),
            new MaceSwap(),
            new MaceTrigger(),
            new NoInteract(),
            new PearlThrow(),
            new PlacementOptimizer(),
            new SafeAnchorMacro(),
            new TriggerBot()
        );
        List<Feature> features = new ArrayList<>();

        for (Module module : modules) {
            moduleManager.register(module);
            features.add(new RadiumModuleFeature(module, mapCategory(module)));
        }

        return features;
    }

    private static Category mapCategory(Module module) {
        return CRYSTAL_MODULES.contains(module.getClass()) ? Category.CRYSTAL : Category.COMBAT;
    }
}
