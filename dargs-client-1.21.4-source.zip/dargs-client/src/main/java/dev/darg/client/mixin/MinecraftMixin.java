package dev.darg.client.mixin;

import dev.darg.client.DargsClient;
import dev.darg.client.access.MinecraftClientItemUseCooldownAccess;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({MinecraftClient.class})
public abstract class MinecraftMixin implements MinecraftClientItemUseCooldownAccess {
    @Shadow
    private int itemUseCooldown;

    @Override
    public void dargsclient$setItemUseCooldown(int ticks) {
        this.itemUseCooldown = ticks;
    }

    @Inject(
        method = {"tick"},
        at = {@At("HEAD")}
    )
    private void dargsclient$tick(CallbackInfo ci) {
        DargsClient client = DargsClient.getInstance();
        if (client != null) {
            client.getFeatureManager().tick();
        }
    }

    @Inject(
        method = {"setScreen"},
        at = {@At("HEAD")},
        cancellable = true
    )
    private void dargsclient$replaceTitleScreen(Screen screen, CallbackInfo ci) {
        if (screen instanceof TitleScreen) {
            DargsClient client = DargsClient.getInstance();
            if (client != null) {
                ((MinecraftClient)(Object)this).setScreen(client.getUiManager().createEntryScreen());
                ci.cancel();
            }
        }
    }

    @Inject(
        method = {"doAttack"},
        at = {@At("HEAD")},
        cancellable = true
    )
    private void dargsclient$beforeAttack(CallbackInfoReturnable<Boolean> cir) {
        DargsClient client = DargsClient.getInstance();
        if (client != null && client.getFeatureManager().beforeAttack((MinecraftClient)(Object)this)) {
            cir.setReturnValue(false);
            cir.cancel();
        }
    }

    @Inject(
        method = {"doItemUse"},
        at = {@At("HEAD")},
        cancellable = true
    )
    private void dargsclient$onItemUse(CallbackInfo ci) {
        DargsClient client = DargsClient.getInstance();
        if (client != null && client.getFeatureManager().beforeItemUse((MinecraftClient)(Object)this)) {
            ci.cancel();
        }
    }

    @Inject(
        method = {"handleBlockBreaking"},
        at = {@At("HEAD")},
        cancellable = true
    )
    private void dargsclient$beforeBlockBreaking(boolean breaking, CallbackInfo ci) {
        DargsClient client = DargsClient.getInstance();
        if (client != null && client.getFeatureManager().beforeBlockBreaking((MinecraftClient)(Object)this, breaking)) {
            ci.cancel();
        }
    }
}
