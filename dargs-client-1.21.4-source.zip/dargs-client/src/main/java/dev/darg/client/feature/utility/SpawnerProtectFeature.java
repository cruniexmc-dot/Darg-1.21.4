package dev.darg.client.feature.utility;

import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.clickgui.InlineControlRenderer;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;

public final class SpawnerProtectFeature extends Feature {
    private static final int MIN_PLAYER_RANGE = 4;
    private static final int MAX_PLAYER_RANGE = 48;
    private static final int MIN_SPAWNER_RANGE = 2;
    private static final int MAX_SPAWNER_RANGE = 16;
    private static final int MIN_BREAK_DELAY = 0;
    private static final int MAX_BREAK_DELAY = 20;
    private static final int RESCAN_INTERVAL_TICKS = 10;
    private static final int MAX_BREAK_TICKS = 160;
    private static final int FAILED_TARGET_COOLDOWN_TICKS = 200;
    private static final float INLINE_HEIGHT = 120.0F;
    private final ClientConfig config = ClientConfig.getInstance();
    private final List<BlockPos> detectedSpawners = new ArrayList<>();
    private final Map<BlockPos, Integer> failedTargetCooldowns = new HashMap<>();
    private int playerRange;
    private int spawnerRange;
    private int breakDelayTicks;
    private boolean disconnectOnFail;
    private boolean disconnectWhenDone;
    private SpawnerProtectFeature.DragTarget dragTarget = SpawnerProtectFeature.DragTarget.NONE;
    private BlockPos currentTarget;
    private Direction currentFace = Direction.UP;
    private int currentBreakTicks;
    private int delayTicks;
    private int rescanTicks;
    private int silkTouchSlot = -1;
    private int originalSlot = -1;
    private int lastKnownSpawnerCount;
    private boolean breakingBlock;
    private boolean forcedSneak;
    private String detectedPlayerName;
    private String lastStatus = "Idle";

    public SpawnerProtectFeature() {
        super("SpawnerProtect", Category.UTILITY);
        this.loadSettings();
    }

    @Override
    protected void onEnable() {
        this.loadSettings();
        this.resetRuntimeState();
        this.lastStatus = "Watching";
    }

    @Override
    protected void onDisable() {
        this.dragTarget = SpawnerProtectFeature.DragTarget.NONE;
        this.cleanupControlState(MinecraftClient.getInstance());
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        ClientPlayerInteractionManager interactionManager = client.interactionManager;
        if (player != null && world != null && interactionManager != null) {
            this.tickFailedTargetCooldowns();
            AbstractClientPlayerEntity threat = this.findNearestThreat(player, world);
            if (threat == null) {
                this.detectedPlayerName = null;
                this.lastStatus = "Watching";
                this.clearProtectionState(client, true);
            } else {
                this.detectedPlayerName = threat.getName().getString();
                if (this.rescanTicks > 0 && !this.detectedSpawners.isEmpty()) {
                    this.rescanTicks--;
                } else {
                    this.scanForSpawners(player, world);
                    this.rescanTicks = 10;
                }

                this.silkTouchSlot = this.findSilkTouchHotbarSlot(player, world);
                if (this.silkTouchSlot < 0) {
                    this.failSafe(client, "Threat near " + this.detectedPlayerName + " but no Silk Touch mining tool is in your hotbar.");
                } else if (this.detectedSpawners.isEmpty()) {
                    this.failSafe(client, "Threat near " + this.detectedPlayerName + " but no spawners were found in range.");
                } else {
                    this.forceSneak(client, player, true);
                    this.ensureSilkTouchSelected(player);
                    if (this.delayTicks > 0) {
                        this.delayTicks--;
                        this.lastStatus = "Delay " + this.delayTicks + "t";
                    } else {
                        this.refreshCurrentTarget(player, world, interactionManager);
                        if (this.currentTarget == null) {
                            int coolingTargets = this.countCoolingTargets();
                            if (coolingTargets > 0) {
                                this.lastStatus = "Cooling " + coolingTargets + " stuck spawner" + (coolingTargets == 1 ? "" : "s");
                            } else {
                                this.protectionFinished(client, "All nearby spawners were cleared.");
                            }
                        } else {
                            this.mineCurrentTarget(player, world, interactionManager);
                        }
                    }
                }
            }
        } else {
            this.cleanupControlState(client);
            this.resetRuntimeState();
            this.lastStatus = "No world";
        }
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 120.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        if (this.dragTarget != SpawnerProtectFeature.DragTarget.NONE) {
            this.updateDraggedValue((double)mouseX, x, width);
        }

        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        float contentX = x + 10.0F;
        float contentWidth = width - 20.0F;
        InlineControlRenderer.drawSlider(
            context,
            textRenderer,
            theme,
            "PLAYER RANGE",
            Integer.toString(this.playerRange),
            contentX,
            y + 4.0F,
            contentWidth,
            sliderRatio(this.playerRange, 4, 48)
        );
        InlineControlRenderer.drawSlider(
            context,
            textRenderer,
            theme,
            "SPAWNER RANGE",
            Integer.toString(this.spawnerRange),
            contentX,
            y + 30.0F,
            contentWidth,
            sliderRatio(this.spawnerRange, 2, 16)
        );
        InlineControlRenderer.drawSlider(
            context,
            textRenderer,
            theme,
            "BREAK DELAY",
            this.breakDelayTicks + "t",
            contentX,
            y + 56.0F,
            contentWidth,
            sliderRatio(this.breakDelayTicks, 0, 20)
        );
        float toggleY = y + 88.0F;
        boolean hoverFail = containsDisconnectOnFailToggle((double)mouseX, (double)mouseY, x, y, width);
        boolean hoverDone = containsDisconnectWhenDoneToggle((double)mouseX, (double)mouseY, x, y, width);
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "Disconnect on fail", this.disconnectOnFail, hoverFail, contentX, toggleY, contentWidth);
        InlineControlRenderer.drawToggle(
            context, textRenderer, theme, "Disconnect when done", this.disconnectWhenDone, hoverDone, contentX, toggleY + 14.0F, contentWidth
        );
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (!containsInline(mouseX, mouseY, x, y, width)) {
            this.dragTarget = SpawnerProtectFeature.DragTarget.NONE;
            return false;
        } else if (button != 0) {
            return true;
        } else if (containsPlayerRangeSlider(mouseX, mouseY, x, y, width)) {
            this.dragTarget = SpawnerProtectFeature.DragTarget.PLAYER_RANGE;
            this.updateDraggedValue(mouseX, x, width);
            return true;
        } else if (containsSpawnerRangeSlider(mouseX, mouseY, x, y, width)) {
            this.dragTarget = SpawnerProtectFeature.DragTarget.SPAWNER_RANGE;
            this.updateDraggedValue(mouseX, x, width);
            return true;
        } else if (containsBreakDelaySlider(mouseX, mouseY, x, y, width)) {
            this.dragTarget = SpawnerProtectFeature.DragTarget.BREAK_DELAY;
            this.updateDraggedValue(mouseX, x, width);
            return true;
        } else if (containsDisconnectOnFailToggle(mouseX, mouseY, x, y, width)) {
            this.disconnectOnFail = !this.disconnectOnFail;
            this.saveSettings();
            return true;
        } else if (containsDisconnectWhenDoneToggle(mouseX, mouseY, x, y, width)) {
            this.disconnectWhenDone = !this.disconnectWhenDone;
            this.saveSettings();
            return true;
        } else {
            return true;
        }
    }

    @Override
    public boolean onCustomClickGuiMouseReleased(double mouseX, double mouseY, int button, float x, float y, float width) {
        if (button == 0 && this.dragTarget != SpawnerProtectFeature.DragTarget.NONE) {
            this.dragTarget = SpawnerProtectFeature.DragTarget.NONE;
            this.saveSettings();
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isClickGuiInteractionActive() {
        return this.dragTarget != SpawnerProtectFeature.DragTarget.NONE;
    }

    @Override
    public List<String> getClickGuiDetails() {
        String toolState = this.silkTouchSlot >= 0 ? "Hotbar " + (this.silkTouchSlot + 1) : "Missing";
        String threatState = this.detectedPlayerName == null ? "None" : this.detectedPlayerName;
        String targetState = this.currentTarget == null ? "None" : shortPos(this.currentTarget);
        return List.of(
            "State: " + (this.isEnabled() ? "Enabled" : "Disabled"),
            "Threat: " + threatState,
            "Spawners: " + this.lastKnownSpawnerCount,
            "Silk Tool: " + toolState,
            "Target: " + targetState,
            "Status: " + this.lastStatus
        );
    }

    @Override
    public String getHudSuffix() {
        if (!this.isEnabled()) {
            return null;
        } else if (this.detectedPlayerName != null) {
            return this.detectedPlayerName;
        } else {
            return this.lastKnownSpawnerCount > 0 ? Integer.toString(this.lastKnownSpawnerCount) : "idle";
        }
    }

    private void loadSettings() {
        this.playerRange = this.config.getSpawnerProtectPlayerRange();
        this.spawnerRange = this.config.getSpawnerProtectSpawnerRange();
        this.breakDelayTicks = this.config.getSpawnerProtectBreakDelay();
        this.disconnectOnFail = this.config.isSpawnerProtectDisconnectOnFail();
        this.disconnectWhenDone = this.config.isSpawnerProtectDisconnectWhenDone();
    }

    private void saveSettings() {
        this.config.setSpawnerProtectPlayerRange(this.playerRange);
        this.config.setSpawnerProtectSpawnerRange(this.spawnerRange);
        this.config.setSpawnerProtectBreakDelay(this.breakDelayTicks);
        this.config.setSpawnerProtectDisconnectOnFail(this.disconnectOnFail);
        this.config.setSpawnerProtectDisconnectWhenDone(this.disconnectWhenDone);
        this.config.save();
    }

    private void resetRuntimeState() {
        this.detectedSpawners.clear();
        this.failedTargetCooldowns.clear();
        this.currentTarget = null;
        this.currentFace = Direction.UP;
        this.currentBreakTicks = 0;
        this.delayTicks = 0;
        this.rescanTicks = 0;
        this.silkTouchSlot = -1;
        this.originalSlot = -1;
        this.lastKnownSpawnerCount = 0;
        this.breakingBlock = false;
        this.forcedSneak = false;
        this.detectedPlayerName = null;
    }

    private void cleanupControlState(MinecraftClient client) {
        this.clearProtectionState(client, false);
        this.resetRuntimeState();
    }

    private void clearProtectionState(MinecraftClient client, boolean clearScannedSpawners) {
        ClientPlayerEntity player = client.player;
        ClientPlayerInteractionManager interactionManager = client.interactionManager;
        if (interactionManager != null && this.breakingBlock) {
            interactionManager.cancelBlockBreaking();
        }

        this.breakingBlock = false;
        this.currentBreakTicks = 0;
        this.delayTicks = 0;
        this.currentTarget = null;
        this.currentFace = Direction.UP;
        if (player != null) {
            this.forceSneak(client, player, false);
            this.restoreOriginalSlot(player);
        } else {
            this.forcedSneak = false;
            this.originalSlot = -1;
        }

        if (clearScannedSpawners) {
            this.detectedSpawners.clear();
            this.lastKnownSpawnerCount = 0;
            this.rescanTicks = 0;
        }
    }

    private AbstractClientPlayerEntity findNearestThreat(ClientPlayerEntity player, ClientWorld world) {
        double bestDistanceSq = (double)this.playerRange * (double)this.playerRange;
        AbstractClientPlayerEntity best = null;

        for (AbstractClientPlayerEntity other : world.getPlayers()) {
            if (other != null && other != player && !other.isRemoved() && !other.isSpectator() && !other.isDead()) {
                double distanceSq = player.squaredDistanceTo(other);
                if (!(distanceSq > bestDistanceSq)) {
                    bestDistanceSq = distanceSq;
                    best = other;
                }
            }
        }

        return best;
    }

    private void scanForSpawners(ClientPlayerEntity player, ClientWorld world) {
        this.detectedSpawners.clear();
        BlockPos center = player.getBlockPos();
        Mutable mutable = new Mutable();

        for (int dx = -this.spawnerRange; dx <= this.spawnerRange; dx++) {
            for (int dy = -this.spawnerRange; dy <= this.spawnerRange; dy++) {
                for (int dz = -this.spawnerRange; dz <= this.spawnerRange; dz++) {
                    mutable.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                    if (world.isInBuildLimit(mutable) && world.getBlockState(mutable).isOf(Blocks.SPAWNER)) {
                        this.detectedSpawners.add(mutable.toImmutable());
                    }
                }
            }
        }

        this.detectedSpawners.sort(Comparator.comparingDouble(pos -> squaredDistanceTo(player, pos)));
        this.lastKnownSpawnerCount = this.detectedSpawners.size();
    }

    private int findSilkTouchHotbarSlot(ClientPlayerEntity player, ClientWorld world) {
        Registry<Enchantment> enchantmentRegistry = world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        Enchantment silkTouchValue = (Enchantment)enchantmentRegistry.getValueOrThrow(Enchantments.SILK_TOUCH);
        RegistryEntry<Enchantment> silkTouch = enchantmentRegistry.getEntry(silkTouchValue);
        BlockState spawnerState = Blocks.SPAWNER.getDefaultState();
        if (silkTouch == null) {
            return -1;
        } else {
            for (int slot = 0; slot < PlayerInventory.getHotbarSize(); slot++) {
                if (EnchantmentHelper.getLevel(silkTouch, player.getInventory().getStack(slot)) > 0
                    && player.getInventory().getStack(slot).isSuitableFor(spawnerState)) {
                    return slot;
                }
            }

            for (int slotx = 0; slotx < PlayerInventory.getHotbarSize(); slotx++) {
                if (EnchantmentHelper.getLevel(silkTouch, player.getInventory().getStack(slotx)) > 0) {
                    return slotx;
                }
            }

            return -1;
        }
    }

    private void ensureSilkTouchSelected(ClientPlayerEntity player) {
        if (this.silkTouchSlot >= 0) {
            PlayerInventory inventory = player.getInventory();
            if (inventory.getSelectedSlot() != this.silkTouchSlot) {
                if (this.originalSlot < 0) {
                    this.originalSlot = inventory.getSelectedSlot();
                }

                inventory.setSelectedSlot(this.silkTouchSlot);
                player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(this.silkTouchSlot));
            }
        }
    }

    private void restoreOriginalSlot(ClientPlayerEntity player) {
        if (this.originalSlot >= 0) {
            if (player.getInventory().getSelectedSlot() != this.originalSlot) {
                player.getInventory().setSelectedSlot(this.originalSlot);
                player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(this.originalSlot));
            }

            this.originalSlot = -1;
        }
    }

    private void forceSneak(MinecraftClient client, ClientPlayerEntity player, boolean enabled) {
        if (enabled != this.forcedSneak) {
            player.setSneaking(enabled);
            client.options.sneakKey.setPressed(enabled);
            this.forcedSneak = enabled;
        }
    }

    private void refreshCurrentTarget(ClientPlayerEntity player, ClientWorld world, ClientPlayerInteractionManager interactionManager) {
        this.detectedSpawners.removeIf(pos -> !world.getBlockState(pos).isOf(Blocks.SPAWNER));
        this.failedTargetCooldowns.keySet().removeIf(pos -> !world.getBlockState(pos).isOf(Blocks.SPAWNER));
        this.lastKnownSpawnerCount = this.detectedSpawners.size();
        if (this.currentTarget == null || !world.getBlockState(this.currentTarget).isOf(Blocks.SPAWNER) || this.isCoolingDown(this.currentTarget)) {
            if (this.breakingBlock) {
                interactionManager.cancelBlockBreaking();
            }

            this.breakingBlock = false;
            this.currentBreakTicks = 0;
            this.currentTarget = this.detectedSpawners
                .stream()
                .filter(pos -> !this.isCoolingDown(pos))
                .min(Comparator.comparingDouble(pos -> squaredDistanceTo(player, pos)))
                .orElse(null);
        }
    }

    private void mineCurrentTarget(ClientPlayerEntity player, ClientWorld world, ClientPlayerInteractionManager interactionManager) {
        if (this.currentTarget != null) {
            if (!world.getBlockState(this.currentTarget).isOf(Blocks.SPAWNER)) {
                this.finishCurrentTarget(interactionManager, false);
            } else {
                Vec3d targetCenter = Vec3d.ofCenter(this.currentTarget);
                this.rotateToward(player, targetCenter);
                Direction face = getClosestFace(this.currentTarget, player.getEyePos());
                if (this.breakingBlock && face == this.currentFace) {
                    if (interactionManager.updateBlockBreakingProgress(this.currentTarget, face)) {
                        player.swingHand(Hand.MAIN_HAND);
                    }

                    this.currentBreakTicks++;
                    this.lastStatus = "Breaking " + shortPos(this.currentTarget);
                    if (this.currentBreakTicks >= 160) {
                        this.finishCurrentTarget(interactionManager, true);
                    }
                } else {
                    interactionManager.cancelBlockBreaking();
                    this.currentFace = face;
                    if (interactionManager.attackBlock(this.currentTarget, face)) {
                        player.swingHand(Hand.MAIN_HAND);
                    }

                    this.breakingBlock = true;
                    this.currentBreakTicks = 0;
                    this.lastStatus = "Breaking " + shortPos(this.currentTarget);
                }
            }
        }
    }

    private void finishCurrentTarget(ClientPlayerInteractionManager interactionManager, boolean timedOut) {
        if (this.breakingBlock) {
            interactionManager.cancelBlockBreaking();
        }

        this.breakingBlock = false;
        this.currentBreakTicks = 0;
        if (this.currentTarget != null) {
            this.detectedSpawners.remove(this.currentTarget);
            if (timedOut) {
                this.failedTargetCooldowns.put(this.currentTarget.toImmutable(), 200);
            } else {
                this.failedTargetCooldowns.remove(this.currentTarget);
            }
        }

        this.currentTarget = null;
        this.currentFace = Direction.UP;
        this.delayTicks = this.breakDelayTicks;
        this.lastKnownSpawnerCount = this.detectedSpawners.size();
        this.lastStatus = timedOut ? "Skipped a stuck spawner" : "Spawner cleared";
    }

    private void tickFailedTargetCooldowns() {
        if (!this.failedTargetCooldowns.isEmpty()) {
            Iterator<Entry<BlockPos, Integer>> iterator = this.failedTargetCooldowns.entrySet().iterator();

            while (iterator.hasNext()) {
                Entry<BlockPos, Integer> entry = iterator.next();
                int remainingTicks = entry.getValue() - 1;
                if (remainingTicks <= 0) {
                    iterator.remove();
                } else {
                    entry.setValue(remainingTicks);
                }
            }
        }
    }

    private boolean isCoolingDown(BlockPos pos) {
        return this.failedTargetCooldowns.containsKey(pos);
    }

    private int countCoolingTargets() {
        int count = 0;

        for (BlockPos pos : this.detectedSpawners) {
            if (this.isCoolingDown(pos)) {
                count++;
            }
        }

        return count;
    }

    private void protectionFinished(MinecraftClient client, String message) {
        if (this.disconnectWhenDone) {
            this.disconnectAndDisable(client, message + " Disconnecting for safety.");
        } else {
            ClientPlayerEntity player = client.player;
            if (player != null) {
                player.sendMessage(Text.literal("[Darg's Client] " + message), false);
            }

            this.setEnabled(false);
        }
    }

    private void failSafe(MinecraftClient client, String message) {
        if (this.disconnectOnFail) {
            this.disconnectAndDisable(client, message);
        } else {
            ClientPlayerEntity player = client.player;
            if (player != null) {
                player.sendMessage(Text.literal("[Darg's Client] " + message), false);
            }

            this.setEnabled(false);
        }
    }

    private void disconnectAndDisable(MinecraftClient client, String message) {
        this.setEnabled(false);
        client.disconnect(Text.literal(message));
    }

    private void rotateToward(ClientPlayerEntity player, Vec3d target) {
        Vec3d eyes = player.getEyePos();
        Vec3d delta = target.subtract(eyes);
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float yaw = (float)Math.toDegrees(Math.atan2(-delta.x, delta.z));
        float pitch = (float)(-Math.toDegrees(Math.atan2(delta.y, horizontal)));
        player.setYaw(MathHelper.wrapDegrees(yaw));
        player.setPitch(MathHelper.clamp(pitch, -90.0F, 90.0F));
    }

    private static Direction getClosestFace(BlockPos pos, Vec3d playerEyes) {
        Vec3d delta = playerEyes.subtract(Vec3d.ofCenter(pos));
        return Direction.getFacing(delta.x, delta.y, delta.z);
    }

    private static double squaredDistanceTo(ClientPlayerEntity player, BlockPos pos) {
        return Vec3d.ofCenter(pos).squaredDistanceTo(player.getX(), player.getY(), player.getZ());
    }

    private void updateDraggedValue(double mouseX, float x, float width) {
        float contentX = x + 10.0F;
        float contentWidth = width - 20.0F;
        float t = (float)((mouseX - (double)contentX) / (double)contentWidth);
        t = Math.max(0.0F, Math.min(1.0F, t));
        switch (this.dragTarget) {
            case NONE:
            default:
                break;
            case PLAYER_RANGE:
                this.playerRange = interpolateInt(t, 4, 48);
                break;
            case SPAWNER_RANGE:
                this.spawnerRange = interpolateInt(t, 2, 16);
                break;
            case BREAK_DELAY:
                this.breakDelayTicks = interpolateInt(t, 0, 20);
        }
    }

    private static float sliderRatio(int value, int min, int max) {
        return (float)(value - min) / (float)(max - min);
    }

    private static int interpolateInt(float t, int min, int max) {
        return Math.round((float)min + t * (float)(max - min));
    }

    private static String shortPos(BlockPos pos) {
        return pos.getX() + ", " + pos.getY() + ", " + pos.getZ();
    }

    private static boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + 120.0F);
    }

    private static boolean containsPlayerRangeSlider(double mouseX, double mouseY, float x, float y, float width) {
        return containsSlider(mouseX, mouseY, x, y, width, 4.0F);
    }

    private static boolean containsSpawnerRangeSlider(double mouseX, double mouseY, float x, float y, float width) {
        return containsSlider(mouseX, mouseY, x, y, width, 30.0F);
    }

    private static boolean containsBreakDelaySlider(double mouseX, double mouseY, float x, float y, float width) {
        return containsSlider(mouseX, mouseY, x, y, width, 56.0F);
    }

    private static boolean containsSlider(double mouseX, double mouseY, float x, float y, float width, float offsetY) {
        return InlineControlRenderer.containsSlider(mouseX, mouseY, x + 10.0F, y + offsetY, width - 20.0F);
    }

    private static boolean containsDisconnectOnFailToggle(double mouseX, double mouseY, float x, float y, float width) {
        return InlineControlRenderer.containsToggle(mouseX, mouseY, x + 10.0F, y + 88.0F, width - 20.0F);
    }

    private static boolean containsDisconnectWhenDoneToggle(double mouseX, double mouseY, float x, float y, float width) {
        return InlineControlRenderer.containsToggle(mouseX, mouseY, x + 10.0F, y + 102.0F, width - 20.0F);
    }

    private static enum DragTarget {
        NONE,
        PLAYER_RANGE,
        SPAWNER_RANGE,
        BREAK_DELAY;
    }
}
