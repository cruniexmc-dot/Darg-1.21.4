package dev.darg.client.mixin;

import dev.darg.client.feature.utility.DisplaySpoofController;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({PlayerListHud.class})
public abstract class PlayerListHudNameSpoofMixin {
    @Inject(
        method = {"getPlayerName"},
        at = {@At("RETURN")},
        cancellable = true
    )
    private void dargsclient$spoofPlayerListName(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
        cir.setReturnValue(DisplaySpoofController.spoofTabListName((Text)cir.getReturnValue(), entry.getProfile().id()));
    }
}
