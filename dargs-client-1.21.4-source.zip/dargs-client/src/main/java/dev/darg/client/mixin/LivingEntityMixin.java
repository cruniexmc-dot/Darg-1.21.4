package dev.darg.client.mixin;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.visual.NoRenderFeature;
import dev.darg.client.feature.visual.SwingSpeedFeature;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({LivingEntity.class})
public abstract class LivingEntityMixin {
    @Inject(
        method = {"swingHand(Lnet/minecraft/util/Hand;Z)V"},
        at = {@At("HEAD")},
        cancellable = true
    )
    private void dargsclient$noRenderSwing(Hand hand, boolean fromServerPlayer, CallbackInfo ci) {
        DargsClient client = DargsClient.getInstance();
        if (client != null) {
            NoRenderFeature noRender = client.getFeatureManager().getFeature(NoRenderFeature.class);
            LivingEntity self = (LivingEntity)(Object)this;
            if (noRender != null && noRender.isEnabled() && !noRender.shouldRenderSwing()) {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.player != null && self == mc.player) {
                    ci.cancel();
                }
            }
        }
    }

    @Inject(
        method = {"getHandSwingDuration"},
        at = {@At("RETURN")},
        cancellable = true
    )
    private void dargsclient$swingSpeed(CallbackInfoReturnable<Integer> cir) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            if (this instanceof AbstractClientPlayerEntity player && player == mc.player) {
                DargsClient client = DargsClient.getInstance();
                if (client == null) {
                    return;
                }

                SwingSpeedFeature swingSpeed = client.getFeatureManager().getFeature(SwingSpeedFeature.class);
                if (swingSpeed != null && swingSpeed.isEnabled()) {
                    float mult = swingSpeed.getSwingSpeedMultiplier();
                    int original = (Integer)cir.getReturnValue();
                    int modified = Math.round((float)original / mult);
                    modified = Math.max(1, Math.min(60, modified));
                    cir.setReturnValue(modified);
                    return;
                }

                return;
            }
        }
    }
}
