package dev.darg.client.feature.visual;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.clickgui.InlineControlRenderer;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.player.PlayerEntity;

public final class TargetHudFeature extends Feature {
    private static final float PANEL_W = 160.0F;
    private static final float PANEL_H = 54.0F;
    private static final float RADIUS = 8.0F;
    private static final float SHADOW_DX = 2.0F;
    private static final float SHADOW_DY = 3.0F;
    private static final int SKIN_SIZE = 30;
    private static final float SKIN_X_OFF = 8.0F;
    private static final float SKIN_Y_OFF = 12.0F;
    private static final float COL_X = 44.0F;
    private static final float COL_W = 109.0F;
    private static final float BAR_Y = 35.0F;
    private static final float BAR_H = 5.0F;
    private static final float STRIPE_W = 3.0F;
    private static final float STRIPE_Y = 6.0F;
    private static final float STRIPE_H = 42.0F;
    private static final float CROSSHAIR_X_OFFSET = 18.0F;
    private static final float CROSSHAIR_Y_OFFSET = -27.0F;
    private static final float SCREEN_MARGIN = 6.0F;
    private static final long TIMEOUT_MS = 10000L;
    private static final float ANIM_SPEED = 10.0F;
    private static final float INLINE_H = 46.0F;
    private boolean hudTimeout = true;
    private PlayerEntity lastTarget = null;
    private long lastAttackMs = 0L;
    private float animation = 0.0F;
    private long lastAnimNanos = 0L;

    public TargetHudFeature() {
        super("TargetHUD", Category.RENDER);
    }

    public void onPlayerAttack(PlayerEntity target) {
        this.lastTarget = target;
        this.lastAttackMs = System.currentTimeMillis();
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of(
            "State: " + (this.isEnabled() ? "Enabled" : "Disabled"),
            "Timeout: " + (this.hudTimeout ? "10s" : "Off"),
            "Target: " + (this.lastTarget != null && this.lastTarget.isAlive() ? this.lastTarget.getName().getString() : "None")
        );
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 46.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        float cx = x + 10.0F;
        float cw = width - 20.0F;
        float togY = y + 8.0F;
        float bindY = y + 24.0F;
        float btnW = 70.0F;
        float btnX = x + width - btnW - 10.0F;
        boolean hoverTog = InlineControlRenderer.containsToggle((double)mouseX, (double)mouseY, cx, togY, cw);
        boolean hoverBind = InlineControlRenderer.containsButton((double)mouseX, (double)mouseY, btnX, bindY, btnW);
        boolean capturing = DargsClient.getInstance().getKeybindManager().isCapturing(this);
        String bindLabel = InlineControlRenderer.fitText(
            textRenderer, DargsClient.getInstance().getKeybindManager().getBindLabel(this).toUpperCase(Locale.ROOT), 58
        );
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "TIMEOUT", this.hudTimeout, hoverTog, cx, togY, cw);
        InlineControlRenderer.drawButton(context, textRenderer, theme, bindLabel, capturing, hoverBind, btnX, bindY, btnW);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager nm) {
        if (!(mouseX < (double)x) && !(mouseX > (double)(x + width)) && !(mouseY < (double)y) && !(mouseY > (double)(y + 46.0F))) {
            float cx = x + 10.0F;
            float cw = width - 20.0F;
            float btnW = 70.0F;
            float btnX = x + width - btnW - 10.0F;
            if (button == 0 && InlineControlRenderer.containsToggle(mouseX, mouseY, cx, y + 8.0F, cw)) {
                this.hudTimeout = !this.hudTimeout;
                nm.push(
                    "Target timeout " + (this.hudTimeout ? "enabled" : "disabled"),
                    this.hudTimeout ? NotificationManager.Type.SUCCESS : NotificationManager.Type.INFO
                );
                return true;
            } else if (button == 0 && InlineControlRenderer.containsButton(mouseX, mouseY, btnX, y + 24.0F, btnW)) {
                if (DargsClient.getInstance().getKeybindManager().isCapturing(this)) {
                    DargsClient.getInstance().getKeybindManager().cancelCapture(nm);
                } else {
                    DargsClient.getInstance().getKeybindManager().beginCapture(this, nm);
                }

                return true;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    @Override
    public void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && client.world != null) {
            boolean shouldShow = this.lastTarget != null
                && this.lastTarget.isAlive()
                && (!this.hudTimeout || System.currentTimeMillis() - this.lastAttackMs <= 10000L);
            this.tickAnimation(shouldShow);
            if (!(this.animation < 0.01F)) {
                PlayerEntity target = this.lastTarget;
                if (target != null && target.isAlive()) {
                    ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
                    TextRenderer textRenderer = client.textRenderer;
                    float x = this.resolveHudX(client);
                    float y = this.resolveHudY(client);
                    int a = Math.round(this.animation * 255.0F);
                    PlayerListEntry entry = client.getNetworkHandler() != null ? client.getNetworkHandler().getPlayerListEntry(target.getUuid()) : null;
                    RenderUtil.drawRoundedRect(context, x + 2.0F, y + 3.0F, 160.0F, 54.0F, 8.0F, withAnim(1426063360, a));
                    RenderUtil.drawRoundedRect(context, x, y, 160.0F, 54.0F, 8.0F, withAnim(theme.hudPanelSoft(), a));
                    RenderUtil.drawRoundedRect(context, x + 1.0F, y + 6.0F, 3.0F, 42.0F, 1.5F, withAnim(theme.accent(), a));
                    if (entry != null) {
                        context.getMatrices().pushMatrix();
                        context.getMatrices().translate(x + 8.0F, y + 12.0F);
                        PlayerSkinDrawer.draw(context, entry.getSkinTextures(), 0, 0, 30);
                        context.getMatrices().popMatrix();
                    } else {
                        RenderUtil.drawRoundedRect(context, x + 8.0F, y + 12.0F, 30.0F, 30.0F, 4.0F, withAnim(theme.hudModuleFill(), a));
                        RenderUtil.drawText(context, textRenderer, "?", x + 8.0F + 11.0F, y + 12.0F + 10.0F, withAnim(theme.mutedGray(), a));
                    }

                    String name = trimName(textRenderer, target.getName().getString(), 77.0F);
                    RenderUtil.drawText(context, textRenderer, name, x + 44.0F, y + 11.0F, withAnim(theme.white(), a));
                    if (entry == null) {
                        float chipW = (float)textRenderer.getWidth("BOT") + 8.0F;
                        float chipX = x + 44.0F + (float)textRenderer.getWidth(name) + 5.0F;
                        RenderUtil.drawRoundedRect(context, chipX, y + 10.0F, chipW, 10.0F, 3.0F, withAnim(-11325136, a));
                        RenderUtil.drawText(context, textRenderer, "BOT", chipX + 4.0F, y + 11.5F, withAnim(-44976, a));
                    }

                    if (entry != null) {
                        int ping = entry.getLatency();
                        int pingColor = pingColor(ping, a);
                        String pingStr = ping + "ms";
                        float pingX = x + 160.0F - (float)textRenderer.getWidth(pingStr) - 7.0F;
                        RenderUtil.drawText(context, textRenderer, pingStr, pingX, y + 11.0F, pingColor);
                    }

                    float dist = (float)Math.round(target.distanceTo(client.player) * 2.0F) / 2.0F;
                    String distStr = dist + "b";
                    RenderUtil.drawText(context, textRenderer, distStr, x + 44.0F, y + 23.0F, withAnim(theme.mutedGray(), a));
                    if (target.isInvisible()) {
                        String invStr = "INVIS";
                        float invX = x + 44.0F + (float)textRenderer.getWidth(distStr) + 6.0F;
                        RenderUtil.drawRoundedRect(
                            context, invX, y + 22.0F, (float)textRenderer.getWidth(invStr) + 8.0F, 10.0F, 3.0F, withAnim(theme.hudChipFill(), a)
                        );
                        RenderUtil.drawText(context, textRenderer, invStr, invX + 4.0F, y + 23.5F, withAnim(theme.softGray(), a));
                    }

                    float maxHp = target.getMaxHealth();
                    float hp = Math.min(target.getHealth(), maxHp);
                    float absorption = target.getAbsorptionAmount();
                    float totalHp = hp + absorption;
                    float hpRatio = Math.max(0.0F, Math.min(1.0F, hp / maxHp));
                    float absRatio = absorption > 0.0F ? Math.min(1.0F, absorption / maxHp) : 0.0F;
                    float barX = x + 44.0F;
                    float barW = 109.0F;
                    RenderUtil.drawRoundedRect(context, barX, y + 35.0F, barW, 5.0F, 2.5F, withAnim(theme.hudTrackFill(), a));
                    float hpFillW = Math.max(hpRatio > 0.0F ? 5.0F : 0.0F, barW * hpRatio);
                    if (hpFillW > 0.0F) {
                        int hpColor = healthColor(hpRatio, target.hurtTime > 0, a);
                        RenderUtil.drawRoundedRect(context, barX, y + 35.0F, hpFillW, 5.0F, 2.5F, hpColor);
                    }

                    if (absRatio > 0.0F) {
                        float absStart = barW * hpRatio;
                        float absFillW = Math.max(5.0F, barW * absRatio);
                        absFillW = Math.min(absFillW, barW - absStart);
                        if (absFillW > 0.0F) {
                            RenderUtil.drawRoundedRect(context, barX + absStart, y + 35.0F, absFillW, 5.0F, 2.5F, withAnim(-13244, a));
                        }
                    }

                    String hpStr = Math.round(totalHp) + "/" + Math.round(maxHp);
                    float hpLabelX = barX + barW - (float)textRenderer.getWidth(hpStr);
                    RenderUtil.drawText(context, textRenderer, hpStr, hpLabelX, y + 35.0F + 5.0F + 2.0F, withAnim(theme.mutedGray(), a));
                }
            }
        }
    }

    private void tickAnimation(boolean shouldShow) {
        float target = shouldShow ? 1.0F : 0.0F;
        long now = System.nanoTime();
        if (this.lastAnimNanos > 0L) {
            float dt = (float)(now - this.lastAnimNanos) / 1.0E9F;
            float lerpFactor = Math.min(1.0F, dt * 10.0F);
            this.animation = this.animation + (target - this.animation) * lerpFactor;
        } else {
            this.animation = target;
        }

        this.lastAnimNanos = now;
    }

    private static int withAnim(int color, int animAlpha) {
        int base = color >> 24 & 0xFF;
        int a = base * animAlpha / 255;
        return RenderUtil.withAlpha(color, a);
    }

    private static int healthColor(float ratio, boolean hurting, int animAlpha) {
        int rgb;
        if (hurting) {
            rgb = 16732240;
        } else if (ratio > 0.6F) {
            rgb = 10154165;
        } else if (ratio > 0.3F) {
            rgb = 16758892;
        } else {
            rgb = 16732240;
        }

        int a = 255 * animAlpha / 255;
        return a << 24 | rgb;
    }

    private static int pingColor(int ping, int animAlpha) {
        int rgb;
        if (ping < 80) {
            rgb = 10154165;
        } else if (ping < 150) {
            rgb = 16777096;
        } else if (ping < 300) {
            rgb = 16758892;
        } else {
            rgb = 16732240;
        }

        int a = 204 * animAlpha / 255;
        return a << 24 | rgb;
    }

    private float resolveHudX(MinecraftClient client) {
        float centerX = (float)client.getWindow().getScaledWidth() * 0.5F;
        float rawX = centerX + 18.0F;
        float maxX = Math.max(6.0F, (float)client.getWindow().getScaledWidth() - 160.0F - 6.0F);
        return Math.max(6.0F, Math.min(maxX, rawX));
    }

    private float resolveHudY(MinecraftClient client) {
        float centerY = (float)client.getWindow().getScaledHeight() * 0.5F;
        float rawY = centerY + -27.0F;
        float maxY = Math.max(6.0F, (float)client.getWindow().getScaledHeight() - 54.0F - 6.0F);
        return Math.max(6.0F, Math.min(maxY, rawY));
    }

    private static String trimName(TextRenderer tr, String name, float maxWidth) {
        if ((float)tr.getWidth(name) <= maxWidth) {
            return name;
        } else {
            while (!name.isEmpty() && (float)tr.getWidth(name + "…") > maxWidth) {
                name = name.substring(0, name.length() - 1);
            }

            return name + "…";
        }
    }
}
