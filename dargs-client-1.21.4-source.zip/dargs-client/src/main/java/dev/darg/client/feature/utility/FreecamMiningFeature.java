package dev.darg.client.feature.utility;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import java.util.List;

public final class FreecamMiningFeature extends Feature {
    public FreecamMiningFeature() {
        super("FreecamMine", Category.UTILITY);
    }

    @Override
    protected void onEnable() {
        FreecamActionFeature actionFeature = DargsClient.getInstance().getFeatureManager().getFeature(FreecamActionFeature.class);
        if (actionFeature != null && actionFeature.isEnabled()) {
            actionFeature.setEnabled(false);
        }

        if (!FreecamController.getInstance().enable(FreecamController.ActionSource.CAMERA)) {
            this.setEnabled(false);
        }
    }

    @Override
    protected void onDisable() {
        FreecamController controller = FreecamController.getInstance();
        if (controller.usesCameraActionSource()) {
            controller.disable();
        }
    }

    @Override
    public void onTick() {
        FreecamController controller = FreecamController.getInstance();
        if (!controller.usesCameraActionSource()) {
            this.setEnabled(false);
        } else {
            controller.tick();
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        FreecamController controller = FreecamController.getInstance();
        return List.of(
            "State: " + (this.isEnabled() ? "Enabled" : "Disabled"),
            "Camera: Detached flight camera",
            "Actions: Uses freecam crosshair",
            "Mining: Left click mines what the camera sees",
            String.format("Speed: %.2f", controller.getSpeed())
        );
    }
}
