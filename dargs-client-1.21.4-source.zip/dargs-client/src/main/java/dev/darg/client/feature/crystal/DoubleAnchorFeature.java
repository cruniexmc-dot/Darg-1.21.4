package dev.darg.client.feature.crystal;

import dev.darg.client.feature.Category;
import dev.darg.client.feature.combat.ConfigurableCombatFeature;
import java.util.List;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;

public final class DoubleAnchorFeature extends ConfigurableCombatFeature {
    private BlockPos lastPos;
    private int count;

    public DoubleAnchorFeature() {
        super("DoubleAnchor", Category.CRYSTAL);
    }

    @Override
    protected void onEnable() {
        this.lastPos = null;
        this.count = 0;
    }

    @Override
    protected void onDisable() {
        this.lastPos = null;
        this.count = 0;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player != null && mc.world != null && mc.currentScreen == null) {
            if (player.getMainHandStack().isOf(Items.RESPAWN_ANCHOR)) {
                if (mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == Type.BLOCK) {
                    BlockPos pos = hit.getBlockPos();
                    if (!mc.world.getBlockState(pos).isOf(Blocks.RESPAWN_ANCHOR)) {
                        return;
                    }

                    if ((Integer)mc.world.getBlockState(pos).get(RespawnAnchorBlock.CHARGES) == 0) {
                        return;
                    }

                    if (GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), 1) != 1) {
                        return;
                    }

                    if (pos.equals(this.lastPos)) {
                        if (this.count >= 1) {
                            return;
                        }
                    } else {
                        this.lastPos = pos;
                        this.count = 0;
                    }

                    player.networkHandler.sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, hit, 0));
                    this.count++;
                    return;
                }
            }
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("Hold right-click on charged respawn anchor");
    }
}
