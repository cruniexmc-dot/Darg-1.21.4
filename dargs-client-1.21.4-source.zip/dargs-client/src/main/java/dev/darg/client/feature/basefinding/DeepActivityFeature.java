package dev.darg.client.feature.basefinding;

import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.render.ChunkMarkerRenderUtil;
import dev.darg.client.render.WorldRenderUtil;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

public final class DeepActivityFeature extends Feature {
    static final int SIG_PLAYER = 1;
    static final int SIG_SWING = 2;
    static final int SIG_HURT = 4;
    static final int SIG_EQUIPMENT = 8;
    static final int SIG_TNT = 16;
    static final int SIG_PROJECTILE = 32;
    static final int SIG_AMETHYST = 64;
    static final int SIG_CAVE_VINE = 128;
    private static final int ACTIVITY_MASK = 63;
    private static final int GROWTH_MASK = 192;
    private static final int DEEP_Y = 0;
    private static final int ACTIVITY_EXPIRY = 200;
    private static final int SCAN_RADIUS = 8;
    private static final int BATCH_SIZE = 10;
    private static final int RESCAN_TICKS = 120;
    private static final int MIN_AMETHYST = 8;
    private static final float MIN_CLUSTER_RATIO = 0.55F;
    private static final int MIN_VINE_LEN = 15;
    private static final float PLATE_Y = -65.0F;
    private static final float LINE_WIDTH = 1.5F;
    private static final float TRACER_OFFSET = 0.15F;
    private static final int SCAN_PLATE_COLOR = 404894498;
    private static final int TRACER_COLOR = -1862301645;
    private static final int ACTIVITY_COLOR = -855690445;
    private static final int GROWTH_COLOR = -870130262;
    private static final int COMBINED_COLOR = -855651328;
    private final ConcurrentHashMap<ChunkPos, Integer> signalMasks = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<ChunkPos, Long> activityTicks = new ConcurrentHashMap<>();
    private final Set<ChunkPos> scannedChunks = ConcurrentHashMap.newKeySet();
    private final Deque<ChunkPos> scanQueue = new ArrayDeque<>();
    private final Set<ChunkPos> queuedChunks = new HashSet<>();
    private int lastChunkX = Integer.MIN_VALUE;
    private int lastChunkZ = Integer.MIN_VALUE;
    private int rescanTicker = 0;
    private long gameTick = 0L;

    public DeepActivityFeature() {
        super("Deep Activity", Category.BASEFINDING);
    }

    @Override
    protected void onEnable() {
        this.clearState();
    }

    @Override
    protected void onDisable() {
        this.clearState();
    }

    private void clearState() {
        this.signalMasks.clear();
        this.activityTicks.clear();
        this.scannedChunks.clear();
        this.scanQueue.clear();
        this.queuedChunks.clear();
        this.lastChunkX = Integer.MIN_VALUE;
        this.lastChunkZ = Integer.MIN_VALUE;
        this.rescanTicker = 0;
        this.gameTick = 0L;
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientWorld world = client.world;
        if (world != null && client.player != null) {
            this.gameTick++;
            this.tickEntitySignals(client, world);
            int chunkX = client.player.getChunkPos().x;
            int chunkZ = client.player.getChunkPos().z;
            if (chunkX == this.lastChunkX && chunkZ == this.lastChunkZ) {
                if (++this.rescanTicker >= 120) {
                    this.rescanTicker = 0;
                    this.enqueueScanWindow(chunkX, chunkZ, false);
                }
            } else {
                this.lastChunkX = chunkX;
                this.lastChunkZ = chunkZ;
                this.enqueueScanWindow(chunkX, chunkZ, true);
                this.cleanupDistant(chunkX, chunkZ);
            }

            int bottomSectionCoord = world.getBottomSectionCoord();

            for (int i = 0; i < 10 && !this.scanQueue.isEmpty(); i++) {
                ChunkPos pos = this.scanQueue.poll();
                if (pos != null) {
                    this.queuedChunks.remove(pos);
                    if (world.isChunkLoaded(pos.x, pos.z)) {
                        WorldChunk chunk = world.getChunk(pos.x, pos.z);
                        if (chunk != null && !chunk.isEmpty()) {
                            this.scanChunkBlocks(world, chunk, pos, bottomSectionCoord);
                        }

                        this.scannedChunks.add(pos);
                    }
                }
            }
        } else {
            this.clearState();
        }
    }

    private void tickEntitySignals(MinecraftClient client, ClientWorld world) {
        int localId = client.player.getId();
        double px = client.player.getX();
        double pz = client.player.getZ();
        double range = 128.0;
        Box box = new Box(px - range, (double)world.getBottomY(), pz - range, px + range, 320.0, pz + range);

        for (AbstractClientPlayerEntity player : world.getPlayers()) {
            if (player.getId() != localId && player.getBlockPos().getY() < 0) {
                ChunkPos cp = new ChunkPos(player.getBlockPos());
                this.markActivity(cp, 1);
                if (player.handSwinging) {
                    this.markActivity(cp, 2);
                }

                if (player.hurtTime > 0) {
                    this.markActivity(cp, 4);
                }

                if (!player.getMainHandStack().isEmpty()) {
                    this.markActivity(cp, 8);
                }
            }
        }

        for (TntEntity tnt : world.getEntitiesByClass(TntEntity.class, box, e -> e.getBlockPos().getY() < 0)) {
            this.markActivity(new ChunkPos(tnt.getBlockPos()), 16);
        }

        for (PersistentProjectileEntity proj : world.getEntitiesByClass(PersistentProjectileEntity.class, box, e -> e.getBlockPos().getY() < 0)) {
            if (proj.getOwner() == null || proj.getOwner().getId() != localId) {
                this.markActivity(new ChunkPos(proj.getBlockPos()), 32);
            }
        }

        for (LivingEntity mob : world.getEntitiesByClass(
            LivingEntity.class, box, e -> !(e instanceof PlayerEntity) && e.getBlockPos().getY() < 0 && e.hurtTime > 0
        )) {
            this.markActivity(new ChunkPos(mob.getBlockPos()), 4);
        }
    }

    private void markActivity(ChunkPos cp, int sigBit) {
        this.signalMasks.merge(cp, sigBit, (a, b) -> a | b);
        this.activityTicks.put(cp, this.gameTick);
    }

    private void markGrowth(ChunkPos cp, int sigBit) {
        this.signalMasks.merge(cp, sigBit, (a, b) -> a | b);
        this.activityTicks.merge(cp, Long.MAX_VALUE, Math::max);
    }

    private void scanChunkBlocks(ClientWorld world, WorldChunk chunk, ChunkPos cp, int bottomSectionCoord) {
        ChunkSection[] sections = chunk.getSectionArray();
        int minSi = Math.max(0, ChunkSectionPos.getSectionCoord(-1) - bottomSectionCoord);
        int clusters = 0;
        int buds = 0;

        for (int si = minSi; si < sections.length; si++) {
            ChunkSection sec = sections[si];
            if (sec != null && !sec.isEmpty() && sec.hasAny(s -> {
                Block bx = s.getBlock();
                return bx == Blocks.AMETHYST_CLUSTER || bx == Blocks.LARGE_AMETHYST_BUD || bx == Blocks.MEDIUM_AMETHYST_BUD || bx == Blocks.SMALL_AMETHYST_BUD;
            })) {
                for (int lx = 0; lx < 16; lx++) {
                    for (int ly = 0; ly < 16; ly++) {
                        for (int lz = 0; lz < 16; lz++) {
                            Block b = sec.getBlockState(lx, ly, lz).getBlock();
                            if (b == Blocks.AMETHYST_CLUSTER) {
                                clusters++;
                            } else if (b == Blocks.LARGE_AMETHYST_BUD || b == Blocks.MEDIUM_AMETHYST_BUD || b == Blocks.SMALL_AMETHYST_BUD) {
                                buds++;
                            }
                        }
                    }
                }
            }
        }

        int totalAmethyst = clusters + buds;
        if (totalAmethyst >= 8 && (float)clusters / (float)totalAmethyst >= 0.55F) {
            this.markGrowth(cp, 64);
        }

        if (this.hasTallVines(world, chunk, sections, bottomSectionCoord, minSi)) {
            this.markGrowth(cp, 128);
        }
    }

    private boolean hasTallVines(ClientWorld world, WorldChunk chunk, ChunkSection[] sections, int bottomSectionCoord, int minSi) {
        int sx = chunk.getPos().getStartX();
        int sz = chunk.getPos().getStartZ();

        for (int si = minSi; si < sections.length; si++) {
            ChunkSection sec = sections[si];
            if (sec != null && !sec.isEmpty() && sec.hasAny(s -> s.getBlock() == Blocks.CAVE_VINES)) {
                int baseY = ChunkSectionPos.getBlockCoord(bottomSectionCoord + si);

                for (int lx = 0; lx < 16; lx++) {
                    for (int lz = 0; lz < 16; lz++) {
                        for (int ly = 0; ly < 16; ly++) {
                            if (sec.getBlockState(lx, ly, lz).getBlock() == Blocks.CAVE_VINES) {
                                Mutable above = new Mutable(sx + lx, baseY + ly + 1, sz + lz);
                                int len = 1;

                                while (len < 15 && world.getBlockState(above).getBlock() == Blocks.CAVE_VINES_PLANT) {
                                    len++;
                                    above.setY(above.getY() + 1);
                                }

                                if (len >= 15) {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        }

        return false;
    }

    private void enqueueScanWindow(int cx, int cz, boolean force) {
        for (int dx = -8; dx <= 8; dx++) {
            for (int dz = -8; dz <= 8; dz++) {
                ChunkPos pos = new ChunkPos(cx + dx, cz + dz);
                if ((force || !this.scannedChunks.contains(pos)) && this.queuedChunks.add(pos)) {
                    this.scanQueue.offer(pos);
                }
            }
        }
    }

    private void cleanupDistant(int cx, int cz) {
        int lim = 10;
        this.signalMasks.keySet().removeIf(p -> Math.abs(p.x - cx) > lim || Math.abs(p.z - cz) > lim);
        this.activityTicks.keySet().removeIf(p -> Math.abs(p.x - cx) > lim || Math.abs(p.z - cz) > lim);
        this.scannedChunks.removeIf(p -> Math.abs(p.x - cx) > lim || Math.abs(p.z - cz) > lim);
        this.queuedChunks.removeIf(p -> Math.abs(p.x - cx) > lim || Math.abs(p.z - cz) > lim);
        this.scanQueue.removeIf(p -> Math.abs(p.x - cx) > lim || Math.abs(p.z - cz) > lim);
    }

    private boolean isActive(ChunkPos cp) {
        Integer mask = this.signalMasks.get(cp);
        if (mask != null && mask != 0) {
            if ((mask & 192) != 0) {
                return true;
            } else {
                Long t = this.activityTicks.get(cp);
                return t != null && this.gameTick - t < 200L;
            }
        } else {
            return false;
        }
    }

    private boolean isActivityRecent(ChunkPos cp) {
        Long t = this.activityTicks.get(cp);
        return t != null && t != Long.MAX_VALUE && this.gameTick - t < 200L;
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world != null && client.player != null) {
            Vec3d cam = client.gameRenderer.getCamera().getCameraPos();
            List<ChunkMarkerRenderUtil.ChunkMarker> markers = new ArrayList<>();

            for (Entry<ChunkPos, Integer> e : this.signalMasks.entrySet()) {
                ChunkPos cp = e.getKey();
                if (this.isActive(cp)) {
                    int mask = e.getValue();
                    boolean growth = (mask & 192) != 0;
                    boolean live = (mask & 63) != 0 && this.isActivityRecent(cp);
                    int color = growth && live ? -855651328 : (live ? -855690445 : -870130262);
                    int outer = WorldRenderUtil.withAlpha(WorldRenderUtil.brighten(color, 0.15F), 155);
                    int inner = WorldRenderUtil.withAlpha(color, 185);
                    List<ItemStack> icons = new ArrayList<>();
                    if ((mask & 64) != 0) {
                        icons.add(new ItemStack(Items.AMETHYST_SHARD));
                    }

                    if ((mask & 128) != 0) {
                        icons.add(new ItemStack(Items.GLOW_BERRIES));
                    }

                    if ((mask & 1) != 0 && live) {
                        icons.add(new ItemStack(Items.PLAYER_HEAD));
                    }

                    if ((mask & 2) != 0 && live) {
                        icons.add(new ItemStack(Items.IRON_PICKAXE));
                    }

                    if ((mask & 4) != 0 && live) {
                        icons.add(new ItemStack(Items.BONE));
                    }

                    if ((mask & 16) != 0 && live) {
                        icons.add(new ItemStack(Items.TNT));
                    }

                    if ((mask & 32) != 0 && live) {
                        icons.add(new ItemStack(Items.ARROW));
                    }

                    markers.add(
                        new ChunkMarkerRenderUtil.ChunkMarker(
                            cp,
                            outer,
                            -65.0F,
                            3.55F,
                            inner,
                            -64.97F,
                            0.92F,
                            2.95F,
                            0,
                            -65.0F,
                            0.0F,
                            0,
                            -65.0F,
                            -1862301645,
                            -64.96F,
                            1.5F,
                            icons.isEmpty() ? null : icons,
                            -64.1F,
                            2.5F,
                            0.0F,
                            true
                        )
                    );
                }
            }

            markers.sort(Comparator.comparingDouble(m -> {
                double dx = (double)(m.pos().x << 4) + 8.0 - cam.x;
                double dz = (double)(m.pos().z << 4) + 8.0 - cam.z;
                return -(dx * dx + dz * dz);
            }));
            ChunkMarkerRenderUtil.render(client, context, 0.15F, this.scannedChunks, new ChunkMarkerRenderUtil.ScanPlateStyle(-65.0F, 0.0F, 404894498), markers);
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        long active = this.signalMasks.keySet().stream().filter(this::isActive).count();
        long growth = this.signalMasks.entrySet().stream().filter(e -> (e.getValue() & 192) != 0).count();
        long live = this.signalMasks.keySet().stream().filter(this::isActivityRecent).count();
        return List.of(
            "State: " + (this.isEnabled() ? "Enabled" : "Disabled"),
            "Flagged chunks: " + active,
            "Growth signals: " + growth + "  Live: " + live,
            "Radius: 8 chunks",
            "Expiry: 200 ticks"
        );
    }
}
