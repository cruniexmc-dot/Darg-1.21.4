package dev.darg.client.mixin;

import dev.darg.client.feature.utility.FreecamController;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec2f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({KeyboardInput.class})
public abstract class KeyboardInputMixin {
    @Inject(
        method = {"tick"},
        at = {@At("TAIL")}
    )
    private void dargsclient$stopPlayerMovementDuringFreecam(CallbackInfo callbackInfo) {
        FreecamController controller = FreecamController.getInstance();
        if (controller.isActive()) {
            Input input = (Input)(Object)this;
            if (controller.usesCameraActionSource()) {
                input.playerInput = PlayerInput.DEFAULT;
                ((InputAccessor)input).dargsclient$setMovementVector(Vec2f.ZERO);
            } else {
                if (controller.usesPlayerActionSource()) {
                    input.playerInput = controller.getLatchedPlayerInput();
                    ((InputAccessor)input).dargsclient$setMovementVector(controller.getLatchedMovementVector());
                }
            }
        }
    }
}
