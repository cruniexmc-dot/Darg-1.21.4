package dev.darg.client.feature.basefinding;

import dev.darg.client.config.ClientConfig;
import dev.darg.client.config.FeatureSettingParse;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.render.SusChunkFinderRenderUtil;
import dev.darg.client.render.WorldRenderUtil;
import dev.darg.client.ui.clickgui.InlineControlRenderer;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.PillagerEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.passive.WanderingTraderEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

public final class SusChunkFinderFeature extends Feature {
    private static final int MIN_SIMULATION_DISTANCE = 4;
    private static final int MAX_SIMULATION_DISTANCE = 16;
    private static final int DEFAULT_SIMULATION_DISTANCE = 8;
    private static final int MIN_SENSITIVITY = 1;
    private static final int MAX_SENSITIVITY = 20;
    private static final int DEFAULT_SENSITIVITY = 3;
    private static final int MIN_ALPHA = 10;
    private static final int MAX_ALPHA = 255;
    private static final int DEFAULT_ALPHA = 80;
    private static final int HIGHLIGHT_EXCESS_THRESHOLD = 3;
    private static final int THREAD_COUNT = Math.max(2, Runtime.getRuntime().availableProcessors() / 2);
    private static final float SLAB_MIN_Y = 63.0F;
    private static final float SLAB_MAX_Y = 63.1F;
    private static final float ROW_STEP = 15.0F;
    private static final float SLIDER_BLOCK_H = 28.0F;
    private static final float SECTION_H = 10.0F;
    private static final float DIV_MARGIN = 6.0F;
    private static final float PADDING_TOP = 8.0F;
    private static final float PADDING_BOTTOM = 10.0F;
    private static final float INLINE_HEIGHT = 240.0F;
    private final ClientConfig config = ClientConfig.getInstance();
    private final ConcurrentHashMap<ChunkPos, SusChunkFinderFeature.ChunkSuspicion> suspiciousChunks = new ConcurrentHashMap<>();
    private final Set<ChunkPos> inFlightChunks = ConcurrentHashMap.newKeySet();
    private final ConcurrentHashMap<ChunkPos, Integer> entityCounts = new ConcurrentHashMap<>();
    private volatile ClientWorld activeWorld;
    private ExecutorService pool;
    private boolean kelpEnabled = true;
    private boolean caveVinesEnabled = true;
    private boolean amethystEnabled = true;
    private boolean vinesEnabled = true;
    private boolean rotatedDeepslateEnabled = true;
    private boolean beehivesEnabled = true;
    private boolean entitiesEnabled = true;
    private int simulationDistance = 8;
    private int sensitivity = 3;
    private int alpha = 80;
    private int draggingSlider = -1;
    private int lastRenderedChunks = 0;
    private int lastRenderedBlocks = 0;

    public SusChunkFinderFeature() {
        super("Sus Chunk Finder", Category.BASEFINDING);
        this.reloadFromConfig();
        ClientChunkEvents.CHUNK_LOAD.register(this::onChunkLoad);
    }

    private void onChunkLoad(ClientWorld world, WorldChunk chunk) {
        if (this.isEnabled() && this.pool != null && !this.pool.isShutdown() && this.activeWorld == world) {
            if (this.hasEnabledBlockSignals()) {
                MinecraftClient client = MinecraftClient.getInstance();
                if (client.player != null) {
                    ChunkPos pos = chunk.getPos();
                    int playerChunkX = client.player.getChunkPos().x;
                    int playerChunkZ = client.player.getChunkPos().z;
                    if (Math.abs(pos.x - playerChunkX) <= this.simulationDistance
                        && Math.abs(pos.z - playerChunkZ) <= this.simulationDistance) {
                        if (!this.inFlightChunks.contains(pos) && !chunk.isEmpty()) {
                            int bottomSectionCoord = world.getBottomSectionCoord();
                            this.inFlightChunks.add(pos);
                            this.pool.submit(() -> this.runScanTask(pos, chunk, bottomSectionCoord));
                        }
                    }
                }
            }
        }
    }

    private void reloadFromConfig() {
        String k = this.getConfigKey();
        this.simulationDistance = FeatureSettingParse.parseInt(this.config.getFeatureSetting(k, "simulation_distance"), 8, 4, 16);
        this.sensitivity = FeatureSettingParse.parseInt(this.config.getFeatureSetting(k, "sensitivity"), 3, 1, 20);
        this.alpha = FeatureSettingParse.parseInt(this.config.getFeatureSetting(k, "alpha"), 80, 10, 255);
        this.kelpEnabled = FeatureSettingParse.parseBool(this.config.getFeatureSetting(k, "kelp"), true);
        this.caveVinesEnabled = FeatureSettingParse.parseBool(this.config.getFeatureSetting(k, "cave_vines"), true);
        this.amethystEnabled = FeatureSettingParse.parseBool(this.config.getFeatureSetting(k, "amethyst"), true);
        this.vinesEnabled = FeatureSettingParse.parseBool(this.config.getFeatureSetting(k, "vines"), true);
        this.rotatedDeepslateEnabled = FeatureSettingParse.parseBool(this.config.getFeatureSetting(k, "rotated_deepslate"), true);
        this.beehivesEnabled = FeatureSettingParse.parseBool(this.config.getFeatureSetting(k, "beehives"), true);
        this.entitiesEnabled = FeatureSettingParse.parseBool(this.config.getFeatureSetting(k, "entities"), true);
        if (this.config.getFeatureSetting(k, "sensitivity").isEmpty()) {
            this.persistSettings();
        }
    }

    private void persistSettings() {
        String k = this.getConfigKey();
        this.config.setFeatureSetting(k, "simulation_distance", Integer.toString(this.simulationDistance));
        this.config.setFeatureSetting(k, "sensitivity", Integer.toString(this.sensitivity));
        this.config.setFeatureSetting(k, "alpha", Integer.toString(this.alpha));
        this.config.setFeatureSetting(k, "kelp", Boolean.toString(this.kelpEnabled));
        this.config.setFeatureSetting(k, "cave_vines", Boolean.toString(this.caveVinesEnabled));
        this.config.setFeatureSetting(k, "amethyst", Boolean.toString(this.amethystEnabled));
        this.config.setFeatureSetting(k, "vines", Boolean.toString(this.vinesEnabled));
        this.config.setFeatureSetting(k, "rotated_deepslate", Boolean.toString(this.rotatedDeepslateEnabled));
        this.config.setFeatureSetting(k, "beehives", Boolean.toString(this.beehivesEnabled));
        this.config.setFeatureSetting(k, "entities", Boolean.toString(this.entitiesEnabled));
        this.config.save();
    }

    @Override
    protected void onEnable() {
        if (this.pool == null || this.pool.isShutdown()) {
            this.pool = Executors.newFixedThreadPool(THREAD_COUNT);
        }
    }

    @Override
    protected void onDisable() {
        if (this.pool != null) {
            this.pool.shutdownNow();
            this.pool = null;
        }

        this.suspiciousChunks.clear();
        this.inFlightChunks.clear();
        this.entityCounts.clear();
        this.activeWorld = null;
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientWorld world = client.world;
        if (world == null || client.player == null) {
            this.suspiciousChunks.clear();
            this.inFlightChunks.clear();
            this.entityCounts.clear();
            this.activeWorld = null;
        } else if (!this.hasEnabledSignals()) {
            this.suspiciousChunks.clear();
            this.inFlightChunks.clear();
            this.entityCounts.clear();
        } else {
            if (this.activeWorld != world) {
                this.activeWorld = world;
                this.suspiciousChunks.clear();
                this.inFlightChunks.clear();
                this.entityCounts.clear();
                if (this.pool == null || this.pool.isShutdown()) {
                    this.pool = Executors.newFixedThreadPool(THREAD_COUNT);
                }
            }

            int playerChunkX = client.player.getChunkPos().x;
            int playerChunkZ = client.player.getChunkPos().z;
            this.suspiciousChunks
                .keySet()
                .removeIf(
                    pos -> Math.abs(pos.x - playerChunkX) > this.simulationDistance
                            || Math.abs(pos.z - playerChunkZ) > this.simulationDistance
                );
            if (this.hasEnabledBlockSignals()) {
                int bottomSectionCoord = world.getBottomSectionCoord();

                for (int dx = -this.simulationDistance; dx <= this.simulationDistance; dx++) {
                    for (int dz = -this.simulationDistance; dz <= this.simulationDistance; dz++) {
                        ChunkPos pos = new ChunkPos(playerChunkX + dx, playerChunkZ + dz);
                        if (!this.inFlightChunks.contains(pos) && world.isChunkLoaded(pos.x, pos.z)) {
                            WorldChunk chunk = world.getChunk(pos.x, pos.z);
                            if (chunk != null && !chunk.isEmpty()) {
                                this.inFlightChunks.add(pos);
                                this.pool.submit(() -> this.runScanTask(pos, chunk, bottomSectionCoord));
                            } else {
                                this.suspiciousChunks.remove(pos);
                            }
                        }
                    }
                }
            }

            if (this.entitiesEnabled) {
                ConcurrentHashMap<ChunkPos, Integer> newEntityCounts = new ConcurrentHashMap<>();
                double px = client.player.getX();
                double pz = client.player.getZ();
                double range = (double)this.simulationDistance * 16.0;
                Box scanBox = new Box(
                    px - range, (double)world.getBottomY(), pz - range, px + range, (double)(world.getBottomY() + world.getHeight()), pz + range
                );
                world.getEntitiesByClass(
                        LivingEntity.class,
                        scanBox,
                        entity -> entity instanceof VillagerEntity
                                || entity instanceof WanderingTraderEntity
                                || entity instanceof PillagerEntity
                                || entity instanceof IronGolemEntity
                    )
                    .forEach(entity -> {
                        ChunkPos cp = new ChunkPos(entity.getBlockPos());
                        newEntityCounts.merge(cp, 1, Integer::sum);
                    });
                this.entityCounts.clear();
                this.entityCounts.putAll(newEntityCounts);
            } else {
                this.entityCounts.clear();
            }
        }
    }

    private void runScanTask(ChunkPos pos, WorldChunk chunk, int bottomSectionCoord) {
        try {
            SusChunkFinderFeature.ChunkSuspicion suspicion = this.scanChunk(pos, chunk, bottomSectionCoord);
            if (suspicion == null) {
                this.suspiciousChunks.remove(pos);
            } else {
                this.suspiciousChunks.put(pos, suspicion);
            }
        } finally {
            this.inFlightChunks.remove(pos);
        }
    }

    private SusChunkFinderFeature.ChunkSuspicion scanChunk(ChunkPos chunkPos, WorldChunk chunk, int bottomSectionCoord) {
        ChunkSection[] sections = chunk.getSectionArray();
        int kelpCount = 0;
        int caveVinesCount = 0;
        int amethystCount = 0;
        int vinesCount = 0;
        int rotatedDeepslateCount = 0;
        int beehiveCount = 0;
        Set<BlockPos> matchedPositions = new LinkedHashSet<>();

        for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
            ChunkSection section = sections[sectionIndex];
            if (section != null && !section.isEmpty() && this.sectionHasPotentialMatches(section)) {
                int sectionBaseY = ChunkSectionPos.getBlockCoord(bottomSectionCoord + sectionIndex);

                for (int localX = 0; localX < 16; localX++) {
                    for (int localY = 0; localY < 16; localY++) {
                        int worldY = sectionBaseY + localY;

                        for (int localZ = 0; localZ < 16; localZ++) {
                            BlockState state = section.getBlockState(localX, localY, localZ);
                            if (this.kelpEnabled && SuspiciousBlockHeuristics.isKelp(state)) {
                                kelpCount++;
                                matchedPositions.add(new BlockPos(chunkPos.getStartX() + localX, worldY, chunkPos.getStartZ() + localZ));
                            } else if (this.caveVinesEnabled && SuspiciousBlockHeuristics.isCaveVine(state)) {
                                caveVinesCount++;
                                matchedPositions.add(new BlockPos(chunkPos.getStartX() + localX, worldY, chunkPos.getStartZ() + localZ));
                            } else if (this.vinesEnabled && SuspiciousBlockHeuristics.isVine(state)) {
                                vinesCount++;
                                matchedPositions.add(new BlockPos(chunkPos.getStartX() + localX, worldY, chunkPos.getStartZ() + localZ));
                            } else if (this.amethystEnabled && SuspiciousBlockHeuristics.isAmethystGrowth(state)) {
                                amethystCount++;
                                matchedPositions.add(new BlockPos(chunkPos.getStartX() + localX, worldY, chunkPos.getStartZ() + localZ));
                            } else if (this.beehivesEnabled && SuspiciousBlockHeuristics.isBeehive(state)) {
                                beehiveCount++;
                                matchedPositions.add(new BlockPos(chunkPos.getStartX() + localX, worldY, chunkPos.getStartZ() + localZ));
                            } else if (this.rotatedDeepslateEnabled && worldY >= 0 && worldY <= 60 && SuspiciousBlockHeuristics.isRotatedDeepslate(state)) {
                                rotatedDeepslateCount++;
                                matchedPositions.add(new BlockPos(chunkPos.getStartX() + localX, worldY, chunkPos.getStartZ() + localZ));
                            }
                        }
                    }
                }
            }
        }

        int rawScore = kelpCount + caveVinesCount + amethystCount + vinesCount + rotatedDeepslateCount + beehiveCount;
        if (rawScore == 0) {
            return null;
        } else {
            int excessScore = Math.max(0, rawScore - this.sensitivity);
            return new SusChunkFinderFeature.ChunkSuspicion(
                chunkPos,
                rawScore,
                excessScore,
                List.copyOf(matchedPositions),
                kelpCount,
                caveVinesCount,
                amethystCount,
                vinesCount,
                rotatedDeepslateCount,
                beehiveCount
            );
        }
    }

    private boolean sectionHasPotentialMatches(ChunkSection section) {
        return section.hasAny(
            state -> {
                if (this.kelpEnabled && SuspiciousBlockHeuristics.isKelp(state)) {
                    return true;
                } else if (this.caveVinesEnabled && SuspiciousBlockHeuristics.isCaveVine(state)) {
                    return true;
                } else if (this.vinesEnabled && SuspiciousBlockHeuristics.isVine(state)) {
                    return true;
                } else if (this.amethystEnabled && SuspiciousBlockHeuristics.isAmethystGrowth(state)) {
                    return true;
                } else {
                    return this.beehivesEnabled && state.isOf(Blocks.BEEHIVE)
                        ? true
                        : this.rotatedDeepslateEnabled && state.isOf(Blocks.DEEPSLATE);
                }
            }
        );
    }

    private boolean hasEnabledBlockSignals() {
        return this.kelpEnabled || this.caveVinesEnabled || this.amethystEnabled || this.vinesEnabled || this.rotatedDeepslateEnabled || this.beehivesEnabled;
    }

    private boolean hasEnabledSignals() {
        return this.hasEnabledBlockSignals() || this.entitiesEnabled;
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world != null && client.player != null) {
            boolean hasBlocks = !this.suspiciousChunks.isEmpty();
            boolean hasEntities = this.entitiesEnabled && !this.entityCounts.isEmpty();
            if (!hasBlocks && !hasEntities) {
                this.lastRenderedChunks = 0;
                this.lastRenderedBlocks = 0;
            } else {
                int slabColor = WorldRenderUtil.argb(this.alpha, 255, 0, 0);
                int blockColor = WorldRenderUtil.argb(this.alpha, 0, 255, 255);
                List<SusChunkFinderRenderUtil.ChunkSlab> slabs = new ArrayList<>();
                List<SusChunkFinderRenderUtil.BlockHighlight> highlights = new ArrayList<>();
                Set<ChunkPos> candidates = new LinkedHashSet<>();
                if (hasBlocks) {
                    candidates.addAll(this.suspiciousChunks.keySet());
                }

                if (hasEntities) {
                    candidates.addAll(this.entityCounts.keySet());
                }

                for (ChunkPos pos : candidates) {
                    SusChunkFinderFeature.ChunkSuspicion blockSuspicion = this.suspiciousChunks.get(pos);
                    int blockRaw = blockSuspicion != null ? blockSuspicion.rawScore() : 0;
                    int entityRaw = this.entitiesEnabled ? this.entityCounts.getOrDefault(pos, 0) : 0;
                    int mergedRaw = blockRaw + entityRaw;
                    if (mergedRaw > this.sensitivity) {
                        int mergedExcess = mergedRaw - this.sensitivity;
                        slabs.add(new SusChunkFinderRenderUtil.ChunkSlab(pos, 63.0F, 63.1F, slabColor));
                        if (blockSuspicion != null && mergedExcess >= 3) {
                            for (BlockPos bp : blockSuspicion.blockPositions()) {
                                highlights.add(new SusChunkFinderRenderUtil.BlockHighlight(bp, blockColor));
                            }
                        }
                    }
                }

                this.lastRenderedChunks = slabs.size();
                this.lastRenderedBlocks = highlights.size();
                SusChunkFinderRenderUtil.render(context, client, slabs, highlights);
            }
        } else {
            this.lastRenderedChunks = 0;
            this.lastRenderedBlocks = 0;
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        long highScore = this.suspiciousChunks.values().stream().filter(s -> s.excessScore() >= 3).count();
        return List.of(
            "State: " + (this.isEnabled() ? "Enabled" : "Disabled"),
            "Flagged: " + this.suspiciousChunks.size() + "  High-score: " + highScore,
            "Rendered: " + this.lastRenderedChunks + " chunks / " + this.lastRenderedBlocks + " blocks",
            "Distance: " + this.simulationDistance + " chunks",
            "Sensitivity: " + this.sensitivity + "  Alpha: " + this.alpha
        );
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 240.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        float cx = x + 10.0F;
        float cw = width - 20.0F;
        float rowY = y + 8.0F;
        if (this.draggingSlider == 0) {
            this.setSimulationDistanceFromMouse((double)mouseX, cx, cw);
        } else if (this.draggingSlider == 1) {
            this.setSensitivityFromMouse((double)mouseX, cx, cw);
        } else if (this.draggingSlider == 2) {
            this.setAlphaFromMouse((double)mouseX, cx, cw);
        }

        RenderUtil.drawText(context, textRenderer, "SIGNALS", cx, rowY, theme.mutedGray());
        rowY += 10.0F;
        drawToggle(context, textRenderer, theme, "KELP", this.kelpEnabled, mouseX, mouseY, cx, rowY, cw);
        rowY += 15.0F;
        drawToggle(context, textRenderer, theme, "CAVE VINES", this.caveVinesEnabled, mouseX, mouseY, cx, rowY, cw);
        rowY += 15.0F;
        drawToggle(context, textRenderer, theme, "AMETHYST", this.amethystEnabled, mouseX, mouseY, cx, rowY, cw);
        rowY += 15.0F;
        drawToggle(context, textRenderer, theme, "VINES", this.vinesEnabled, mouseX, mouseY, cx, rowY, cw);
        rowY += 15.0F;
        drawToggle(context, textRenderer, theme, "ROTATED DEEPSLATE", this.rotatedDeepslateEnabled, mouseX, mouseY, cx, rowY, cw);
        rowY += 15.0F;
        drawToggle(context, textRenderer, theme, "BEEHIVES", this.beehivesEnabled, mouseX, mouseY, cx, rowY, cw);
        rowY += 15.0F;
        drawToggle(context, textRenderer, theme, "ENTITIES", this.entitiesEnabled, mouseX, mouseY, cx, rowY, cw);
        rowY += 15.0F;
        rowY += 6.0F;
        RenderUtil.drawRoundedRect(context, cx, rowY, cw, 1.0F, 0.5F, theme.moduleButtonActionFill());
        rowY += 7.0F;
        RenderUtil.drawText(context, textRenderer, "SETTINGS", cx, rowY, theme.mutedGray());
        rowY += 10.0F;
        InlineControlRenderer.drawSlider(
            context, textRenderer, theme, "SIMULATION DISTANCE", this.simulationDistance + " ch", cx, rowY, cw, (float)(this.simulationDistance - 4) / 12.0F
        );
        rowY += 28.0F;
        InlineControlRenderer.drawSlider(
            context, textRenderer, theme, "SENSITIVITY", Integer.toString(this.sensitivity), cx, rowY, cw, (float)(this.sensitivity - 1) / 19.0F
        );
        rowY += 28.0F;
        InlineControlRenderer.drawSlider(context, textRenderer, theme, "ALPHA", Integer.toString(this.alpha), cx, rowY, cw, (float)(this.alpha - 10) / 245.0F);
    }

    private static void drawToggle(
        DrawContext context, TextRenderer textRenderer, ClientTheme theme, String label, boolean enabled, int mouseX, int mouseY, float x, float y, float w
    ) {
        boolean hovered = InlineControlRenderer.containsToggle((double)mouseX, (double)mouseY, x, y, w);
        InlineControlRenderer.drawToggle(context, textRenderer, theme, label, enabled, hovered, x, y, w);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (button != 0) {
            return this.containsInline(mouseX, mouseY, x, y, width);
        } else {
            float cx = x + 10.0F;
            float cw = width - 20.0F;
            float rowY = y + 8.0F;
            rowY += 10.0F;
            if (InlineControlRenderer.containsToggle(mouseX, mouseY, cx, rowY, cw)) {
                this.kelpEnabled = !this.kelpEnabled;
                this.onSettingsChanged();
                return true;
            } else {
                rowY += 15.0F;
                if (InlineControlRenderer.containsToggle(mouseX, mouseY, cx, rowY, cw)) {
                    this.caveVinesEnabled = !this.caveVinesEnabled;
                    this.onSettingsChanged();
                    return true;
                } else {
                    rowY += 15.0F;
                    if (InlineControlRenderer.containsToggle(mouseX, mouseY, cx, rowY, cw)) {
                        this.amethystEnabled = !this.amethystEnabled;
                        this.onSettingsChanged();
                        return true;
                    } else {
                        rowY += 15.0F;
                        if (InlineControlRenderer.containsToggle(mouseX, mouseY, cx, rowY, cw)) {
                            this.vinesEnabled = !this.vinesEnabled;
                            this.onSettingsChanged();
                            return true;
                        } else {
                            rowY += 15.0F;
                            if (InlineControlRenderer.containsToggle(mouseX, mouseY, cx, rowY, cw)) {
                                this.rotatedDeepslateEnabled = !this.rotatedDeepslateEnabled;
                                this.onSettingsChanged();
                                return true;
                            } else {
                                rowY += 15.0F;
                                if (InlineControlRenderer.containsToggle(mouseX, mouseY, cx, rowY, cw)) {
                                    this.beehivesEnabled = !this.beehivesEnabled;
                                    this.onSettingsChanged();
                                    return true;
                                } else {
                                    rowY += 15.0F;
                                    if (InlineControlRenderer.containsToggle(mouseX, mouseY, cx, rowY, cw)) {
                                        this.entitiesEnabled = !this.entitiesEnabled;
                                        this.onSettingsChanged();
                                        return true;
                                    } else {
                                        rowY += 15.0F;
                                        rowY += 13.0F;
                                        rowY += 10.0F;
                                        if (InlineControlRenderer.containsSlider(mouseX, mouseY, cx, rowY, cw)) {
                                            this.draggingSlider = 0;
                                            this.setSimulationDistanceFromMouse(mouseX, cx, cw);
                                            return true;
                                        } else {
                                            rowY += 28.0F;
                                            if (InlineControlRenderer.containsSlider(mouseX, mouseY, cx, rowY, cw)) {
                                                this.draggingSlider = 1;
                                                this.setSensitivityFromMouse(mouseX, cx, cw);
                                                return true;
                                            } else {
                                                rowY += 28.0F;
                                                if (InlineControlRenderer.containsSlider(mouseX, mouseY, cx, rowY, cw)) {
                                                    this.draggingSlider = 2;
                                                    this.setAlphaFromMouse(mouseX, cx, cw);
                                                    return true;
                                                } else {
                                                    return this.containsInline(mouseX, mouseY, x, y, width);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Override
    public boolean onCustomClickGuiMouseReleased(double mouseX, double mouseY, int button, float x, float y, float width) {
        if (button == 0 && this.draggingSlider >= 0) {
            this.draggingSlider = -1;
            this.onSettingsChanged();
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isClickGuiInteractionActive() {
        return this.draggingSlider >= 0;
    }

    private void onSettingsChanged() {
        this.persistSettings();
        this.suspiciousChunks.clear();
        this.inFlightChunks.clear();
        this.entityCounts.clear();
    }

    private boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + 240.0F);
    }

    private void setSimulationDistanceFromMouse(double mouseX, float x, float width) {
        float ratio = MathHelper.clamp((float)((mouseX - (double)x) / (double)width), 0.0F, 1.0F);
        this.simulationDistance = MathHelper.clamp(4 + Math.round(ratio * 12.0F), 4, 16);
    }

    private void setSensitivityFromMouse(double mouseX, float x, float width) {
        float ratio = MathHelper.clamp((float)((mouseX - (double)x) / (double)width), 0.0F, 1.0F);
        this.sensitivity = MathHelper.clamp(1 + Math.round(ratio * 19.0F), 1, 20);
    }

    private void setAlphaFromMouse(double mouseX, float x, float width) {
        float ratio = MathHelper.clamp((float)((mouseX - (double)x) / (double)width), 0.0F, 1.0F);
        this.alpha = MathHelper.clamp(10 + Math.round(ratio * 245.0F), 10, 255);
    }

    private static record ChunkSuspicion(
        ChunkPos pos,
        int rawScore,
        int excessScore,
        List<BlockPos> blockPositions,
        int kelpCount,
        int caveVinesCount,
        int amethystCount,
        int vinesCount,
        int rotatedDeepslateCount,
        int beehiveCount
    ) {
    }
}
