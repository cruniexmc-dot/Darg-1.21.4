package dev.darg.client.feature.utility;

import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import java.util.List;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;

public final class FakeStatsFeature extends Feature {
    private static final int WHITE = -1;
    private static final int SOFT_GRAY = -4671304;
    private static final int MUTED_GRAY = -8750470;
    private static final int PANEL_LIGHT = -14013903;
    private static final int PANEL_HOVER = -13553352;
    private static final int ACCENT = -3365;
    private static final float HEADER_HEIGHT = 42.0F;
    private static final float EMPTY_HEIGHT = 24.0F;
    private static final float ROW_HEIGHT = 18.0F;
    private static final float ROW_GAP = 3.0F;
    private static final float FOOTER_HEIGHT = 36.0F;
    private static final int MAX_VISIBLE_ROWS = 6;
    private static final int MAX_VALUE_LENGTH = 32;
    private final ClientConfig config = ClientConfig.getInstance();
    private String focusedKey;
    private String editingValue = "";

    public FakeStatsFeature() {
        super("FakeStats", Category.SETTINGS);
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        int rows = Math.max(1, Math.min(6, this.getVisibleEntries().size()));
        float bodyHeight = this.getVisibleEntries().isEmpty() ? 24.0F : (float)rows * 18.0F + (float)(rows - 1) * 3.0F;
        return 42.0F + bodyHeight + 36.0F;
    }

    @Override
    protected void onEnable() {
        this.focusedKey = null;
        this.editingValue = "";
        DisplaySpoofController.setFakeStatsEnabled(true);
    }

    @Override
    protected void onDisable() {
        this.focusedKey = null;
        this.editingValue = "";
        DisplaySpoofController.setFakeStatsEnabled(false);
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        float contentX = x + 10.0F;
        float contentWidth = width - 20.0F;
        List<DisplaySpoofController.SidebarStatEntry> entries = this.getVisibleEntries();
        RenderUtil.drawText(context, textRenderer, "LIVE SIDEBAR STAT SPOOF", contentX, y + 4.0F, -1);
        RenderUtil.drawText(
            context,
            textRenderer,
            entries.isEmpty() ? "Open a scoreboard to capture lines" : "Click a row to override its current value",
            contentX,
            y + 15.0F,
            -8750470
        );
        float bodyY = y + 26.0F;
        if (entries.isEmpty()) {
            RenderUtil.drawRoundedRect(context, contentX, bodyY, contentWidth, 24.0F, 5.0F, -14013903);
            RenderUtil.drawText(context, textRenderer, "No live sidebar entries detected yet.", contentX + 8.0F, bodyY + 6.0F, -4671304);
        } else {
            for (int i = 0; i < entries.size(); i++) {
                this.renderEntryRow(context, textRenderer, contentX, bodyY + (float)i * 21.0F, contentWidth, mouseX, mouseY, entries.get(i));
            }
        }

        float footerY = bodyY + (entries.isEmpty() ? 24.0F : (float)entries.size() * 18.0F + (float)(entries.size() - 1) * 3.0F);
        RenderUtil.drawText(context, textRenderer, "Backspace empty = use live value again", contentX, footerY + 4.0F, -8750470);
        float resetY = footerY + 16.0F;
        boolean hasOverrides = !this.config.getFakeStatOverrides().isEmpty();
        boolean resetHovered = hasOverrides && contains((double)mouseX, (double)mouseY, contentX, resetY, contentWidth, 16.0F);
        RenderUtil.drawRoundedRect(context, contentX, resetY, contentWidth, 16.0F, 5.0F, resetHovered ? -13553352 : -14013903);
        String resetLabel = hasOverrides ? "RESET ALL OVERRIDES" : "NO OVERRIDES SET";
        int resetColor = hasOverrides ? (resetHovered ? -3365 : -4671304) : -8750470;
        float resetLabelX = contentX + (contentWidth - (float)textRenderer.getWidth(resetLabel)) / 2.0F;
        RenderUtil.drawText(context, textRenderer, resetLabel, resetLabelX, resetY + 4.0F, resetColor);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (!contains(mouseX, mouseY, x, y, width, this.getCustomClickGuiHeight(width))) {
            this.focusedKey = null;
            this.editingValue = "";
            return false;
        } else if (button != 0) {
            return true;
        } else {
            float contentX = x + 10.0F;
            float contentWidth = width - 20.0F;
            float rowY = y + 26.0F;

            for (DisplaySpoofController.SidebarStatEntry entry : this.getVisibleEntries()) {
                if (contains(mouseX, mouseY, contentX, rowY, contentWidth, 18.0F)) {
                    this.focusedKey = entry.key();
                    this.editingValue = this.getDisplayedValue(entry);
                    return true;
                }

                rowY += 21.0F;
            }

            List<DisplaySpoofController.SidebarStatEntry> resetEntries = this.getVisibleEntries();
            float bodyStartY = y + 26.0F;
            float bodyEndY = bodyStartY + (resetEntries.isEmpty() ? 24.0F : (float)resetEntries.size() * 18.0F + (float)(resetEntries.size() - 1) * 3.0F);
            float resetY = bodyEndY + 16.0F;
            if (!this.config.getFakeStatOverrides().isEmpty() && contains(mouseX, mouseY, contentX, resetY, contentWidth, 16.0F)) {
                this.config.clearAllFakeStatOverrides();
                this.config.save();
                this.focusedKey = null;
                this.editingValue = "";
                return true;
            } else {
                this.focusedKey = null;
                this.editingValue = "";
                return true;
            }
        }
    }

    @Override
    public boolean onClickGuiKeyPressed(KeyInput keyInput) {
        if (this.focusedKey == null) {
            return false;
        } else {
            int key = keyInput.key();
            if (key == 256 || key == 257) {
                this.focusedKey = null;
                this.editingValue = "";
                return true;
            } else if (key != 259 && key != 261) {
                return false;
            } else {
                if (!this.editingValue.isEmpty()) {
                    this.editingValue = this.editingValue.substring(0, this.editingValue.length() - 1);
                    this.saveFocusedValue();
                }

                return true;
            }
        }
    }

    @Override
    public boolean onClickGuiCharTyped(CharInput charInput) {
        if (this.focusedKey != null && charInput.isValidChar()) {
            String input = charInput.asString();
            if (input.isBlank() && charInput.codepoint() != 32) {
                return false;
            } else if (this.editingValue.length() >= 32) {
                return true;
            } else {
                this.editingValue = this.editingValue + input;
                this.saveFocusedValue();
                return true;
            }
        } else {
            return false;
        }
    }

    @Override
    public boolean isClickGuiInteractionActive() {
        return this.focusedKey != null;
    }

    @Override
    public List<String> getClickGuiDetails() {
        List<DisplaySpoofController.SidebarStatEntry> entries = DisplaySpoofController.getCapturedSidebarEntries();
        String summary = entries.isEmpty() ? "No live stats captured" : entries.getFirst().label() + ": " + this.getDisplayedValue(entries.getFirst());
        return List.of("State: " + (this.isEnabled() ? "Enabled" : "Disabled"), "Captured: " + entries.size(), summary, "Client-side only");
    }

    @Override
    public String getHudSuffix() {
        int captured = DisplaySpoofController.getCapturedSidebarEntries().size();
        return this.isEnabled() ? captured + " LIVE" : null;
    }

    private void renderEntryRow(
        DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY, DisplaySpoofController.SidebarStatEntry entry
    ) {
        boolean hovered = contains((double)mouseX, (double)mouseY, x, y, width, 18.0F);
        boolean focused = entry.key().equals(this.focusedKey);
        boolean overridden = this.hasOverride(entry.key());
        String label = fit(textRenderer, entry.label(), width * 0.48F);
        String value = fit(textRenderer, this.getDisplayedValue(entry), width * 0.42F);
        int fill = focused ? -13553352 : (hovered ? -13553352 : -14013903);
        RenderUtil.drawRoundedRect(context, x, y, width, 18.0F, 5.0F, fill);
        RenderUtil.drawText(context, textRenderer, label, x + 8.0F, y + 5.0F, -1);
        RenderUtil.drawText(
            context, textRenderer, value, x + width - 8.0F - (float)textRenderer.getWidth(value), y + 5.0F, !focused && !overridden ? -4671304 : -3365
        );
    }

    private List<DisplaySpoofController.SidebarStatEntry> getVisibleEntries() {
        List<DisplaySpoofController.SidebarStatEntry> entries = DisplaySpoofController.getCapturedSidebarEntries();
        return entries.size() <= 6 ? entries : entries.subList(0, 6);
    }

    private boolean hasOverride(String key) {
        return !this.config.getFakeStatOverrides().getOrDefault(key, "").isBlank();
    }

    private String getDisplayedValue(DisplaySpoofController.SidebarStatEntry entry) {
        if (entry.key().equals(this.focusedKey)) {
            return this.editingValue;
        } else {
            String override = this.config.getFakeStatOverrides().getOrDefault(entry.key(), "");
            return override.isBlank() ? entry.currentValue() : override;
        }
    }

    private void saveFocusedValue() {
        if (this.focusedKey != null) {
            if (this.editingValue.isBlank()) {
                this.config.clearFakeStatOverride(this.focusedKey);
            } else {
                this.config.setFakeStatOverride(this.focusedKey, this.editingValue);
                this.editingValue = this.config.getFakeStatOverrides().getOrDefault(this.focusedKey, this.editingValue);
            }

            this.config.save();
        }
    }

    private static boolean contains(double mouseX, double mouseY, float x, float y, float width, float height) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + height);
    }

    private static String fit(TextRenderer textRenderer, String value, float maxWidth) {
        if ((float)textRenderer.getWidth(value) <= maxWidth) {
            return value;
        } else {
            String trimmed = value;

            while (!trimmed.isEmpty() && (float)textRenderer.getWidth(trimmed + "..") > maxWidth) {
                trimmed = trimmed.substring(0, trimmed.length() - 1);
            }

            return trimmed + "..";
        }
    }
}
