package dev.darg.client.feature.utility;

import dev.darg.client.DargsClient;
import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import java.util.List;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;

public final class MediaSpoofFeature extends Feature {
    public static final String DONUT_MEDIA_PREFIX = "\ud83d\udcf9+";
    private static final int WHITE = -1;
    private static final int SOFT_GRAY = -4671304;
    private static final int MUTED_GRAY = -8750470;
    private static final int PANEL_LIGHT = -14013903;
    private static final int PANEL_HOVER = -13553352;
    private static final int ACCENT = -3365;
    private static final float INLINE_HEIGHT = 64.0F;
    private static final int MAX_PREFIX_LENGTH = 32;
    private final ClientConfig config = ClientConfig.getInstance();
    private boolean focused;
    private String spoofPrefix = this.config.getRankSpoofValue();

    public MediaSpoofFeature() {
        super("MediaSpoof", Category.SETTINGS);
    }

    @Override
    public void onTick() {
        if (this.isEnabled()) {
            NameSpoofFeature nameSpoof = DargsClient.getInstance().getFeatureManager().getFeature(NameSpoofFeature.class);
            boolean lock = nameSpoof != null && nameSpoof.isEnabled();
            DisplaySpoofController.setDonutMediaPrefixLock(lock);
            if (lock) {
                this.spoofPrefix = "\ud83d\udcf9+";
                this.focused = false;
            }
        }
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 64.0F;
    }

    @Override
    protected void onEnable() {
        DisplaySpoofController.setDonutMediaPrefixLock(false);
        this.spoofPrefix = this.config.getRankSpoofValue();
        DisplaySpoofController.setRankSpoofEnabled(true);
    }

    @Override
    protected void onDisable() {
        this.focused = false;
        this.spoofPrefix = "";
        DisplaySpoofController.setDonutMediaPrefixLock(false);
        DisplaySpoofController.setRankSpoofEnabled(false);
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        float contentX = x + 10.0F;
        float contentWidth = width - 20.0F;
        float fieldY = y + 32.0F;
        boolean hovered = contains((double)mouseX, (double)mouseY, contentX, fieldY, contentWidth, 16.0F);
        RenderUtil.drawText(context, textRenderer, "DONUT MEDIA PREFIX", contentX, y + 4.0F, -1);
        RenderUtil.drawText(context, textRenderer, "Gradient \ud83d\udcf9+ on tab / nametag; edit below", contentX, y + 14.0F, -8750470);
        RenderUtil.drawText(context, textRenderer, "With NameSpoof on, prefix locks to \ud83d\udcf9+ each tick", contentX, y + 24.0F, -8750470);
        RenderUtil.drawRoundedRect(context, contentX, fieldY, contentWidth, 16.0F, 5.0F, this.focused ? -13553352 : (hovered ? -13553352 : -14013903));
        String fieldText = DisplaySpoofController.isDonutMediaPrefixLocked() ? "\ud83d\udcf9+" : this.spoofPrefix;
        RenderUtil.drawText(
            context, textRenderer, fit(textRenderer, fieldText, contentWidth - 16.0F), contentX + 8.0F, fieldY + 4.0F, this.focused ? -3365 : -4671304
        );
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (!contains(mouseX, mouseY, x, y, width, 64.0F)) {
            this.focused = false;
            return false;
        } else {
            if (button == 0 && !DisplaySpoofController.isDonutMediaPrefixLocked()) {
                this.focused = contains(mouseX, mouseY, x + 10.0F, y + 32.0F, width - 20.0F, 16.0F);
            }

            return true;
        }
    }

    @Override
    public boolean onClickGuiKeyPressed(KeyInput keyInput) {
        if (this.focused && !DisplaySpoofController.isDonutMediaPrefixLocked()) {
            int key = keyInput.key();
            if (key != 256 && key != 257) {
                if ((key == 259 || key == 261) && !this.spoofPrefix.isEmpty()) {
                    this.spoofPrefix = this.spoofPrefix.substring(0, this.spoofPrefix.length() - 1);
                    this.save();
                    return true;
                } else {
                    return false;
                }
            } else {
                this.focused = false;
                return true;
            }
        } else {
            return false;
        }
    }

    @Override
    public boolean onClickGuiCharTyped(CharInput charInput) {
        if (this.focused && !DisplaySpoofController.isDonutMediaPrefixLocked() && charInput.isValidChar()) {
            String input = charInput.asString();
            if (input.isBlank() && charInput.codepoint() != 32) {
                return false;
            } else if (this.spoofPrefix.length() >= 32) {
                return true;
            } else {
                this.spoofPrefix = this.spoofPrefix + input;
                this.save();
                return true;
            }
        } else {
            return false;
        }
    }

    @Override
    public boolean isClickGuiInteractionActive() {
        return this.focused;
    }

    @Override
    public List<String> getClickGuiDetails() {
        String shown = DisplaySpoofController.isDonutMediaPrefixLocked() ? "\ud83d\udcf9+" : this.spoofPrefix;
        return List.of("State: " + (this.isEnabled() ? "Enabled" : "Disabled"), "Prefix: " + shown, "Client-side only");
    }

    @Override
    public String getHudSuffix() {
        if (!this.isEnabled()) {
            return null;
        } else {
            return DisplaySpoofController.isDonutMediaPrefixLocked() ? "\ud83d\udcf9+" : this.spoofPrefix;
        }
    }

    private void save() {
        this.config.setRankSpoofValue(this.spoofPrefix);
        this.config.save();
    }

    private static boolean contains(double mouseX, double mouseY, float x, float y, float width, float height) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + height);
    }

    private static String fit(TextRenderer textRenderer, String value, float maxWidth) {
        if ((float)textRenderer.getWidth(value) <= maxWidth) {
            return value;
        } else {
            String trimmed = value;

            while (!trimmed.isEmpty() && (float)textRenderer.getWidth(trimmed + "..") > maxWidth) {
                trimmed = trimmed.substring(0, trimmed.length() - 1);
            }

            return trimmed + "..";
        }
    }
}
