package dev.darg.client.feature.utility;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import java.util.List;

public final class FreecamActionFeature extends Feature {
    public FreecamActionFeature() {
        super("FreecamAction", Category.UTILITY);
    }

    @Override
    protected void onEnable() {
        FreecamMiningFeature miningFeature = DargsClient.getInstance().getFeatureManager().getFeature(FreecamMiningFeature.class);
        if (miningFeature != null && miningFeature.isEnabled()) {
            miningFeature.setEnabled(false);
        }

        if (!FreecamController.getInstance().enable(FreecamController.ActionSource.PLAYER)) {
            this.setEnabled(false);
        }
    }

    @Override
    protected void onDisable() {
        FreecamController controller = FreecamController.getInstance();
        if (controller.usesPlayerActionSource()) {
            controller.disable();
        }
    }

    @Override
    public void onTick() {
        FreecamController controller = FreecamController.getInstance();
        if (!controller.usesPlayerActionSource()) {
            this.setEnabled(false);
        } else {
            controller.tick();
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        FreecamController controller = FreecamController.getInstance();
        return List.of(
            "State: " + (this.isEnabled() ? "Enabled" : "Disabled"),
            "Camera: Detached flight camera",
            "Actions: Uses the real player crosshair",
            "Use case: Keep acting while the camera moves freely",
            String.format("Speed: %.2f", controller.getSpeed())
        );
    }
}
