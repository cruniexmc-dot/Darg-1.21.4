package dev.darg.client.feature;

import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.basefinding.LightFinderFeature;
import dev.darg.client.feature.basefinding.PacketScannerFeature;
import dev.darg.client.feature.basefinding.SusChunkFinderFeature;
import dev.darg.client.feature.combat.CombatFeatureHooks;
import dev.darg.client.feature.radium.RadiumCombatRegistry;
import dev.darg.client.feature.utility.AreaDiggerFeature;
import dev.darg.client.feature.utility.AutoElytraFlyerFeature;
import dev.darg.client.feature.utility.AutoSprintFeature;
import dev.darg.client.feature.utility.AutoToolFeature;
import dev.darg.client.feature.utility.ConfigManagerFeature;
import dev.darg.client.feature.utility.FakeStatsFeature;
import dev.darg.client.feature.utility.FastPlaceFeature;
import dev.darg.client.feature.utility.FreeLookFeature;
import dev.darg.client.feature.utility.FreecamActionFeature;
import dev.darg.client.feature.utility.FreecamMiningFeature;
import dev.darg.client.feature.utility.HudFeature;
import dev.darg.client.feature.utility.MediaSpoofFeature;
import dev.darg.client.feature.utility.NameSpoofFeature;
import dev.darg.client.feature.utility.SnapTapFeature;
import dev.darg.client.feature.utility.SpawnerProtectFeature;
import dev.darg.client.feature.utility.SpotifyHudFeature;
import dev.darg.client.feature.visual.BlockEspFeature;
import dev.darg.client.feature.visual.ClickGuiFeature;
import dev.darg.client.feature.visual.CoolHatFeature;
import dev.darg.client.feature.visual.DargsAuraFeature;
import dev.darg.client.feature.visual.DroppedItemEspFeature;
import dev.darg.client.feature.visual.FullbrightFeature;
import dev.darg.client.feature.visual.ItemTrajectoriesFeature;
import dev.darg.client.feature.visual.NoRenderFeature;
import dev.darg.client.feature.visual.PlayerEspFeature;
import dev.darg.client.feature.visual.StorageEspFeature;
import dev.darg.client.feature.visual.SwingSpeedFeature;
import dev.darg.client.feature.visual.TargetHudFeature;
import dev.darg.client.feature.visual.ZoomFeature;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.Packet;

public final class FeatureManager {
    private final ClientConfig config = ClientConfig.getInstance();
    private final List<Feature> features = new ArrayList<>();
    private final Map<String, Boolean> persistedEnabledStates = new HashMap<>();
    private boolean bootstrapped = false;
    private boolean pendingConfiguredStateRestore = false;

    public void bootstrapDefaults() {
        if (!this.bootstrapped) {
            this.bootstrapped = true;
            RadiumCombatRegistry.createFeatures().forEach(this::register);
            this.register(new ClickGuiFeature());
            this.register(new AutoSprintFeature());
            this.register(new AutoToolFeature());
            this.register(new FastPlaceFeature());
            this.register(new SnapTapFeature());
            this.register(new AreaDiggerFeature());
            this.register(new AutoElytraFlyerFeature());
            this.register(new ConfigManagerFeature());
            this.register(new FakeStatsFeature());
            this.register(new FreecamMiningFeature());
            this.register(new FreecamActionFeature());
            this.register(new FreeLookFeature());
            this.register(new LightFinderFeature());
            this.register(new SpawnerProtectFeature());
            this.register(new SusChunkFinderFeature());
            this.register(new PacketScannerFeature());
            this.register(new PlayerEspFeature());
            this.register(new CoolHatFeature());
            this.register(new DargsAuraFeature());
            this.register(new FullbrightFeature());
            this.register(new NoRenderFeature());
            this.register(new SwingSpeedFeature());
            this.register(new ZoomFeature());
            this.register(new ItemTrajectoriesFeature());
            this.register(new BlockEspFeature());
            this.register(new StorageEspFeature());
            this.register(new TargetHudFeature());
            this.register(new NameSpoofFeature());
            this.register(new MediaSpoofFeature());
            this.registerEnabled(new DroppedItemEspFeature());
            this.registerEnabled(new HudFeature());
            this.registerEnabled(new SpotifyHudFeature());
            this.pendingConfiguredStateRestore = true;
        }
    }

    public <T extends Feature> T register(T feature) {
        this.features.add(feature);
        return feature;
    }

    public <T extends Feature> T registerEnabled(T feature) {
        this.register(feature);
        feature.setEnabled(true);
        return feature;
    }

    public List<Feature> getFeatures() {
        return Collections.unmodifiableList(this.features);
    }

    public <T extends Feature> T getFeature(Class<T> featureClass) {
        for (Feature feature : this.features) {
            if (featureClass.isInstance(feature)) {
                return featureClass.cast(feature);
            }
        }

        return null;
    }

    public void tick() {
        if (this.pendingConfiguredStateRestore) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null && client.player != null) {
                this.pendingConfiguredStateRestore = false;
                this.applyConfiguredFeatureStates();
            }
        }

        for (Feature feature : this.features) {
            if (feature.isEnabled()) {
                feature.onTick();
            }
        }

        this.persistFeatureStateSnapshot(false);
    }

    public void renderHud(DrawContext context, RenderTickCounter tickCounter) {
        for (Feature feature : this.features) {
            if (feature.isEnabled()) {
                feature.onHudRender(context, tickCounter);
            }
        }
    }

    public void renderWorld(WorldRenderContext context) {
        for (Feature feature : this.features) {
            if (feature.isEnabled()) {
                feature.onWorldRender(context);
            }
        }
    }

    public boolean beforeAttack(MinecraftClient client) {
        for (Feature feature : this.features) {
            if (feature.isEnabled() && feature instanceof CombatFeatureHooks.AttackHook attackHook && attackHook.onBeforeAttack(client)) {
                return true;
            }
        }

        return false;
    }

    public boolean beforeItemUse(MinecraftClient client) {
        for (Feature feature : this.features) {
            if (feature.isEnabled() && feature instanceof CombatFeatureHooks.ItemUseHook itemUseHook && itemUseHook.onBeforeItemUse(client)) {
                return true;
            }
        }

        return false;
    }

    public boolean beforeBlockBreaking(MinecraftClient client, boolean breaking) {
        for (Feature feature : this.features) {
            if (feature.isEnabled()
                && feature instanceof CombatFeatureHooks.BlockBreakingHook blockBreakingHook
                && blockBreakingHook.onBeforeBlockBreaking(client, breaking)) {
                return true;
            }
        }

        return false;
    }

    public boolean onSendPacket(MinecraftClient client, Packet<?> packet) {
        for (Feature feature : this.features) {
            if (feature.isEnabled() && feature instanceof CombatFeatureHooks.PacketSendHook packetSendHook && packetSendHook.onSendPacket(client, packet)) {
                return true;
            }
        }

        return false;
    }

    public void onReceivePacket(MinecraftClient client, Packet<?> packet) {
        for (Feature feature : this.features) {
            if (feature.isEnabled() && feature instanceof CombatFeatureHooks.PacketReceiveHook receiveHook) {
                receiveHook.onReceivePacket(client, packet);
            }
        }
    }

    public void mouseMoved(double deltaX, double deltaY) {
        for (Feature feature : this.features) {
            if (feature.isEnabled()) {
                feature.onMouseMove(deltaX, deltaY);
            }
        }
    }

    public void attackEntity(Entity entity) {
        for (Feature feature : this.features) {
            if (feature.isEnabled()) {
                feature.onAttackEntity(entity);
            }
        }
    }

    public void renderClickGuiOverlay(DrawContext context, int mouseX, int mouseY, float delta) {
        for (Feature feature : this.features) {
            if (shouldHandleClickGui(feature)) {
                feature.onClickGuiRender(context, mouseX, mouseY, delta);
            }
        }
    }

    public boolean clickGuiMouseClicked(double mouseX, double mouseY, int button) {
        for (Feature feature : this.features) {
            if (shouldHandleClickGui(feature) && feature.onClickGuiMouseClicked(mouseX, mouseY, button)) {
                return true;
            }
        }

        return false;
    }

    public boolean clickGuiMouseReleased(double mouseX, double mouseY, int button) {
        for (Feature feature : this.features) {
            if (shouldHandleClickGui(feature) && feature.onClickGuiMouseReleased(mouseX, mouseY, button)) {
                return true;
            }
        }

        return false;
    }

    public boolean clickGuiMouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (Feature feature : this.features) {
            if (shouldHandleClickGui(feature) && feature.onClickGuiMouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount)) {
                return true;
            }
        }

        return false;
    }

    public boolean clickGuiKeyPressed(KeyInput keyInput) {
        for (Feature feature : this.features) {
            if (shouldHandleClickGui(feature) && feature.onClickGuiKeyPressed(keyInput)) {
                return true;
            }
        }

        return false;
    }

    public boolean clickGuiCharTyped(CharInput charInput) {
        for (Feature feature : this.features) {
            if (shouldHandleClickGui(feature) && feature.onClickGuiCharTyped(charInput)) {
                return true;
            }
        }

        return false;
    }

    public boolean hasActiveClickGuiInteraction() {
        for (Feature feature : this.features) {
            if (feature.isClickGuiInteractionActive()) {
                return true;
            }
        }

        return false;
    }

    public void notifyToggle(Feature feature) {
        this.persistFeatureStateSnapshot(false);
        HudFeature hudFeature = this.getFeature(HudFeature.class);
        if (hudFeature != null) {
            hudFeature.pushToggleNotification(feature);
        }
    }

    public void applyConfiguredFeatureStates() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.player != null) {
            this.pendingConfiguredStateRestore = false;
            this.restoreFeatureStates();
            this.persistedEnabledStates.clear();
            this.persistFeatureStateSnapshot(false);
        } else {
            this.pendingConfiguredStateRestore = true;
        }
    }

    public void queueConfiguredFeatureStateRestore() {
        this.pendingConfiguredStateRestore = true;
    }

    public void synchronizeFeatureStatesToConfig() {
        this.persistFeatureStateSnapshot(false);
    }

    private void restoreFeatureStates() {
        for (Feature feature : this.features) {
            if (feature.shouldPersistEnabledState()) {
                Boolean savedState = this.config.getFeatureEnabledState(feature.getConfigKey());
                if (savedState != null) {
                    feature.setEnabled(savedState);
                }
            }
        }
    }

    private void persistFeatureStateSnapshot(boolean forceSave) {
        boolean dirty = forceSave;

        for (Feature feature : this.features) {
            if (feature.shouldPersistEnabledState()) {
                String key = feature.getConfigKey();
                boolean enabled = feature.isEnabled();
                Boolean previous = this.persistedEnabledStates.put(key, enabled);
                this.config.setFeatureEnabledState(key, enabled);
                if (previous == null || previous != enabled) {
                    dirty = true;
                }
            }
        }

        if (dirty) {
            this.config.save();
        }
    }

    private static boolean shouldHandleClickGui(Feature feature) {
        return feature.isEnabled() || feature.isClickGuiInteractionActive();
    }
}
