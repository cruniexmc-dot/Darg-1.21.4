package dev.darg.client;

import dev.darg.client.config.ClientConfig;
import dev.darg.client.input.ClientKeybinds;
import dev.darg.client.render.ClientRenderHooks;

final class ClientBootstrap {
    private static boolean hooksRegistered = false;

    private ClientBootstrap() {
    }

    static void run(DargsClient client) {
        ClientConfig.getInstance();
        ClientKeybinds.register();
        client.getFeatureManager().bootstrapDefaults();
        client.getKeybindManager().initialize(client.getFeatureManager());
        registerClientHooks();
    }

    private static void registerClientHooks() {
        if (!hooksRegistered) {
            hooksRegistered = true;
            ClientRenderHooks.register();
        }
    }
}
