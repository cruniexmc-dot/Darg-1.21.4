package dev.darg.client.mixin;

import dev.darg.client.DargsClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.PacketCallbacks;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientConnection.class})
public abstract class ClientConnectionMixin {
    @Inject(
        method = {"send(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/PacketCallbacks;)V"},
        at = {@At("HEAD")},
        cancellable = true
    )
    private void dargsclient$onSendPacket(Packet<?> packet, PacketCallbacks callbacks, CallbackInfo ci) {
        DargsClient client = DargsClient.getInstance();
        if (client != null && client.getFeatureManager().onSendPacket(MinecraftClient.getInstance(), packet)) {
            ci.cancel();
        }
    }
}
