package dev.darg.client.ui.clickgui;

import dev.darg.client.ui.theme.ClientTheme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class InlineControlRenderer {
    private static final float SWITCH_W = 22.0F;
    private static final float SWITCH_H = 12.0F;
    private static final float SWITCH_KNOB = 10.0F;
    private static final float SLIDER_TRACK_OFFSET = 14.0F;
    private static final float SLIDER_TRACK_H = 2.0F;
    private static final float SLIDER_KNOB_W = 8.0F;
    private static final float SLIDER_KNOB_H = 8.0F;
    private static final float BUTTON_HEIGHT = 16.0F;

    private InlineControlRenderer() {
    }

    public static void drawSlider(
        DrawContext context, TextRenderer textRenderer, Object themeObj, String label, String value, float x, float y, float width, float ratio
    ) {
        ClientTheme theme = themeObj instanceof ClientTheme t ? t : null;
        int textColor = theme != null ? theme.white() : -1;
        int valueColor = theme != null ? theme.softGray() : -5592406;
        int trackColor = theme != null ? theme.clickGuiPanelBorder() : 1291845632;
        int fillColor = theme != null ? theme.accent() : -1;
        float clampedRatio = Math.max(0.0F, Math.min(1.0F, ratio));
        float trackY = y + 14.0F;
        float trackWidth = width - 2.0F;
        float fillWidth = trackWidth * clampedRatio;
        float knobX = x + fillWidth - 4.0F;
        RenderUtil.drawText(context, textRenderer, label, x, y, textColor);
        RenderUtil.drawText(context, textRenderer, value, x + width - (float)RenderUtil.getTextWidth(textRenderer, value), y, valueColor);
        RenderUtil.drawRoundedRect(context, x, trackY, trackWidth, 2.0F, 1.0F, trackColor);
        if (fillWidth > 0.0F) {
            RenderUtil.drawRoundedRect(context, x, trackY, Math.max(2.0F, fillWidth), 2.0F, 1.0F, fillColor);
        }

        RenderUtil.drawRoundedRect(context, knobX, trackY - 3.0F, 8.0F, 8.0F, 4.0F, fillColor);
    }

    public static boolean containsSlider(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)(y + 14.0F - 4.0F) && mouseY <= (double)(y + 14.0F + 8.0F + 4.0F);
    }

    public static void drawToggle(
        DrawContext context, TextRenderer textRenderer, Object themeObj, String label, boolean enabled, boolean hovered, float x, float y, float width
    ) {
        ClientTheme theme = themeObj instanceof ClientTheme t ? t : null;
        int trackBorder = theme != null ? theme.moduleButtonFill() : -13750738;
        int trackFill = theme != null ? (enabled ? theme.accent() : theme.clickGuiPanelBorder()) : 1291845632;
        int labelColor = theme != null ? theme.white() : -1;
        RenderUtil.drawRoundedRect(context, x, y, 22.0F, 12.0F, 6.0F, trackBorder);
        RenderUtil.drawRoundedRect(context, x + 1.0F, y + 1.0F, 20.0F, 10.0F, 5.0F, trackFill);
        float knobX = enabled ? x + 22.0F - 10.0F - 1.0F : x + 1.0F;
        float knobY = y + 1.0F;
        RenderUtil.drawRoundedRect(context, knobX, knobY, 10.0F, 10.0F, 5.0F, theme != null ? theme.white() : -1);
        RenderUtil.drawText(context, textRenderer, label, x + 22.0F + 6.0F, y + 2.0F, labelColor);
    }

    public static boolean containsToggle(double mouseX, double mouseY, float x, float y, float width) {
        return containsBox(mouseX, mouseY, x, y, width, 12.0F);
    }

    public static void drawButton(
        DrawContext context, TextRenderer textRenderer, Object themeObj, String label, boolean active, boolean hovered, float x, float y, float width
    ) {
        ClientTheme theme = themeObj instanceof ClientTheme t ? t : null;
        int fill = theme != null ? (!hovered && !active ? theme.moduleButtonActionFill() : theme.moduleButtonActionHoverFill()) : -14671836;
        int labelColor = theme != null ? theme.white() : -1;
        RenderUtil.drawRoundedRect(context, x, y, width, 16.0F, 6.0F, fill);
        int labelWidth = RenderUtil.getTextWidth(textRenderer, label);
        RenderUtil.drawText(context, textRenderer, label, x + (width - (float)labelWidth) / 2.0F, y + 4.0F, labelColor);
    }

    public static boolean containsButton(double mouseX, double mouseY, float x, float y, float width) {
        return containsBox(mouseX, mouseY, x, y, width, 16.0F);
    }

    public static String fitText(TextRenderer textRenderer, String value, int maxWidth) {
        if (RenderUtil.getTextWidth(textRenderer, value) <= maxWidth) {
            return value;
        } else {
            String ellipsis = "...";
            String trimmed = value;

            while (!trimmed.isEmpty() && RenderUtil.getTextWidth(textRenderer, trimmed + ellipsis) > maxWidth) {
                trimmed = trimmed.substring(0, trimmed.length() - 1);
            }

            return trimmed + ellipsis;
        }
    }

    private static boolean containsBox(double mouseX, double mouseY, float x, float y, float width, float height) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + height);
    }
}
