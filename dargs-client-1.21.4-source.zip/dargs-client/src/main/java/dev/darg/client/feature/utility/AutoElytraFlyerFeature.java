package dev.darg.client.feature.utility;

import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class AutoElytraFlyerFeature extends Feature {
    private static final int WHITE = -1;
    private static final int SOFT_GRAY = -4671304;
    private static final int MUTED_GRAY = -8750470;
    private static final int DARK_TEXT = -15592942;
    private static final int ACCENT = -3365;
    private static final int PANEL_LIGHT = -14013903;
    private static final int PANEL_HOVER = -13553352;
    private static final float INLINE_HEIGHT = 62.0F;
    private static final float BUTTON_HEIGHT = 16.0F;
    private static final float TARGET_TOLERANCE = 2.0F;
    private static final int DEPLOY_COOLDOWN_TICKS = 8;
    private static final int ROCKET_COOLDOWN_TICKS = 26;
    private static final double ASCEND_VELOCITY_ASSIST = 0.038;
    private static final double DESCEND_VELOCITY_ASSIST = 0.03;
    private static final double MAX_ASCEND_SPEED = 0.12;
    private static final double MAX_DESCEND_SPEED = -0.18;
    private static final double MIN_HORIZONTAL_SPEED = 0.85;
    private static final int DEFAULT_MIN_Y = -64;
    private static final int DEFAULT_MAX_Y = 320;
    private final ClientConfig config = ClientConfig.getInstance();
    private int targetY;
    private int lastDeployTick = -8;
    private int lastRocketTick = -26;
    private boolean draggingTargetY;

    public AutoElytraFlyerFeature() {
        super("AutoElytraFlyer", Category.UTILITY);
        this.targetY = this.config.getAutoElytraTargetY();
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 62.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (this.draggingTargetY) {
            this.setTargetYFromMouse((double)mouseX, x, width, client);
        }

        float contentX = x + 10.0F;
        float contentWidth = width - 20.0F;
        float sliderY = y + 14.0F;
        float sliderWidth = contentWidth - 2.0F;
        float fillWidth = sliderWidth * this.getTargetProgress(client);
        float knobX = contentX + fillWidth - 3.0F;
        float buttonY = y + 40.0F;
        boolean hoverButton = containsCurrentYButton((double)mouseX, (double)mouseY, x, y, width);
        String currentYText = client.player == null ? "Current: unavailable" : "Current: " + Math.round(client.player.getY());
        String rocketText = "Rockets: " + this.getRocketCount(client.player);
        RenderUtil.drawText(context, textRenderer, "TARGET Y", contentX, y + 3.0F, -1);
        RenderUtil.drawText(
            context,
            textRenderer,
            Integer.toString(this.targetY),
            x + width - 10.0F - (float)textRenderer.getWidth(Integer.toString(this.targetY)),
            y + 3.0F,
            -4671304
        );
        RenderUtil.drawRoundedRect(context, contentX, sliderY, sliderWidth, 4.0F, 2.0F, -14013903);
        RenderUtil.drawRoundedRect(context, contentX, sliderY, Math.max(4.0F, fillWidth), 4.0F, 2.0F, -3365);
        RenderUtil.drawRoundedRect(context, knobX, sliderY - 3.0F, 8.0F, 10.0F, 4.0F, -3365);
        RenderUtil.drawText(context, textRenderer, currentYText, contentX, y + 24.0F, -4671304);
        RenderUtil.drawText(context, textRenderer, rocketText, x + width - 10.0F - (float)textRenderer.getWidth(rocketText), y + 24.0F, -8750470);
        RenderUtil.drawRoundedRect(context, contentX, buttonY, contentWidth, 16.0F, 5.0F, hoverButton ? -13553352 : -14013903);
        RenderUtil.drawText(context, textRenderer, "USE CURRENT Y", contentX + 8.0F, buttonY + 5.0F, -1);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (button != 0) {
            return containsInline(mouseX, mouseY, x, y, width);
        } else if (containsTargetSlider(mouseX, mouseY, x, y, width)) {
            this.draggingTargetY = true;
            this.setTargetYFromMouse(mouseX, x, width, MinecraftClient.getInstance());
            return true;
        } else if (containsCurrentYButton(mouseX, mouseY, x, y, width)) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player != null) {
                this.targetY = this.clampTargetY(Math.round((float)client.player.getY()), client);
                this.saveTargetY();
                notificationManager.push("AutoElytraFlyer target set to " + this.targetY, NotificationManager.Type.INFO);
            }

            return true;
        } else {
            return containsInline(mouseX, mouseY, x, y, width);
        }
    }

    @Override
    public boolean onCustomClickGuiMouseReleased(double mouseX, double mouseY, int button, float x, float y, float width) {
        if (button == 0 && this.draggingTargetY) {
            this.draggingTargetY = false;
            this.saveTargetY();
            return true;
        } else {
            return false;
        }
    }

    @Override
    protected void onEnable() {
        MinecraftClient client = MinecraftClient.getInstance();
        this.targetY = this.clampTargetY(this.targetY, client);
        this.lastDeployTick = -8;
        this.lastRocketTick = -26;
    }

    @Override
    protected void onDisable() {
        this.draggingTargetY = false;
        this.lastDeployTick = -8;
        this.lastRocketTick = -26;
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player != null) {
            this.targetY = this.clampTargetY(this.targetY, client);
            if (hasUsableElytra(player)) {
                if (this.shouldStartGlide(player)) {
                    player.networkHandler.sendPacket(new ClientCommandC2SPacket(player, Mode.START_FALL_FLYING));
                    this.lastDeployTick = player.age;
                }

                if (player.isGliding()) {
                    this.maintainAltitude(client, player);
                }
            }
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of(
            "Status: Incomplete", "State: " + (this.isEnabled() ? "Enabled" : "Disabled"), "Target Y: " + this.targetY, "Mode: Firework altitude hold"
        );
    }

    private void maintainAltitude(MinecraftClient client, ClientPlayerEntity player) {
        double deltaY = (double)this.targetY - player.getY();
        Vec3d velocity = player.getVelocity();
        double horizontalSpeed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
        if (deltaY > 2.0) {
            double assistedY = Math.min(0.12, velocity.y + 0.038);
            player.setVelocity(velocity.x, assistedY, velocity.z);
            if (this.shouldUseRocket(player, deltaY, horizontalSpeed)) {
                this.useRocket(client, player);
            }
        } else if (deltaY < -2.0) {
            double assistedY = Math.max(-0.18, velocity.y - 0.03);
            player.setVelocity(velocity.x, assistedY, velocity.z);
        } else {
            if (Math.abs(velocity.y) > 0.05) {
                player.setVelocity(velocity.x, velocity.y * 0.7, velocity.z);
            }
        }
    }

    private boolean shouldUseRocket(ClientPlayerEntity player, double deltaY, double horizontalSpeed) {
        if (player.age - this.lastRocketTick < 26) {
            return false;
        } else {
            return deltaY < 4.0 ? false : player.getVelocity().y <= 0.02 || horizontalSpeed < 0.85 || deltaY > 12.0;
        }
    }

    private boolean useRocket(MinecraftClient client, ClientPlayerEntity player) {
        ClientPlayerInteractionManager interactionManager = client.interactionManager;
        if (interactionManager == null) {
            return false;
        } else if (tryUseHandRocket(player, interactionManager, Hand.OFF_HAND)) {
            this.lastRocketTick = player.age;
            return true;
        } else if (tryUseHandRocket(player, interactionManager, Hand.MAIN_HAND)) {
            this.lastRocketTick = player.age;
            return true;
        } else {
            PlayerInventory inventory = player.getInventory();
            int hotbarRocketSlot = findHotbarRocketSlot(inventory);
            if (hotbarRocketSlot >= 0 && useHotbarRocket(player, interactionManager, hotbarRocketSlot)) {
                this.lastRocketTick = player.age;
                return true;
            } else {
                int inventoryRocketSlot = findInventoryRocketSlot(inventory);
                if (inventoryRocketSlot >= 0 && useInventoryRocket(player, interactionManager, inventoryRocketSlot)) {
                    this.lastRocketTick = player.age;
                    return true;
                } else {
                    return false;
                }
            }
        }
    }

    private static boolean tryUseHandRocket(ClientPlayerEntity player, ClientPlayerInteractionManager interactionManager, Hand hand) {
        ItemStack stack = hand == Hand.MAIN_HAND ? player.getMainHandStack() : player.getOffHandStack();
        if (stack.isOf(Items.FIREWORK_ROCKET) && !player.getItemCooldownManager().isCoolingDown(stack)) {
            ActionResult actionResult = interactionManager.interactItem(player, hand);
            return actionResult.isAccepted();
        } else {
            return false;
        }
    }

    private static boolean useHotbarRocket(ClientPlayerEntity player, ClientPlayerInteractionManager interactionManager, int hotbarSlot) {
        PlayerInventory inventory = player.getInventory();
        int previousSlot = inventory.getSelectedSlot();
        if (previousSlot != hotbarSlot) {
            selectHotbarSlot(player, hotbarSlot);
        }

        boolean used = tryUseHandRocket(player, interactionManager, Hand.MAIN_HAND);
        if (previousSlot != hotbarSlot) {
            selectHotbarSlot(player, previousSlot);
        }

        return used;
    }

    private static boolean useInventoryRocket(ClientPlayerEntity player, ClientPlayerInteractionManager interactionManager, int inventorySlot) {
        if (player.currentScreenHandler != player.playerScreenHandler) {
            return false;
        } else {
            PlayerInventory inventory = player.getInventory();
            int hotbarSlot = inventory.getSelectedSlot();
            int screenSlot = inventoryIndexToScreenSlot(inventorySlot);
            interactionManager.clickSlot(player.playerScreenHandler.syncId, screenSlot, hotbarSlot, SlotActionType.SWAP, player);

            boolean used;
            try {
                used = tryUseHandRocket(player, interactionManager, Hand.MAIN_HAND);
            } finally {
                interactionManager.clickSlot(player.playerScreenHandler.syncId, screenSlot, hotbarSlot, SlotActionType.SWAP, player);
            }

            return used;
        }
    }

    private static void selectHotbarSlot(ClientPlayerEntity player, int slot) {
        player.getInventory().setSelectedSlot(slot);
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
    }

    private static int findHotbarRocketSlot(PlayerInventory inventory) {
        for (int slot = 0; slot < PlayerInventory.getHotbarSize(); slot++) {
            if (inventory.getStack(slot).isOf(Items.FIREWORK_ROCKET)) {
                return slot;
            }
        }

        return -1;
    }

    private static int findInventoryRocketSlot(PlayerInventory inventory) {
        for (int slot = PlayerInventory.getHotbarSize(); slot < 36; slot++) {
            if (inventory.getStack(slot).isOf(Items.FIREWORK_ROCKET)) {
                return slot;
            }
        }

        return -1;
    }

    private static int inventoryIndexToScreenSlot(int inventorySlot) {
        return inventorySlot < PlayerInventory.getHotbarSize() ? 36 + inventorySlot : inventorySlot;
    }

    private static boolean hasUsableElytra(ClientPlayerEntity player) {
        ItemStack chestStack = player.getEquippedStack(EquipmentSlot.CHEST);
        return chestStack.isOf(Items.ELYTRA) && chestStack.getDamage() < chestStack.getMaxDamage() - 1;
    }

    private boolean shouldStartGlide(ClientPlayerEntity player) {
        if (player.isOnGround() || player.isGliding() || player.getAbilities().flying || player.isTouchingWater() || player.isSubmergedInWater()) {
            return false;
        } else if (!player.hasVehicle() && !player.isClimbing() && !player.isSwimming()) {
            return player.age - this.lastDeployTick < 8 ? false : player.fallDistance > 1.5 && player.getVelocity().y < -0.1;
        } else {
            return false;
        }
    }

    private int getRocketCount(ClientPlayerEntity player) {
        if (player == null) {
            return 0;
        } else {
            int rockets = 0;
            PlayerInventory inventory = player.getInventory();

            for (int slot = 0; slot < inventory.size(); slot++) {
                ItemStack stack = inventory.getStack(slot);
                if (stack.isOf(Items.FIREWORK_ROCKET)) {
                    rockets += stack.getCount();
                }
            }

            return rockets;
        }
    }

    private void setTargetYFromMouse(double mouseX, float x, float width, MinecraftClient client) {
        float sliderStart = x + 10.0F;
        float sliderWidth = width - 22.0F;
        float ratio = clamp((float)((mouseX - (double)sliderStart) / (double)sliderWidth), 0.0F, 1.0F);
        int minY = getMinTargetY(client);
        int maxY = getMaxTargetY(client);
        this.targetY = Math.round((float)minY + (float)(maxY - minY) * ratio);
    }

    private float getTargetProgress(MinecraftClient client) {
        int minY = getMinTargetY(client);
        int maxY = getMaxTargetY(client);
        return maxY <= minY ? 0.0F : clamp((float)(this.targetY - minY) / (float)(maxY - minY), 0.0F, 1.0F);
    }

    private int clampTargetY(int value, MinecraftClient client) {
        return MathHelper.clamp(value, getMinTargetY(client), getMaxTargetY(client));
    }

    private static int getMinTargetY(MinecraftClient client) {
        return client.world == null ? -64 : client.world.getBottomY();
    }

    private static int getMaxTargetY(MinecraftClient client) {
        return client.world == null ? 320 : client.world.getTopYInclusive();
    }

    private void saveTargetY() {
        this.config.setAutoElytraTargetY(this.targetY);
        this.config.save();
    }

    private static boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + 62.0F);
    }

    private static boolean containsTargetSlider(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)(x + 10.0F) && mouseX <= (double)(x + width - 10.0F) && mouseY >= (double)(y + 10.0F) && mouseY <= (double)(y + 24.0F);
    }

    private static boolean containsCurrentYButton(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)(x + 10.0F) && mouseX <= (double)(x + width - 10.0F) && mouseY >= (double)(y + 40.0F) && mouseY <= (double)(y + 40.0F + 16.0F);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
