package dev.darg.client.feature.utility;

import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.List;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class SnapTapFeature extends Feature {
    private static final float INLINE_HEIGHT = 40.0F;
    public static volatile long leftStrafeLastPressTime;
    public static volatile long rightStrafeLastPressTime;
    public static volatile long forwardStrafeLastPressTime;
    public static volatile long backwardStrafeLastPressTime;

    public SnapTapFeature() {
        super("SnapTap", Category.UTILITY);
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 40.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        float cx = x + 10.0F;
        int sub = theme.softGray();
        RenderUtil.drawText(context, textRenderer, "Uses movement keys A, D, W, S", cx, y + 8.0F, sub);
        RenderUtil.drawText(context, textRenderer, "No extra settings — toggle on/off", cx, y + 22.0F, sub);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        return this.containsInline(mouseX, mouseY, x, y, width);
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("Uses keyboard strafe keys (A D W S)", "No extra options — toggle module on/off");
    }

    private boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + 40.0F);
    }
}
