package dev.darg.client.config;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Map.Entry;
import net.fabricmc.loader.api.FabricLoader;

public final class ClientConfig {
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("dargsclient.properties");
    private static final String DEFAULT_SPOTIFY_CLIENT_ID = "";
    private static final int DEFAULT_AUTO_ELYTRA_TARGET_Y = 160;
    private static final int DEFAULT_BLOCK_ESP_ALPHA = 125;
    private static final boolean DEFAULT_PLAYER_ESP_TRACERS = true;
    private static final boolean DEFAULT_BLOCK_ESP_TRACERS = false;
    private static final String DEFAULT_BLOCK_ESP_SELECTED_BLOCKS = "minecraft:diamond_ore,minecraft:deepslate_diamond_ore";
    private static final float DEFAULT_ZOOM_FACTOR = 4.0F;
    private static final int DEFAULT_AUTO_EAT_THRESHOLD_PERCENT = 60;
    private static final String DEFAULT_AREA_DIGGER_TOOL_MODE = "AUTO";
    private static final boolean DEFAULT_DARGS_AURA_DIRT_BENDING = true;
    private static final float DEFAULT_DARGS_AURA_BLOCK_SPEED = 1.0F;
    private static final String DEFAULT_NAME_SPOOF_VALUE = "Darg";
    private static final String DEFAULT_RANK_SPOOF_VALUE = "\ud83d\udcf9+";
    private static final boolean DEFAULT_HUD_WATERMARK = true;
    private static final boolean DEFAULT_HUD_INFO = true;
    private static final boolean DEFAULT_HUD_MODULES = true;
    private static final boolean DEFAULT_HUD_TIME = true;
    private static final boolean DEFAULT_HUD_COORDINATES = true;
    private static final boolean DEFAULT_HUD_POTIONS = false;
    private static final boolean DEFAULT_HUD_NOTIFICATIONS = true;
    private static final boolean DEFAULT_HUD_RAINBOW = false;
    private static final boolean DEFAULT_HUD_ARMOR_PREVIEW = true;
    private static final boolean DEFAULT_HUD_INVENTORY_PREVIEW = true;
    private static final int DEFAULT_HUD_OPACITY = 190;
    private static final float DEFAULT_HUD_RAINBOW_SPEED = 1.35F;
    private static final int DEFAULT_HUD_NOTIFICATION_DURATION_MS = 3200;
    private static final String DEFAULT_HUD_SORT_MODE = "LONGEST";
    private static final float DEFAULT_HUD_SCALE = 1.0F;
    private static final float DEFAULT_HUD_ARMOR_X = 12.0F;
    private static final float DEFAULT_HUD_ARMOR_Y = 84.0F;
    private static final float DEFAULT_HUD_INVENTORY_X = 12.0F;
    private static final float DEFAULT_HUD_INVENTORY_Y = 132.0F;
    private static final int DEFAULT_AUTO_CRYSTAL_PLACE_DELAY = 2;
    private static final int DEFAULT_AUTO_CRYSTAL_BREAK_DELAY = 2;
    private static final int DEFAULT_AMETHYST_ESP_CLUSTER_THRESHOLD = 10;
    private static final int DEFAULT_SPAWNER_PROTECT_PLAYER_RANGE = 24;
    private static final int DEFAULT_SPAWNER_PROTECT_SPAWNER_RANGE = 10;
    private static final int DEFAULT_SPAWNER_PROTECT_BREAK_DELAY = 5;
    private static final boolean DEFAULT_SPAWNER_PROTECT_DISCONNECT_ON_FAIL = true;
    private static final boolean DEFAULT_SPAWNER_PROTECT_DISCONNECT_WHEN_DONE = true;
    private static final int DEFAULT_ANCHOR_MACRO_EXPLODE_SLOT = 8;
    private static final int DEFAULT_DHAND_MOD_TOTEM_SLOT = 8;
    private static final int DEFAULT_HOVER_TOTEM_SLOT = 8;
    private static final int DEFAULT_AUTO_DOUBLE_HAND_SEARCH_RADIUS = 6;
    private static ClientConfig instance;
    private float spotifyHudX = 18.0F;
    private float spotifyHudY = 58.0F;
    private String spotifyAccessToken = "";
    private String spotifyRefreshToken = "";
    private String spotifyClientId = "";
    private String spotifyClientSecret = "";
    private float zoomFactor = 4.0F;
    private int autoElytraTargetY = 160;
    private int autoEatThresholdPercent = 60;
    private String areaDiggerStart = "";
    private String areaDiggerEnd = "";
    private String areaDiggerToolMode = "AUTO";
    private boolean dargsAuraDirtBending = true;
    private float dargsAuraBlockSpeed = 1.0F;
    private final Map<String, ClientConfig.PanelPosition> clickGuiPanelPositions = new LinkedHashMap<>();
    private final Map<String, String> fakeStatOverrides = new LinkedHashMap<>();
    private final Map<String, String> featureSettingValues = new LinkedHashMap<>();
    private String nameSpoofValue = "Darg";
    private String rankSpoofValue = "\ud83d\udcf9+";
    private int blockEspAlpha = 125;
    private boolean playerEspTracers = true;
    private boolean blockEspTracers = false;
    private final Set<String> blockEspSelectedBlocks = new LinkedHashSet<>();
    private final Map<String, Integer> blockEspBlockColors = new LinkedHashMap<>();
    private boolean hudWatermark = true;
    private boolean hudInfo = true;
    private boolean hudModules = true;
    private boolean hudTime = true;
    private boolean hudCoordinates = true;
    private boolean hudPotions = false;
    private boolean hudNotifications = true;
    private boolean hudRainbow = false;
    private boolean hudArmorPreview = true;
    private boolean hudInventoryPreview = true;
    private int hudOpacity = 190;
    private float hudRainbowSpeed = 1.35F;
    private int hudNotificationDurationMs = 3200;
    private String hudSortMode = "LONGEST";
    private float hudScale = 1.0F;
    private float hudArmorX = 12.0F;
    private float hudArmorY = 84.0F;
    private float hudInventoryX = 12.0F;
    private float hudInventoryY = 132.0F;
    private int autoCrystalPlaceDelay = 2;
    private int autoCrystalBreakDelay = 2;
    private int amethystEspClusterThreshold = 10;
    private int spawnerProtectPlayerRange = 24;
    private int spawnerProtectSpawnerRange = 10;
    private int spawnerProtectBreakDelay = 5;
    private boolean spawnerProtectDisconnectOnFail = true;
    private boolean spawnerProtectDisconnectWhenDone = true;
    private int anchorMacroExplodeSlot = 8;
    private int dhandModTotemSlot = 8;
    private int hoverTotemSlot = 8;
    private int autoDoubleHandSearchRadius = 6;
    private final Map<String, String> featureBinds = new LinkedHashMap<>();
    private final Map<String, Boolean> featureEnabledStates = new LinkedHashMap<>();

    private ClientConfig() {
        this.load();
    }

    public static synchronized ClientConfig getInstance() {
        if (instance == null) {
            instance = new ClientConfig();
        }

        return instance;
    }

    public synchronized float getSpotifyHudX() {
        return this.spotifyHudX;
    }

    public synchronized float getSpotifyHudY() {
        return this.spotifyHudY;
    }

    public synchronized void setSpotifyHudPosition(float x, float y) {
        this.spotifyHudX = x;
        this.spotifyHudY = y;
    }

    public synchronized ClientConfig.SpotifyCredentials getSpotifyCredentials() {
        return new ClientConfig.SpotifyCredentials(this.spotifyAccessToken, this.spotifyRefreshToken, this.spotifyClientId, this.spotifyClientSecret);
    }

    public synchronized void setSpotifyAccessToken(String accessToken) {
        this.spotifyAccessToken = sanitize(accessToken);
    }

    public synchronized void setSpotifyRefreshToken(String refreshToken) {
        this.spotifyRefreshToken = sanitize(refreshToken);
    }

    public synchronized void setSpotifyClientId(String clientId) {
        this.spotifyClientId = sanitize(clientId);
    }

    public synchronized void setSpotifySession(String accessToken, String refreshToken) {
        this.spotifyAccessToken = sanitize(accessToken);
        this.spotifyRefreshToken = sanitize(refreshToken);
    }

    public synchronized void clearSpotifySession() {
        this.spotifyAccessToken = "";
        this.spotifyRefreshToken = "";
    }

    public synchronized boolean isPlayerEspTracersEnabled() {
        return this.playerEspTracers;
    }

    public synchronized void setPlayerEspTracersEnabled(boolean enabled) {
        this.playerEspTracers = enabled;
    }

    public synchronized int getBlockEspAlpha() {
        return this.blockEspAlpha;
    }

    public synchronized float getZoomFactor() {
        return this.zoomFactor;
    }

    public synchronized void setZoomFactor(float factor) {
        this.zoomFactor = Math.max(2.0F, Math.min(10.0F, factor));
    }

    public synchronized int getAutoElytraTargetY() {
        return this.autoElytraTargetY;
    }

    public synchronized void setAutoElytraTargetY(int targetY) {
        this.autoElytraTargetY = Math.max(-64, Math.min(320, targetY));
    }

    public synchronized int getAutoEatThresholdPercent() {
        return this.autoEatThresholdPercent;
    }

    public synchronized void setAutoEatThresholdPercent(int thresholdPercent) {
        this.autoEatThresholdPercent = Math.max(5, Math.min(100, thresholdPercent));
    }

    public synchronized String getAreaDiggerStart() {
        return this.areaDiggerStart;
    }

    public synchronized void setAreaDiggerStart(String value) {
        this.areaDiggerStart = sanitize(value);
    }

    public synchronized String getAreaDiggerEnd() {
        return this.areaDiggerEnd;
    }

    public synchronized void setAreaDiggerEnd(String value) {
        this.areaDiggerEnd = sanitize(value);
    }

    public synchronized String getAreaDiggerToolMode() {
        return this.areaDiggerToolMode;
    }

    public synchronized void setAreaDiggerToolMode(String value) {
        String sanitized = sanitize(value);
        this.areaDiggerToolMode = sanitized.isEmpty() ? "AUTO" : sanitized;
    }

    public synchronized boolean isDargsAuraDirtBendingEnabled() {
        return this.dargsAuraDirtBending;
    }

    public synchronized void setDargsAuraDirtBendingEnabled(boolean enabled) {
        this.dargsAuraDirtBending = enabled;
    }

    public synchronized float getDargsAuraBlockSpeed() {
        return this.dargsAuraBlockSpeed;
    }

    public synchronized void setDargsAuraBlockSpeed(float speed) {
        this.dargsAuraBlockSpeed = Math.max(0.35F, Math.min(2.5F, speed));
    }

    public synchronized ClientConfig.PanelPosition getClickGuiPanelPosition(String panelKey) {
        String sanitizedKey = sanitize(panelKey).toLowerCase(Locale.ROOT);
        return sanitizedKey.isEmpty() ? null : this.clickGuiPanelPositions.get(sanitizedKey);
    }

    public synchronized void setClickGuiPanelPosition(String panelKey, float x, float y, float width) {
        String sanitizedKey = sanitize(panelKey).toLowerCase(Locale.ROOT);
        if (!sanitizedKey.isEmpty()) {
            this.clickGuiPanelPositions.put(sanitizedKey, new ClientConfig.PanelPosition(x, y, width));
        }
    }

    public synchronized Map<String, String> getFakeStatOverrides() {
        return new LinkedHashMap<>(this.fakeStatOverrides);
    }

    public synchronized void setFakeStatOverride(String normalizedKey, String value) {
        String sanitizedKey = sanitize(normalizedKey);
        if (!sanitizedKey.isEmpty()) {
            String sanitizedValue = sanitize(value);
            if (sanitizedValue.isEmpty()) {
                this.fakeStatOverrides.remove(sanitizedKey);
            } else {
                if (sanitizedValue.length() > 32) {
                    sanitizedValue = sanitizedValue.substring(0, 32);
                }

                this.fakeStatOverrides.put(sanitizedKey, sanitizedValue);
            }
        }
    }

    public synchronized void clearFakeStatOverride(String normalizedKey) {
        this.fakeStatOverrides.remove(sanitize(normalizedKey));
    }

    public synchronized void clearAllFakeStatOverrides() {
        this.fakeStatOverrides.clear();
    }

    public synchronized String getNameSpoofValue() {
        return this.nameSpoofValue;
    }

    public synchronized void setNameSpoofValue(String value) {
        this.nameSpoofValue = sanitizeSpoofValue(value, "Darg");
    }

    public synchronized String getRankSpoofValue() {
        return this.rankSpoofValue;
    }

    public synchronized void setRankSpoofValue(String value) {
        this.rankSpoofValue = sanitizeSpoofValue(value, "\ud83d\udcf9+");
    }

    public synchronized void setBlockEspAlpha(int alpha) {
        this.blockEspAlpha = Math.max(0, Math.min(255, alpha));
    }

    public synchronized boolean isBlockEspTracersEnabled() {
        return this.blockEspTracers;
    }

    public synchronized void setBlockEspTracersEnabled(boolean enabled) {
        this.blockEspTracers = enabled;
    }

    public synchronized Set<String> getBlockEspSelectedBlocks() {
        return new LinkedHashSet<>(this.blockEspSelectedBlocks);
    }

    public synchronized void setBlockEspSelectedBlocks(Set<String> blockIds) {
        this.blockEspSelectedBlocks.clear();
        if (blockIds != null) {
            for (String blockId : blockIds) {
                String sanitized = sanitize(blockId);
                if (!sanitized.isEmpty()) {
                    this.blockEspSelectedBlocks.add(sanitized);
                }
            }
        }
    }

    public synchronized Map<String, Integer> getBlockEspBlockColors() {
        return new LinkedHashMap<>(this.blockEspBlockColors);
    }

    public synchronized void setBlockEspBlockColors(Map<String, Integer> blockColors) {
        this.blockEspBlockColors.clear();
        if (blockColors != null) {
            for (Entry<String, Integer> entry : blockColors.entrySet()) {
                String sanitizedKey = sanitize(entry.getKey());
                Integer color = entry.getValue();
                if (!sanitizedKey.isEmpty() && color != null) {
                    this.blockEspBlockColors.put(sanitizedKey, color & 16777215);
                }
            }
        }
    }

    public synchronized boolean isHudWatermarkEnabled() {
        return this.hudWatermark;
    }

    public synchronized void setHudWatermarkEnabled(boolean enabled) {
        this.hudWatermark = enabled;
    }

    public synchronized boolean isHudInfoEnabled() {
        return this.hudInfo;
    }

    public synchronized void setHudInfoEnabled(boolean enabled) {
        this.hudInfo = enabled;
    }

    public synchronized boolean isHudModulesEnabled() {
        return this.hudModules;
    }

    public synchronized void setHudModulesEnabled(boolean enabled) {
        this.hudModules = enabled;
    }

    public synchronized boolean isHudTimeEnabled() {
        return this.hudTime;
    }

    public synchronized void setHudTimeEnabled(boolean enabled) {
        this.hudTime = enabled;
    }

    public synchronized boolean isHudCoordinatesEnabled() {
        return this.hudCoordinates;
    }

    public synchronized void setHudCoordinatesEnabled(boolean enabled) {
        this.hudCoordinates = enabled;
    }

    public synchronized boolean isHudPotionsEnabled() {
        return this.hudPotions;
    }

    public synchronized void setHudPotionsEnabled(boolean enabled) {
        this.hudPotions = enabled;
    }

    public synchronized boolean isHudNotificationsEnabled() {
        return this.hudNotifications;
    }

    public synchronized void setHudNotificationsEnabled(boolean enabled) {
        this.hudNotifications = enabled;
    }

    public synchronized boolean isHudRainbowEnabled() {
        return this.hudRainbow;
    }

    public synchronized void setHudRainbowEnabled(boolean enabled) {
        this.hudRainbow = enabled;
    }

    public synchronized boolean isHudArmorPreviewEnabled() {
        return this.hudArmorPreview;
    }

    public synchronized void setHudArmorPreviewEnabled(boolean enabled) {
        this.hudArmorPreview = enabled;
    }

    public synchronized boolean isHudInventoryPreviewEnabled() {
        return this.hudInventoryPreview;
    }

    public synchronized void setHudInventoryPreviewEnabled(boolean enabled) {
        this.hudInventoryPreview = enabled;
    }

    public synchronized float getHudArmorX() {
        return this.hudArmorX;
    }

    public synchronized float getHudArmorY() {
        return this.hudArmorY;
    }

    public synchronized void setHudArmorPosition(float x, float y) {
        this.hudArmorX = x;
        this.hudArmorY = y;
    }

    public synchronized float getHudInventoryX() {
        return this.hudInventoryX;
    }

    public synchronized float getHudInventoryY() {
        return this.hudInventoryY;
    }

    public synchronized void setHudInventoryPosition(float x, float y) {
        this.hudInventoryX = x;
        this.hudInventoryY = y;
    }

    public synchronized int getHudOpacity() {
        return this.hudOpacity;
    }

    public synchronized void setHudOpacity(int opacity) {
        this.hudOpacity = Math.max(60, Math.min(255, opacity));
    }

    public synchronized float getHudRainbowSpeed() {
        return this.hudRainbowSpeed;
    }

    public synchronized void setHudRainbowSpeed(float rainbowSpeed) {
        this.hudRainbowSpeed = Math.max(0.25F, Math.min(4.0F, rainbowSpeed));
    }

    public synchronized int getHudNotificationDurationMs() {
        return this.hudNotificationDurationMs;
    }

    public synchronized void setHudNotificationDurationMs(int durationMs) {
        this.hudNotificationDurationMs = Math.max(1000, Math.min(8000, durationMs));
    }

    public synchronized int getAutoCrystalPlaceDelay() {
        return this.autoCrystalPlaceDelay;
    }

    public synchronized void setAutoCrystalPlaceDelay(int delay) {
        this.autoCrystalPlaceDelay = Math.max(0, Math.min(20, delay));
    }

    public synchronized int getAutoCrystalBreakDelay() {
        return this.autoCrystalBreakDelay;
    }

    public synchronized void setAutoCrystalBreakDelay(int delay) {
        this.autoCrystalBreakDelay = Math.max(0, Math.min(20, delay));
    }

    public synchronized int getAmethystEspClusterThreshold() {
        return this.amethystEspClusterThreshold;
    }

    public synchronized void setAmethystEspClusterThreshold(int threshold) {
        this.amethystEspClusterThreshold = Math.max(1, Math.min(50, threshold));
    }

    public synchronized int getSpawnerProtectPlayerRange() {
        return this.spawnerProtectPlayerRange;
    }

    public synchronized void setSpawnerProtectPlayerRange(int range) {
        this.spawnerProtectPlayerRange = Math.max(4, Math.min(48, range));
    }

    public synchronized int getSpawnerProtectSpawnerRange() {
        return this.spawnerProtectSpawnerRange;
    }

    public synchronized void setSpawnerProtectSpawnerRange(int range) {
        this.spawnerProtectSpawnerRange = Math.max(2, Math.min(16, range));
    }

    public synchronized int getSpawnerProtectBreakDelay() {
        return this.spawnerProtectBreakDelay;
    }

    public synchronized void setSpawnerProtectBreakDelay(int delay) {
        this.spawnerProtectBreakDelay = Math.max(0, Math.min(20, delay));
    }

    public synchronized boolean isSpawnerProtectDisconnectOnFail() {
        return this.spawnerProtectDisconnectOnFail;
    }

    public synchronized void setSpawnerProtectDisconnectOnFail(boolean enabled) {
        this.spawnerProtectDisconnectOnFail = enabled;
    }

    public synchronized boolean isSpawnerProtectDisconnectWhenDone() {
        return this.spawnerProtectDisconnectWhenDone;
    }

    public synchronized void setSpawnerProtectDisconnectWhenDone(boolean enabled) {
        this.spawnerProtectDisconnectWhenDone = enabled;
    }

    public synchronized int getAnchorMacroExplodeSlot() {
        return this.anchorMacroExplodeSlot;
    }

    public synchronized void setAnchorMacroExplodeSlot(int slot) {
        this.anchorMacroExplodeSlot = Math.max(0, Math.min(8, slot));
    }

    public synchronized int getDhandModTotemSlot() {
        return this.dhandModTotemSlot;
    }

    public synchronized void setDhandModTotemSlot(int slot) {
        this.dhandModTotemSlot = Math.max(0, Math.min(8, slot));
    }

    public synchronized int getHoverTotemSlot() {
        return this.hoverTotemSlot;
    }

    public synchronized void setHoverTotemSlot(int slot) {
        this.hoverTotemSlot = Math.max(0, Math.min(8, slot));
    }

    public synchronized int getAutoDoubleHandSearchRadius() {
        return this.autoDoubleHandSearchRadius;
    }

    public synchronized void setAutoDoubleHandSearchRadius(int radius) {
        this.autoDoubleHandSearchRadius = Math.max(2, Math.min(12, radius));
    }

    public synchronized String getHudSortMode() {
        return this.hudSortMode;
    }

    public synchronized void setHudSortMode(String hudSortMode) {
        String sanitized = sanitize(hudSortMode);
        this.hudSortMode = sanitized.isEmpty() ? "LONGEST" : sanitized;
    }

    public synchronized float getHudScale() {
        return this.hudScale;
    }

    public synchronized void setHudScale(float scale) {
        float clamped = Math.max(0.75F, Math.min(1.5F, scale));
        this.hudScale = clamped;
    }

    public synchronized String getFeatureBind(String featureKey) {
        return this.featureBinds.getOrDefault(sanitize(featureKey), "");
    }

    public synchronized void setFeatureBind(String featureKey, String serializedBind) {
        String sanitizedKey = sanitize(featureKey);
        String sanitizedBind = sanitize(serializedBind);
        if (!sanitizedKey.isEmpty()) {
            this.featureBinds.put(sanitizedKey, sanitizedBind);
        }
    }

    public synchronized void clearFeatureBind(String featureKey) {
        this.featureBinds.remove(sanitize(featureKey));
    }

    public synchronized Boolean getFeatureEnabledState(String featureKey) {
        String sanitizedKey = sanitize(featureKey);
        return sanitizedKey.isEmpty() ? null : this.featureEnabledStates.get(sanitizedKey);
    }

    public synchronized void setFeatureEnabledState(String featureKey, boolean enabled) {
        String sanitizedKey = sanitize(featureKey);
        if (!sanitizedKey.isEmpty()) {
            this.featureEnabledStates.put(sanitizedKey, enabled);
        }
    }

    public synchronized void clearFeatureEnabledState(String featureKey) {
        this.featureEnabledStates.remove(sanitize(featureKey));
    }

    public synchronized String getFeatureSetting(String featureKey, String settingKey) {
        return this.featureSettingValues.getOrDefault(composeFeatureSettingKey(featureKey, settingKey), "");
    }

    public synchronized void setFeatureSetting(String featureKey, String settingKey, String value) {
        String compositeKey = composeFeatureSettingKey(featureKey, settingKey);
        if (!compositeKey.isEmpty()) {
            String sanitizedValue = sanitize(value);
            if (sanitizedValue.isEmpty()) {
                this.featureSettingValues.remove(compositeKey);
            } else {
                this.featureSettingValues.put(compositeKey, sanitizedValue);
            }
        }
    }

    public synchronized void clearFeatureSetting(String featureKey, String settingKey) {
        this.featureSettingValues.remove(composeFeatureSettingKey(featureKey, settingKey));
    }

    public synchronized Map<String, String> exportSnapshotValues() {
        return new LinkedHashMap<>(this.buildPropertyMap());
    }

    public synchronized void applySnapshotValues(Map<String, String> values) {
        Properties properties = new Properties();
        if (values != null) {
            for (Entry<String, String> entry : values.entrySet()) {
                String key = sanitize(entry.getKey());
                if (!key.isEmpty()) {
                    properties.setProperty(key, entry.getValue() == null ? "" : entry.getValue());
                }
            }
        }

        this.applyProperties(properties, false);
        this.save();
    }

    public synchronized void save() {
        Properties properties = new Properties();

        for (Entry<String, String> entry : this.buildPropertyMap().entrySet()) {
            properties.setProperty(entry.getKey(), entry.getValue());
        }

        try {
            Files.createDirectories(CONFIG_PATH.getParent());

            try (OutputStream outputStream = Files.newOutputStream(CONFIG_PATH)) {
                properties.store(outputStream, "Darg's Client configuration");
            }
        } catch (IOException var7) {
        }
    }

    private synchronized LinkedHashMap<String, String> buildPropertyMap() {
        LinkedHashMap<String, String> values = new LinkedHashMap<>();
        values.put("spotify.hud.x", Float.toString(this.spotifyHudX));
        values.put("spotify.hud.y", Float.toString(this.spotifyHudY));
        values.put("spotify.access_token", this.spotifyAccessToken);
        values.put("spotify.refresh_token", this.spotifyRefreshToken);
        values.put("spotify.client_id", this.spotifyClientId);
        values.put("spotify.client_secret", this.spotifyClientSecret);
        values.put("zoom.factor", Float.toString(this.zoomFactor));
        values.put("auto_elytra.target_y", Integer.toString(this.autoElytraTargetY));
        values.put("auto_eat.threshold_percent", Integer.toString(this.autoEatThresholdPercent));
        values.put("area_digger.start", this.areaDiggerStart);
        values.put("area_digger.end", this.areaDiggerEnd);
        values.put("area_digger.tool_mode", this.areaDiggerToolMode);
        values.put("dargs_aura.dirt_bending", Boolean.toString(this.dargsAuraDirtBending));
        values.put("dargs_aura.block_speed", Float.toString(this.dargsAuraBlockSpeed));
        values.put("name_spoof.value", this.nameSpoofValue);
        values.put("rank_spoof.value", this.rankSpoofValue);
        values.put("player_esp.tracers", Boolean.toString(this.playerEspTracers));
        values.put("block_esp.alpha", Integer.toString(this.blockEspAlpha));
        values.put("block_esp.tracers", Boolean.toString(this.blockEspTracers));
        values.put("block_esp.selected_blocks", String.join(",", this.blockEspSelectedBlocks));
        values.put("block_esp.block_colors", serializeColorMap(this.blockEspBlockColors));
        values.put("hud.watermark", Boolean.toString(this.hudWatermark));
        values.put("hud.info", Boolean.toString(this.hudInfo));
        values.put("hud.modules", Boolean.toString(this.hudModules));
        values.put("hud.time", Boolean.toString(this.hudTime));
        values.put("hud.coordinates", Boolean.toString(this.hudCoordinates));
        values.put("hud.potions", Boolean.toString(this.hudPotions));
        values.put("hud.notifications", Boolean.toString(this.hudNotifications));
        values.put("hud.rainbow", Boolean.toString(this.hudRainbow));
        values.put("hud.armor_preview", Boolean.toString(this.hudArmorPreview));
        values.put("hud.inventory_preview", Boolean.toString(this.hudInventoryPreview));
        values.put("hud.opacity", Integer.toString(this.hudOpacity));
        values.put("hud.rainbow_speed", Float.toString(this.hudRainbowSpeed));
        values.put("hud.notification_duration", Integer.toString(this.hudNotificationDurationMs));
        values.put("hud.sort_mode", this.hudSortMode);
        values.put("hud.scale", Float.toString(this.hudScale));
        values.put("hud.armor.x", Float.toString(this.hudArmorX));
        values.put("hud.armor.y", Float.toString(this.hudArmorY));
        values.put("hud.inventory.x", Float.toString(this.hudInventoryX));
        values.put("hud.inventory.y", Float.toString(this.hudInventoryY));
        values.put("auto_crystal.place_delay", Integer.toString(this.autoCrystalPlaceDelay));
        values.put("auto_crystal.break_delay", Integer.toString(this.autoCrystalBreakDelay));
        values.put("amethyst_esp.cluster_threshold", Integer.toString(this.amethystEspClusterThreshold));
        values.put("spawner_protect.player_range", Integer.toString(this.spawnerProtectPlayerRange));
        values.put("spawner_protect.spawner_range", Integer.toString(this.spawnerProtectSpawnerRange));
        values.put("spawner_protect.break_delay", Integer.toString(this.spawnerProtectBreakDelay));
        values.put("spawner_protect.disconnect_on_fail", Boolean.toString(this.spawnerProtectDisconnectOnFail));
        values.put("spawner_protect.disconnect_when_done", Boolean.toString(this.spawnerProtectDisconnectWhenDone));
        values.put("anchor_macro.explode_slot", Integer.toString(this.anchorMacroExplodeSlot));
        values.put("dhand_mod.totem_slot", Integer.toString(this.dhandModTotemSlot));
        values.put("hover_totem.slot", Integer.toString(this.hoverTotemSlot));
        values.put("auto_double_hand.search_radius", Integer.toString(this.autoDoubleHandSearchRadius));

        for (Entry<String, String> entry : this.featureBinds.entrySet()) {
            values.put("feature.bind." + entry.getKey(), entry.getValue());
        }

        for (Entry<String, Boolean> entry : this.featureEnabledStates.entrySet()) {
            values.put("feature.state." + entry.getKey(), Boolean.toString(Boolean.TRUE.equals(entry.getValue())));
        }

        for (Entry<String, String> entry : this.featureSettingValues.entrySet()) {
            values.put("feature.setting." + entry.getKey(), sanitize(entry.getValue()));
        }

        for (Entry<String, ClientConfig.PanelPosition> entry : this.clickGuiPanelPositions.entrySet()) {
            ClientConfig.PanelPosition position = entry.getValue();
            values.put("click_gui.panel." + entry.getKey(), position.x() + "," + position.y() + "," + position.width());
        }

        for (Entry<String, String> entry : this.fakeStatOverrides.entrySet()) {
            values.put("fake_stats.override." + entry.getKey(), sanitize(entry.getValue()));
        }

        return values;
    }

    private synchronized void applyProperties(Properties properties, boolean preferEnvironmentSecrets) {
        this.spotifyHudX = parseFloat(properties.getProperty("spotify.hud.x"), 18.0F);
        this.spotifyHudY = parseFloat(properties.getProperty("spotify.hud.y"), 58.0F);
        this.spotifyAccessToken = readSecret(properties, "spotify.access_token", "DARGS_SPOTIFY_ACCESS_TOKEN", "", preferEnvironmentSecrets);
        this.spotifyRefreshToken = readSecret(properties, "spotify.refresh_token", "DARGS_SPOTIFY_REFRESH_TOKEN", "", preferEnvironmentSecrets);
        this.spotifyClientId = readSecret(properties, "spotify.client_id", "DARGS_SPOTIFY_CLIENT_ID", "", preferEnvironmentSecrets);
        this.spotifyClientSecret = readSecret(properties, "spotify.client_secret", "DARGS_SPOTIFY_CLIENT_SECRET", "", preferEnvironmentSecrets);
        this.zoomFactor = parseFloat(properties.getProperty("zoom.factor"), 4.0F);
        this.autoElytraTargetY = parseInt(properties.getProperty("auto_elytra.target_y"), 160, -64, 320);
        this.autoEatThresholdPercent = parseInt(properties.getProperty("auto_eat.threshold_percent"), 60, 5, 100);
        this.areaDiggerStart = sanitize(properties.getProperty("area_digger.start"));
        this.areaDiggerEnd = sanitize(properties.getProperty("area_digger.end"));
        this.areaDiggerToolMode = parseString(properties.getProperty("area_digger.tool_mode"), "AUTO");
        this.dargsAuraDirtBending = parseBoolean(properties.getProperty("dargs_aura.dirt_bending"), true);
        this.dargsAuraBlockSpeed = parseFloatInRange(properties.getProperty("dargs_aura.block_speed"), 1.0F, 0.35F, 2.5F);
        this.fakeStatOverrides.clear();
        this.nameSpoofValue = parseString(properties.getProperty("name_spoof.value"), "Darg");
        this.rankSpoofValue = parseString(properties.getProperty("rank_spoof.value"), "\ud83d\udcf9+");
        this.playerEspTracers = parseBoolean(properties.getProperty("player_esp.tracers"), true);
        this.blockEspAlpha = parseInt(properties.getProperty("block_esp.alpha"), 125, 0, 255);
        this.blockEspTracers = parseBoolean(properties.getProperty("block_esp.tracers"), false);
        this.blockEspSelectedBlocks.clear();
        this.blockEspSelectedBlocks
            .addAll(parseList(properties.getProperty("block_esp.selected_blocks"), "minecraft:diamond_ore,minecraft:deepslate_diamond_ore"));
        this.blockEspBlockColors.clear();
        this.blockEspBlockColors.putAll(parseColorMap(properties.getProperty("block_esp.block_colors")));
        this.hudWatermark = parseBoolean(properties.getProperty("hud.watermark"), true);
        this.hudInfo = parseBoolean(properties.getProperty("hud.info"), true);
        this.hudModules = parseBoolean(properties.getProperty("hud.modules"), true);
        this.hudTime = parseBoolean(properties.getProperty("hud.time"), true);
        this.hudCoordinates = parseBoolean(properties.getProperty("hud.coordinates"), true);
        this.hudPotions = parseBoolean(properties.getProperty("hud.potions"), false);
        this.hudNotifications = parseBoolean(properties.getProperty("hud.notifications"), true);
        this.hudRainbow = parseBoolean(properties.getProperty("hud.rainbow"), false);
        this.hudArmorPreview = parseBoolean(properties.getProperty("hud.armor_preview"), true);
        this.hudInventoryPreview = parseBoolean(properties.getProperty("hud.inventory_preview"), true);
        this.hudOpacity = parseInt(properties.getProperty("hud.opacity"), 190, 60, 255);
        this.hudRainbowSpeed = parseFloatInRange(properties.getProperty("hud.rainbow_speed"), 1.35F, 0.25F, 4.0F);
        this.hudNotificationDurationMs = parseInt(properties.getProperty("hud.notification_duration"), 3200, 1000, 8000);
        this.hudSortMode = parseString(properties.getProperty("hud.sort_mode"), "LONGEST");
        this.hudScale = parseFloatInRange(properties.getProperty("hud.scale"), 1.0F, 0.75F, 1.5F);
        this.hudArmorX = parseFloat(properties.getProperty("hud.armor.x"), 12.0F);
        this.hudArmorY = parseFloat(properties.getProperty("hud.armor.y"), 84.0F);
        this.hudInventoryX = parseFloat(properties.getProperty("hud.inventory.x"), 12.0F);
        this.hudInventoryY = parseFloat(properties.getProperty("hud.inventory.y"), 132.0F);
        this.autoCrystalPlaceDelay = parseInt(properties.getProperty("auto_crystal.place_delay"), 2, 0, 20);
        this.autoCrystalBreakDelay = parseInt(properties.getProperty("auto_crystal.break_delay"), 2, 0, 20);
        this.amethystEspClusterThreshold = parseInt(properties.getProperty("amethyst_esp.cluster_threshold"), 10, 1, 50);
        this.spawnerProtectPlayerRange = parseInt(properties.getProperty("spawner_protect.player_range"), 24, 4, 48);
        this.spawnerProtectSpawnerRange = parseInt(properties.getProperty("spawner_protect.spawner_range"), 10, 2, 16);
        this.spawnerProtectBreakDelay = parseInt(properties.getProperty("spawner_protect.break_delay"), 5, 0, 20);
        this.spawnerProtectDisconnectOnFail = parseBoolean(properties.getProperty("spawner_protect.disconnect_on_fail"), true);
        this.spawnerProtectDisconnectWhenDone = parseBoolean(properties.getProperty("spawner_protect.disconnect_when_done"), true);
        this.anchorMacroExplodeSlot = parseInt(properties.getProperty("anchor_macro.explode_slot"), 8, 0, 8);
        this.dhandModTotemSlot = parseInt(properties.getProperty("dhand_mod.totem_slot"), 8, 0, 8);
        this.hoverTotemSlot = parseInt(properties.getProperty("hover_totem.slot"), 8, 0, 8);
        this.autoDoubleHandSearchRadius = parseInt(properties.getProperty("auto_double_hand.search_radius"), 6, 2, 12);
        this.featureBinds.clear();
        this.featureEnabledStates.clear();
        this.featureSettingValues.clear();
        this.clickGuiPanelPositions.clear();

        for (String propertyName : properties.stringPropertyNames()) {
            if (propertyName.startsWith("feature.bind.")) {
                String featureKey = propertyName.substring("feature.bind.".length());
                this.featureBinds.put(sanitize(featureKey), sanitize(properties.getProperty(propertyName)));
            }
        }

        for (String propertyNamex : properties.stringPropertyNames()) {
            if (propertyNamex.startsWith("feature.state.")) {
                String featureKey = sanitize(propertyNamex.substring("feature.state.".length()));
                if (!featureKey.isEmpty()) {
                    this.featureEnabledStates.put(featureKey, parseBoolean(properties.getProperty(propertyNamex), false));
                }
            }
        }

        for (String propertyNamexx : properties.stringPropertyNames()) {
            if (propertyNamexx.startsWith("feature.setting.")) {
                String compositeKey = sanitize(propertyNamexx.substring("feature.setting.".length()));
                if (!compositeKey.isEmpty()) {
                    String sanitizedValue = sanitize(properties.getProperty(propertyNamexx));
                    if (!sanitizedValue.isEmpty()) {
                        this.featureSettingValues.put(compositeKey, sanitizedValue);
                    }
                }
            }
        }

        for (String propertyNamexxx : properties.stringPropertyNames()) {
            if (propertyNamexxx.startsWith("click_gui.panel.")) {
                String panelKey = sanitize(propertyNamexxx.substring("click_gui.panel.".length())).toLowerCase(Locale.ROOT);
                String serializedPosition = sanitize(properties.getProperty(propertyNamexxx));
                if (!panelKey.isEmpty() && !serializedPosition.isEmpty()) {
                    String[] parts = serializedPosition.split(",", 3);
                    if (parts.length >= 2) {
                        try {
                            float x = Float.parseFloat(parts[0].trim());
                            float y = Float.parseFloat(parts[1].trim());
                            float w = parts.length >= 3 ? Float.parseFloat(parts[2].trim()) : 0.0F;
                            this.clickGuiPanelPositions.put(panelKey, new ClientConfig.PanelPosition(x, y, w));
                        } catch (NumberFormatException var11) {
                        }
                    }
                }
            }
        }

        for (String propertyNamexxxx : properties.stringPropertyNames()) {
            if (propertyNamexxxx.startsWith("fake_stats.override.")) {
                String normalizedKey = sanitize(propertyNamexxxx.substring("fake_stats.override.".length()));
                String overrideValue = sanitize(properties.getProperty(propertyNamexxxx));
                if (!normalizedKey.isEmpty() && !overrideValue.isEmpty()) {
                    this.fakeStatOverrides.put(normalizedKey, overrideValue);
                }
            }
        }
    }

    private synchronized void load() {
        Properties properties = new Properties();
        if (Files.exists(CONFIG_PATH)) {
            try (InputStream inputStream = Files.newInputStream(CONFIG_PATH)) {
                properties.load(inputStream);
            } catch (IOException var7) {
            }
        }

        this.applyProperties(properties, true);
        this.save();
    }

    private static float parseFloat(String value, float fallback) {
        if (value != null && !value.isBlank()) {
            try {
                return Float.parseFloat(value);
            } catch (NumberFormatException var3) {
                return fallback;
            }
        } else {
            return fallback;
        }
    }

    private static int parseInt(String value, int fallback, int min, int max) {
        if (value != null && !value.isBlank()) {
            try {
                return Math.max(min, Math.min(max, Integer.parseInt(value)));
            } catch (NumberFormatException var5) {
                return fallback;
            }
        } else {
            return fallback;
        }
    }

    private static float parseFloatInRange(String value, float fallback, float min, float max) {
        if (value != null && !value.isBlank()) {
            try {
                return Math.max(min, Math.min(max, Float.parseFloat(value)));
            } catch (NumberFormatException var5) {
                return fallback;
            }
        } else {
            return fallback;
        }
    }

    private static boolean parseBoolean(String value, boolean fallback) {
        return value != null && !value.isBlank() ? Boolean.parseBoolean(value) : fallback;
    }

    private static String parseString(String value, String fallback) {
        String sanitized = sanitize(value);
        return sanitized.isEmpty() ? fallback : sanitized;
    }

    private static String sanitizeSpoofValue(String value, String fallback) {
        String sanitized = sanitize(value);
        if (sanitized.isEmpty()) {
            return fallback;
        } else {
            return sanitized.length() > 32 ? sanitized.substring(0, 32) : sanitized;
        }
    }

    private static Set<String> parseList(String value, String fallback) {
        LinkedHashSet<String> values = new LinkedHashSet<>();
        String source = value != null && !value.isBlank() ? value : fallback;

        for (String entry : source.split(",")) {
            String sanitized = sanitize(entry);
            if (!sanitized.isEmpty()) {
                values.add(sanitized);
            }
        }

        return values;
    }

    private static Map<String, Integer> parseColorMap(String value) {
        LinkedHashMap<String, Integer> values = new LinkedHashMap<>();
        if (value != null && !value.isBlank()) {
            for (String entry : value.split(";")) {
                String sanitized = sanitize(entry);
                if (!sanitized.isEmpty()) {
                    int separatorIndex = sanitized.indexOf(61);
                    if (separatorIndex > 0 && separatorIndex < sanitized.length() - 1) {
                        String blockId = sanitize(sanitized.substring(0, separatorIndex));
                        String colorValue = sanitize(sanitized.substring(separatorIndex + 1));
                        if (!blockId.isEmpty() && !colorValue.isEmpty()) {
                            try {
                                values.put(blockId, Integer.valueOf(Integer.parseInt(colorValue, 16) & 16777215));
                            } catch (NumberFormatException var11) {
                            }
                        }
                    }
                }
            }

            return values;
        } else {
            return values;
        }
    }

    private static String serializeColorMap(Map<String, Integer> values) {
        if (values != null && !values.isEmpty()) {
            StringBuilder builder = new StringBuilder();

            for (Entry<String, Integer> entry : values.entrySet()) {
                String blockId = sanitize(entry.getKey());
                Integer color = entry.getValue();
                if (!blockId.isEmpty() && color != null) {
                    if (!builder.isEmpty()) {
                        builder.append(';');
                    }

                    builder.append(blockId).append('=').append(String.format(Locale.ROOT, "%06X", color & 16777215));
                }
            }

            return builder.toString();
        } else {
            return "";
        }
    }

    private static String resolveSecret(Properties properties, String propertyKey, String envKey) {
        return resolveSecret(properties, propertyKey, envKey, "");
    }

    private static String readSecret(Properties properties, String propertyKey, String envKey, String fallback, boolean preferEnvironment) {
        return preferEnvironment ? resolveSecret(properties, propertyKey, envKey, fallback) : sanitize(properties.getProperty(propertyKey, fallback));
    }

    private static String resolveSecret(Properties properties, String propertyKey, String envKey, String fallback) {
        String envValue = System.getenv(envKey);
        return envValue != null && !envValue.isBlank() ? sanitize(envValue) : sanitize(properties.getProperty(propertyKey, fallback));
    }

    private static String sanitize(String value) {
        return value == null ? "" : value.trim();
    }

    private static String composeFeatureSettingKey(String featureKey, String settingKey) {
        String sanitizedFeature = sanitize(featureKey);
        String sanitizedSetting = sanitize(settingKey);
        return !sanitizedFeature.isEmpty() && !sanitizedSetting.isEmpty() ? sanitizedFeature + "." + sanitizedSetting : "";
    }

    public static record PanelPosition(float x, float y, float width) {
    }

    public static record SpotifyCredentials(String accessToken, String refreshToken, String clientId, String clientSecret) {
        public boolean hasAccessToken() {
            return this.accessToken != null && !this.accessToken.isBlank();
        }

        public boolean hasRefreshToken() {
            return this.refreshToken != null && !this.refreshToken.isBlank();
        }

        public boolean hasClientId() {
            return this.clientId != null && !this.clientId.isBlank();
        }

        public boolean canRefresh() {
            return this.hasRefreshToken() && this.hasClientId();
        }

        public boolean hasClientSecret() {
            return this.clientSecret != null && !this.clientSecret.isBlank();
        }

        public boolean isConfigured() {
            return this.hasAccessToken() || this.canRefresh();
        }
    }
}
