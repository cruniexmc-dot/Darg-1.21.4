package dev.darg.client.feature.combat;

import dev.darg.client.feature.Category;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

public final class ShieldDisablerFeature extends ConfigurableCombatFeature {
    private final ConfigurableCombatFeature.NumberSetting hitDelay = this.intSetting("hit_delay", "Hit Delay", 0, 0, 20);
    private final ConfigurableCombatFeature.NumberSetting switchDelay = this.intSetting("switch_delay", "Switch Delay", 0, 0, 20);
    private final ConfigurableCombatFeature.BooleanSetting switchBack = this.booleanSetting("switch_back", "Switch Back", true);
    private final ConfigurableCombatFeature.BooleanSetting stun = this.booleanSetting("stun", "Stun", false);
    private final ConfigurableCombatFeature.BooleanSetting clickSimulate = this.booleanSetting("click_simulation", "Click Simulation", false);
    private final ConfigurableCombatFeature.BooleanSetting requireHoldAxe = this.booleanSetting("hold_axe", "Hold Axe", false);
    private int previousSlot = -1;
    private int hitClock;
    private int switchClock;
    private boolean waitingForShieldDrop;

    public ShieldDisablerFeature() {
        super("ShieldDisabler", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        this.previousSlot = -1;
        this.hitClock = this.hitDelay.intValue();
        this.switchClock = this.switchDelay.intValue();
        this.waitingForShieldDrop = false;
    }

    @Override
    protected void onDisable() {
        this.restorePreviousSlot();
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player != null && client.world != null && client.currentScreen == null) {
            if (!this.requireHoldAxe.get() || player.getMainHandStack().getItem() instanceof AxeItem) {
                if (client.crosshairTarget instanceof EntityHitResult hitResult) {
                    if (!(hitResult.getEntity() instanceof PlayerEntity target) || player.isUsingItem()) {
                        this.restoreIfSafe();
                        return;
                    }

                    if (target.isBlocking() && !CombatSupport.isShieldFacingAway(target, player) && target.isHolding(Items.SHIELD)) {
                        this.waitingForShieldDrop = true;
                        if (this.switchClock > 0) {
                            this.switchClock--;
                        } else {
                            if (this.previousSlot < 0) {
                                this.previousSlot = player.getInventory().getSelectedSlot();
                            }

                            int axeSlot = CombatSupport.findHotbarAxe(player);
                            if (axeSlot >= 0) {
                                if (player.getInventory().getSelectedSlot() != axeSlot) {
                                    CombatSupport.selectHotbarSlot(player, axeSlot);
                                    this.switchClock = this.switchDelay.intValue();
                                } else if (this.hitClock > 0) {
                                    this.hitClock--;
                                } else {
                                    if (this.clickSimulate.get()) {
                                        client.options.attackKey.setPressed(true);
                                    }

                                    client.interactionManager.attackEntity(player, target);
                                    player.swingHand(Hand.MAIN_HAND);
                                    if (this.stun.get()) {
                                        client.interactionManager.attackEntity(player, target);
                                        player.swingHand(Hand.MAIN_HAND);
                                    }

                                    if (this.clickSimulate.get()) {
                                        client.options.attackKey.setPressed(false);
                                    }

                                    this.hitClock = this.hitDelay.intValue();
                                    this.switchClock = this.switchDelay.intValue();
                                }
                            }
                        }
                    } else {
                        this.restoreIfSafe();
                    }
                } else {
                    this.restoreIfSafe();
                }
            }
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of(
            "Hit delay: " + this.hitDelay.intValue() + " ticks", "Switch back: " + this.switchBack.get(), "Require axe: " + this.requireHoldAxe.get()
        );
    }

    private void restoreIfSafe() {
        if (this.waitingForShieldDrop || this.previousSlot >= 0) {
            if (this.switchBack.get()) {
                this.restorePreviousSlot();
            }

            this.waitingForShieldDrop = false;
        }
    }

    private void restorePreviousSlot() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player != null && this.previousSlot >= 0) {
            CombatSupport.selectHotbarSlot(player, this.previousSlot);
            this.previousSlot = -1;
        }
    }
}
