package dev.darg.client.ui.theme;

import java.util.Locale;

public enum ThemePalette {
    PASTEL_DARK,
    NEON,
    MONO,
    SAKURA;

    public String id() {
        return this.name();
    }

    public static ThemePalette parse(String value) {
        if (value != null && !value.isBlank()) {
            String normalized = value.trim().toUpperCase(Locale.ROOT);

            for (ThemePalette palette : values()) {
                if (palette.name().equals(normalized)) {
                    return palette;
                }
            }

            return PASTEL_DARK;
        } else {
            return PASTEL_DARK;
        }
    }
}
