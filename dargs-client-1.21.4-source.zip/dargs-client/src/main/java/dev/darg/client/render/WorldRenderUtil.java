package dev.darg.client.render;

import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.util.math.Vec3d;

public final class WorldRenderUtil {
    private WorldRenderUtil() {
    }

    public static int argb(int alpha, int red, int green, int blue) {
        return (alpha & 0xFF) << 24 | (red & 0xFF) << 16 | (green & 0xFF) << 8 | blue & 0xFF;
    }

    public static int withAlpha(int color, int alpha) {
        return (alpha & 0xFF) << 24 | color & 16777215;
    }

    public static int alpha(int color) {
        return color >> 24 & 0xFF;
    }

    public static int red(int color) {
        return color >> 16 & 0xFF;
    }

    public static int green(int color) {
        return color >> 8 & 0xFF;
    }

    public static int blue(int color) {
        return color & 0xFF;
    }

    public static int brighten(int color, float amount) {
        float clamped = Math.max(0.0F, Math.min(1.0F, amount));
        int red = red(color);
        int green = green(color);
        int blue = blue(color);
        int brightRed = red + Math.round((float)(255 - red) * clamped);
        int brightGreen = green + Math.round((float)(255 - green) * clamped);
        int brightBlue = blue + Math.round((float)(255 - blue) * clamped);
        return argb(alpha(color), brightRed, brightGreen, brightBlue);
    }

    public static Vec3d getTracerStart(Camera camera, float tickProgress, float offset) {
        return Vec3d.fromPolar(camera.getPitch(), camera.getYaw()).multiply((double)offset);
    }

    public static void drawLine(Entry entry, VertexConsumer buffer, Vec3d start, Vec3d end, int argb, float lineWidth) {
        drawLine(
            entry,
            buffer,
            (float)start.x,
            (float)start.y,
            (float)start.z,
            (float)end.x,
            (float)end.y,
            (float)end.z,
            argb,
            lineWidth
        );
    }

    public static void drawLine(Entry entry, VertexConsumer buffer, float x1, float y1, float z1, float x2, float y2, float z2, int argb, float lineWidth) {
        float dx = x2 - x1;
        float dy = y2 - y1;
        float dz = z2 - z1;
        float length = (float)Math.sqrt((double)(dx * dx + dy * dy + dz * dz));
        if (!(length < 1.0E-4F)) {
            float nx = dx / length;
            float ny = dy / length;
            float nz = dz / length;
            int red = red(argb);
            int green = green(argb);
            int blue = blue(argb);
            int alpha = alpha(argb);
            buffer.vertex(entry, x1, y1, z1).color(red, green, blue, alpha).normal(entry, nx, ny, nz).lineWidth(lineWidth);
            buffer.vertex(entry, x2, y2, z2).color(red, green, blue, alpha).normal(entry, nx, ny, nz).lineWidth(lineWidth);
        }
    }

    public static void drawWireBox(
        Entry entry, VertexConsumer buffer, float minX, float minY, float minZ, float maxX, float maxY, float maxZ, int argb, float lineWidth
    ) {
        drawLine(entry, buffer, minX, minY, minZ, maxX, minY, minZ, argb, lineWidth);
        drawLine(entry, buffer, maxX, minY, minZ, maxX, minY, maxZ, argb, lineWidth);
        drawLine(entry, buffer, maxX, minY, maxZ, minX, minY, maxZ, argb, lineWidth);
        drawLine(entry, buffer, minX, minY, maxZ, minX, minY, minZ, argb, lineWidth);
        drawLine(entry, buffer, minX, maxY, minZ, maxX, maxY, minZ, argb, lineWidth);
        drawLine(entry, buffer, maxX, maxY, minZ, maxX, maxY, maxZ, argb, lineWidth);
        drawLine(entry, buffer, maxX, maxY, maxZ, minX, maxY, maxZ, argb, lineWidth);
        drawLine(entry, buffer, minX, maxY, maxZ, minX, maxY, minZ, argb, lineWidth);
        drawLine(entry, buffer, minX, minY, minZ, minX, maxY, minZ, argb, lineWidth);
        drawLine(entry, buffer, maxX, minY, minZ, maxX, maxY, minZ, argb, lineWidth);
        drawLine(entry, buffer, maxX, minY, maxZ, maxX, maxY, maxZ, argb, lineWidth);
        drawLine(entry, buffer, minX, minY, maxZ, minX, maxY, maxZ, argb, lineWidth);
    }
}
