package dev.darg.client.feature.visual;

import dev.darg.client.DargsClient;
import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.input.FeatureBind;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class ZoomFeature extends Feature {
    private static final int WHITE = -1;
    private static final int SOFT_GRAY = -5592406;
    private static final int ACCENT = -10773258;
    private static final int PANEL_LIGHT = -14013894;
    private static final int PANEL_HOVER = -13290160;
    private static final int DARK_TEXT = -15658718;
    private static final float MIN_ZOOM = 2.0F;
    private static final float MAX_ZOOM = 10.0F;
    private static final float INLINE_HEIGHT = 58.0F;
    private final ClientConfig config = ClientConfig.getInstance();
    private float zoomFactor;
    private boolean draggingSlider;

    public ZoomFeature() {
        super("Zoom", Category.RENDER);
        this.setKeybind(FeatureBind.keyboard(67));
        this.zoomFactor = this.config.getZoomFactor();
    }

    public float getZoomFactor() {
        return this.zoomFactor;
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 58.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        if (this.draggingSlider) {
            this.setZoomFromMouse((double)mouseX, x, width);
        }

        float cx = x + 10.0F;
        float cw = width - 20.0F;
        float sliderY = y + 10.0F;
        float trackY = sliderY + 14.0F;
        float ratio = (this.zoomFactor - 2.0F) / 8.0F;
        float fillW = cw * ratio;
        float knobX = cx + fillW - 3.0F;
        String valueLabel = String.format("%.1fx", this.zoomFactor);
        float keybindY = y + 36.0F;
        RenderUtil.drawText(context, textRenderer, "ZOOM", cx, sliderY, -1);
        RenderUtil.drawText(context, textRenderer, valueLabel, x + width - 10.0F - (float)textRenderer.getWidth(valueLabel), sliderY, -5592406);
        RenderUtil.drawRoundedRect(context, cx, trackY, cw, 4.0F, 2.0F, -14013894);
        RenderUtil.drawRoundedRect(context, cx, trackY, Math.max(4.0F, fillW), 4.0F, 2.0F, -10773258);
        RenderUtil.drawRoundedRect(context, knobX, trackY - 3.0F, 8.0F, 10.0F, 4.0F, -10773258);
        RenderUtil.drawText(context, textRenderer, "KEYBIND", cx, keybindY + 2.0F, -1);
        float bindW = 70.0F;
        float bindX = x + width - bindW - 10.0F;
        boolean capturing = DargsClient.getInstance().getKeybindManager().isCapturing(this);
        boolean hoverBind = this.containsKeybind((double)mouseX, (double)mouseY, x, y, width);
        String bindLabel = fit(textRenderer, DargsClient.getInstance().getKeybindManager().getBindLabel(this).toUpperCase(Locale.ROOT), 58.0F);
        int bindFill = capturing ? -10773258 : (hoverBind ? -13290160 : -14013894);
        int bindText = capturing ? -15658718 : -1;
        RenderUtil.drawRoundedRect(context, bindX, keybindY, bindW, 16.0F, 5.0F, bindFill);
        RenderUtil.drawText(context, textRenderer, bindLabel, bindX + 7.0F, keybindY + 4.0F, bindText);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (!this.containsInline(mouseX, mouseY, x, y, width)) {
            return false;
        } else if (button == 0 && this.containsSlider(mouseX, mouseY, x, y, width)) {
            this.draggingSlider = true;
            this.setZoomFromMouse(mouseX, x, width);
            return true;
        } else if (button == 0 && this.containsKeybind(mouseX, mouseY, x, y, width)) {
            DargsClient.getInstance().getKeybindManager().beginCapture(this, notificationManager);
            return true;
        } else if (button == 1 && this.containsKeybind(mouseX, mouseY, x, y, width)) {
            DargsClient.getInstance().getKeybindManager().clearBind(this, notificationManager);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean onCustomClickGuiMouseReleased(double mouseX, double mouseY, int button, float x, float y, float width) {
        if (this.draggingSlider) {
            this.draggingSlider = false;
            this.config.save();
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isClickGuiInteractionActive() {
        return this.draggingSlider;
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("State: " + (this.isEnabled() ? "Zooming" : "Idle"), String.format("Zoom: %.1fx", this.zoomFactor));
    }

    private void setZoomFromMouse(double mouseX, float x, float width) {
        float start = x + 10.0F;
        float trackW = width - 20.0F;
        float ratio = Math.max(0.0F, Math.min(1.0F, (float)((mouseX - (double)start) / (double)trackW)));
        this.zoomFactor = 2.0F + ratio * 8.0F;
        this.config.setZoomFactor(this.zoomFactor);
    }

    private boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + 58.0F);
    }

    private boolean containsSlider(double mouseX, double mouseY, float x, float y, float width) {
        float trackY = y + 24.0F;
        return mouseX >= (double)(x + 10.0F)
            && mouseX <= (double)(x + width - 10.0F)
            && mouseY >= (double)(trackY - 5.0F)
            && mouseY <= (double)(trackY + 12.0F);
    }

    private boolean containsKeybind(double mouseX, double mouseY, float x, float y, float width) {
        float keybindY = y + 36.0F;
        float bindX = x + width - 80.0F;
        return mouseX >= (double)bindX && mouseX <= (double)(bindX + 70.0F) && mouseY >= (double)keybindY && mouseY <= (double)(keybindY + 16.0F);
    }

    private static String fit(TextRenderer tr, String text, float maxWidth) {
        if ((float)tr.getWidth(text) <= maxWidth) {
            return text;
        } else {
            while (text.length() > 1 && (float)tr.getWidth(text + "..") > maxWidth) {
                text = text.substring(0, text.length() - 1);
            }

            return text + "..";
        }
    }
}
