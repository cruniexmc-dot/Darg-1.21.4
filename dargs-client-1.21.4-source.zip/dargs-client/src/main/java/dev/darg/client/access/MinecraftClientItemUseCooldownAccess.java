package dev.darg.client.access;

public interface MinecraftClientItemUseCooldownAccess {
    void dargsclient$setItemUseCooldown(int var1);
}
