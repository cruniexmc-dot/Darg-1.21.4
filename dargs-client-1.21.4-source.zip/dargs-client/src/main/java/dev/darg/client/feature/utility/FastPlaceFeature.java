package dev.darg.client.feature.utility;

import dev.darg.client.DargsClient;
import dev.darg.client.access.MinecraftClientItemUseCooldownAccess;
import dev.darg.client.config.ClientConfig;
import dev.darg.client.config.FeatureSettingParse;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.clickgui.InlineControlRenderer;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public final class FastPlaceFeature extends Feature {
    private static final int MIN_DELAY = 0;
    private static final int MAX_DELAY = 4;
    private static final float INLINE_HEIGHT = 88.0F;
    private final ClientConfig config = ClientConfig.getInstance();
    private int delayTicks;
    private boolean onlyXpBottles;
    private boolean onlyBlocks;
    private boolean draggingSlider;

    public FastPlaceFeature() {
        super("FastPlace", Category.UTILITY);
        this.reloadFromConfig();
    }

    private void reloadFromConfig() {
        String fk = this.getConfigKey();
        this.delayTicks = FeatureSettingParse.parseInt(this.config.getFeatureSetting(fk, "delay"), 0, 0, 4);
        this.onlyXpBottles = FeatureSettingParse.parseBool(this.config.getFeatureSetting(fk, "only_xp"), false);
        this.onlyBlocks = FeatureSettingParse.parseBool(this.config.getFeatureSetting(fk, "only_blocks"), false);
    }

    private void persistDelay() {
        this.config.setFeatureSetting(this.getConfigKey(), "delay", Integer.toString(this.delayTicks));
        this.config.save();
    }

    private void persistBool(String key, boolean value) {
        this.config.setFeatureSetting(this.getConfigKey(), key, value ? "true" : "false");
        this.config.save();
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            ItemStack held = client.player.getMainHandStack();
            if (!held.isEmpty()) {
                if (this.shouldFastUse(held)) {
                    ((MinecraftClientItemUseCooldownAccess)client).dargsclient$setItemUseCooldown(this.delayTicks);
                }
            }
        }
    }

    private boolean shouldFastUse(ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        } else if (this.onlyXpBottles) {
            return stack.isOf(Items.EXPERIENCE_BOTTLE);
        } else {
            return this.onlyBlocks ? stack.getItem() instanceof BlockItem : true;
        }
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 88.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        float cx = x + 10.0F;
        float cw = width - 20.0F;
        if (this.draggingSlider) {
            this.setDelayFromMouse((double)mouseX, cx, cw);
        }

        float sliderY = y + 8.0F;
        float ratio = (float)(this.delayTicks - 0) / 4.0F;
        InlineControlRenderer.drawSlider(context, textRenderer, theme, "USE DELAY", Integer.toString(this.delayTicks), cx, sliderY, cw, ratio);
        float t1 = y + 40.0F;
        float t2 = y + 56.0F;
        boolean h1 = InlineControlRenderer.containsToggle((double)mouseX, (double)mouseY, cx, t1, cw);
        boolean h2 = InlineControlRenderer.containsToggle((double)mouseX, (double)mouseY, cx, t2, cw);
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "ONLY XP BOTTLES", this.onlyXpBottles, h1, cx, t1, cw);
        InlineControlRenderer.drawToggle(context, textRenderer, theme, "ONLY BLOCKS", this.onlyBlocks, h2, cx, t2, cw);
        float keybindY = y + 74.0F;
        float bindW = 70.0F;
        float bindX = x + width - bindW - 10.0F;
        boolean capturing = DargsClient.getInstance().getKeybindManager().isCapturing(this);
        boolean hoverBind = InlineControlRenderer.containsButton((double)mouseX, (double)mouseY, bindX, keybindY, bindW);
        String bindLabel = InlineControlRenderer.fitText(
            textRenderer, DargsClient.getInstance().getKeybindManager().getBindLabel(this).toUpperCase(Locale.ROOT), 58
        );
        InlineControlRenderer.drawButton(context, textRenderer, theme, bindLabel, capturing, hoverBind, bindX, keybindY, bindW);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (!this.containsInline(mouseX, mouseY, x, y, width)) {
            return false;
        } else {
            float cx = x + 10.0F;
            float cw = width - 20.0F;
            if (button == 0 && this.containsDelaySlider(mouseX, mouseY, x, y, width)) {
                this.draggingSlider = true;
                this.setDelayFromMouse(mouseX, cx, cw);
                return true;
            } else if (button == 0 && InlineControlRenderer.containsToggle(mouseX, mouseY, cx, y + 40.0F, cw)) {
                this.onlyXpBottles = !this.onlyXpBottles;
                if (this.onlyXpBottles) {
                    this.onlyBlocks = false;
                }

                this.persistBool("only_xp", this.onlyXpBottles);
                this.persistBool("only_blocks", this.onlyBlocks);
                notificationManager.push("FastPlace: only XP " + (this.onlyXpBottles ? "on" : "off"), NotificationManager.Type.INFO);
                return true;
            } else if (button == 0 && InlineControlRenderer.containsToggle(mouseX, mouseY, cx, y + 56.0F, cw)) {
                this.onlyBlocks = !this.onlyBlocks;
                if (this.onlyBlocks) {
                    this.onlyXpBottles = false;
                }

                this.persistBool("only_blocks", this.onlyBlocks);
                this.persistBool("only_xp", this.onlyXpBottles);
                notificationManager.push("FastPlace: only blocks " + (this.onlyBlocks ? "on" : "off"), NotificationManager.Type.INFO);
                return true;
            } else {
                float bindW = 70.0F;
                float bindX = x + width - bindW - 10.0F;
                float keybindY = y + 74.0F;
                if (button == 0 && InlineControlRenderer.containsButton(mouseX, mouseY, bindX, keybindY, bindW)) {
                    DargsClient.getInstance().getKeybindManager().beginCapture(this, notificationManager);
                    return true;
                } else if (button == 1 && InlineControlRenderer.containsButton(mouseX, mouseY, bindX, keybindY, bindW)) {
                    DargsClient.getInstance().getKeybindManager().clearBind(this, notificationManager);
                    return true;
                } else {
                    return true;
                }
            }
        }
    }

    @Override
    public boolean onCustomClickGuiMouseReleased(double mouseX, double mouseY, int button, float x, float y, float width) {
        if (this.draggingSlider) {
            this.draggingSlider = false;
            this.persistDelay();
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isClickGuiInteractionActive() {
        return this.draggingSlider;
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("Delay ticks: " + this.delayTicks, "Only XP: " + (this.onlyXpBottles ? "Yes" : "No"), "Only blocks: " + (this.onlyBlocks ? "Yes" : "No"));
    }

    private void setDelayFromMouse(double mouseX, float cx, float cw) {
        float ratio = Math.max(0.0F, Math.min(1.0F, (float)((mouseX - (double)cx) / (double)cw)));
        this.delayTicks = 0 + Math.round(ratio * 4.0F);
    }

    private boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + 88.0F);
    }

    private boolean containsDelaySlider(double mouseX, double mouseY, float x, float y, float width) {
        float cx = x + 10.0F;
        float cw = width - 20.0F;
        float trackY = y + 8.0F + 14.0F;
        return mouseX >= (double)cx && mouseX <= (double)(cx + cw) && mouseY >= (double)(trackY - 5.0F) && mouseY <= (double)(trackY + 12.0F);
    }
}
