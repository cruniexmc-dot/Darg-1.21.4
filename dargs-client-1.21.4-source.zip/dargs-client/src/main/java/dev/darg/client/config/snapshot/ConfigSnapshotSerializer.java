package dev.darg.client.config.snapshot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;
import dev.darg.client.DargsClient;
import dev.darg.client.config.ClientConfig;
import java.util.LinkedHashMap;
import java.util.Map;
import net.fabricmc.loader.api.FabricLoader;

public final class ConfigSnapshotSerializer {
    public static final int SCHEMA_VERSION = 1;
    private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create();

    private ConfigSnapshotSerializer() {
    }

    public static ConfigSnapshot exportLocalSnapshot() {
        ClientConfig config = ClientConfig.getInstance();
        synchronizeRuntimeFeatureState();
        return new ConfigSnapshot(1, resolveClientVersion(), config.exportSnapshotValues());
    }

    public static void applyLocalSnapshot(ConfigSnapshot snapshot) {
        if (snapshot != null) {
            ClientConfig.getInstance().applySnapshotValues(new LinkedHashMap<>(snapshot.values()));
            applyRuntimeConfigState();
        }
    }

    public static String toJson(ConfigSnapshot snapshot) {
        ConfigSnapshotSerializer.SnapshotPayload payload = new ConfigSnapshotSerializer.SnapshotPayload();
        payload.schemaVersion = snapshot == null ? 1 : snapshot.schemaVersion();
        payload.clientVersion = snapshot == null ? resolveClientVersion() : snapshot.clientVersion();
        payload.values = snapshot == null ? Map.of() : snapshot.values();
        return GSON.toJson(payload);
    }

    public static ConfigSnapshot fromJson(String json) {
        ConfigSnapshotSerializer.SnapshotPayload payload = (ConfigSnapshotSerializer.SnapshotPayload)GSON.fromJson(
            json, ConfigSnapshotSerializer.SnapshotPayload.class
        );
        return payload == null
            ? new ConfigSnapshot(1, resolveClientVersion(), Map.of())
            : new ConfigSnapshot(
                payload.schemaVersion <= 0 ? 1 : payload.schemaVersion,
                payload.clientVersion != null && !payload.clientVersion.isBlank() ? payload.clientVersion : resolveClientVersion(),
                payload.values == null ? Map.of() : payload.values
            );
    }

    public static String resolveClientVersion() {
        return FabricLoader.getInstance()
            .getModContainer("dargsclient")
            .map(container -> container.getMetadata().getVersion().getFriendlyString())
            .orElse("unknown");
    }

    private static void applyRuntimeConfigState() {
        DargsClient client = DargsClient.getInstance();
        if (client != null) {
            client.getFeatureManager().applyConfiguredFeatureStates();
            client.getFeatureManager().queueConfiguredFeatureStateRestore();
            client.getKeybindManager().initialize(client.getFeatureManager());
        }
    }

    private static void synchronizeRuntimeFeatureState() {
        DargsClient client = DargsClient.getInstance();
        if (client != null) {
            client.getFeatureManager().synchronizeFeatureStatesToConfig();
        }
    }

    private static final class SnapshotPayload {
        @SerializedName("schema_version")
        int schemaVersion;
        @SerializedName("client_version")
        String clientVersion;
        Map<String, String> values;
    }
}
