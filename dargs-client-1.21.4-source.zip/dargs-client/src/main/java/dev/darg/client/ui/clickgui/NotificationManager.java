package dev.darg.client.ui.clickgui;

import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class NotificationManager {
    private static final long FADE_IN_MS = 120L;
    private static final long HOLD_MS = 2300L;
    private static final long FADE_OUT_MS = 260L;
    private static final long DURATION_MS = 2680L;
    private final List<NotificationManager.NotificationEntry> activeNotifications = new ArrayList<>();

    public void push(String message, NotificationManager.Type type) {
        this.activeNotifications.add(new NotificationManager.NotificationEntry(message, type, System.currentTimeMillis()));
    }

    public void render(DrawContext context, TextRenderer textRenderer, int screenWidth, int screenHeight) {
        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        long now = System.currentTimeMillis();
        Iterator<NotificationManager.NotificationEntry> iterator = this.activeNotifications.iterator();

        while (iterator.hasNext()) {
            NotificationManager.NotificationEntry entry = iterator.next();
            if (now - entry.createdAt > 2680L) {
                iterator.remove();
            }
        }

        int index = 0;

        for (int i = this.activeNotifications.size() - 1; i >= 0; i--) {
            NotificationManager.NotificationEntry entry = this.activeNotifications.get(i);
            long age = now - entry.createdAt;
            float visibility = getVisibility(age);
            if (!(visibility <= 0.0F)) {
                float width = Math.max(196.0F, (float)RenderUtil.getTextWidth(textRenderer, entry.message) + 58.0F);
                float height = 44.0F;
                float x = 16.0F - (1.0F - visibility) * 16.0F;
                float y = (float)screenHeight - 18.0F - (float)(index + 1) * (height + 8.0F);
                int accentBase = entry.type == NotificationManager.Type.SUCCESS
                    ? theme.clickGuiNotificationSuccessAccent()
                    : theme.clickGuiNotificationInfoAccent();
                int panelColor = applyAlpha(theme.clickGuiNotificationPanel(), visibility);
                int shadowColor = applyAlpha(theme.clickGuiNotificationShadow(), visibility);
                int accentColor = applyAlpha(accentBase, visibility);
                int auraColor = applyAlpha(RenderUtil.mixColor(accentBase, theme.white(), 0.22F), visibility * 0.32F);
                int titleColor = applyAlpha(theme.white(), visibility);
                int bodyColor = applyAlpha(RenderUtil.mixColor(theme.softGray(), accentBase, 0.18F), visibility);
                int trackColor = applyAlpha(RenderUtil.mixColor(theme.moduleButtonFill(), accentBase, 0.18F), visibility);
                float progress = Math.max(0.0F, 1.0F - (float)age / 2680.0F);
                RenderUtil.drawRoundedRect(context, x - 1.0F, y - 1.0F, width + 2.0F, height + 2.0F, 15.0F, auraColor);
                RenderUtil.drawRoundedRect(context, x + 2.0F, y + 3.0F, width, height, 14.0F, shadowColor);
                RenderUtil.drawRoundedRect(context, x, y, width, height, 14.0F, panelColor);
                RenderUtil.drawRoundedRect(context, x + 10.0F, y + 9.0F, 4.0F, height - 18.0F, 2.0F, accentColor);
                RenderUtil.drawTextWithGlow(
                    context, textRenderer, entry.type.label, x + 22.0F, y + 11.0F, titleColor, accentBase, Math.round(62.0F * visibility)
                );
                RenderUtil.drawTextWithGlow(context, textRenderer, entry.message, x + 22.0F, y + 24.0F, bodyColor, accentBase, Math.round(26.0F * visibility));
                RenderUtil.drawRoundedRect(context, x + 22.0F, y + height - 8.0F, width - 32.0F, 3.0F, 2.0F, trackColor);
                RenderUtil.drawRoundedRect(context, x + 22.0F, y + height - 8.0F, (width - 32.0F) * progress, 3.0F, 2.0F, accentColor);
                index++;
            }
        }
    }

    private static float getVisibility(long ageMs) {
        if (ageMs <= 0L) {
            return 0.0F;
        } else if (ageMs < 120L) {
            return clamp((float)ageMs / 120.0F);
        } else {
            long fadeOutStart = 2420L;
            if (ageMs < fadeOutStart) {
                return 1.0F;
            } else {
                return ageMs < 2680L ? 1.0F - clamp((float)(ageMs - fadeOutStart) / 260.0F) : 0.0F;
            }
        }
    }

    private static int applyAlpha(int color, float alpha) {
        int baseAlpha = color >>> 24;
        int scaledAlpha = Math.min(255, Math.max(0, Math.round((float)baseAlpha * clamp(alpha))));
        return scaledAlpha << 24 | color & 16777215;
    }

    private static float clamp(float value) {
        return Math.max(0.0F, Math.min(1.0F, value));
    }

    private static final class NotificationEntry {
        private final String message;
        private final NotificationManager.Type type;
        private final long createdAt;

        private NotificationEntry(String message, NotificationManager.Type type, long createdAt) {
            this.message = message;
            this.type = type;
            this.createdAt = createdAt;
        }
    }

    public static enum Type {
        SUCCESS("ACTIVE"),
        INFO("NOTICE");

        private final String label;

        private Type(String label) {
            this.label = label;
        }
    }
}
