package dev.darg.client.feature.utility;

import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PriorityQueue;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.block.FallingBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.Direction.Type;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public final class AreaDiggerFeature extends Feature {
    private static final float REACH_DISTANCE = 4.65F;
    private static final int MAX_VOLUME = 24576;
    private static final int PATH_MARGIN_XZ = 8;
    private static final int PATH_MARGIN_Y = 4;
    private static final int MAX_NAV_GRAPH_NODES = 2400;
    private static final int LOOKAHEAD_COLUMNS = 6;
    private static final int MAX_COLUMN_TARGETS = 3;
    private static final int PATH_LOOKAHEAD_NODES = 5;
    private static final int BREAK_SWITCH_DELAY_TICKS = 2;
    private static final int BREAK_PULSE_INTERVAL = 1;
    private static final float BOX_LINE_WIDTH = 1.4F;
    private static final float WALK_YAW_STEP = 8.0F;
    private static final float WALK_PITCH_STEP = 6.0F;
    private static final float MINE_YAW_STEP = 12.0F;
    private static final float MINE_PITCH_STEP = 10.0F;
    private static final float FORWARD_ALIGNMENT = 42.0F;
    private static final float STRAFE_ALIGNMENT = 78.0F;
    private static final double SINGLE_MINING_STAND_TOLERANCE_SQ = 0.16;
    private static final double DRILL_MINING_STAND_TOLERANCE_SQ = 0.56;
    private static final double MINING_STABLE_VELOCITY_SQ = 0.0036;
    private static final double PATH_NODE_REACHED_DISTANCE_SQ = 0.36;
    private static final double SINGLE_TRAVEL_STOP_DISTANCE_SQ = 0.045;
    private static final double DRILL_TRAVEL_STOP_DISTANCE_SQ = 0.14;
    private static final double BREAK_TIME_WEIGHT = 2.8;
    private static final int LAVA_MOVE_PENALTY = 14;
    private static final int WATER_MOVE_PENALTY = 5;
    private static final int FALLING_MOVE_PENALTY = 4;
    private static final int HOLE_EDGE_MOVE_PENALTY = 9;
    private static final int HUD_PANEL_FILL = -652798179;
    private static final int HUD_PANEL_EDGE = -13619142;
    private static final int HUD_TEXT = -725018;
    private static final int HUD_MUTED = -5592910;
    private static final int HUD_ACCENT = -6623051;
    private static final int HUD_TRACK = -14408661;
    private static final int AREA_RED = 255;
    private static final int AREA_GREEN = 242;
    private static final int AREA_BLUE = 219;
    private static final int AREA_ALPHA = 185;
    private static final int TARGET_RED = 154;
    private static final int TARGET_GREEN = 240;
    private static final int TARGET_BLUE = 181;
    private static final int TARGET_ALPHA = 210;
    private static final int PATH_RED = 255;
    private static final int PATH_GREEN = 184;
    private static final int PATH_BLUE = 108;
    private static final int PATH_ALPHA = 188;
    private final ClientConfig config = ClientConfig.getInstance();
    private BlockPos startPos;
    private BlockPos endPos;
    private AreaDiggerFeature.ToolMode toolMode;
    private String statusText = "Select two corners";
    private AreaDiggerFeature.ToolFootprint currentFootprint = AreaDiggerFeature.ToolFootprint.SINGLE;
    private int remainingBlocks;
    private int stuckTicks;
    private Vec3d lastPlayerPos = Vec3d.ZERO;
    private BlockPos currentTarget;
    private BlockPos currentStandPos;
    private Direction currentFace;
    private BlockPos activeBreakTarget;
    private Direction activeBreakFace;
    private int activeBreakOrderIndex = Integer.MAX_VALUE;
    private int breakWarmupTicks;
    private int breakPulseTicks;
    private boolean breakStarted;
    private List<BlockPos> currentPath = List.of();
    private int currentPathIndex;
    private Vec3d smoothedTravelGoal;
    private AreaDiggerFeature.PlanningMode currentPlanningMode = AreaDiggerFeature.PlanningMode.NORMAL;
    private boolean completionAnnounced;
    private int baselineRemainingBlocks;
    private Integer currentLayerY;
    private AreaDiggerFeature.ExcavationStrategy currentStrategy = AreaDiggerFeature.ExcavationStrategy.COLUMN;

    public AreaDiggerFeature() {
        super("AreaDigger", Category.UTILITY);
        this.startPos = parseBlockPos(this.config.getAreaDiggerStart());
        this.endPos = parseBlockPos(this.config.getAreaDiggerEnd());
        this.toolMode = AreaDiggerFeature.ToolMode.parse(this.config.getAreaDiggerToolMode());
    }

    @Override
    public boolean shouldPersistEnabledState() {
        return false;
    }

    @Override
    protected void onEnable() {
        this.resetRuntimeState();
    }

    @Override
    protected void onDisable() {
        this.stopAutomation(true);
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        ClientPlayerInteractionManager interactionManager = client.interactionManager;
        ClientWorld world = client.world;
        if (player == null || interactionManager == null || world == null) {
            this.stopAutomation(false);
            this.statusText = "World unavailable";
        } else if (client.currentScreen != null) {
            this.releaseMovementKeys(client);
            this.statusText = "Paused in screen";
        } else if (!this.hasSelection()) {
            this.stopAutomation(false);
            this.statusText = "Select two corners";
        } else {
            AreaDiggerFeature.Cuboid area = AreaDiggerFeature.Cuboid.of(this.startPos, this.endPos);
            if (area.volume() > 24576) {
                this.stopAutomation(false);
                this.statusText = "Area too large (" + area.volume() + ")";
            } else {
                AreaDiggerFeature.ToolFootprint footprint = this.resolveFootprint(player);
                this.currentFootprint = footprint;
                AreaDiggerFeature.NavigationGraph navigationGraph = this.buildNavigationGraph(world, this.getFeetBlock(player), area);
                AreaDiggerFeature.ScanResult scanResult = this.scanArea(world, player, area, footprint, navigationGraph);
                this.remainingBlocks = scanResult.remainingBlocks();
                this.baselineRemainingBlocks = Math.max(this.baselineRemainingBlocks, this.remainingBlocks);
                if (this.remainingBlocks <= 0) {
                    this.stopAutomation(false);
                    this.statusText = "Area cleared";
                    if (!this.completionAnnounced) {
                        this.completionAnnounced = true;
                        player.sendMessage(Text.literal("[Darg's Client] AreaDigger finished the selected area."), false);
                        this.setEnabled(false);
                    }
                } else {
                    this.completionAnnounced = false;
                    if (scanResult.bestTarget() == null) {
                        this.stopAutomation(false);
                        this.statusText = "No exposed path into area";
                    } else {
                        AreaDiggerFeature.MineCandidate candidate = scanResult.bestTarget();
                        this.applyCandidate(world, candidate, footprint);
                        this.selectBestHotbarTool(player, world.getBlockState(candidate.target()));
                        if (candidate.mode() != AreaDiggerFeature.PlanningMode.APPROACH && this.isReadyToMine(world, player, candidate)) {
                            this.releaseMovementKeys(client);
                            this.statusText = (candidate.mode() == AreaDiggerFeature.PlanningMode.UNBLOCK ? "Unblocking " : footprint.label() + " mining ")
                                + formatPos(candidate.target())
                                + " #"
                                + candidate.snakeOrder();
                            this.mineTarget(client, player, interactionManager, candidate);
                        } else {
                            this.navigateToCandidate(client, player, candidate);
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && client.world != null && this.hasSelection()) {
            MatrixStack matrices = context.matrices();
            VertexConsumerProvider consumers = context.consumers();
            if (matrices != null && consumers != null) {
                Camera camera = client.gameRenderer.getCamera();
                Vec3d cameraPos = camera.getCameraPos();
                Entry entry = matrices.peek();
                VertexConsumer consumer = consumers.getBuffer(RenderLayers.linesTranslucent());
                AreaDiggerFeature.Cuboid area = AreaDiggerFeature.Cuboid.of(this.startPos, this.endPos);
                this.drawBox(
                    entry,
                    consumer,
                    (double)area.minX(),
                    (double)area.minY(),
                    (double)area.minZ(),
                    (double)area.maxX() + 1.0,
                    (double)area.maxY() + 1.0,
                    (double)area.maxZ() + 1.0,
                    cameraPos,
                    255,
                    242,
                    219,
                    185
                );
                if (this.currentTarget != null) {
                    this.drawBox(
                        entry,
                        consumer,
                        (double)this.currentTarget.getX(),
                        (double)this.currentTarget.getY(),
                        (double)this.currentTarget.getZ(),
                        (double)this.currentTarget.getX() + 1.0,
                        (double)this.currentTarget.getY() + 1.0,
                        (double)this.currentTarget.getZ() + 1.0,
                        cameraPos,
                        154,
                        240,
                        181,
                        210
                    );
                }

                if (this.currentPath.size() >= 2) {
                    for (int index = Math.max(0, this.currentPathIndex - 1); index < this.currentPath.size() - 1; index++) {
                        Vec3d start = Vec3d.ofBottomCenter((Vec3i)this.currentPath.get(index)).subtract(cameraPos).add(0.0, 0.05, 0.0);
                        Vec3d end = Vec3d.ofBottomCenter((Vec3i)this.currentPath.get(index + 1)).subtract(cameraPos).add(0.0, 0.05, 0.0);
                        this.drawLine(entry, consumer, start, end, 255, 184, 108, 188);
                    }
                }
            }
        }
    }

    @Override
    public List<Feature.ClickGuiAction> getClickGuiActions() {
        List<Feature.ClickGuiAction> actions = new ArrayList<>();
        actions.add(new Feature.ClickGuiAction("set_start_look", "Set Start From Look", true));
        actions.add(new Feature.ClickGuiAction("set_end_look", "Set End From Look", true));
        actions.add(new Feature.ClickGuiAction("set_start_feet", "Set Start From Feet", false));
        actions.add(new Feature.ClickGuiAction("set_end_feet", "Set End From Feet", false));
        actions.add(new Feature.ClickGuiAction("cycle_mode", "Tool Mode: " + this.toolMode.label(), false));
        if (this.hasSelection()) {
            actions.add(new Feature.ClickGuiAction("clear_area", "Clear Selection", false));
        }

        return actions;
    }

    @Override
    public boolean handleClickGuiAction(String actionId, NotificationManager notificationManager) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        switch (actionId) {
            case "set_start_look":
                BlockPos looked = this.getLookedBlock(client);
                if (looked == null) {
                    notificationManager.push("Look at a block first", NotificationManager.Type.INFO);
                    return true;
                }

                this.startPos = looked.toImmutable();
                this.saveSelection();
                notificationManager.push("AreaDigger start set to " + formatPos(this.startPos), NotificationManager.Type.SUCCESS);
                return true;
            case "set_end_look":
                BlockPos looked = this.getLookedBlock(client);
                if (looked == null) {
                    notificationManager.push("Look at a block first", NotificationManager.Type.INFO);
                    return true;
                }

                this.endPos = looked.toImmutable();
                this.saveSelection();
                notificationManager.push("AreaDigger end set to " + formatPos(this.endPos), NotificationManager.Type.SUCCESS);
                return true;
            case "set_start_feet":
                if (player == null) {
                    notificationManager.push("Join a world first", NotificationManager.Type.INFO);
                    return true;
                }

                this.startPos = player.getBlockPos().toImmutable();
                this.saveSelection();
                notificationManager.push("AreaDigger start set to " + formatPos(this.startPos), NotificationManager.Type.SUCCESS);
                return true;
            case "set_end_feet":
                if (player == null) {
                    notificationManager.push("Join a world first", NotificationManager.Type.INFO);
                    return true;
                }

                this.endPos = player.getBlockPos().toImmutable();
                this.saveSelection();
                notificationManager.push("AreaDigger end set to " + formatPos(this.endPos), NotificationManager.Type.SUCCESS);
                return true;
            case "cycle_mode":
                this.toolMode = this.toolMode.next();
                this.config.setAreaDiggerToolMode(this.toolMode.name());
                this.config.save();
                notificationManager.push("AreaDigger mode: " + this.toolMode.label(), NotificationManager.Type.SUCCESS);
                return true;
            case "clear_area":
                this.startPos = null;
                this.endPos = null;
                this.saveSelection();
                notificationManager.push("AreaDigger selection cleared", NotificationManager.Type.INFO);
                return true;
            default:
                return false;
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        AreaDiggerFeature.Cuboid area = this.hasSelection() ? AreaDiggerFeature.Cuboid.of(this.startPos, this.endPos) : null;
        return List.of(
            "Mode: " + this.toolMode.label(),
            "Start: " + (this.startPos == null ? "-" : formatPos(this.startPos)),
            "End: " + (this.endPos == null ? "-" : formatPos(this.endPos)),
            "Volume: " + (area == null ? "-" : Integer.toString(area.volume())),
            "Remaining: " + this.remainingBlocks,
            "Status: " + this.statusText
        );
    }

    @Override
    public String getHudSuffix() {
        if (!this.hasSelection()) {
            return "SELECT";
        } else {
            return this.remainingBlocks > 0 ? this.remainingBlocks + " " + this.toolMode.shortLabel() : this.toolMode.shortLabel();
        }
    }

    @Override
    public void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        if (this.isEnabled() && this.hasSelection()) {
            MinecraftClient client = MinecraftClient.getInstance();
            TextRenderer textRenderer = client.textRenderer;
            if (textRenderer != null) {
                int total = Math.max(this.baselineRemainingBlocks, this.remainingBlocks);
                int cleared = Math.max(0, total - this.remainingBlocks);
                float progress = total <= 0 ? 0.0F : MathHelper.clamp((float)cleared / (float)total, 0.0F, 1.0F);
                float width = 178.0F;
                float height = 58.0F;
                float x = ((float)context.getScaledWindowWidth() - width) * 0.5F;
                float y = 14.0F;
                RenderUtil.drawRoundedRect(context, x, y, width, height, 8.0F, -652798179);
                RenderUtil.drawRoundedRect(context, x, y, width, 1.0F, 1.0F, -13619142);
                RenderUtil.drawRoundedRect(context, x, y + height - 1.0F, width, 1.0F, 1.0F, -13619142);
                RenderUtil.drawRoundedRect(context, x, y, 1.0F, height, 1.0F, -13619142);
                RenderUtil.drawRoundedRect(context, x + width - 1.0F, y, 1.0F, height, 1.0F, -13619142);
                RenderUtil.drawText(context, textRenderer, "AREA DIGGER", x + 8.0F, y + 6.0F, -725018);
                RenderUtil.drawText(context, textRenderer, Math.round(progress * 100.0F) + "%", x + width - 34.0F, y + 6.0F, -6623051);
                float barX = x + 8.0F;
                float barY = y + 20.0F;
                float barWidth = width - 16.0F;
                RenderUtil.drawRoundedRect(context, barX, barY, barWidth, 8.0F, 4.0F, -14408661);
                if (progress > 0.0F) {
                    RenderUtil.drawRoundedRect(context, barX, barY, Math.max(8.0F, barWidth * progress), 8.0F, 4.0F, -6623051);
                }

                RenderUtil.drawText(context, textRenderer, "Cleared " + cleared + " / " + total, x + 8.0F, y + 34.0F, -5592910);
                String rightLine = this.currentLayerY == null
                    ? this.currentStrategy.name()
                    : "Layer Y: " + this.currentLayerY + " • " + this.currentStrategy.name();
                RenderUtil.drawText(context, textRenderer, rightLine, x + 8.0F, y + 45.0F, -5592910);
                String statusLine = this.statusText.length() > 28 ? this.statusText.substring(0, 28) + "…" : this.statusText;
                RenderUtil.drawText(context, textRenderer, statusLine, x + 88.0F, y + 34.0F, -725018);
            }
        }
    }

    private void navigateToCandidate(MinecraftClient client, ClientPlayerEntity player, AreaDiggerFeature.MineCandidate candidate) {
        if (this.currentPath.isEmpty()) {
            this.statusText = (candidate.mode() == AreaDiggerFeature.PlanningMode.UNBLOCK ? "Unblocking to " : "Walking to ") + formatPos(candidate.standPos());
            this.steerToward(
                client, player, this.updateSmoothedTravelGoal(this.getStandTravelPoint(candidate.standPos(), candidate.target(), candidate.face())), false
            );
        } else {
            String prefix = switch (candidate.mode()) {
                case UNBLOCK -> "Unblock path ";
                case APPROACH -> "Approach path ";
                default -> "Snake path ";
            };
            this.statusText = prefix + formatPos(candidate.standPos()) + " (" + this.currentPath.size() + ")";
            this.followPath(client, player);
        }

        this.updateStuckState(player);
    }

    private void applyCandidate(ClientWorld world, AreaDiggerFeature.MineCandidate candidate, AreaDiggerFeature.ToolFootprint footprint) {
        boolean sameStand = this.currentStandPos != null && this.currentStandPos.equals(candidate.standPos());
        boolean sameMode = this.currentPlanningMode == candidate.mode();
        boolean routeStillValid = sameStand && sameMode && this.pathStillLeadsTo(candidate.standPos());
        boolean keepCurrentDrillTarget = footprint == AreaDiggerFeature.ToolFootprint.DRILL
            && sameStand
            && sameMode
            && this.currentTarget != null
            && this.currentFace != null
            && this.shouldMine(world, this.currentTarget)
            && this.currentFace.getAxis() == candidate.face().getAxis();
        if (keepCurrentDrillTarget) {
            this.currentPlanningMode = candidate.mode();
        } else {
            this.currentTarget = candidate.target();
            this.currentFace = candidate.face();
            this.currentStandPos = candidate.standPos();
            this.currentPlanningMode = candidate.mode();
            if (!routeStillValid) {
                this.currentPath = candidate.path();
                this.currentPathIndex = this.currentPath.size() > 1 ? 1 : 0;
                this.smoothedTravelGoal = this.currentPath.isEmpty() ? Vec3d.ofBottomCenter(candidate.standPos()) : null;
            }
        }
    }

    private boolean pathStillLeadsTo(BlockPos standPos) {
        return this.currentPath.isEmpty() ? false : this.currentPath.get(this.currentPath.size() - 1).equals(standPos);
    }

    private void mineTarget(
        MinecraftClient client, ClientPlayerEntity player, ClientPlayerInteractionManager interactionManager, AreaDiggerFeature.MineCandidate candidate
    ) {
        Vec3d hit = this.getHitPoint(candidate.target(), candidate.face());
        AreaDiggerFeature.RotationState rotation = this.rotateToward(player, hit, 12.0F, 10.0F);
        if (!candidate.target().equals(this.activeBreakTarget)
            || candidate.face() != this.activeBreakFace
            || candidate.snakeOrder() != this.activeBreakOrderIndex) {
            interactionManager.cancelBlockBreaking();
            this.activeBreakTarget = candidate.target().toImmutable();
            this.activeBreakFace = candidate.face();
            this.activeBreakOrderIndex = candidate.snakeOrder();
            this.breakWarmupTicks = 2;
            this.breakPulseTicks = 0;
            this.breakStarted = false;
        }

        if (rotation.isAligned()) {
            if (this.breakWarmupTicks > 0) {
                this.breakWarmupTicks--;
            } else if (!this.breakStarted) {
                if (interactionManager.attackBlock(candidate.target(), candidate.face())) {
                    player.swingHand(Hand.MAIN_HAND);
                }

                this.breakStarted = true;
                this.breakPulseTicks = 1;
            } else if (this.breakPulseTicks > 0) {
                this.breakPulseTicks--;
            } else {
                if (interactionManager.updateBlockBreakingProgress(candidate.target(), candidate.face())) {
                    player.swingHand(Hand.MAIN_HAND);
                }

                this.breakPulseTicks = 1;
            }
        }
    }

    private void followPath(MinecraftClient client, ClientPlayerEntity player) {
        if (this.currentPath.isEmpty()) {
            this.releaseMovementKeys(client);
        } else {
            while (this.currentPathIndex < this.currentPath.size() - 1 && this.isAtNode(player, this.currentPath.get(this.currentPathIndex))) {
                this.currentPathIndex++;
            }

            this.advancePathLookahead(player);
            AreaDiggerFeature.PathGoal goal = this.computeSmoothedPathGoal();
            boolean jump = goal.anchor().getY() > this.getFeetBlock(player).getY();
            this.steerToward(client, player, this.updateSmoothedTravelGoal(goal.position()), jump);
        }
    }

    private void steerToward(MinecraftClient client, ClientPlayerEntity player, Vec3d goal, boolean jump) {
        Vec3d from = new Vec3d(player.getX(), player.getBoundingBox().minY, player.getZ());
        Vec3d delta = goal.subtract(from);
        float yawStep = Math.min(16.0F, 8.0F + (float)Math.min(6.0, Math.sqrt(delta.horizontalLengthSquared()) * 1.4));
        Vec3d lookGoal = new Vec3d(goal.x, player.getEyeY(), goal.z);
        AreaDiggerFeature.RotationState rotation = this.rotateToward(player, lookGoal, yawStep, 6.0F);
        float absoluteYawError = Math.abs(rotation.yawError());
        this.releaseMovementKeys(client);
        double stopDistanceSq = this.currentFootprint == AreaDiggerFeature.ToolFootprint.DRILL ? 0.14 : 0.045;
        if (!(delta.horizontalLengthSquared() <= stopDistanceSq) || !(Math.abs(delta.y) <= 0.35)) {
            boolean forward = absoluteYawError <= 100.0F;
            boolean strafe = absoluteYawError >= 14.0F && absoluteYawError <= 78.0F;
            if (forward) {
                client.options.forwardKey.setPressed(true);
            }

            if (strafe) {
                if (rotation.yawError() > 0.0F) {
                    client.options.leftKey.setPressed(true);
                } else {
                    client.options.rightKey.setPressed(true);
                }
            }

            client.options.sprintKey.setPressed(forward && absoluteYawError <= 28.0F && player.isOnGround() && delta.horizontalLengthSquared() > 2.25);
            client.options.jumpKey.setPressed(jump && absoluteYawError <= 78.0F && (player.isOnGround() || delta.y > 0.55));
        }
    }

    private Vec3d updateSmoothedTravelGoal(Vec3d desiredGoal) {
        if (this.smoothedTravelGoal == null) {
            this.smoothedTravelGoal = desiredGoal;
            return desiredGoal;
        } else {
            double distanceSq = this.smoothedTravelGoal.squaredDistanceTo(desiredGoal);
            double blend = distanceSq > 16.0 ? 0.5 : (distanceSq > 4.0 ? 0.32 : 0.2);
            this.smoothedTravelGoal = this.smoothedTravelGoal.lerp(desiredGoal, blend);
            return this.smoothedTravelGoal;
        }
    }

    private AreaDiggerFeature.PathGoal computeSmoothedPathGoal() {
        int lastIndex = Math.min(this.currentPath.size() - 1, this.currentPathIndex);
        Vec3d weightedGoal = Vec3d.ZERO;
        double totalWeight = 0.0;
        BlockPos anchor = this.currentPath.get(lastIndex);
        Direction lane = null;

        for (int index = this.currentPathIndex; index <= Math.min(this.currentPath.size() - 1, this.currentPathIndex + 5); index++) {
            BlockPos node = this.currentPath.get(index);
            if (index > this.currentPathIndex) {
                Direction step = this.stepDirection(this.currentPath.get(index - 1), node);
                if (step == null) {
                    break;
                }

                if (lane == null) {
                    lane = step;
                } else if (lane != step) {
                    break;
                }
            }

            Vec3d nodeGoal = node.equals(this.currentStandPos) && this.currentTarget != null && this.currentFace != null
                ? this.getStandTravelPoint(node, this.currentTarget, this.currentFace)
                : Vec3d.ofBottomCenter(node);
            double weight = 1.0 / (1.0 + (double)(index - this.currentPathIndex) * 0.7);
            weightedGoal = weightedGoal.add(nodeGoal.multiply(weight));
            totalWeight += weight;
            anchor = node;
        }

        return !(totalWeight <= 0.0)
            ? new AreaDiggerFeature.PathGoal(weightedGoal.multiply(1.0 / totalWeight), anchor)
            : new AreaDiggerFeature.PathGoal(
                anchor.equals(this.currentStandPos) && this.currentTarget != null && this.currentFace != null
                    ? this.getStandTravelPoint(anchor, this.currentTarget, this.currentFace)
                    : Vec3d.ofBottomCenter(anchor),
                anchor
            );
    }

    private void advancePathLookahead(ClientPlayerEntity player) {
        if (this.currentPathIndex < this.currentPath.size() - 1) {
            BlockPos previous = this.currentPathIndex > 0 ? this.currentPath.get(this.currentPathIndex - 1) : this.getFeetBlock(player);
            Direction lane = null;
            int bestIndex = this.currentPathIndex;
            int limit = Math.min(this.currentPath.size() - 1, this.currentPathIndex + 5);

            for (int index = this.currentPathIndex; index <= limit; index++) {
                BlockPos node = this.currentPath.get(index);
                Direction step = this.stepDirection(previous, node);
                if (step == null) {
                    break;
                }

                if (lane == null) {
                    lane = step;
                } else if (lane != step) {
                    break;
                }

                if (Math.abs(node.getY() - previous.getY()) > 1) {
                    break;
                }

                bestIndex = index;
                previous = node;
            }

            this.currentPathIndex = Math.max(this.currentPathIndex, bestIndex);
        }
    }

    private Direction stepDirection(BlockPos from, BlockPos to) {
        int dx = Integer.compare(to.getX(), from.getX());
        int dz = Integer.compare(to.getZ(), from.getZ());
        if (dx == 1 && dz == 0) {
            return Direction.EAST;
        } else if (dx == -1 && dz == 0) {
            return Direction.WEST;
        } else if (dx == 0 && dz == 1) {
            return Direction.SOUTH;
        } else {
            return dx == 0 && dz == -1 ? Direction.NORTH : null;
        }
    }

    private AreaDiggerFeature.ScanResult scanArea(
        ClientWorld world,
        ClientPlayerEntity player,
        AreaDiggerFeature.Cuboid area,
        AreaDiggerFeature.ToolFootprint footprint,
        AreaDiggerFeature.NavigationGraph navigationGraph
    ) {
        int remaining = 0;
        AreaDiggerFeature.ExcavationStrategy strategy = this.determineExcavationStrategy(area);
        Integer activeLayerY = this.selectActiveLayerY(world, area, strategy);
        this.currentStrategy = strategy;
        this.currentLayerY = activeLayerY;
        List<AreaDiggerFeature.ColumnPlan> columnPlans = new ArrayList<>();

        for (AreaDiggerFeature.ColumnCursor cursor : this.iterateSnakeColumns(area)) {
            List<BlockPos> remainingInColumn = new ArrayList<>();

            for (int y = area.minY(); y <= area.maxY(); y++) {
                if (activeLayerY == null || y == activeLayerY) {
                    BlockPos pos = new BlockPos(cursor.x(), y, cursor.z());
                    if (this.shouldMine(world, pos)) {
                        remaining++;
                        remainingInColumn.add(pos.toImmutable());
                    }
                }
            }

            if (!remainingInColumn.isEmpty()) {
                remainingInColumn = this.prioritizeColumnTargets(world, remainingInColumn);
                columnPlans.add(new AreaDiggerFeature.ColumnPlan(cursor, this.computeColumnOrder(area, cursor), remainingInColumn));
            }
        }

        if (remaining <= 0) {
            return new AreaDiggerFeature.ScanResult(0, null);
        } else {
            AreaDiggerFeature.MineCandidate lookaheadCandidate = this.selectCandidate(
                world, player, area, footprint, navigationGraph, columnPlans, 0, Math.min(6, columnPlans.size()), AreaDiggerFeature.PlanningMode.NORMAL
            );
            if (lookaheadCandidate != null) {
                return new AreaDiggerFeature.ScanResult(remaining, lookaheadCandidate);
            } else {
                AreaDiggerFeature.MineCandidate unblockCandidate = this.selectCandidate(
                    world, player, area, footprint, navigationGraph, columnPlans, 0, columnPlans.size(), AreaDiggerFeature.PlanningMode.UNBLOCK
                );
                return unblockCandidate != null
                    ? new AreaDiggerFeature.ScanResult(remaining, unblockCandidate)
                    : new AreaDiggerFeature.ScanResult(remaining, this.selectApproachCandidate(world, player, area, navigationGraph, columnPlans));
            }
        }
    }

    private AreaDiggerFeature.ExcavationStrategy determineExcavationStrategy(AreaDiggerFeature.Cuboid area) {
        return area.height() >= 4 && area.width() >= 2 && area.depth() >= 2
            ? AreaDiggerFeature.ExcavationStrategy.LAYERED
            : AreaDiggerFeature.ExcavationStrategy.COLUMN;
    }

    private Integer selectActiveLayerY(ClientWorld world, AreaDiggerFeature.Cuboid area, AreaDiggerFeature.ExcavationStrategy strategy) {
        if (strategy != AreaDiggerFeature.ExcavationStrategy.LAYERED) {
            return null;
        } else {
            for (int y = area.maxY(); y >= area.minY(); y--) {
                for (int x = area.minX(); x <= area.maxX(); x++) {
                    for (int z = area.minZ(); z <= area.maxZ(); z++) {
                        if (this.shouldMine(world, new BlockPos(x, y, z))) {
                            return y;
                        }
                    }
                }
            }

            return null;
        }
    }

    private AreaDiggerFeature.MineCandidate selectCandidate(
        ClientWorld world,
        ClientPlayerEntity player,
        AreaDiggerFeature.Cuboid area,
        AreaDiggerFeature.ToolFootprint footprint,
        AreaDiggerFeature.NavigationGraph navigationGraph,
        List<AreaDiggerFeature.ColumnPlan> columnPlans,
        int startIndex,
        int endIndex,
        AreaDiggerFeature.PlanningMode planningMode
    ) {
        AreaDiggerFeature.MineCandidate best = null;

        for (int columnIndex = startIndex; columnIndex < endIndex; columnIndex++) {
            AreaDiggerFeature.ColumnPlan columnPlan = columnPlans.get(columnIndex);
            int targetLimit = Math.min(3, columnPlan.remainingBlocks().size());

            for (int blockIndex = 0; blockIndex < targetLimit; blockIndex++) {
                BlockPos target = columnPlan.remainingBlocks().get(blockIndex);

                for (AreaDiggerFeature.MineCandidate candidate : this.buildCandidates(
                    world, player, area, footprint, navigationGraph, columnPlan, target, blockIndex, planningMode
                )) {
                    if (best == null || candidate.score() > best.score()) {
                        best = candidate;
                    }
                }
            }
        }

        return best;
    }

    private List<AreaDiggerFeature.MineCandidate> buildCandidates(
        ClientWorld world,
        ClientPlayerEntity player,
        AreaDiggerFeature.Cuboid area,
        AreaDiggerFeature.ToolFootprint footprint,
        AreaDiggerFeature.NavigationGraph navigationGraph,
        AreaDiggerFeature.ColumnPlan columnPlan,
        BlockPos target,
        int blockDepth,
        AreaDiggerFeature.PlanningMode planningMode
    ) {
        List<AreaDiggerFeature.MineCandidate> candidates = new ArrayList<>();
        BlockPos playerFeet = this.getFeetBlock(player);
        int targetOrder = this.computeSnakeIndex(area, target);
        BlockState targetState = world.getBlockState(target);
        if (planningMode == AreaDiggerFeature.PlanningMode.NORMAL && this.shouldDelayForFallingSupport(world, target, targetState)) {
            return candidates;
        } else {
            for (Direction direction : Direction.values()) {
                if (this.isFaceExposed(world, area, target, direction)) {
                    AreaDiggerFeature.CoverageInfo coverage = this.measureCoverage(world, area, target, direction, footprint);
                    double faceBonus = this.scoreFacePreference(world, area, footprint, target, direction);
                    double estimatedBreakTicks = this.estimateBreakTicks(player, world, target, coverage, footprint);
                    boolean directlyReachable = this.canMineFrom(world, player.getEyePos(), target, direction);
                    if (directlyReachable) {
                        Vec3d hit = this.getHitPoint(target, direction);
                        double hazardPenalty = this.scoreHazards(world, playerFeet, target);
                        double routeBonus = this.scoreStandPreference(target, direction, playerFeet, footprint);
                        double score = this.scoreCandidate(
                                playerFeet,
                                player.getEyePos(),
                                hit,
                                coverage,
                                columnPlan,
                                blockDepth,
                                0,
                                targetOrder,
                                planningMode,
                                true,
                                estimatedBreakTicks,
                                hazardPenalty
                            )
                            + faceBonus
                            + routeBonus;
                        candidates.add(
                            new AreaDiggerFeature.MineCandidate(
                                target.toImmutable(),
                                direction,
                                playerFeet.toImmutable(),
                                coverage.coverage(),
                                coverage.earliestOrder(),
                                score,
                                planningMode,
                                List.of()
                            )
                        );
                    }

                    for (BlockPos standPos : this.getStandPositions(world, target, direction)) {
                        if (navigationGraph.canReach(standPos)) {
                            List<BlockPos> path = this.simplifyPath(world, navigationGraph.buildPathTo(standPos));
                            if (!path.isEmpty()) {
                                Vec3d standEyePos = this.estimateEyePos(player, standPos);
                                if (this.canMineFrom(world, standEyePos, target, direction)) {
                                    int pathDistance = navigationGraph.distanceTo(standPos);
                                    Vec3d hit = this.getHitPoint(target, direction);
                                    double hazardPenalty = this.scoreHazards(world, standPos, target);
                                    double routeBonus = this.scoreStandPreference(target, direction, standPos, footprint)
                                        - (double)this.countPathTurns(path) * 16.0;
                                    double score = this.scoreCandidate(
                                            playerFeet,
                                            player.getEyePos(),
                                            hit,
                                            coverage,
                                            columnPlan,
                                            blockDepth,
                                            pathDistance,
                                            targetOrder,
                                            planningMode,
                                            false,
                                            estimatedBreakTicks,
                                            hazardPenalty
                                        )
                                        + faceBonus
                                        + routeBonus;
                                    candidates.add(
                                        new AreaDiggerFeature.MineCandidate(
                                            target.toImmutable(),
                                            direction,
                                            standPos.toImmutable(),
                                            coverage.coverage(),
                                            coverage.earliestOrder(),
                                            score,
                                            planningMode,
                                            path
                                        )
                                    );
                                }
                            }
                        }
                    }
                }
            }

            return candidates;
        }
    }

    private AreaDiggerFeature.MineCandidate selectApproachCandidate(
        ClientWorld world,
        ClientPlayerEntity player,
        AreaDiggerFeature.Cuboid area,
        AreaDiggerFeature.NavigationGraph navigationGraph,
        List<AreaDiggerFeature.ColumnPlan> columnPlans
    ) {
        AreaDiggerFeature.MineCandidate best = null;

        for (int index = 0; index < Math.min(6, columnPlans.size()); index++) {
            AreaDiggerFeature.ColumnPlan columnPlan = columnPlans.get(index);
            BlockPos target = this.selectPreferredColumnTarget(world, columnPlan.remainingBlocks());

            for (Direction direction : Type.HORIZONTAL) {
                for (BlockPos standPos : this.getStandPositions(world, target, direction)) {
                    if (navigationGraph.canReach(standPos)) {
                        List<BlockPos> path = this.simplifyPath(world, navigationGraph.buildPathTo(standPos));
                        if (!path.isEmpty()) {
                            int pathDistance = navigationGraph.distanceTo(standPos);
                            double score = -((double)columnPlan.columnOrder() * 48.0)
                                - (double)pathDistance * 6.0
                                + this.scoreStandPreference(target, direction, standPos, this.currentFootprint)
                                - (double)this.countPathTurns(path) * 12.0;
                            AreaDiggerFeature.MineCandidate candidate = new AreaDiggerFeature.MineCandidate(
                                target, direction, standPos, 0, this.computeSnakeIndex(area, target), score, AreaDiggerFeature.PlanningMode.APPROACH, path
                            );
                            if (best == null || candidate.score() > best.score()) {
                                best = candidate;
                            }
                        }
                    }
                }
            }
        }

        return best;
    }

    private double scoreCandidate(
        BlockPos playerFeet,
        Vec3d eyePos,
        Vec3d hit,
        AreaDiggerFeature.CoverageInfo coverage,
        AreaDiggerFeature.ColumnPlan columnPlan,
        int blockDepth,
        int pathDistance,
        int targetOrder,
        AreaDiggerFeature.PlanningMode planningMode,
        boolean direct,
        double estimatedBreakTicks,
        double hazardPenalty
    ) {
        double score = 0.0;
        score -= (double)columnPlan.columnOrder() * (planningMode == AreaDiggerFeature.PlanningMode.NORMAL ? 72.0 : 18.0);
        score -= (double)blockDepth * 26.0;
        score -= (double)pathDistance * 8.5;
        score -= eyePos.squaredDistanceTo(hit) * 0.1;
        score -= estimatedBreakTicks * 2.8;
        score -= hazardPenalty;
        score += (double)coverage.coverage() * 8.0;
        score += (double)Math.max(0, targetOrder - coverage.earliestOrder()) * 0.5;
        if (direct) {
            score += 18.0;
        }

        if (planningMode == AreaDiggerFeature.PlanningMode.UNBLOCK) {
            score -= 120.0;
        }

        if (this.currentTarget != null && this.currentTarget.equals(columnPlan.remainingBlocks().getFirst())) {
            score += 6.0;
        }

        return score;
    }

    private AreaDiggerFeature.NavigationGraph buildNavigationGraph(ClientWorld world, BlockPos start, AreaDiggerFeature.Cuboid area) {
        int minX = area.minX() - 8;
        int maxX = area.maxX() + 8;
        int minY = area.minY() - 4;
        int maxY = area.maxY() + 4;
        int minZ = area.minZ() - 8;
        int maxZ = area.maxZ() + 8;
        BlockPos graphStart = this.findNavigationStart(world, start, minX, maxX, minY, maxY, minZ, maxZ);
        if (graphStart == null) {
            return AreaDiggerFeature.NavigationGraph.empty();
        } else {
            PriorityQueue<AreaDiggerFeature.PathNode> open = new PriorityQueue<>(Comparator.comparingDouble(AreaDiggerFeature.PathNode::priority));
            Map<BlockPos, BlockPos> parents = new HashMap<>();
            Map<BlockPos, Integer> distances = new HashMap<>();
            open.add(new AreaDiggerFeature.PathNode(graphStart, 0, 0.0));
            distances.put(graphStart, 0);
            int expanded = 0;

            while (!open.isEmpty() && expanded < 2400) {
                AreaDiggerFeature.PathNode node = open.poll();
                if (node.cost() == distances.getOrDefault(node.pos(), Integer.MAX_VALUE)) {
                    expanded++;

                    for (BlockPos neighbor : this.getNeighbors(world, node.pos(), minX, maxX, minY, maxY, minZ, maxZ)) {
                        int nextCost = node.cost() + this.movementCost(world, neighbor);
                        if (nextCost < distances.getOrDefault(neighbor, Integer.MAX_VALUE)) {
                            distances.put(neighbor, nextCost);
                            parents.put(neighbor, node.pos());
                            open.add(new AreaDiggerFeature.PathNode(neighbor, nextCost, (double)nextCost));
                        }
                    }
                }
            }

            return new AreaDiggerFeature.NavigationGraph(graphStart, parents, distances);
        }
    }

    private BlockPos findNavigationStart(ClientWorld world, BlockPos start, int minX, int maxX, int minY, int maxY, int minZ, int maxZ) {
        for (BlockPos probe : List.of(
            start,
            start.down(),
            start.up(),
            start.north(),
            start.south(),
            start.east(),
            start.west(),
            start.north().down(),
            start.south().down(),
            start.east().down(),
            start.west().down()
        )) {
            if (probe.getX() >= minX
                && probe.getX() <= maxX
                && probe.getY() >= minY
                && probe.getY() <= maxY
                && probe.getZ() >= minZ
                && probe.getZ() <= maxZ
                && this.isWalkable(world, probe)) {
                return probe.toImmutable();
            }
        }

        return null;
    }

    private List<BlockPos> getNeighbors(ClientWorld world, BlockPos origin, int minX, int maxX, int minY, int maxY, int minZ, int maxZ) {
        List<BlockPos> neighbors = new ArrayList<>(12);

        for (Direction direction : Type.HORIZONTAL) {
            BlockPos sameLevel = origin.offset(direction);
            this.addWalkable(world, neighbors, sameLevel, minX, maxX, minY, maxY, minZ, maxZ);
            this.addWalkable(world, neighbors, sameLevel.up(), minX, maxX, minY, maxY, minZ, maxZ);
            this.addWalkable(world, neighbors, sameLevel.down(), minX, maxX, minY, maxY, minZ, maxZ);
        }

        return neighbors;
    }

    private void addWalkable(ClientWorld world, List<BlockPos> neighbors, BlockPos pos, int minX, int maxX, int minY, int maxY, int minZ, int maxZ) {
        if (pos.getX() >= minX
            && pos.getX() <= maxX
            && pos.getY() >= minY
            && pos.getY() <= maxY
            && pos.getZ() >= minZ
            && pos.getZ() <= maxZ) {
            if (this.isWalkable(world, pos)) {
                neighbors.add(pos.toImmutable());
            }
        }
    }

    private int movementCost(ClientWorld world, BlockPos feetPos) {
        int cost = 1;
        if (this.hasNearbyLava(world, feetPos)) {
            cost += 14;
        } else if (this.hasNearbyWater(world, feetPos)) {
            cost += 5;
        }

        if (this.hasLooseFallingThreat(world, feetPos)) {
            cost += 4;
        }

        if (this.isNearAvoidedHole(world, feetPos)) {
            cost += 9;
        }

        return cost;
    }

    private boolean isWalkable(ClientWorld world, BlockPos feetPos) {
        return this.isOpen(world, feetPos) && this.isOpen(world, feetPos.up()) && this.hasSolidFloor(world, feetPos.down());
    }

    private boolean shouldMine(ClientWorld world, BlockPos pos) {
        BlockState state = world.getBlockState(pos);
        return !state.isAir() && state.getFluidState().isEmpty() && state.getHardness(world, pos) >= 0.0F;
    }

    private boolean isFallingState(BlockState state) {
        return state.getBlock() instanceof FallingBlock;
    }

    private boolean isLavaFluid(FluidState state) {
        return state.isOf(Fluids.LAVA) || state.isOf(Fluids.FLOWING_LAVA);
    }

    private boolean isWaterFluid(FluidState state) {
        return state.isOf(Fluids.WATER) || state.isOf(Fluids.FLOWING_WATER);
    }

    private boolean hasNearbyLava(ClientWorld world, BlockPos feetPos) {
        return this.forNearbyHazardPos(feetPos).stream().anyMatch(pos -> this.isLavaFluid(world.getFluidState(pos)));
    }

    private boolean hasNearbyWater(ClientWorld world, BlockPos feetPos) {
        return this.forNearbyHazardPos(feetPos).stream().anyMatch(pos -> this.isWaterFluid(world.getFluidState(pos)));
    }

    private boolean hasLooseFallingThreat(ClientWorld world, BlockPos feetPos) {
        return this.isFallingState(world.getBlockState(feetPos.up().up()))
            || this.isFallingState(world.getBlockState(feetPos.up().up().north()))
            || this.isFallingState(world.getBlockState(feetPos.up().up().south()))
            || this.isFallingState(world.getBlockState(feetPos.up().up().east()))
            || this.isFallingState(world.getBlockState(feetPos.up().up().west()));
    }

    private boolean isNearAvoidedHole(ClientWorld world, BlockPos feetPos) {
        for (Direction direction : Type.HORIZONTAL) {
            BlockPos neighbor = feetPos.offset(direction);
            if (!this.isAllowedDescentHole(neighbor) && this.getDropDepth(world, neighbor) >= 2) {
                return true;
            }
        }

        return false;
    }

    private boolean isAllowedDescentHole(BlockPos feetPos) {
        if (this.hasSelection() && this.currentStrategy == AreaDiggerFeature.ExcavationStrategy.LAYERED && this.currentLayerY != null) {
            AreaDiggerFeature.Cuboid area = AreaDiggerFeature.Cuboid.of(this.startPos, this.endPos);
            return area.contains(feetPos) && feetPos.getY() <= this.currentLayerY;
        } else {
            return false;
        }
    }

    private int getDropDepth(ClientWorld world, BlockPos feetPos) {
        if (this.isOpen(world, feetPos) && this.isOpen(world, feetPos.up())) {
            int depth = 0;

            BlockPos cursor;
            for (cursor = feetPos.down(); depth < 4 && this.isOpen(world, cursor); cursor = cursor.down()) {
                depth++;
            }

            return this.hasSolidFloor(world, cursor) ? depth : 4;
        } else {
            return 0;
        }
    }

    private List<BlockPos> forNearbyHazardPos(BlockPos feetPos) {
        return List.of(
            feetPos,
            feetPos.up(),
            feetPos.down(),
            feetPos.north(),
            feetPos.south(),
            feetPos.east(),
            feetPos.west(),
            feetPos.up().north(),
            feetPos.up().south(),
            feetPos.up().east(),
            feetPos.up().west()
        );
    }

    private boolean shouldDelayForFallingSupport(ClientWorld world, BlockPos target, BlockState state) {
        return !this.isFallingState(state) && this.isFallingState(world.getBlockState(target.up()));
    }

    private boolean isFaceExposed(ClientWorld world, AreaDiggerFeature.Cuboid area, BlockPos target, Direction face) {
        BlockPos adjacent = target.offset(face);
        return !this.isOpen(world, adjacent) ? false : !area.contains(adjacent) || this.isOpen(world, adjacent);
    }

    private BlockPos selectPreferredColumnTarget(ClientWorld world, List<BlockPos> remainingInColumn) {
        for (int index = remainingInColumn.size() - 1; index >= 0; index--) {
            BlockPos pos = remainingInColumn.get(index);
            if (this.isFallingState(world.getBlockState(pos))) {
                return pos;
            }
        }

        for (BlockPos pos : remainingInColumn) {
            if (!this.isFallingState(world.getBlockState(pos.up()))) {
                return pos;
            }
        }

        return remainingInColumn.getFirst();
    }

    private List<BlockPos> prioritizeColumnTargets(ClientWorld world, List<BlockPos> remainingInColumn) {
        BlockPos preferred = this.selectPreferredColumnTarget(world, remainingInColumn);
        List<BlockPos> prioritized = new ArrayList<>(remainingInColumn.size());
        prioritized.add(preferred);

        for (BlockPos pos : remainingInColumn) {
            if (!pos.equals(preferred)) {
                prioritized.add(pos);
            }
        }

        return prioritized;
    }

    private List<BlockPos> getStandPositions(ClientWorld world, BlockPos target, Direction face) {
        List<BlockPos> positions = new ArrayList<>();
        if (face.getAxis().isHorizontal()) {
            BlockPos base = target.offset(face);
            this.addStandPosition(world, positions, base);
            this.addStandPosition(world, positions, base.down());
            this.addStandPosition(world, positions, base.up());
            this.addStandPosition(world, positions, base.offset(face));
            this.addStandPosition(world, positions, base.offset(face).down());
        } else if (face == Direction.UP) {
            for (Direction horizontal : Type.HORIZONTAL) {
                BlockPos base = target.offset(horizontal);
                this.addStandPosition(world, positions, base);
                this.addStandPosition(world, positions, base.down());
                this.addStandPosition(world, positions, base.up());
            }
        }

        return positions;
    }

    private void addStandPosition(ClientWorld world, List<BlockPos> positions, BlockPos candidate) {
        if (this.isWalkable(world, candidate) && !positions.contains(candidate)) {
            positions.add(candidate.toImmutable());
        }
    }

    private List<BlockPos> simplifyPath(ClientWorld world, List<BlockPos> path) {
        if (path.size() <= 2) {
            return path;
        } else {
            List<BlockPos> simplified = new ArrayList<>();
            int index = 0;
            simplified.add(path.getFirst());

            while (index < path.size() - 1) {
                int best = index + 1;

                for (int candidate = path.size() - 1; candidate > index + 1; candidate--) {
                    if (this.canTraverseStraight(world, path.get(index), path.get(candidate))) {
                        best = candidate;
                        break;
                    }
                }

                simplified.add(path.get(best));
                index = best;
            }

            return simplified;
        }
    }

    private boolean canTraverseStraight(ClientWorld world, BlockPos from, BlockPos to) {
        if (from.equals(to)) {
            return true;
        } else if (from.getY() != to.getY()) {
            return false;
        } else if (from.getX() == to.getX()) {
            int step = Integer.compare(to.getZ(), from.getZ());

            for (int z = from.getZ() + step; z != to.getZ() + step; z += step) {
                if (!this.isWalkable(world, new BlockPos(from.getX(), from.getY(), z))) {
                    return false;
                }
            }

            return true;
        } else if (from.getZ() == to.getZ()) {
            int step = Integer.compare(to.getX(), from.getX());

            for (int x = from.getX() + step; x != to.getX() + step; x += step) {
                if (!this.isWalkable(world, new BlockPos(x, from.getY(), from.getZ()))) {
                    return false;
                }
            }

            return true;
        } else {
            return false;
        }
    }

    private int countPathTurns(List<BlockPos> path) {
        if (path.size() < 3) {
            return 0;
        } else {
            int turns = 0;
            Direction previous = null;

            for (int index = 1; index < path.size(); index++) {
                Direction current = this.stepDirection(path.get(index - 1), path.get(index));
                if (current != null) {
                    if (previous != null && current != previous) {
                        turns++;
                    }

                    previous = current;
                }
            }

            return turns;
        }
    }

    private double scoreStandPreference(BlockPos target, Direction face, BlockPos standPos, AreaDiggerFeature.ToolFootprint footprint) {
        BlockPos ideal = target.offset(face);
        double distanceWeight = footprint == AreaDiggerFeature.ToolFootprint.DRILL ? 3.5 : 6.0;
        double score = -Vec3d.ofBottomCenter(standPos).squaredDistanceTo(Vec3d.ofBottomCenter(ideal)) * distanceWeight;
        if (standPos.equals(ideal)) {
            score += 28.0;
        } else if (standPos.equals(ideal.down())) {
            score += 18.0;
        } else if (standPos.equals(ideal.up())) {
            score += 10.0;
        }

        if (face.getAxis().isHorizontal()) {
            BlockPos extended = ideal.offset(face);
            if (standPos.equals(extended) || standPos.equals(extended.down())) {
                score -= 14.0;
            }
        }

        if (footprint == AreaDiggerFeature.ToolFootprint.DRILL
            && this.currentStandPos != null
            && this.currentStandPos.equals(standPos)
            && this.currentFace != null
            && this.currentFace.getAxis() == face.getAxis()) {
            score += 26.0;
        }

        return score;
    }

    private Vec3d getStandTravelPoint(BlockPos standPos, BlockPos target, Direction face) {
        Vec3d point = Vec3d.ofBottomCenter(standPos);
        if (face.getAxis().isHorizontal()) {
            point = point.add((double)face.getOffsetX() * 0.22, 0.0, (double)face.getOffsetZ() * 0.22);
        }

        return point;
    }

    private AreaDiggerFeature.CoverageInfo measureCoverage(
        ClientWorld world, AreaDiggerFeature.Cuboid area, BlockPos center, Direction face, AreaDiggerFeature.ToolFootprint footprint
    ) {
        if (footprint == AreaDiggerFeature.ToolFootprint.SINGLE) {
            return new AreaDiggerFeature.CoverageInfo(1, this.computeSnakeIndex(area, center));
        } else {
            int count = 0;
            int earliestOrder = Integer.MAX_VALUE;

            for (int first = -1; first <= 1; first++) {
                for (int second = -1; second <= 1; second++) {
                    BlockPos sample = switch (face.getAxis()) {
                        case X -> center.add(0, first, second);
                        case Y -> center.add(first, 0, second);
                        case Z -> center.add(first, second, 0);
                        default -> throw new MatchException(null, null);
                    };
                    if (area.contains(sample) && this.shouldMine(world, sample)) {
                        count++;
                        earliestOrder = Math.min(earliestOrder, this.computeSnakeIndex(area, sample));
                    }
                }
            }

            return count <= 0
                ? new AreaDiggerFeature.CoverageInfo(1, this.computeSnakeIndex(area, center))
                : new AreaDiggerFeature.CoverageInfo(count, earliestOrder);
        }
    }

    private double scoreHazards(ClientWorld world, BlockPos standPos, BlockPos target) {
        double penalty = 0.0;
        if (this.hasNearbyLava(world, standPos)) {
            penalty += 260.0;
        } else if (this.hasNearbyWater(world, standPos)) {
            penalty += 80.0;
        }

        if (this.hasLooseFallingThreat(world, standPos)) {
            penalty += 45.0;
        }

        for (Direction direction : Direction.values()) {
            BlockPos adjacent = target.offset(direction);
            FluidState fluidState = world.getFluidState(adjacent);
            if (this.isLavaFluid(fluidState)) {
                penalty += 140.0;
            } else if (this.isWaterFluid(fluidState)) {
                penalty += 35.0;
            }
        }

        if (this.isFallingState(world.getBlockState(target.up()))) {
            penalty += 35.0;
        }

        return penalty;
    }

    private double estimateBreakTicks(
        ClientPlayerEntity player, ClientWorld world, BlockPos target, AreaDiggerFeature.CoverageInfo coverage, AreaDiggerFeature.ToolFootprint footprint
    ) {
        BlockState state = world.getBlockState(target);
        float hardness = state.getHardness(world, target);
        if (hardness < 0.0F) {
            return 9999.0;
        } else {
            double bestSpeed = Math.max(1.0, this.bestHotbarMiningSpeed(player, state));
            double baseTicks = Math.max(1.0, (double)hardness * 30.0 / bestSpeed);
            double effectiveCoverage = footprint == AreaDiggerFeature.ToolFootprint.DRILL ? Math.max(1.0, (double)coverage.coverage() * 0.85) : 1.0;
            return baseTicks / effectiveCoverage;
        }
    }

    private double bestHotbarMiningSpeed(ClientPlayerEntity player, BlockState state) {
        double bestSpeed = 1.0;
        PlayerInventory inventory = player.getInventory();

        for (int slot = 0; slot < PlayerInventory.getHotbarSize(); slot++) {
            ItemStack stack = inventory.getStack(slot);
            if (!stack.isEmpty()) {
                double speed = (double)Math.max(1.0F, stack.getMiningSpeedMultiplier(state));
                if (stack.isSuitableFor(state)) {
                    speed += 6.0;
                }

                bestSpeed = Math.max(bestSpeed, speed);
            }
        }

        return bestSpeed;
    }

    private double scoreFacePreference(
        ClientWorld world, AreaDiggerFeature.Cuboid area, AreaDiggerFeature.ToolFootprint footprint, BlockPos target, Direction face
    ) {
        if (footprint == AreaDiggerFeature.ToolFootprint.SINGLE) {
            return 0.0;
        } else {
            Axis preferredAxis = this.preferredDrillAxis(world, area, target);
            double score = face.getAxis() == preferredAxis ? 22.0 : -14.0;
            if (preferredAxis != Axis.Y && face.getAxis() == Axis.Y) {
                score -= 10.0;
            }

            if (this.currentTarget != null && this.currentTarget.equals(target) && this.currentFace == face) {
                score += 6.0;
            }

            return score;
        }
    }

    private Axis preferredDrillAxis(ClientWorld world, AreaDiggerFeature.Cuboid area, BlockPos target) {
        Axis bestAxis = Axis.Y;
        double bestScore = Double.NEGATIVE_INFINITY;

        for (Axis axis : Axis.values()) {
            double axisScore = this.drillPlaneScore(world, area, target, axis) + this.shapeAxisBias(area, axis);
            if (axisScore > bestScore) {
                bestScore = axisScore;
                bestAxis = axis;
            }
        }

        return bestAxis;
    }

    private double drillPlaneScore(ClientWorld world, AreaDiggerFeature.Cuboid area, BlockPos center, Axis axis) {
        int count = 0;
        double orderBonus = 0.0;

        for (int first = -1; first <= 1; first++) {
            for (int second = -1; second <= 1; second++) {
                BlockPos sample = switch (axis) {
                    case X -> center.add(0, first, second);
                    case Y -> center.add(first, 0, second);
                    case Z -> center.add(first, second, 0);
                    default -> throw new MatchException(null, null);
                };
                if (area.contains(sample) && this.shouldMine(world, sample)) {
                    count++;
                    orderBonus += Math.max(0.0, 12.0 - (double)Math.abs(this.computeSnakeIndex(area, sample) - this.computeSnakeIndex(area, center)) * 0.1);
                }
            }
        }

        return (double)count * 10.0 + orderBonus;
    }

    private double shapeAxisBias(AreaDiggerFeature.Cuboid area, Axis axis) {
        if (axis == Axis.Y) {
            return area.height() > Math.max(area.width(), area.depth()) + 1 ? 12.0 : 0.0;
        } else if (axis == Axis.X) {
            return area.width() >= area.depth() ? 4.0 : 0.0;
        } else {
            return area.depth() > area.width() ? 4.0 : 0.0;
        }
    }

    private AreaDiggerFeature.ToolFootprint resolveFootprint(ClientPlayerEntity player) {
        return this.toolMode.resolve(player.getMainHandStack());
    }

    private boolean isReadyToMine(ClientWorld world, ClientPlayerEntity player, AreaDiggerFeature.MineCandidate candidate) {
        if (!this.isAtMiningStand(player, candidate)) {
            return false;
        } else {
            return !this.isMovementSettled(player) ? false : this.canMineFrom(world, player.getEyePos(), candidate.target(), candidate.face());
        }
    }

    private boolean isAtMiningStand(ClientPlayerEntity player, AreaDiggerFeature.MineCandidate candidate) {
        double toleranceSq = this.currentFootprint == AreaDiggerFeature.ToolFootprint.DRILL ? 0.56 : 0.16;
        return new Vec3d(player.getX(), player.getBoundingBox().minY, player.getZ())
                .squaredDistanceTo(this.getStandTravelPoint(candidate.standPos(), candidate.target(), candidate.face()))
            <= toleranceSq;
    }

    private boolean isMovementSettled(ClientPlayerEntity player) {
        Vec3d velocity = player.getVelocity();
        return player.isOnGround() && velocity.horizontalLengthSquared() <= 0.0036 && Math.abs(velocity.y) <= 0.08;
    }

    private boolean canMineFrom(ClientWorld world, Vec3d eyePos, BlockPos target, Direction face) {
        Vec3d hitPoint = this.getHitPoint(target, face);
        if (eyePos.squaredDistanceTo(hitPoint) > 21.622501F) {
            return false;
        } else {
            BlockHitResult raycast = world.raycast(
                new RaycastContext(eyePos, hitPoint, ShapeType.COLLIDER, FluidHandling.NONE, MinecraftClient.getInstance().player)
            );
            return raycast.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK
                && raycast.getBlockPos().equals(target)
                && raycast.getSide() == face;
        }
    }

    private Vec3d estimateEyePos(ClientPlayerEntity player, BlockPos feetPos) {
        double eyeOffset = player.getEyeY() - player.getBoundingBox().minY;
        return Vec3d.ofBottomCenter(feetPos).add(0.0, eyeOffset, 0.0);
    }

    private Vec3d getHitPoint(BlockPos target, Direction face) {
        return Vec3d.ofCenter(target)
            .add((double)face.getOffsetX() * 0.48, (double)face.getOffsetY() * 0.48, (double)face.getOffsetZ() * 0.48);
    }

    private AreaDiggerFeature.RotationState rotateToward(ClientPlayerEntity player, Vec3d point, float maxYawStep, float maxPitchStep) {
        Vec3d eyePos = player.getEyePos();
        Vec3d delta = point.subtract(eyePos);
        double horizontalDistance = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float targetYaw = (float)Math.toDegrees(Math.atan2(-delta.x, delta.z));
        float targetPitch = (float)(-Math.toDegrees(Math.atan2(delta.y, horizontalDistance)));
        float yawError = MathHelper.wrapDegrees(targetYaw - player.getYaw());
        float pitchError = MathHelper.clamp(targetPitch - player.getPitch(), -180.0F, 180.0F);
        float nextYaw = player.getYaw() + MathHelper.clamp(yawError, -maxYawStep, maxYawStep);
        float nextPitch = player.getPitch() + MathHelper.clamp(pitchError, -maxPitchStep, maxPitchStep);
        player.setYaw(nextYaw);
        player.setPitch(MathHelper.clamp(nextPitch, -90.0F, 90.0F));
        player.setBodyYaw(nextYaw);
        player.setHeadYaw(nextYaw);
        return new AreaDiggerFeature.RotationState(yawError, pitchError, Math.abs(yawError) <= 9.0F && Math.abs(pitchError) <= 10.0F);
    }

    private void selectBestHotbarTool(ClientPlayerEntity player, BlockState state) {
        PlayerInventory inventory = player.getInventory();
        int selectedSlot = inventory.getSelectedSlot();
        int bestSlot = selectedSlot;
        float bestScore = this.scoreStack(inventory.getStack(selectedSlot), state);

        for (int slot = 0; slot < PlayerInventory.getHotbarSize(); slot++) {
            float score = this.scoreStack(inventory.getStack(slot), state);
            if (score > bestScore + 0.01F) {
                bestScore = score;
                bestSlot = slot;
            }
        }

        if (bestSlot != selectedSlot) {
            inventory.setSelectedSlot(bestSlot);
            player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(bestSlot));
        }
    }

    private float scoreStack(ItemStack stack, BlockState state) {
        if (stack.isEmpty()) {
            return 0.0F;
        } else {
            float score = stack.getMiningSpeedMultiplier(state);
            if (stack.isSuitableFor(state)) {
                score += 100.0F;
            }

            return score;
        }
    }

    private void updateStuckState(ClientPlayerEntity player) {
        Vec3d currentPos = new Vec3d(player.getX(), player.getBoundingBox().minY, player.getZ());
        if (currentPos.squaredDistanceTo(this.lastPlayerPos) < 0.0025) {
            this.stuckTicks++;
        } else {
            this.stuckTicks = 0;
        }

        if (this.stuckTicks > 12) {
            this.stuckTicks = 0;
            this.breakWarmupTicks = 2;
            this.currentPath = List.of();
            this.currentPathIndex = 0;
        }

        this.lastPlayerPos = currentPos;
    }

    private boolean isAtNode(ClientPlayerEntity player, BlockPos node) {
        return new Vec3d(player.getX(), player.getBoundingBox().minY, player.getZ()).squaredDistanceTo(Vec3d.ofBottomCenter(node)) <= 0.36;
    }

    private BlockPos getFeetBlock(ClientPlayerEntity player) {
        return BlockPos.ofFloored(player.getX(), player.getBoundingBox().minY + 0.05, player.getZ());
    }

    private boolean isOpen(ClientWorld world, BlockPos pos) {
        return world.getBlockState(pos).getCollisionShape(world, pos).isEmpty();
    }

    private boolean hasSolidFloor(ClientWorld world, BlockPos pos) {
        return !world.getBlockState(pos).getCollisionShape(world, pos).isEmpty();
    }

    private BlockPos getLookedBlock(MinecraftClient client) {
        if (client.crosshairTarget instanceof BlockHitResult blockHitResult && client.crosshairTarget.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK) {
            return blockHitResult.getBlockPos();
        }

        return null;
    }

    private void saveSelection() {
        this.config.setAreaDiggerStart(serializeBlockPos(this.startPos));
        this.config.setAreaDiggerEnd(serializeBlockPos(this.endPos));
        this.config.save();
        this.resetRuntimeState();
    }

    private boolean hasSelection() {
        return this.startPos != null && this.endPos != null;
    }

    private void stopAutomation(boolean cancelMining) {
        MinecraftClient client = MinecraftClient.getInstance();
        this.releaseMovementKeys(client);
        if (cancelMining && client.interactionManager != null) {
            client.interactionManager.cancelBlockBreaking();
        }

        this.activeBreakTarget = null;
        this.activeBreakFace = null;
        this.activeBreakOrderIndex = Integer.MAX_VALUE;
        this.breakStarted = false;
        this.breakWarmupTicks = 0;
        this.breakPulseTicks = 0;
        this.currentTarget = null;
        this.currentStandPos = null;
        this.currentFace = null;
        this.currentPath = List.of();
        this.currentPathIndex = 0;
        this.smoothedTravelGoal = null;
        this.currentPlanningMode = AreaDiggerFeature.PlanningMode.NORMAL;
    }

    private void resetRuntimeState() {
        this.stopAutomation(false);
        this.remainingBlocks = 0;
        this.baselineRemainingBlocks = 0;
        this.currentLayerY = null;
        this.currentStrategy = AreaDiggerFeature.ExcavationStrategy.COLUMN;
        this.statusText = this.hasSelection() ? "Ready" : "Select two corners";
        this.completionAnnounced = false;
        this.stuckTicks = 0;
        this.lastPlayerPos = Vec3d.ZERO;
    }

    private void releaseMovementKeys(MinecraftClient client) {
        if (client != null) {
            client.options.forwardKey.setPressed(false);
            client.options.backKey.setPressed(false);
            client.options.leftKey.setPressed(false);
            client.options.rightKey.setPressed(false);
            client.options.sprintKey.setPressed(false);
            client.options.jumpKey.setPressed(false);
        }
    }

    private void drawBox(
        Entry entry,
        VertexConsumer buffer,
        double minX,
        double minY,
        double minZ,
        double maxX,
        double maxY,
        double maxZ,
        Vec3d cameraPos,
        int red,
        int green,
        int blue,
        int alpha
    ) {
        float startX = (float)(minX - cameraPos.x);
        float startY = (float)(minY - cameraPos.y);
        float startZ = (float)(minZ - cameraPos.z);
        float endX = (float)(maxX - cameraPos.x);
        float endY = (float)(maxY - cameraPos.y);
        float endZ = (float)(maxZ - cameraPos.z);
        this.emitLine(buffer, entry, startX, startY, startZ, endX, startY, startZ, red, green, blue, alpha);
        this.emitLine(buffer, entry, endX, startY, startZ, endX, startY, endZ, red, green, blue, alpha);
        this.emitLine(buffer, entry, endX, startY, endZ, startX, startY, endZ, red, green, blue, alpha);
        this.emitLine(buffer, entry, startX, startY, endZ, startX, startY, startZ, red, green, blue, alpha);
        this.emitLine(buffer, entry, startX, endY, startZ, endX, endY, startZ, red, green, blue, alpha);
        this.emitLine(buffer, entry, endX, endY, startZ, endX, endY, endZ, red, green, blue, alpha);
        this.emitLine(buffer, entry, endX, endY, endZ, startX, endY, endZ, red, green, blue, alpha);
        this.emitLine(buffer, entry, startX, endY, endZ, startX, endY, startZ, red, green, blue, alpha);
        this.emitLine(buffer, entry, startX, startY, startZ, startX, endY, startZ, red, green, blue, alpha);
        this.emitLine(buffer, entry, endX, startY, startZ, endX, endY, startZ, red, green, blue, alpha);
        this.emitLine(buffer, entry, endX, startY, endZ, endX, endY, endZ, red, green, blue, alpha);
        this.emitLine(buffer, entry, startX, startY, endZ, startX, endY, endZ, red, green, blue, alpha);
    }

    private void drawLine(Entry entry, VertexConsumer buffer, Vec3d start, Vec3d end, int red, int green, int blue, int alpha) {
        this.emitLine(
            buffer,
            entry,
            (float)start.x,
            (float)start.y,
            (float)start.z,
            (float)end.x,
            (float)end.y,
            (float)end.z,
            red,
            green,
            blue,
            alpha
        );
    }

    private void emitLine(
        VertexConsumer consumer,
        Entry entry,
        float startX,
        float startY,
        float startZ,
        float endX,
        float endY,
        float endZ,
        int red,
        int green,
        int blue,
        int alpha
    ) {
        float deltaX = endX - startX;
        float deltaY = endY - startY;
        float deltaZ = endZ - startZ;
        float length = MathHelper.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
        if (!(length <= 1.0E-4F)) {
            float normalX = deltaX / length;
            float normalY = deltaY / length;
            float normalZ = deltaZ / length;
            consumer.vertex(entry, startX, startY, startZ)
                .color(red, green, blue, alpha)
                .normal(entry, normalX, normalY, normalZ)
                .lineWidth(1.4F);
            consumer.vertex(entry, endX, endY, endZ)
                .color(red, green, blue, alpha)
                .normal(entry, normalX, normalY, normalZ)
                .lineWidth(1.4F);
        }
    }

    private static String serializeBlockPos(BlockPos pos) {
        return pos == null ? "" : pos.getX() + "," + pos.getY() + "," + pos.getZ();
    }

    private static BlockPos parseBlockPos(String value) {
        if (value != null && !value.isBlank()) {
            String[] parts = value.split(",");
            if (parts.length != 3) {
                return null;
            } else {
                try {
                    return new BlockPos(Integer.parseInt(parts[0].trim()), Integer.parseInt(parts[1].trim()), Integer.parseInt(parts[2].trim()));
                } catch (NumberFormatException var3) {
                    return null;
                }
            }
        } else {
            return null;
        }
    }

    private static String formatPos(BlockPos pos) {
        return pos.getX() + "," + pos.getY() + "," + pos.getZ();
    }

    private int computeSnakeIndex(AreaDiggerFeature.Cuboid area, BlockPos pos) {
        int width = area.width();
        int zProgress = this.axisProgress(this.startPos.getZ(), this.endPos.getZ(), pos.getZ());
        int xProgress = this.axisProgress(this.startPos.getX(), this.endPos.getX(), pos.getX());
        int columnProgress = (zProgress & 1) == 0 ? xProgress : width - 1 - xProgress;
        int yProgress = pos.getY() - area.minY();
        return (zProgress * width + columnProgress) * area.height() + yProgress;
    }

    private int computeColumnOrder(AreaDiggerFeature.Cuboid area, AreaDiggerFeature.ColumnCursor cursor) {
        return this.computeSnakeIndex(area, new BlockPos(cursor.x(), area.minY(), cursor.z())) / area.height();
    }

    private int axisProgress(int start, int end, int value) {
        return start <= end ? value - start : start - value;
    }

    private List<AreaDiggerFeature.ColumnCursor> iterateSnakeColumns(AreaDiggerFeature.Cuboid area) {
        List<AreaDiggerFeature.ColumnCursor> columns = new ArrayList<>(area.width() * area.depth());
        boolean forwardX = this.startPos.getX() <= this.endPos.getX();
        boolean forwardZ = this.startPos.getZ() <= this.endPos.getZ();

        for (int zOffset = 0; zOffset < area.depth(); zOffset++) {
            int z = forwardZ ? area.minZ() + zOffset : area.maxZ() - zOffset;
            boolean reverseX = (zOffset & 1) == 1;
            boolean ascendingX = reverseX ? !forwardX : forwardX;
            if (ascendingX) {
                for (int x = area.minX(); x <= area.maxX(); x++) {
                    columns.add(new AreaDiggerFeature.ColumnCursor(x, z));
                }
            } else {
                for (int x = area.maxX(); x >= area.minX(); x--) {
                    columns.add(new AreaDiggerFeature.ColumnCursor(x, z));
                }
            }
        }

        return columns;
    }

    private static boolean looksLikeDrill(ItemStack stack) {
        if (stack != null && !stack.isEmpty()) {
            String itemId = Registries.ITEM.getId(stack.getItem()).toString().toLowerCase(Locale.ROOT);
            String displayName = stack.getName().getString().toLowerCase(Locale.ROOT);
            return itemId.contains("drill") || displayName.contains("drill");
        } else {
            return false;
        }
    }

    private static record ColumnCursor(int x, int z) {
    }

    private static record ColumnPlan(AreaDiggerFeature.ColumnCursor cursor, int columnOrder, List<BlockPos> remainingBlocks) {
    }

    private static record CoverageInfo(int coverage, int earliestOrder) {
    }

    private static record Cuboid(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
        static AreaDiggerFeature.Cuboid of(BlockPos first, BlockPos second) {
            return new AreaDiggerFeature.Cuboid(
                Math.min(first.getX(), second.getX()),
                Math.min(first.getY(), second.getY()),
                Math.min(first.getZ(), second.getZ()),
                Math.max(first.getX(), second.getX()),
                Math.max(first.getY(), second.getY()),
                Math.max(first.getZ(), second.getZ())
            );
        }

        boolean contains(BlockPos pos) {
            return pos.getX() >= this.minX
                && pos.getX() <= this.maxX
                && pos.getY() >= this.minY
                && pos.getY() <= this.maxY
                && pos.getZ() >= this.minZ
                && pos.getZ() <= this.maxZ;
        }

        int volume() {
            return (this.maxX - this.minX + 1) * (this.maxY - this.minY + 1) * (this.maxZ - this.minZ + 1);
        }

        int width() {
            return this.maxX - this.minX + 1;
        }

        int depth() {
            return this.maxZ - this.minZ + 1;
        }

        int height() {
            return this.maxY - this.minY + 1;
        }
    }

    private static enum ExcavationStrategy {
        COLUMN,
        LAYERED;
    }

    private static record MineCandidate(
        BlockPos target,
        Direction face,
        BlockPos standPos,
        int coverage,
        int snakeOrder,
        double score,
        AreaDiggerFeature.PlanningMode mode,
        List<BlockPos> path
    ) {
    }

    private static record NavigationGraph(BlockPos start, Map<BlockPos, BlockPos> parents, Map<BlockPos, Integer> distances) {
        static AreaDiggerFeature.NavigationGraph empty() {
            return new AreaDiggerFeature.NavigationGraph(null, Map.of(), Map.of());
        }

        boolean canReach(BlockPos pos) {
            return this.distances.containsKey(pos);
        }

        int distanceTo(BlockPos pos) {
            return this.distances.getOrDefault(pos, Integer.MAX_VALUE);
        }

        List<BlockPos> buildPathTo(BlockPos goal) {
            if (goal != null && this.distances.containsKey(goal)) {
                List<BlockPos> path = new ArrayList<>();

                for (BlockPos cursor = goal; cursor != null; cursor = this.parents.get(cursor)) {
                    path.add(cursor);
                }

                Collections.reverse(path);
                return path;
            } else {
                return List.of();
            }
        }
    }

    private static record PathGoal(Vec3d position, BlockPos anchor) {
    }

    private static record PathNode(BlockPos pos, int cost, double priority) {
    }

    private static enum PlanningMode {
        NORMAL,
        UNBLOCK,
        APPROACH;
    }

    private static record RotationState(float yawError, float pitchError, boolean isAligned) {
    }

    private static record ScanResult(int remainingBlocks, AreaDiggerFeature.MineCandidate bestTarget) {
    }

    private static enum ToolFootprint {
        SINGLE("1x1"),
        DRILL("3x3");

        private final String label;

        private ToolFootprint(String label) {
            this.label = label;
        }

        public String label() {
            return this.label;
        }
    }

    private static enum ToolMode {
        AUTO("AUTO"),
        SINGLE("1x1"),
        DRILL("3x3");

        private final String label;

        private ToolMode(String label) {
            this.label = label;
        }

        public String label() {
            return this.label;
        }

        public String shortLabel() {
            return switch (this) {
                case AUTO -> "AUTO";
                case SINGLE -> "1x1";
                case DRILL -> "3x3";
            };
        }

        public AreaDiggerFeature.ToolMode next() {
            return values()[(this.ordinal() + 1) % values().length];
        }

        public AreaDiggerFeature.ToolFootprint resolve(ItemStack stack) {
            return switch (this) {
                case AUTO -> AreaDiggerFeature.looksLikeDrill(stack) ? AreaDiggerFeature.ToolFootprint.DRILL : AreaDiggerFeature.ToolFootprint.SINGLE;
                case SINGLE -> AreaDiggerFeature.ToolFootprint.SINGLE;
                case DRILL -> AreaDiggerFeature.ToolFootprint.DRILL;
            };
        }

        public static AreaDiggerFeature.ToolMode parse(String value) {
            if (value != null && !value.isBlank()) {
                try {
                    return valueOf(value.trim().toUpperCase(Locale.ROOT));
                } catch (IllegalArgumentException var2) {
                    return AUTO;
                }
            } else {
                return AUTO;
            }
        }
    }
}
