package dev.darg.client.feature.visual;

import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.render.WorldRenderUtil;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class TracersFeature extends Feature {
    private static final double RANGE = 96.0;
    private static final float START_OFFSET = 0.15F;
    private static final float LINE_WIDTH = 1.5F;
    private static final int LINE_COLOR = -754978085;
    private int lastTargetCount;

    public TracersFeature() {
        super("Tracers", Category.RENDER);
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity player = client.player;
        if (client.world != null && player != null) {
            MatrixStack matrices = context.matrices();
            VertexConsumerProvider consumers = context.consumers();
            if (matrices != null && consumers != null) {
                float tickProgress = client.getRenderTickCounter().getTickProgress(false);
                Vec3d cameraPos = client.gameRenderer.getCamera().getCameraPos();
                Vec3d start = WorldRenderUtil.getTracerStart(client.gameRenderer.getCamera(), tickProgress, 0.15F);
                int targetCount = 0;
                matrices.push();

                try {
                    Entry entry = matrices.peek();
                    VertexConsumer lineBuffer = consumers.getBuffer(RenderLayers.linesTranslucent());

                    for (PlayerEntity target : client.world.getPlayers()) {
                        if (target != player && target.isAlive() && !target.isSpectator() && !(player.squaredDistanceTo(target) > 9216.0)) {
                            Vec3d targetPos = target.getLerpedPos(tickProgress)
                                .add(0.0, (double)target.getStandingEyeHeight() * 0.9, 0.0)
                                .subtract(cameraPos);
                            WorldRenderUtil.drawLine(entry, lineBuffer, start, targetPos, -754978085, 1.5F);
                            targetCount++;
                        }
                    }
                } finally {
                    matrices.pop();
                }

                this.lastTargetCount = targetCount;
            }
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of(
            "State: " + (this.isEnabled() ? "Enabled" : "Disabled"), "Range: 96 blocks", "Origin: Crosshair", "Targets: Players (" + this.lastTargetCount + ")"
        );
    }
}
