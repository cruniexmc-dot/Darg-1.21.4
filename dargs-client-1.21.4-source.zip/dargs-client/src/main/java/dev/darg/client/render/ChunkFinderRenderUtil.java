package dev.darg.client.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import dev.darg.client.mixin.RenderLayerInvoker;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.font.TextRenderer.TextLayerType;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.OutputTarget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.RenderSetup.Builder;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

public final class ChunkFinderRenderUtil {
    private static final float TRACER_START_OFFSET = 0.15F;
    private static final float TRACER_LINE_WIDTH = 2.0F;
    private static final int TRACER_COLOR_ARGB = -805241088;
    private static final Object RENDER_LAYER_LOCK = new Object();
    private static RenderLayer chunkFinderFillLayer;
    private static RenderLayer chunkFinderLineLayer;

    private ChunkFinderRenderUtil() {
    }

    public static void renderFlaggedChunks(
        WorldRenderContext context, MinecraftClient client, Set<ChunkPos> flaggedChunks, Map<ChunkPos, List<String>> reasonsByChunk, boolean showReasons
    ) {
        if (!flaggedChunks.isEmpty()) {
            List<ChunkPos> renderChunks = new ArrayList<>(Math.min(flaggedChunks.size(), 50));

            for (ChunkPos pos : flaggedChunks) {
                renderChunks.add(pos);
                if (renderChunks.size() >= 50) {
                    break;
                }
            }

            if (!renderChunks.isEmpty()) {
                Camera camera = client.gameRenderer.getCamera();
                if (camera != null && camera.isReady()) {
                    OrderedRenderCommandQueue commandQueue = context.commandQueue();
                    MatrixStack matrices = context.matrices();
                    if (matrices != null) {
                        Vec3d cameraPos = camera.getCameraPos();
                        double camX = cameraPos.x;
                        double camY = cameraPos.y;
                        double camZ = cameraPos.z;
                        float tickProgress = client.getRenderTickCounter().getTickProgress(false);
                        Vec3d tracerStart = WorldRenderUtil.getTracerStart(camera, tickProgress, 0.15F);
                        int rendered = 0;
                        int renderY = 63;
                        int fillArgb = 1174470400;
                        commandQueue.submitCustom(matrices, getChunkFinderFillLayer(), (entry, consumer) -> {
                            for (ChunkPos posx : renderChunks) {
                                float x1 = (float)((double)posx.getStartX() - camX);
                                float z1 = (float)((double)posx.getStartZ() - camZ);
                                float x2 = (float)((double)(posx.getEndX() + 1) - camX);
                                float z2 = (float)((double)(posx.getEndZ() + 1) - camZ);
                                float y = (float)((double)renderY - camY);
                                emitFilledBox(consumer, entry, x1, y, z1, x2, y, z2, fillArgb);
                            }
                        });
                        commandQueue.submitCustom(matrices, getChunkFinderLineLayer(), (entry, consumer) -> {
                            for (ChunkPos posx : renderChunks) {
                                float cx = (float)((double)posx.getStartX() + 8.0 - camX);
                                float cy = (float)((double)renderY + 0.5 - camY);
                                float cz = (float)((double)posx.getStartZ() + 8.0 - camZ);
                                WorldRenderUtil.drawLine(entry, consumer, tracerStart, new Vec3d((double)cx, (double)cy, (double)cz), -805241088, 2.0F);
                            }
                        });
                        Immediate textConsumers = client.getBufferBuilders().getEntityVertexConsumers();
                        TextRenderer textRenderer = client.textRenderer;
                        boolean drewText = false;

                        for (ChunkPos posx : renderChunks) {
                            if (showReasons) {
                                List<String> reasons = reasonsByChunk.get(posx);
                                if (reasons != null && !reasons.isEmpty()) {
                                    double tX = (double)posx.getStartX() + 8.0 - camX;
                                    double tY = (double)renderY + 2.0 - camY;
                                    double tZ = (double)posx.getStartZ() + 8.0 - camZ;
                                    matrices.push();
                                    matrices.translate(tX, tY, tZ);
                                    matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw()));
                                    matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
                                    float scale = 0.05F;
                                    matrices.scale(-scale, -scale, scale);
                                    int yOffset = 0;

                                    for (String reason : reasons) {
                                        textRenderer.draw(
                                            reason,
                                            (float)(-textRenderer.getWidth(reason)) / 2.0F,
                                            (float)yOffset,
                                            -1,
                                            true,
                                            matrices.peek().getPositionMatrix(),
                                            textConsumers,
                                            TextLayerType.NORMAL,
                                            0,
                                            15728880
                                        );
                                        yOffset += 10;
                                        drewText = true;
                                    }

                                    matrices.pop();
                                }
                            }
                        }

                        if (drewText) {
                            textConsumers.draw();
                        }
                    }
                }
            }
        }
    }

    private static void emitFilledBox(VertexConsumer consumer, Entry entry, float x1, float y1, float z1, float x2, float y2, float z2, int argb) {
        int r = argb >> 16 & 0xFF;
        int g = argb >> 8 & 0xFF;
        int b = argb & 0xFF;
        int a = argb >> 24 & 0xFF;
        quad(consumer, entry, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2, r, g, b, a);
        quad(consumer, entry, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1, r, g, b, a);
        quad(consumer, entry, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1, r, g, b, a);
        quad(consumer, entry, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2, r, g, b, a);
        quad(consumer, entry, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1, r, g, b, a);
        quad(consumer, entry, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2, r, g, b, a);
    }

    private static void quad(
        VertexConsumer consumer,
        Entry entry,
        float x1,
        float y1,
        float z1,
        float x2,
        float y2,
        float z2,
        float x3,
        float y3,
        float z3,
        float x4,
        float y4,
        float z4,
        int r,
        int g,
        int b,
        int a
    ) {
        consumer.vertex(entry, x1, y1, z1).color(r, g, b, a);
        consumer.vertex(entry, x2, y2, z2).color(r, g, b, a);
        consumer.vertex(entry, x3, y3, z3).color(r, g, b, a);
        consumer.vertex(entry, x4, y4, z4).color(r, g, b, a);
    }

    private static RenderLayer getChunkFinderFillLayer() {
        RenderLayer layer = chunkFinderFillLayer;
        if (layer != null) {
            return layer;
        } else {
            synchronized (RENDER_LAYER_LOCK) {
                if (chunkFinderFillLayer == null) {
                    RenderPipeline pipeline = RenderPipelines.register(
                        RenderPipeline.builder(new Snippet[]{RenderPipelines.POSITION_COLOR_SNIPPET})
                            .withLocation("pipeline/dargsclient_chunk_finder_fill_no_depth")
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build()
                    );
                    Builder setupBuilder = RenderSetup.builder(pipeline).layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING).translucent();
                    chunkFinderFillLayer = RenderLayerInvoker.dargsclient$invokeOf("dargs_chunk_finder_fill_no_depth", setupBuilder.build());
                }

                return chunkFinderFillLayer;
            }
        }
    }

    private static RenderLayer getChunkFinderLineLayer() {
        RenderLayer layer = chunkFinderLineLayer;
        if (layer != null) {
            return layer;
        } else {
            synchronized (RENDER_LAYER_LOCK) {
                if (chunkFinderLineLayer == null) {
                    RenderPipeline pipeline = RenderPipelines.register(
                        RenderPipeline.builder(new Snippet[]{RenderPipelines.RENDERTYPE_LINES_SNIPPET})
                            .withLocation("pipeline/dargsclient_chunk_finder_lines")
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .build()
                    );
                    Builder setupBuilder = RenderSetup.builder(pipeline)
                        .layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
                        .outputTarget(OutputTarget.MAIN_TARGET);
                    chunkFinderLineLayer = RenderLayerInvoker.dargsclient$invokeOf("dargs_chunk_finder_lines", setupBuilder.build());
                }

                return chunkFinderLineLayer;
            }
        }
    }
}
