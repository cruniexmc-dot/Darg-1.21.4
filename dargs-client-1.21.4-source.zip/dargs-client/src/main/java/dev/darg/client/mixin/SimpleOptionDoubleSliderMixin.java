package dev.darg.client.mixin;

import java.util.Optional;
import net.minecraft.client.option.SimpleOption.DoubleSliderCallbacks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({DoubleSliderCallbacks.class})
public class SimpleOptionDoubleSliderMixin {
    @Inject(
        method = {"validate"},
        at = {@At("HEAD")},
        cancellable = true
    )
    private void dargsclient$allowAnyDouble(Double value, CallbackInfoReturnable<Optional<Double>> cir) {
        cir.setReturnValue(Optional.of(value));
    }
}
