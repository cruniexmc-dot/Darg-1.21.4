package dev.darg.client.feature.basefinding;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.mixin.RenderLayerInvoker;
import dev.darg.client.render.WorldRenderUtil;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.OutputTarget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

public final class FloorScanFeature extends Feature {
    private static final int SCAN_Y = -1;
    private static final int LOCAL_Y = 15;
    private static final int SCAN_RADIUS_CHUNKS = 8;
    private static final int BATCH_SIZE = 12;
    private static final int RESCAN_INTERVAL = 100;
    private static final int MAX_RENDERED = 1500;
    private static final int LIGHT_SCORE = 3;
    private static final int CRAFTED_SCORE = 1;
    private static final int MIN_SCORE = 2;
    private static final int MED_SCORE = 12;
    private static final int HIGH_SCORE = 24;
    private static final float BOX_LINE_WIDTH = 1.6F;
    private static final float TRACER_LINE_WIDTH = 1.2F;
    private static final float TRACER_START_OFFSET = 0.15F;
    private static final int COLOR_LOW = -1342118401;
    private static final int COLOR_MEDIUM = -1056975104;
    private static final int COLOR_HIGH = -788577280;
    private static final int TRACER_COLOR = -2130706433;
    private static final Set<Block> NATURAL_DEEP = Set.of(
        Blocks.DEEPSLATE,
        Blocks.DEEPSLATE_COAL_ORE,
        Blocks.DEEPSLATE_IRON_ORE,
        Blocks.DEEPSLATE_GOLD_ORE,
        Blocks.DEEPSLATE_COPPER_ORE,
        Blocks.DEEPSLATE_LAPIS_ORE,
        Blocks.DEEPSLATE_REDSTONE_ORE,
        Blocks.DEEPSLATE_DIAMOND_ORE,
        Blocks.DEEPSLATE_EMERALD_ORE,
        Blocks.INFESTED_DEEPSLATE,
        Blocks.TUFF,
        Blocks.STONE,
        Blocks.GRANITE,
        Blocks.DIORITE,
        Blocks.ANDESITE,
        Blocks.GRAVEL,
        Blocks.WATER,
        Blocks.LAVA,
        Blocks.AIR,
        Blocks.CAVE_AIR,
        Blocks.COBBLESTONE,
        Blocks.OBSIDIAN,
        Blocks.CALCITE,
        Blocks.SMOOTH_BASALT,
        Blocks.AMETHYST_BLOCK,
        Blocks.BUDDING_AMETHYST,
        Blocks.SMALL_AMETHYST_BUD,
        Blocks.MEDIUM_AMETHYST_BUD,
        Blocks.LARGE_AMETHYST_BUD,
        Blocks.AMETHYST_CLUSTER
    );
    private static volatile RenderLayer noDepthLineLayer;
    private final ConcurrentHashMap<ChunkPos, Integer> chunkScores = new ConcurrentHashMap<>();
    private final Set<ChunkPos> scannedChunks = ConcurrentHashMap.newKeySet();
    private final Deque<ChunkPos> scanQueue = new ArrayDeque<>();
    private final Set<ChunkPos> queuedChunks = new HashSet<>();
    private int lastChunkX = Integer.MIN_VALUE;
    private int lastChunkZ = Integer.MIN_VALUE;
    private int rescanTicker = 0;

    private static boolean isLightSource(Block block) {
        return block == Blocks.TORCH
            || block == Blocks.WALL_TORCH
            || block == Blocks.SOUL_TORCH
            || block == Blocks.SOUL_WALL_TORCH
            || block == Blocks.LANTERN
            || block == Blocks.SOUL_LANTERN
            || block == Blocks.GLOWSTONE
            || block == Blocks.SEA_LANTERN
            || block == Blocks.SHROOMLIGHT
            || block == Blocks.END_ROD
            || block == Blocks.CAMPFIRE
            || block == Blocks.SOUL_CAMPFIRE
            || block == Blocks.JACK_O_LANTERN;
    }

    private static RenderLayer getNoDepthLineLayer() {
        RenderLayer layer = noDepthLineLayer;
        if (layer != null) {
            return layer;
        } else {
            synchronized (FloorScanFeature.class) {
                if (noDepthLineLayer == null) {
                    noDepthLineLayer = RenderLayerInvoker.dargsclient$invokeOf(
                        "dargsclient_floorscan_lines",
                        RenderSetup.builder(
                                RenderPipelines.register(
                                    RenderPipeline.builder(new Snippet[]{RenderPipelines.RENDERTYPE_LINES_SNIPPET})
                                        .withLocation("pipeline/dargsclient_floorscan_lines")
                                        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                                        .withDepthWrite(false)
                                        .build()
                                )
                            )
                            .layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
                            .outputTarget(OutputTarget.ITEM_ENTITY_TARGET)
                            .build()
                    );
                }

                return noDepthLineLayer;
            }
        }
    }

    public FloorScanFeature() {
        super("FloorScan", Category.BASEFINDING);
    }

    @Override
    protected void onEnable() {
        this.clearState();
    }

    @Override
    protected void onDisable() {
        this.clearState();
    }

    private void clearState() {
        this.chunkScores.clear();
        this.scannedChunks.clear();
        this.scanQueue.clear();
        this.queuedChunks.clear();
        this.lastChunkX = Integer.MIN_VALUE;
        this.lastChunkZ = Integer.MIN_VALUE;
        this.rescanTicker = 0;
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world != null && client.player != null && client.world.getBottomY() < -1) {
            int chunkX = client.player.getChunkPos().x;
            int chunkZ = client.player.getChunkPos().z;
            if (chunkX == this.lastChunkX && chunkZ == this.lastChunkZ) {
                if (++this.rescanTicker >= 100) {
                    this.rescanTicker = 0;
                    this.enqueueScanWindow(chunkX, chunkZ, false);
                }
            } else {
                this.lastChunkX = chunkX;
                this.lastChunkZ = chunkZ;
                this.enqueueScanWindow(chunkX, chunkZ, true);
                this.cleanupDistant(chunkX, chunkZ);
            }

            int bottomSectionCoord = client.world.getBottomSectionCoord();

            for (int i = 0; i < 12 && !this.scanQueue.isEmpty(); i++) {
                ChunkPos pos = this.scanQueue.poll();
                if (pos != null) {
                    this.queuedChunks.remove(pos);
                    if (client.world.isChunkLoaded(pos.x, pos.z)) {
                        WorldChunk chunk = client.world.getChunk(pos.x, pos.z);
                        if (chunk != null && !chunk.isEmpty()) {
                            this.scanChunk(chunk, pos, bottomSectionCoord);
                        } else {
                            this.chunkScores.remove(pos);
                            this.scannedChunks.add(pos);
                        }
                    }
                }
            }
        } else {
            this.clearState();
        }
    }

    private void enqueueScanWindow(int cx, int cz, boolean forceRescan) {
        for (int dx = -8; dx <= 8; dx++) {
            for (int dz = -8; dz <= 8; dz++) {
                ChunkPos pos = new ChunkPos(cx + dx, cz + dz);
                if ((forceRescan || !this.scannedChunks.contains(pos)) && this.queuedChunks.add(pos)) {
                    this.scanQueue.offer(pos);
                }
            }
        }
    }

    private void cleanupDistant(int cx, int cz) {
        int limit = 10;
        this.chunkScores.keySet().removeIf(p -> Math.abs(p.x - cx) > limit || Math.abs(p.z - cz) > limit);
        this.scannedChunks.removeIf(p -> Math.abs(p.x - cx) > limit || Math.abs(p.z - cz) > limit);
        this.queuedChunks.removeIf(p -> Math.abs(p.x - cx) > limit || Math.abs(p.z - cz) > limit);
        this.scanQueue.removeIf(p -> Math.abs(p.x - cx) > limit || Math.abs(p.z - cz) > limit);
    }

    private void scanChunk(WorldChunk chunk, ChunkPos cp, int bottomSectionCoord) {
        int sectionCoord = ChunkSectionPos.getSectionCoord(-1);
        int sectionIndex = sectionCoord - bottomSectionCoord;
        ChunkSection[] sections = chunk.getSectionArray();
        if (sectionIndex >= 0 && sectionIndex < sections.length) {
            ChunkSection section = sections[sectionIndex];
            if (section != null && !section.isEmpty()) {
                int score = 0;

                for (int lx = 0; lx < 16; lx++) {
                    for (int lz = 0; lz < 16; lz++) {
                        BlockState state = section.getBlockState(lx, 15, lz);
                        Block block = state.getBlock();
                        if (!NATURAL_DEEP.contains(block)) {
                            score += isLightSource(block) ? 3 : 1;
                        }
                    }
                }

                if (score >= 2) {
                    this.chunkScores.put(cp, score);
                } else {
                    this.chunkScores.remove(cp);
                }

                this.scannedChunks.add(cp);
            } else {
                this.chunkScores.remove(cp);
                this.scannedChunks.add(cp);
            }
        } else {
            this.chunkScores.remove(cp);
            this.scannedChunks.add(cp);
        }
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        if (!this.chunkScores.isEmpty()) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.world != null && client.player != null) {
                MatrixStack matrices = context.matrices();
                VertexConsumerProvider consumers = context.consumers();
                if (matrices != null && consumers != null) {
                    Vec3d cam = client.gameRenderer.getCamera().getCameraPos();
                    float tickDelta = client.getRenderTickCounter().getTickProgress(false);
                    Vec3d tracerOrigin = WorldRenderUtil.getTracerStart(client.gameRenderer.getCamera(), tickDelta, 0.15F);
                    double px = client.player.getX();
                    double py = client.player.getY();
                    double pz = client.player.getZ();
                    List<Entry<ChunkPos, Integer>> snapshot = new ArrayList<>(this.chunkScores.entrySet());
                    snapshot.sort(Comparator.comparingDouble(ex -> {
                        double dx = (double)(((ChunkPos)ex.getKey()).x * 16 + 8) - px;
                        double dz = (double)(((ChunkPos)ex.getKey()).z * 16 + 8) - pz;
                        return dx * dx + dz * dz;
                    }));
                    matrices.push();

                    try {
                        net.minecraft.client.util.math.MatrixStack.Entry entry = matrices.peek();
                        VertexConsumer buf = consumers.getBuffer(getNoDepthLineLayer());
                        int rendered = 0;

                        for (Entry<ChunkPos, Integer> e : snapshot) {
                            if (rendered >= 1500) {
                                break;
                            }

                            ChunkPos cp = e.getKey();
                            int score = e.getValue();
                            int color = scoreColor(score);
                            float minX = (float)((double)cp.getStartX() - cam.x);
                            float minY = (float)(-1.0 - cam.y);
                            float minZ = (float)((double)cp.getStartZ() - cam.z);
                            float maxX = minX + 16.0F;
                            float maxY = minY + 1.0F;
                            float maxZ = minZ + 16.0F;
                            WorldRenderUtil.drawWireBox(entry, buf, minX, minY, minZ, maxX, maxY, maxZ, color, 1.6F);
                            WorldRenderUtil.drawLine(
                                entry, buf, tracerOrigin, new Vec3d((double)(minX + 8.0F), (double)minY + 0.5, (double)(minZ + 8.0F)), -2130706433, 1.2F
                            );
                            rendered++;
                        }
                    } finally {
                        matrices.pop();
                    }
                }
            }
        }
    }

    private static int scoreColor(int score) {
        if (score >= 24) {
            return -788577280;
        } else {
            return score >= 12 ? -1056975104 : -1342118401;
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        int low = 0;
        int med = 0;
        int high = 0;

        for (int score : this.chunkScores.values()) {
            if (score >= 24) {
                high++;
            } else if (score >= 12) {
                med++;
            } else {
                low++;
            }
        }

        return List.of(
            "State: " + (this.isEnabled() ? "Enabled" : "Disabled"),
            "High (red):    " + high,
            "Medium (yellow): " + med,
            "Low (cyan):    " + low,
            "Min score: 2  (light=3, crafted=1)",
            "Radius: 8 chunks"
        );
    }
}
