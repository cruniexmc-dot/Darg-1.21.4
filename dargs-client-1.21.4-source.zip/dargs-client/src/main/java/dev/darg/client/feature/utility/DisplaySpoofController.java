package dev.darg.client.feature.utility;

import dev.darg.client.config.ClientConfig;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.number.NumberFormat;
import net.minecraft.scoreboard.number.StyledNumberFormat;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;

public final class DisplaySpoofController {
    private static final List<Character> VALUE_SEPARATORS = List.of(':', '=', '»', '›');
    private static final Pattern TRAILING_VALUE_PATTERN = Pattern.compile("[$€£]?[0-9][0-9,./:%]*([a-zA-Z]+)?(\\s+[0-9][0-9,./:%]*([a-zA-Z]+)?)*$");
    private static final long SCOREBOARD_CAPTURE_TTL_MS = 180000L;
    private static final int MAX_CAPTURED_ENTRIES = 24;
    private static final int MEDIA_GRADIENT_START_RGB = 16735405;
    private static final int MEDIA_GRADIENT_END_RGB = 10309341;
    private static volatile boolean fakeStatsEnabled;
    private static volatile boolean nameSpoofEnabled;
    private static volatile boolean rankSpoofEnabled;
    private static volatile boolean donutMediaPrefixLock;
    private static volatile boolean scoreboardSidebarActive;
    private static int scoreboardDrawIndex;
    private static String scoreboardLineContext = "";
    private static String scoreboardLabelDisplay = "";
    private static final Map<String, DisplaySpoofController.SidebarStatEntry> capturedSidebarEntries = new LinkedHashMap<>();

    private DisplaySpoofController() {
    }

    public static void setFakeStatsEnabled(boolean enabled) {
        fakeStatsEnabled = enabled;
    }

    public static void setNameSpoofEnabled(boolean enabled) {
        nameSpoofEnabled = enabled;
    }

    public static void setRankSpoofEnabled(boolean enabled) {
        rankSpoofEnabled = enabled;
        if (!enabled) {
            donutMediaPrefixLock = false;
        }
    }

    public static void setDonutMediaPrefixLock(boolean locked) {
        donutMediaPrefixLock = locked;
    }

    public static boolean isDonutMediaPrefixLocked() {
        return donutMediaPrefixLock;
    }

    public static Text spoofScoreboardTitle(Text original) {
        return spoofInlineText(original);
    }

    public static void beginScoreboardSidebar() {
        pruneCapturedEntries();
        scoreboardSidebarActive = true;
        scoreboardDrawIndex = 0;
        scoreboardLineContext = "";
        scoreboardLabelDisplay = "";
    }

    public static void captureSidebarObjective(ScoreboardObjective objective) {
        if (objective != null) {
            Scoreboard scoreboard = objective.getScoreboard();
            NumberFormat numberFormat = objective.getNumberFormatOr(StyledNumberFormat.RED);

            for (ScoreboardEntry entry : scoreboard.getScoreboardEntries(objective)) {
                if (!entry.hidden()) {
                    Text label = Team.decorateName(scoreboard.getScoreHolderTeam(entry.owner()), entry.name());
                    Text value = entry.formatted(numberFormat);
                    captureScoreboardEntry(label.getString(), value.getString());
                }
            }
        }
    }

    public static void endScoreboardSidebar() {
        scoreboardSidebarActive = false;
        scoreboardDrawIndex = 0;
        scoreboardLineContext = "";
        scoreboardLabelDisplay = "";
    }

    public static List<DisplaySpoofController.SidebarStatEntry> getCapturedSidebarEntries() {
        captureActiveSidebarObjective();
        synchronized (capturedSidebarEntries) {
            pruneCapturedEntriesLocked();
            List<DisplaySpoofController.SidebarStatEntry> entries = new ArrayList<>(capturedSidebarEntries.values());
            entries.sort((left, right) -> Long.compare(right.lastSeenMillis(), left.lastSeenMillis()));
            return List.copyOf(entries);
        }
    }

    public static String normalizeSidebarKey(String label) {
        if (label == null) {
            return "";
        } else {
            String normalized = label.toLowerCase(Locale.ROOT).trim();

            while (!normalized.isEmpty() && VALUE_SEPARATORS.contains(normalized.charAt(normalized.length() - 1))) {
                normalized = normalized.substring(0, normalized.length() - 1).trim();
            }

            return normalized.replaceAll("\\s+", " ");
        }
    }

    public static Text spoofScoreboardDrawText(Text original) {
        if (original == null) {
            return null;
        } else if (scoreboardDrawIndex++ == 0) {
            return spoofScoreboardTitle(original);
        } else {
            String content = original.getString();
            String labelPart = extractLabelPart(content);
            String valuePart = extractValuePart(content);
            boolean isCombined = !valuePart.isEmpty() && !labelPart.equals(content.trim());
            if (isCombined) {
                String labelKey = normalizeSidebarKey(labelPart);
                captureDrawnEntry(labelKey, labelPart, valuePart);
                scoreboardLineContext = "";
                scoreboardLabelDisplay = "";
                if (!fakeStatsEnabled) {
                    return spoofInlineText(original);
                } else {
                    String override = ClientConfig.getInstance().getFakeStatOverrides().getOrDefault(labelKey, "");
                    return !override.isBlank() ? styledReplacement(original, rebuildWithOverride(content, override)) : spoofInlineText(original);
                }
            } else if (!scoreboardLineContext.isBlank()) {
                String pendingKey = scoreboardLineContext;
                String pendingLabel = scoreboardLabelDisplay;
                scoreboardLineContext = "";
                scoreboardLabelDisplay = "";
                captureDrawnEntry(pendingKey, pendingLabel, content);
                if (!fakeStatsEnabled) {
                    return spoofInlineText(original);
                } else {
                    String override = ClientConfig.getInstance().getFakeStatOverrides().getOrDefault(pendingKey, "");
                    return !override.isBlank() ? styledReplacement(original, override) : spoofInlineText(original);
                }
            } else {
                scoreboardLineContext = normalizeSidebarKey(content);
                scoreboardLabelDisplay = content;
                return spoofInlineText(original);
            }
        }
    }

    public static Text spoofTabListName(Text original, UUID playerUuid) {
        return !isLocalPlayer(playerUuid) ? original : buildSpoofedDisplayText(original);
    }

    public static Text spoofEntityName(Entity entity, Text original) {
        return entity != null && isLocalPlayer(entity.getUuid()) ? buildSpoofedDisplayText(original) : original;
    }

    private static String extractLabelPart(String text) {
        int sepIndex = findLastSeparatorIndex(text);
        if (sepIndex > 0 && sepIndex < text.length() - 1) {
            return text.substring(0, sepIndex).trim();
        } else {
            Matcher matcher = TRAILING_VALUE_PATTERN.matcher(text);
            if (matcher.find() && matcher.start() > 0) {
                String candidate = text.substring(0, matcher.start()).trim();
                if (!candidate.isEmpty()) {
                    return candidate;
                }
            }

            return text.trim();
        }
    }

    private static String extractValuePart(String text) {
        int sepIndex = findLastSeparatorIndex(text);
        if (sepIndex > 0 && sepIndex < text.length() - 1) {
            return text.substring(sepIndex + 1).trim();
        } else {
            Matcher matcher = TRAILING_VALUE_PATTERN.matcher(text);
            return matcher.find() && matcher.start() > 0 ? matcher.group().trim() : "";
        }
    }

    private static String rebuildWithOverride(String original, String override) {
        int sepIndex = findLastSeparatorIndex(original);
        if (sepIndex > 0 && sepIndex < original.length() - 1) {
            return original.substring(0, sepIndex + 1) + " " + override;
        } else {
            Matcher matcher = TRAILING_VALUE_PATTERN.matcher(original);
            return matcher.find() && matcher.start() > 0 ? original.substring(0, matcher.start()) + override : original;
        }
    }

    private static int findLastSeparatorIndex(String text) {
        int best = -1;

        for (char sep : VALUE_SEPARATORS) {
            best = Math.max(best, text.lastIndexOf(sep));
        }

        return best;
    }

    private static void captureDrawnEntry(String normalizedKey, String label, String value) {
        if (!normalizedKey.isEmpty() && !label.isEmpty() && !value.isEmpty()) {
            String sanitizedLabel = label.replace('\n', ' ').trim();
            String sanitizedValue = applyNameReplacement(value.replace('\n', ' ').trim());
            if (!sanitizedLabel.isEmpty() && !sanitizedValue.isEmpty()) {
                long now = System.currentTimeMillis();
                synchronized (capturedSidebarEntries) {
                    pruneCapturedEntriesLocked();
                    capturedSidebarEntries.remove(normalizedKey);
                    capturedSidebarEntries.put(normalizedKey, new DisplaySpoofController.SidebarStatEntry(normalizedKey, sanitizedLabel, sanitizedValue, now));

                    while (capturedSidebarEntries.size() > 24) {
                        capturedSidebarEntries.remove(capturedSidebarEntries.keySet().iterator().next());
                    }
                }
            }
        }
    }

    private static void captureScoreboardEntry(String context, String rawValue) {
        String fullText = sanitizeScoreboardLabel(context);
        if (!fullText.isEmpty()) {
            String label = extractLabelPart(fullText);
            String currentValue = extractValuePart(fullText);
            if (currentValue.isEmpty()) {
                label = fullText;
                currentValue = sanitizeScoreboardValue(rawValue);
            }

            String normalizedKey = normalizeSidebarKey(label);
            if (!normalizedKey.isEmpty() && !currentValue.isEmpty()) {
                captureDrawnEntry(normalizedKey, label, currentValue);
            }
        }
    }

    private static String sanitizeScoreboardLabel(String context) {
        return context == null ? "" : context.replace('\n', ' ').trim();
    }

    private static String sanitizeScoreboardValue(String value) {
        return value == null ? "" : applyNameReplacement(value.replace('\n', ' ').trim());
    }

    private static void pruneCapturedEntries() {
        synchronized (capturedSidebarEntries) {
            pruneCapturedEntriesLocked();
        }
    }

    private static void captureActiveSidebarObjective() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world != null) {
            Scoreboard scoreboard = client.world.getScoreboard();
            ScoreboardObjective objective = null;
            if (client.player != null) {
                Team playerTeam = scoreboard.getScoreHolderTeam(client.player.getNameForScoreboard());
                if (playerTeam != null) {
                    ScoreboardDisplaySlot slot = ScoreboardDisplaySlot.fromFormatting(playerTeam.getColor());
                    if (slot != null) {
                        objective = scoreboard.getObjectiveForSlot(slot);
                    }
                }
            }

            if (objective == null) {
                objective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
            }

            captureSidebarObjective(objective);
        }
    }

    private static void pruneCapturedEntriesLocked() {
        long cutoff = System.currentTimeMillis() - 180000L;
        capturedSidebarEntries.entrySet().removeIf(entry -> entry.getValue().lastSeenMillis() < cutoff);
    }

    private static Text spoofInlineText(Text original) {
        return original == null ? null : styledReplacement(original, applyNameReplacement(original.getString()));
    }

    private static String applyNameReplacement(String value) {
        if (!nameSpoofEnabled && !rankSpoofEnabled) {
            return value;
        } else {
            MinecraftClient client = MinecraftClient.getInstance();
            String realName = client.player == null ? "" : client.player.getGameProfile().name();
            return realName.isBlank() ? value : value.replace(realName, buildSpoofedIdentity(realName));
        }
    }

    private static String buildSpoofedIdentity(String fallbackName) {
        ClientConfig config = ClientConfig.getInstance();
        String baseName = nameSpoofEnabled && !config.getNameSpoofValue().isBlank() ? config.getNameSpoofValue() : fallbackName;
        String prefix = getEffectiveRankPrefix();
        if (rankSpoofEnabled && !prefix.isBlank()) {
            return prefix.endsWith(" ") ? prefix + baseName : prefix + " " + baseName;
        } else {
            return baseName;
        }
    }

    private static String getEffectiveRankPrefix() {
        return donutMediaPrefixLock ? "\ud83d\udcf9+" : ClientConfig.getInstance().getRankSpoofValue().trim();
    }

    private static Text buildSpoofedDisplayText(Text original) {
        if (original != null && (nameSpoofEnabled || rankSpoofEnabled)) {
            ClientConfig config = ClientConfig.getInstance();
            MinecraftClient client = MinecraftClient.getInstance();
            String realName = client.player == null ? "" : client.player.getGameProfile().name();
            String baseName = nameSpoofEnabled && !config.getNameSpoofValue().isBlank() ? config.getNameSpoofValue() : realName;
            String rank = getEffectiveRankPrefix();
            if (rankSpoofEnabled && !rank.isBlank()) {
                MutableText prefix = gradientRankPrefix(rank);
                return prefix.append(Text.literal(" ")).append(Text.literal(baseName).setStyle(original.getStyle()));
            } else {
                return (Text)(!nameSpoofEnabled ? original : Text.literal(baseName).setStyle(original.getStyle()));
            }
        } else {
            return original;
        }
    }

    private static MutableText gradientRankPrefix(String prefix) {
        if (prefix.isEmpty()) {
            return Text.empty();
        } else {
            int[] codePoints = prefix.codePoints().toArray();
            MutableText result = Text.empty();

            for (int i = 0; i < codePoints.length; i++) {
                float progress = codePoints.length > 1 ? (float)i / (float)(codePoints.length - 1) : 0.0F;
                int rgb = lerpRgb(16735405, 10309341, progress);
                String fragment = new String(Character.toChars(codePoints[i]));
                result.append(
                    Text.literal(fragment).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(rgb)).withBold(true).withItalic(true))
                );
            }

            return result;
        }
    }

    private static int lerpRgb(int from, int to, float t) {
        int fr = from >> 16 & 0xFF;
        int fg = from >> 8 & 0xFF;
        int fb = from & 0xFF;
        int tr = to >> 16 & 0xFF;
        int tg = to >> 8 & 0xFF;
        int tb = to & 0xFF;
        int r = Math.round((float)fr + (float)(tr - fr) * t);
        int g = Math.round((float)fg + (float)(tg - fg) * t);
        int b = Math.round((float)fb + (float)(tb - fb) * t);
        return r << 16 | g << 8 | b;
    }

    private static boolean isLocalPlayer(UUID uuid) {
        MinecraftClient client = MinecraftClient.getInstance();
        return client.player != null && Objects.equals(client.player.getUuid(), uuid);
    }

    private static Text styledReplacement(Text original, String replacement) {
        return (Text)(original != null && replacement != null && !replacement.equals(original.getString())
            ? Text.literal(replacement).setStyle(original.getStyle())
            : original);
    }

    public static record SidebarStatEntry(String key, String label, String currentValue, long lastSeenMillis) {
    }
}
