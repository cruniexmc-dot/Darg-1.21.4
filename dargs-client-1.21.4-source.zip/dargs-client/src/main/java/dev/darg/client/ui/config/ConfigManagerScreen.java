package dev.darg.client.ui.config;

import dev.darg.client.config.local.LocalConfigProfile;
import dev.darg.client.ui.clickgui.RenderUtil;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.util.Window;
import net.minecraft.text.Text;

public final class ConfigManagerScreen extends Screen {
    private static final int BACKDROP = -938866164;
    private static final int PANEL = -300805352;
    private static final int PANEL_SHADOW = 1409286144;
    private static final int PANEL_BORDER = -14012871;
    private static final int PANEL_INNER = -15789802;
    private static final int HEADER = -15263456;
    private static final int HEADER_EDGE = -14473162;
    private static final int SECTION = -14934490;
    private static final int SECTION_BORDER = -13881024;
    private static final int SECTION_LIGHT = -14407885;
    private static final int SECTION_HOVER = -13749696;
    private static final int INPUT_FILL = -15460319;
    private static final int INPUT_BORDER = -13354678;
    private static final int BUTTON_BORDER = -13223092;
    private static final int WHITE = -1;
    private static final int SOFT_GRAY = -4671304;
    private static final int MUTED_GRAY = -8750470;
    private static final int DIM_GRAY = -10789272;
    private static final int ACCENT = -3365;
    private static final int LOCAL_ACCENT = -10072;
    private static final int ERROR = -34182;
    private static final int SUCCESS = -6429529;
    private static final int DARK_TEXT = -15658735;
    private static final float REFERENCE_WINDOW_WIDTH = 1920.0F;
    private static final float REFERENCE_WINDOW_HEIGHT = 1080.0F;
    private static final float BASE_MENU_PIXEL_SCALE = 2.0F;
    private static final float MIN_MENU_PIXEL_SCALE = 1.4F;
    private static final float MAX_MENU_PIXEL_SCALE = 2.35F;
    private static final float PANEL_WIDTH = 1040.0F;
    private static final float PANEL_HEIGHT = 600.0F;
    private static final float OUTER_PADDING = 22.0F;
    private static final float COLUMN_GAP = 20.0F;
    private static final float LIST_ROW_HEIGHT = 42.0F;
    private static final float LIST_ROW_GAP = 6.0F;
    private static final float ACTION_BUTTON_HEIGHT = 28.0F;
    private static final float ACTION_BUTTON_GAP = 10.0F;
    private static final long CONFIRMATION_WINDOW_MS = 3500L;
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm").withZone(ZoneId.systemDefault());
    private final Screen parent;
    private final ConfigManagerController controller = new ConfigManagerController();
    private float menuScale = 1.0F;
    private float menuSpaceWidth = 0.0F;
    private float menuSpaceHeight = 0.0F;
    private String pendingConfirmationAction = "";
    private long pendingConfirmationUntil = 0L;

    public ConfigManagerScreen(Screen parent) {
        super(Text.literal("Config Manager"));
        this.parent = parent;
    }

    protected void init() {
        this.controller.initialize();
        this.updateMenuMetrics();
    }

    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, -938866164);
        this.updateMenuMetrics();
        ConfigManagerScreen.Layout layout = this.createLayout();
        int panelMouseX = this.toMenuSpace((double)mouseX);
        int panelMouseY = this.toMenuSpace((double)mouseY);
        context.getMatrices().pushMatrix();
        context.getMatrices().scale(this.menuScale, this.menuScale);
        this.renderPanel(context, layout, panelMouseX, panelMouseY);
        context.getMatrices().popMatrix();
    }

    public boolean mouseClicked(Click click, boolean doubleClick) {
        this.updateMenuMetrics();
        ConfigManagerScreen.Layout layout = this.createLayout();
        int mouseX = this.toMenuSpace(click.x());
        int mouseY = this.toMenuSpace(click.y());
        int button = click.button();
        if (button != 0) {
            return super.mouseClicked(click, doubleClick);
        } else {
            boolean insidePanel = contains((double)mouseX, (double)mouseY, layout.panelX(), layout.panelY(), layout.panelWidth(), layout.panelHeight());
            if (!insidePanel) {
                this.controller.setNameFieldFocused(false);
                this.clearPendingConfirmation();
                return super.mouseClicked(click, doubleClick);
            } else {
                boolean focusedNameField = contains(
                    (double)mouseX, (double)mouseY, layout.nameFieldX(), layout.nameFieldY(), layout.nameFieldWidth(), layout.nameFieldHeight()
                );
                this.controller.setNameFieldFocused(focusedNameField);
                if (this.handleProfileClick(layout, mouseX, mouseY)) {
                    this.clearPendingConfirmation();
                    return true;
                } else {
                    for (ConfigManagerScreen.ActionButton buttonSpec : this.buildActionButtons(layout)) {
                        if (contains((double)mouseX, (double)mouseY, buttonSpec.x(), buttonSpec.y(), buttonSpec.width(), buttonSpec.height())) {
                            if (!buttonSpec.enabled()) {
                                return true;
                            }

                            if (!this.confirmActionIfNeeded(buttonSpec.id(), confirmationLabel(buttonSpec.id()))) {
                                return true;
                            }

                            this.clearPendingConfirmation();
                            this.performAction(buttonSpec.id());
                            return true;
                        }
                    }

                    this.clearPendingConfirmation();
                    return true;
                }
            }
        }
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        this.updateMenuMetrics();
        ConfigManagerScreen.Layout layout = this.createLayout();
        int panelMouseX = this.toMenuSpace(mouseX);
        int panelMouseY = this.toMenuSpace(mouseY);
        if (!contains((double)panelMouseX, (double)panelMouseY, layout.listBodyX(), layout.listBodyY(), layout.listBodyWidth(), layout.listBodyHeight())) {
            return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
        } else {
            int direction = verticalAmount < 0.0 ? 1 : (verticalAmount > 0.0 ? -1 : 0);
            if (direction == 0) {
                return true;
            } else {
                this.controller.scrollLocal(direction, this.visibleRowCount(layout));
                this.clearPendingConfirmation();
                return true;
            }
        }
    }

    public boolean keyPressed(KeyInput keyInput) {
        int key = keyInput.key();
        if (this.controller.isNameFieldFocused()) {
            if (key == 256 || key == 257) {
                this.controller.setNameFieldFocused(false);
                return true;
            }

            if (key == 259 || key == 261) {
                this.controller.backspaceProfileName();
                return true;
            }
        }

        if (key == 256) {
            this.close();
            return true;
        } else if (this.client != null && this.client.options.inventoryKey.matchesKey(keyInput)) {
            this.close();
            return true;
        } else {
            return super.keyPressed(keyInput);
        }
    }

    public boolean charTyped(CharInput charInput) {
        if (this.controller.isNameFieldFocused() && charInput.isValidChar()) {
            String input = charInput.asString();
            if (input.isBlank() && charInput.codepoint() != 32) {
                return true;
            } else {
                this.controller.appendProfileName(input);
                return true;
            }
        } else {
            return super.charTyped(charInput);
        }
    }

    public boolean shouldPause() {
        return false;
    }

    public void close() {
        MinecraftClient minecraftClient = MinecraftClient.getInstance();
        minecraftClient.setScreen(this.parent);
    }

    private void renderPanel(DrawContext context, ConfigManagerScreen.Layout layout, int mouseX, int mouseY) {
        RenderUtil.drawRoundedRect(context, layout.panelX() + 3.0F, layout.panelY() + 4.0F, layout.panelWidth(), layout.panelHeight(), 14.0F, 1409286144);
        this.drawCard(context, layout.panelX(), layout.panelY(), layout.panelWidth(), layout.panelHeight(), 14.0F, -14012871, -300805352);
        RenderUtil.drawRoundedRect(
            context, layout.panelX() + 2.0F, layout.panelY() + 2.0F, layout.panelWidth() - 4.0F, layout.panelHeight() - 4.0F, 12.0F, -15789802
        );
        this.drawCard(context, layout.panelX(), layout.panelY(), layout.panelWidth(), 56.0F, 14.0F, -14473162, -15263456);
        RenderUtil.drawRoundedRect(context, layout.panelX() + 16.0F, layout.panelY() + 10.0F, 3.0F, 28.0F, 2.0F, -10072);
        RenderUtil.drawText(context, this.textRenderer, "LOCAL CONFIGS", layout.panelX() + 22.0F, layout.panelY() + 12.0F, -1);
        RenderUtil.drawText(
            context,
            this.textRenderer,
            this.fit("Snapshots of your current modules, values, binds, and positions", layout.panelWidth() - 180.0F),
            layout.panelX() + 22.0F,
            layout.panelY() + 24.0F,
            -8750470
        );
        this.renderHeaderChips(context, layout);
        this.renderListSection(context, layout, mouseX, mouseY);
        this.renderNameSection(context, layout, mouseX, mouseY);
        this.renderDetailsSection(context, layout);
        this.renderActionsSection(context, layout, mouseX, mouseY);
        this.renderStatusSection(context, layout);
    }

    private void renderListSection(DrawContext context, ConfigManagerScreen.Layout layout, int mouseX, int mouseY) {
        this.drawCard(context, layout.listX(), layout.listY(), layout.listWidth(), layout.listHeight(), 10.0F, -13881024, -14934490);
        RenderUtil.drawText(context, this.textRenderer, "PROFILES", layout.listX() + 12.0F, layout.listY() + 10.0F, -1);
        RenderUtil.drawText(
            context,
            this.textRenderer,
            this.controller.isLoadingLocal() ? "Refreshing..." : "Stored on this device",
            layout.listX() + 80.0F,
            layout.listY() + 10.0F,
            -8750470
        );
        List<LocalConfigProfile> profiles = this.controller.getVisibleLocalProfiles(this.visibleRowCount(layout));
        if (this.controller.isLoadingLocal()) {
            this.renderEmptyList(context, layout, "Refreshing local profile list...");
        } else if (profiles.isEmpty()) {
            this.renderEmptyList(context, layout, "No local profiles yet. Save the current setup to create one.");
        } else {
            float rowY = layout.listBodyY();

            for (LocalConfigProfile profile : profiles) {
                this.renderLocalRow(context, layout, rowY, mouseX, mouseY, profile);
                rowY += 48.0F;
            }
        }
    }

    private void renderEmptyList(DrawContext context, ConfigManagerScreen.Layout layout, String message) {
        this.drawCard(context, layout.listBodyX(), layout.listBodyY(), layout.listBodyWidth(), 52.0F, 8.0F, -13223092, -14407885);
        RenderUtil.drawText(
            context, this.textRenderer, this.fit(message, layout.listBodyWidth() - 16.0F), layout.listBodyX() + 8.0F, layout.listBodyY() + 12.0F, -4671304
        );
    }

    private void renderLocalRow(DrawContext context, ConfigManagerScreen.Layout layout, float rowY, int mouseX, int mouseY, LocalConfigProfile profile) {
        boolean selected = profile.id().equals(this.controller.getSelectedLocalId());
        boolean hovered = contains((double)mouseX, (double)mouseY, layout.listBodyX(), rowY, layout.listBodyWidth(), 42.0F);
        int fill = selected ? -13749696 : (hovered ? -13749696 : -14407885);
        int nameColor = selected ? -3365 : -1;
        String displayName = profile.name().isBlank() ? "Unnamed Local Profile" : profile.name();
        this.drawCard(context, layout.listBodyX(), rowY, layout.listBodyWidth(), 42.0F, 8.0F, selected ? -10072 : (hovered ? -13223092 : -13881024), fill);
        RenderUtil.drawRoundedRect(context, layout.listBodyX() + 1.0F, rowY + 1.0F, 3.0F, 40.0F, 2.0F, selected ? -10072 : (hovered ? -4671304 : -10789272));
        RenderUtil.drawText(
            context, this.textRenderer, this.fit(displayName, layout.listBodyWidth() - 92.0F), layout.listBodyX() + 12.0F, rowY + 7.0F, nameColor
        );
        RenderUtil.drawText(
            context,
            this.textRenderer,
            this.fit("Updated " + formatInstant(profile.updatedAt()), layout.listBodyWidth() - 92.0F),
            layout.listBodyX() + 12.0F,
            rowY + 21.0F,
            -8750470
        );
        float badgeWidth = 16.0F + (float)this.textRenderer.getWidth("LOCAL");
        float badgeX = layout.listBodyX() + layout.listBodyWidth() - badgeWidth - 8.0F;
        this.drawChip(context, badgeX, rowY + 10.0F, badgeWidth, 16.0F, "LOCAL", selected ? -10072 : -14934490, selected ? -15658735 : -4671304);
    }

    private void renderNameSection(DrawContext context, ConfigManagerScreen.Layout layout, int mouseX, int mouseY) {
        this.drawCard(context, layout.rightX(), layout.nameSectionY(), layout.rightWidth(), layout.nameSectionHeight(), 10.0F, -13881024, -14934490);
        RenderUtil.drawText(context, this.textRenderer, "PROFILE NAME", layout.rightX() + 12.0F, layout.nameSectionY() + 10.0F, -1);
        RenderUtil.drawText(
            context,
            this.textRenderer,
            this.fit("Used for save, rename, and duplicate", layout.rightWidth() - 130.0F),
            layout.rightX() + 118.0F,
            layout.nameSectionY() + 10.0F,
            -8750470
        );
        boolean hovered = contains((double)mouseX, (double)mouseY, layout.nameFieldX(), layout.nameFieldY(), layout.nameFieldWidth(), layout.nameFieldHeight());
        boolean focused = this.controller.isNameFieldFocused();
        this.drawCard(
            context,
            layout.nameFieldX(),
            layout.nameFieldY(),
            layout.nameFieldWidth(),
            layout.nameFieldHeight(),
            8.0F,
            focused ? -10072 : -13354678,
            focused ? RenderUtil.mixColor(-15460319, -10072, 0.1F) : (hovered ? -13749696 : -15460319)
        );
        String value = this.controller.getProfileNameInput();
        String display = value.isBlank() ? "New Profile" : value;
        boolean showCaret = focused && System.currentTimeMillis() / 450L % 2L == 0L;
        String renderValue = this.fit(display + (showCaret ? "|" : ""), layout.nameFieldWidth() - 18.0F);
        RenderUtil.drawText(
            context,
            this.textRenderer,
            renderValue,
            layout.nameFieldX() + 8.0F,
            layout.nameFieldY() + 8.0F,
            focused ? -3365 : (value.isBlank() ? -8750470 : -4671304)
        );
    }

    private void renderDetailsSection(DrawContext context, ConfigManagerScreen.Layout layout) {
        this.drawCard(context, layout.rightX(), layout.detailsY(), layout.rightWidth(), layout.detailsHeight(), 10.0F, -13881024, -14934490);
        RenderUtil.drawText(context, this.textRenderer, "DETAILS", layout.rightX() + 12.0F, layout.detailsY() + 10.0F, -1);
        List<String> lines = this.buildDetailLines();
        float textY = layout.detailsY() + 28.0F;

        for (int index = 0; index < lines.size(); index++) {
            String line = lines.get(index);
            RenderUtil.drawText(
                context,
                this.textRenderer,
                this.fit(line, layout.rightWidth() - 24.0F),
                layout.rightX() + 12.0F,
                textY,
                index == 0 ? -3365 : (index < 3 ? -1 : -4671304)
            );
            textY += 12.0F;
        }
    }

    private void renderActionsSection(DrawContext context, ConfigManagerScreen.Layout layout, int mouseX, int mouseY) {
        this.drawCard(context, layout.rightX(), layout.actionsY(), layout.rightWidth(), layout.actionsHeight(), 10.0F, -13881024, -14934490);
        RenderUtil.drawText(context, this.textRenderer, "ACTIONS", layout.rightX() + 12.0F, layout.actionsY() + 10.0F, -1);
        RenderUtil.drawText(
            context,
            this.textRenderer,
            this.fit("Everything stays local to this device", layout.rightWidth() - 86.0F),
            layout.rightX() + 74.0F,
            layout.actionsY() + 10.0F,
            -8750470
        );

        for (ConfigManagerScreen.ActionButton button : this.buildActionButtons(layout)) {
            this.renderActionButton(context, button, mouseX, mouseY);
        }
    }

    private void renderActionButton(DrawContext context, ConfigManagerScreen.ActionButton button, int mouseX, int mouseY) {
        boolean hovered = contains((double)mouseX, (double)mouseY, button.x(), button.y(), button.width(), button.height());
        boolean waitingConfirm = button.id().equals(this.pendingConfirmationAction) && System.currentTimeMillis() <= this.pendingConfirmationUntil;
        int fill = !button.enabled()
            ? -15460319
            : (waitingConfirm ? -3365 : (button.primary() ? (hovered ? RenderUtil.mixColor(-10072, -1, 0.18F) : -10072) : (hovered ? -13749696 : -14407885)));
        int textColor = !button.enabled() ? -8750470 : (!waitingConfirm && !button.primary() ? -1 : -15658735);
        this.drawCard(
            context,
            button.x(),
            button.y(),
            button.width(),
            button.height(),
            7.0F,
            !button.enabled() ? -13223092 : (!waitingConfirm && !button.primary() ? -13223092 : fill),
            fill
        );
        RenderUtil.drawText(context, this.textRenderer, waitingConfirm ? "CONFIRM" : button.label(), button.x() + 10.0F, button.y() + 9.0F, textColor);
    }

    private void renderStatusSection(DrawContext context, ConfigManagerScreen.Layout layout) {
        int statusColor = this.controller.isStatusError() ? -34182 : (this.controller.isBusy() ? -3365 : -6429529);
        this.drawCard(context, layout.rightX(), layout.statusY(), layout.rightWidth(), layout.statusHeight(), 10.0F, -13881024, -14934490);
        RenderUtil.drawRoundedRect(context, layout.rightX() + 12.0F, layout.statusY() + 12.0F, 14.0F, 14.0F, 5.0F, statusColor);
        RenderUtil.drawText(
            context,
            this.textRenderer,
            this.controller.isBusy() ? "WORKING" : (this.controller.isStatusError() ? "STATUS" : "READY"),
            layout.rightX() + 34.0F,
            layout.statusY() + 11.0F,
            statusColor
        );
        List<String> lines = this.wrap(
            this.controller.isBusy() && !this.controller.getBusyLabel().isBlank() ? this.controller.getBusyLabel() + "..." : this.controller.getStatusMessage(),
            layout.rightWidth() - 44.0F
        );
        float textY = layout.statusY() + 28.0F;

        for (String line : lines) {
            RenderUtil.drawText(context, this.textRenderer, line, layout.rightX() + 12.0F, textY, -4671304);
            textY += 11.0F;
        }
    }

    private boolean handleProfileClick(ConfigManagerScreen.Layout layout, int mouseX, int mouseY) {
        float rowY = layout.listBodyY();

        for (LocalConfigProfile profile : this.controller.getVisibleLocalProfiles(this.visibleRowCount(layout))) {
            if (contains((double)mouseX, (double)mouseY, layout.listBodyX(), rowY, layout.listBodyWidth(), 42.0F)) {
                this.controller.selectLocalProfile(profile.id());
                return true;
            }

            rowY += 48.0F;
        }

        return false;
    }

    private boolean confirmActionIfNeeded(String actionId, String label) {
        if (!requiresConfirmation(actionId)) {
            return true;
        } else {
            long now = System.currentTimeMillis();
            if (actionId.equals(this.pendingConfirmationAction) && now <= this.pendingConfirmationUntil) {
                return true;
            } else {
                this.pendingConfirmationAction = actionId;
                this.pendingConfirmationUntil = now + 3500L;
                this.controller.showStatus(label, false);
                return false;
            }
        }
    }

    private void clearPendingConfirmation() {
        this.pendingConfirmationAction = "";
        this.pendingConfirmationUntil = 0L;
    }

    private void performAction(String actionId) {
        switch (actionId) {
            case "local.save":
                this.controller.saveCurrentAsLocal();
                break;
            case "local.load":
                this.controller.loadSelectedLocal();
                break;
            case "local.overwrite":
                this.controller.overwriteSelectedLocal();
                break;
            case "local.rename":
                this.controller.renameSelectedLocal();
                break;
            case "local.duplicate":
                this.controller.duplicateSelectedLocal();
                break;
            case "local.delete":
                this.controller.deleteSelectedLocal();
                break;
            case "local.refresh":
                this.controller.refreshLocal();
        }
    }

    private List<String> buildDetailLines() {
        LocalConfigProfile selected = this.controller.getSelectedLocalProfile();
        if (selected == null) {
            return List.of(
                "No local profile selected",
                "Save the current config or pick a local profile from the left list.",
                "Each save includes enabled modules, values, binds, and positions."
            );
        } else {
            ArrayList<String> lines = new ArrayList<>();
            lines.add(selected.name().isBlank() ? "Unnamed Local Profile" : selected.name());
            lines.add("Type: Local current-state snapshot");
            lines.add("Values: " + selected.snapshot().values().size());
            lines.add("Schema: " + selected.schemaVersion());
            lines.add("Client: " + selected.clientVersion());
            lines.add("Updated: " + formatInstant(selected.updatedAt()));
            lines.add("Created: " + formatInstant(selected.createdAt()));
            return lines;
        }
    }

    private List<ConfigManagerScreen.ActionButton> buildActionButtons(ConfigManagerScreen.Layout layout) {
        ArrayList<ConfigManagerScreen.ActionButton> buttons = new ArrayList<>();
        float x = layout.rightX() + 12.0F;
        float y = layout.actionsY() + 30.0F;
        float columnWidth = (layout.rightWidth() - 32.0F) * 0.5F;
        float fullWidth = layout.rightWidth() - 24.0F;
        float rightX = x + columnWidth + 10.0F;
        buttons.add(new ConfigManagerScreen.ActionButton("local.save", "SAVE CURRENT", x, y, columnWidth, 28.0F, true, !this.controller.isBusy()));
        buttons.add(
            new ConfigManagerScreen.ActionButton(
                "local.load", "LOAD", rightX, y, columnWidth, 28.0F, false, this.controller.hasSelectedLocalProfile() && !this.controller.isBusy()
            )
        );
        y += 38.0F;
        buttons.add(
            new ConfigManagerScreen.ActionButton(
                "local.overwrite", "OVERWRITE", x, y, columnWidth, 28.0F, false, this.controller.hasSelectedLocalProfile() && !this.controller.isBusy()
            )
        );
        buttons.add(
            new ConfigManagerScreen.ActionButton(
                "local.rename", "RENAME", rightX, y, columnWidth, 28.0F, false, this.controller.hasSelectedLocalProfile() && !this.controller.isBusy()
            )
        );
        y += 38.0F;
        buttons.add(
            new ConfigManagerScreen.ActionButton(
                "local.duplicate", "DUPLICATE", x, y, columnWidth, 28.0F, false, this.controller.hasSelectedLocalProfile() && !this.controller.isBusy()
            )
        );
        buttons.add(
            new ConfigManagerScreen.ActionButton(
                "local.delete", "DELETE", rightX, y, columnWidth, 28.0F, false, this.controller.hasSelectedLocalProfile() && !this.controller.isBusy()
            )
        );
        y += 38.0F;
        buttons.add(new ConfigManagerScreen.ActionButton("local.refresh", "REFRESH LOCAL LIST", x, y, fullWidth, 28.0F, false, !this.controller.isBusy()));
        return buttons;
    }

    private ConfigManagerScreen.Layout createLayout() {
        float panelWidth = Math.min(Math.max(0.0F, this.menuSpaceWidth - 28.0F), 1040.0F);
        float panelHeight = Math.min(Math.max(0.0F, this.menuSpaceHeight - 28.0F), 600.0F);
        float panelX = (this.menuSpaceWidth - panelWidth) * 0.5F;
        float panelY = (this.menuSpaceHeight - panelHeight) * 0.5F;
        float listX = panelX + 22.0F;
        float listY = panelY + 56.0F;
        float listHeight = panelHeight - 78.0F;
        float listWidth = clamp(panelWidth * 0.32F, 236.0F, 390.0F);
        float maxListWidth = Math.max(220.0F, panelWidth - 44.0F - 20.0F - 320.0F);
        if (listWidth > maxListWidth) {
            listWidth = maxListWidth;
        }

        float rightX = listX + listWidth + 20.0F;
        float rightWidth = panelX + panelWidth - 22.0F - rightX;
        float sectionGap = 12.0F;
        float nameSectionHeight = 78.0F;
        float detailsHeight = 132.0F;
        float actionsHeight = 186.0F;
        float detailsY = listY + nameSectionHeight + sectionGap;
        float actionsY = detailsY + detailsHeight + sectionGap;
        float statusY = actionsY + actionsHeight + sectionGap;
        float statusHeight = Math.max(76.0F, panelY + panelHeight - 22.0F - statusY);
        return new ConfigManagerScreen.Layout(
            panelX,
            panelY,
            panelWidth,
            panelHeight,
            listX,
            listY,
            listWidth,
            listHeight,
            listX + 10.0F,
            listY + 32.0F,
            listWidth - 20.0F,
            listHeight - 42.0F,
            rightX,
            rightWidth,
            listY,
            nameSectionHeight,
            rightX + 12.0F,
            listY + 28.0F,
            rightWidth - 24.0F,
            30.0F,
            detailsY,
            detailsHeight,
            actionsY,
            actionsHeight,
            statusY,
            statusHeight
        );
    }

    private int visibleRowCount(ConfigManagerScreen.Layout layout) {
        return Math.max(1, (int)((layout.listBodyHeight() + 6.0F) / 48.0F));
    }

    private void updateMenuMetrics() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) {
            this.menuScale = 1.0F;
            this.menuSpaceWidth = (float)this.width;
            this.menuSpaceHeight = (float)this.height;
        } else {
            Window window = client.getWindow();
            float resolutionScale = Math.min((float)window.getWidth() / 1920.0F, (float)window.getHeight() / 1080.0F);
            float targetPixelScale = clamp(2.0F * resolutionScale, 1.4F, 2.35F);
            this.menuScale = targetPixelScale / Math.max(1.0F, (float)window.getScaleFactor());
            float fitScale = Math.min((float)this.width / Math.max(1.0F, 1068.0F), (float)this.height / Math.max(1.0F, 628.0F));
            this.menuScale = Math.min(this.menuScale, Math.max(0.001F, fitScale));
            this.menuSpaceWidth = (float)this.width / this.menuScale;
            this.menuSpaceHeight = (float)this.height / this.menuScale;
        }
    }

    private int toMenuSpace(double value) {
        return Math.round((float)value / Math.max(0.001F, this.menuScale));
    }

    private static boolean contains(double mouseX, double mouseY, float x, float y, float width, float height) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + height);
    }

    private static boolean requiresConfirmation(String actionId) {
        return "local.overwrite".equals(actionId) || "local.delete".equals(actionId);
    }

    private static String confirmationLabel(String actionId) {
        return switch (actionId) {
            case "local.overwrite" -> "Click OVERWRITE again to confirm replacing the local profile.";
            case "local.delete" -> "Click DELETE again to remove the local profile.";
            default -> "";
        };
    }

    private void renderHeaderChips(DrawContext context, ConfigManagerScreen.Layout layout) {
        float chipY = layout.panelY() + 13.0F;
        float x = layout.panelX() + layout.panelWidth() - 22.0F;
        x = this.drawHeaderChip(context, x, chipY, "LOCAL ONLY", "ON", -10072);
        this.drawHeaderChip(context, x, chipY, "PROFILES", Integer.toString(this.controller.getLocalProfiles().size()), -3365);
    }

    private float drawHeaderChip(DrawContext context, float rightX, float y, String label, String value, int accent) {
        float valueWidth = (float)this.textRenderer.getWidth(value);
        float labelWidth = (float)this.textRenderer.getWidth(label);
        float width = 34.0F + labelWidth + valueWidth;
        float x = rightX - width;
        this.drawCard(context, x, y, width, 20.0F, 8.0F, -13223092, -14407885);
        RenderUtil.drawRoundedRect(context, x + 6.0F, y + 5.0F, 5.0F, 10.0F, 2.0F, accent);
        RenderUtil.drawText(context, this.textRenderer, label, x + 16.0F, y + 6.0F, -8750470);
        RenderUtil.drawText(context, this.textRenderer, value, x + width - valueWidth - 8.0F, y + 6.0F, -1);
        return x - 8.0F;
    }

    private void drawCard(DrawContext context, float x, float y, float width, float height, float radius, int borderColor, int fillColor) {
        RenderUtil.drawRoundedRect(context, x, y, width, height, radius, borderColor);
        RenderUtil.drawRoundedRect(context, x + 1.0F, y + 1.0F, width - 2.0F, height - 2.0F, Math.max(0.0F, radius - 1.0F), fillColor);
    }

    private void drawChip(DrawContext context, float x, float y, float width, float height, String text, int fillColor, int textColor) {
        this.drawCard(context, x, y, width, height, 6.0F, -13223092, fillColor);
        RenderUtil.drawText(context, this.textRenderer, text, x + 8.0F, y + 5.0F, textColor);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private String fit(String value, float maxWidth) {
        if (value == null) {
            return "";
        } else if ((float)this.textRenderer.getWidth(value) <= maxWidth) {
            return value;
        } else {
            String trimmed = value;

            while (!trimmed.isEmpty() && (float)this.textRenderer.getWidth(trimmed + "..") > maxWidth) {
                trimmed = trimmed.substring(0, trimmed.length() - 1);
            }

            return trimmed + "..";
        }
    }

    private List<String> wrap(String value, float maxWidth) {
        if (value != null && !value.isBlank()) {
            ArrayList<String> lines = new ArrayList<>();
            String[] words = value.trim().split("\\s+");
            StringBuilder builder = new StringBuilder();

            for (String word : words) {
                String candidate = builder.isEmpty() ? word : builder + " " + word;
                if ((float)this.textRenderer.getWidth(candidate) <= maxWidth) {
                    builder.setLength(0);
                    builder.append(candidate);
                } else {
                    if (!builder.isEmpty()) {
                        lines.add(builder.toString());
                        builder.setLength(0);
                    }

                    if ((float)this.textRenderer.getWidth(word) <= maxWidth) {
                        builder.append(word);
                    } else {
                        String remainder = word;

                        while (!remainder.isEmpty()) {
                            int index = remainder.length();

                            while (index > 1 && (float)this.textRenderer.getWidth(remainder.substring(0, index) + "-") > maxWidth) {
                                index--;
                            }

                            if (index <= 1) {
                                lines.add(remainder);
                                remainder = "";
                            } else {
                                lines.add(remainder.substring(0, index) + "-");
                                remainder = remainder.substring(index);
                            }
                        }
                    }
                }
            }

            if (!builder.isEmpty()) {
                lines.add(builder.toString());
            }

            return (List<String>)(lines.size() > 3 ? lines.subList(0, 3) : lines);
        } else {
            return List.of("Idle");
        }
    }

    private static String formatInstant(Instant instant) {
        return instant == null ? "Unknown" : DATE_FORMAT.format(instant);
    }

    private static record ActionButton(String id, String label, float x, float y, float width, float height, boolean primary, boolean enabled) {
    }

    private static record Layout(
        float panelX,
        float panelY,
        float panelWidth,
        float panelHeight,
        float listX,
        float listY,
        float listWidth,
        float listHeight,
        float listBodyX,
        float listBodyY,
        float listBodyWidth,
        float listBodyHeight,
        float rightX,
        float rightWidth,
        float nameSectionY,
        float nameSectionHeight,
        float nameFieldX,
        float nameFieldY,
        float nameFieldWidth,
        float nameFieldHeight,
        float detailsY,
        float detailsHeight,
        float actionsY,
        float actionsHeight,
        float statusY,
        float statusHeight
    ) {
    }
}
