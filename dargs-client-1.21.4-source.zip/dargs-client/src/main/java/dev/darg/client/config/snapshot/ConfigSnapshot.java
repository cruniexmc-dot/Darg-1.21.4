package dev.darg.client.config.snapshot;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public record ConfigSnapshot(int schemaVersion, String clientVersion, Map<String, String> values) {
    public ConfigSnapshot(int schemaVersion, String clientVersion, Map<String, String> values) {
        schemaVersion = Math.max(1, schemaVersion);
        clientVersion = clientVersion == null ? "" : clientVersion.trim();
        values = Collections.unmodifiableMap(new LinkedHashMap<>(values == null ? Map.of() : values));
        this.schemaVersion = schemaVersion;
        this.clientVersion = clientVersion;
        this.values = values;
    }
}
