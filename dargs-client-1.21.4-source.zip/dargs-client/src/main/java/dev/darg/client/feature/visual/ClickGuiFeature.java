package dev.darg.client.feature.visual;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import net.minecraft.client.MinecraftClient;

public final class ClickGuiFeature extends Feature {
    public ClickGuiFeature() {
        super("ClickGUI", Category.SETTINGS);
    }

    @Override
    public boolean isVisibleInClickGui() {
        return false;
    }

    @Override
    protected void onEnable() {
        MinecraftClient client = MinecraftClient.getInstance();
        client.setScreen(DargsClient.getInstance().getUiManager().createClickGuiScreen());
        this.setEnabled(false);
    }
}
