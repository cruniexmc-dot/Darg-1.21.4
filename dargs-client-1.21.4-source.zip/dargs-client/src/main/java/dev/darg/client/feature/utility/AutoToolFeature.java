package dev.darg.client.feature.utility;

import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;

public final class AutoToolFeature extends Feature {
    private BlockPos lastSwapPos;
    private int lastSwapSlot = -1;

    public AutoToolFeature() {
        super("AutoTool", Category.UTILITY);
    }

    @Override
    protected void onDisable() {
        this.lastSwapPos = null;
        this.lastSwapSlot = -1;
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        ClientPlayerInteractionManager interactionManager = client.interactionManager;
        if (player == null || client.world == null || interactionManager == null) {
            this.resetSwapMemory();
        } else if (client.options.attackKey.isPressed() && interactionManager.isBreakingBlock()) {
            if (client.crosshairTarget instanceof BlockHitResult blockHitResult && client.crosshairTarget.getType() == Type.BLOCK) {
                BlockPos targetPos = blockHitResult.getBlockPos();
                BlockState state = client.world.getBlockState(targetPos);
                if (state.isAir()) {
                    this.resetSwapMemory();
                    return;
                }

                PlayerInventory inventory = player.getInventory();
                int selectedSlot = inventory.getSelectedSlot();
                int bestSlot = findBestHotbarSlot(state, selectedSlot, inventory);
                if (bestSlot >= 0 && bestSlot != selectedSlot) {
                    if (targetPos.equals(this.lastSwapPos) && bestSlot == this.lastSwapSlot) {
                        return;
                    }

                    selectHotbarSlot(player, bestSlot);
                    this.lastSwapPos = targetPos.toImmutable();
                    this.lastSwapSlot = bestSlot;
                    return;
                }

                this.lastSwapPos = targetPos.toImmutable();
                this.lastSwapSlot = selectedSlot;
                return;
            }

            this.resetSwapMemory();
        } else {
            this.resetSwapMemory();
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("State: " + (this.isEnabled() ? "Enabled" : "Disabled"), "Switches while actively mining", "Uses the best matching hotbar tool");
    }

    @Override
    public String getHudSuffix() {
        return "HOTBAR";
    }

    private static int findBestHotbarSlot(BlockState state, int selectedSlot, PlayerInventory inventory) {
        float currentScore = scoreStack(inventory.getStack(selectedSlot), state);
        int bestSlot = selectedSlot;
        float bestScore = currentScore;

        for (int slot = 0; slot < PlayerInventory.getHotbarSize(); slot++) {
            ItemStack stack = inventory.getStack(slot);
            float score = scoreStack(stack, state);
            if (score > bestScore + 0.01F) {
                bestScore = score;
                bestSlot = slot;
            }
        }

        return bestSlot;
    }

    private static float scoreStack(ItemStack stack, BlockState state) {
        if (stack.isEmpty()) {
            return 0.0F;
        } else {
            float score = stack.getMiningSpeedMultiplier(state);
            if (stack.isSuitableFor(state)) {
                score += 100.0F;
            }

            return score;
        }
    }

    private static void selectHotbarSlot(ClientPlayerEntity player, int slot) {
        player.getInventory().setSelectedSlot(slot);
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
    }

    private void resetSwapMemory() {
        this.lastSwapPos = null;
        this.lastSwapSlot = -1;
    }
}
