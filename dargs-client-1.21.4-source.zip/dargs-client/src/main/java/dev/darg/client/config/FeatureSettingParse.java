package dev.darg.client.config;

public final class FeatureSettingParse {
    private FeatureSettingParse() {
    }

    public static boolean parseBool(String raw, boolean defaultValue) {
        if (raw != null && !raw.isEmpty()) {
            String s = raw.trim();
            return "1".equals(s) || "true".equalsIgnoreCase(s) || "yes".equalsIgnoreCase(s);
        } else {
            return defaultValue;
        }
    }

    public static int parseInt(String raw, int defaultValue, int min, int max) {
        if (raw != null && !raw.isEmpty()) {
            try {
                int v = Integer.parseInt(raw.trim());
                return Math.max(min, Math.min(max, v));
            } catch (NumberFormatException var5) {
                return defaultValue;
            }
        } else {
            return defaultValue;
        }
    }

    public static float parseFloat(String raw, float defaultValue, float min, float max) {
        if (raw != null && !raw.isEmpty()) {
            try {
                float v = Float.parseFloat(raw.trim());
                return !Float.isNaN(v) && !Float.isInfinite(v) ? Math.max(min, Math.min(max, v)) : defaultValue;
            } catch (NumberFormatException var5) {
                return defaultValue;
            }
        } else {
            return defaultValue;
        }
    }
}
