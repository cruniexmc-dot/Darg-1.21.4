package dev.darg.client.mixin;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.utility.FreeLookFeature;
import dev.darg.client.feature.utility.FreecamController;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Mouse.class})
public abstract class MouseMixin {
    @Redirect(
        method = {"updateMouse"},
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/network/ClientPlayerEntity;changeLookDirection(DD)V"
        )
    )
    private void dargsclient$redirectFreeLook(ClientPlayerEntity player, double deltaX, double deltaY) {
        DargsClient client = DargsClient.getInstance();
        if (client != null) {
            client.getFeatureManager().mouseMoved(deltaX, deltaY);
        }

        if (client == null) {
            player.changeLookDirection(deltaX, deltaY);
        } else {
            FreecamController freecamController = FreecamController.getInstance();
            if (freecamController.isActive()) {
                freecamController.applyMouseLook(deltaX, deltaY);
            } else {
                FreeLookFeature freeLookFeature = client.getFeatureManager().getFeature(FreeLookFeature.class);
                if (freeLookFeature != null && freeLookFeature.isEnabled()) {
                    freeLookFeature.applyMouseLook(player, 1.0F, deltaX, deltaY);
                } else {
                    player.changeLookDirection(deltaX, deltaY);
                }
            }
        }
    }

    @Inject(
        method = {"onMouseScroll"},
        at = {@At("HEAD")},
        cancellable = true
    )
    private void dargsclient$adjustFreecamSpeed(long window, double horizontal, double vertical, CallbackInfo callbackInfo) {
        FreecamController freecamController = FreecamController.getInstance();
        if (freecamController.isActive() && vertical != 0.0) {
            if (MinecraftClient.getInstance().currentScreen == null) {
                freecamController.adjustSpeed(vertical);
                callbackInfo.cancel();
            }
        }
    }
}
