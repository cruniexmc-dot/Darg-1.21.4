package dev.darg.client.ui;

import dev.darg.client.ui.clickgui.ClickGuiScreen;
import dev.darg.client.ui.config.ConfigManagerScreen;
import dev.darg.client.ui.entry.DargEntryScreen;
import net.minecraft.client.gui.screen.Screen;

public final class UiManager {
    public ClickGuiScreen createClickGuiScreen() {
        return new ClickGuiScreen();
    }

    public ConfigManagerScreen createConfigManagerScreen(Screen parent) {
        return new ConfigManagerScreen(parent);
    }

    public DargEntryScreen createEntryScreen() {
        return new DargEntryScreen();
    }
}
