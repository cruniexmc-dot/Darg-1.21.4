package dev.darg.client.feature.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.Packet;

public final class CombatFeatureHooks {
    private CombatFeatureHooks() {
    }

    public interface AttackHook {
        boolean onBeforeAttack(MinecraftClient var1);
    }

    public interface BlockBreakingHook {
        boolean onBeforeBlockBreaking(MinecraftClient var1, boolean var2);
    }

    public interface ItemUseHook {
        boolean onBeforeItemUse(MinecraftClient var1);
    }

    public interface PacketReceiveHook {
        void onReceivePacket(MinecraftClient var1, Packet<?> var2);
    }

    public interface PacketSendHook {
        boolean onSendPacket(MinecraftClient var1, Packet<?> var2);
    }
}
