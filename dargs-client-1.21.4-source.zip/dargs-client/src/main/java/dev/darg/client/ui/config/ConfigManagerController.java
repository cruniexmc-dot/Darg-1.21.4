package dev.darg.client.ui.config;

import dev.darg.client.config.local.LocalConfigProfile;
import dev.darg.client.config.local.LocalConfigProfileStore;
import dev.darg.client.config.snapshot.ConfigSnapshot;
import dev.darg.client.config.snapshot.ConfigSnapshotSerializer;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;

public final class ConfigManagerController {
    private static final int MAX_PROFILE_NAME_LENGTH = 48;
    private final MinecraftClient client;
    private final LocalConfigProfileStore localStore = new LocalConfigProfileStore();
    private List<LocalConfigProfile> localProfiles = List.of();
    private String selectedLocalId = "";
    private int localScroll = 0;
    private String profileNameInput = "";
    private boolean nameFieldFocused = false;
    private boolean initialized = false;
    private boolean loadingLocal = false;
    private boolean busy = false;
    private String busyLabel = "";
    private String statusMessage = "Local profiles save the current enabled modules, setting values, and positions.";
    private boolean statusError = false;

    public ConfigManagerController() {
        this.client = MinecraftClient.getInstance();
    }

    public void initialize() {
        if (!this.initialized) {
            this.initialized = true;
            this.refreshLocal();
        }
    }

    public List<LocalConfigProfile> getLocalProfiles() {
        return this.localProfiles;
    }

    public List<LocalConfigProfile> getVisibleLocalProfiles(int visibleCount) {
        return subList(this.localProfiles, this.localScroll, visibleCount);
    }

    public int getLocalScroll() {
        return this.localScroll;
    }

    public void scrollLocal(int amount, int visibleCount) {
        if (visibleCount > 0 && amount != 0) {
            this.localScroll = clampScroll(this.localProfiles.size(), visibleCount, this.localScroll + amount);
        }
    }

    public String getSelectedLocalId() {
        return this.selectedLocalId;
    }

    public LocalConfigProfile getSelectedLocalProfile() {
        for (LocalConfigProfile profile : this.localProfiles) {
            if (profile.id().equals(this.selectedLocalId)) {
                return profile;
            }
        }

        return null;
    }

    public void selectLocalProfile(String profileId) {
        if (profileId != null && !profileId.isBlank()) {
            this.selectedLocalId = profileId;
            LocalConfigProfile profile = this.getSelectedLocalProfile();
            if (profile != null) {
                this.profileNameInput = profile.name();
            }
        }
    }

    public boolean isNameFieldFocused() {
        return this.nameFieldFocused;
    }

    public void setNameFieldFocused(boolean focused) {
        this.nameFieldFocused = focused;
    }

    public String getProfileNameInput() {
        return this.profileNameInput;
    }

    public void setProfileNameInput(String value) {
        this.profileNameInput = sanitizeProfileName(value);
    }

    public void appendProfileName(String input) {
        if (input != null && !input.isEmpty() && this.profileNameInput.length() < 48) {
            int room = 48 - this.profileNameInput.length();
            String sanitized = input.replaceAll("\\s+", " ");
            if (!sanitized.isBlank() || input.contains(" ")) {
                this.profileNameInput = this.profileNameInput + sanitized.substring(0, Math.min(room, sanitized.length()));
                this.profileNameInput = sanitizeProfileName(this.profileNameInput);
            }
        }
    }

    public void backspaceProfileName() {
        if (!this.profileNameInput.isEmpty()) {
            this.profileNameInput = this.profileNameInput.substring(0, this.profileNameInput.length() - 1);
        }
    }

    public boolean isLoadingLocal() {
        return this.loadingLocal;
    }

    public boolean isBusy() {
        return this.busy;
    }

    public String getBusyLabel() {
        return this.busyLabel;
    }

    public String getStatusMessage() {
        return this.statusMessage;
    }

    public boolean isStatusError() {
        return this.statusError;
    }

    public void showStatus(String message, boolean error) {
        this.statusMessage = message != null && !message.isBlank() ? message : "";
        this.statusError = error;
    }

    public void refreshLocal() {
        if (!this.loadingLocal) {
            this.loadingLocal = true;
            CompletableFuture.supplyAsync(this.localStore::listProfiles)
                .whenComplete(
                    (profiles, throwable) -> this.onClientThread(
                            () -> {
                                this.loadingLocal = false;
                                if (throwable != null) {
                                    this.handleError("Failed to refresh local profiles", throwable);
                                } else {
                                    this.localProfiles = profiles == null ? List.of() : List.copyOf(profiles);
                                    this.localScroll = clampScroll(this.localProfiles.size(), 7, this.localScroll);
                                    this.restoreLocalSelection(this.selectedLocalId);
                                    this.showStatus(
                                        this.localProfiles.isEmpty()
                                            ? "No local profiles yet. Save the current setup to create one."
                                            : "Loaded " + this.localProfiles.size() + " local profile" + (this.localProfiles.size() == 1 ? "" : "s") + ".",
                                        false
                                    );
                                }
                            }
                        )
                );
        }
    }

    public boolean hasSelectedLocalProfile() {
        return this.getSelectedLocalProfile() != null;
    }

    public void saveCurrentAsLocal() {
        if (!this.busy) {
            ConfigSnapshot snapshot = ConfigSnapshotSerializer.exportLocalSnapshot();
            this.runBusy(
                "Saving local profile",
                CompletableFuture.supplyAsync(() -> this.localStore.saveProfile(this.resolveNameInput("New Profile"), snapshot)),
                created -> {
                    if (created == null) {
                        this.showStatus("Failed to save local profile.", true);
                    } else {
                        this.refreshLocalAfter(created.id(), "Saved local profile \"" + created.name() + "\".");
                    }
                }
            );
        }
    }

    public void loadSelectedLocal() {
        LocalConfigProfile selected = this.getSelectedLocalProfile();
        if (!this.busy && selected != null) {
            this.runBusy("Loading local profile", CompletableFuture.supplyAsync(() -> this.localStore.loadProfile(selected.id())), loaded -> {
                if (loaded == null) {
                    this.showStatus("Local profile no longer exists.", true);
                    this.refreshLocal();
                } else {
                    ConfigSnapshotSerializer.applyLocalSnapshot(loaded.snapshot());
                    this.showStatus("Loaded local profile \"" + loaded.name() + "\".", false);
                }
            });
        }
    }

    public void overwriteSelectedLocal() {
        LocalConfigProfile selected = this.getSelectedLocalProfile();
        if (!this.busy && selected != null) {
            ConfigSnapshot snapshot = ConfigSnapshotSerializer.exportLocalSnapshot();
            this.runBusy(
                "Overwriting local profile", CompletableFuture.supplyAsync(() -> this.localStore.overwriteProfile(selected.id(), snapshot)), updated -> {
                    if (updated == null) {
                        this.showStatus("Local profile no longer exists.", true);
                        this.refreshLocal();
                    } else {
                        this.refreshLocalAfter(updated.id(), "Overwrote local profile \"" + updated.name() + "\".");
                    }
                }
            );
        }
    }

    public void renameSelectedLocal() {
        LocalConfigProfile selected = this.getSelectedLocalProfile();
        if (!this.busy && selected != null) {
            String name = this.resolveNameInput(selected.name());
            this.runBusy("Renaming local profile", CompletableFuture.supplyAsync(() -> this.localStore.renameProfile(selected.id(), name)), renamed -> {
                if (renamed == null) {
                    this.showStatus("Local profile no longer exists.", true);
                    this.refreshLocal();
                } else {
                    this.refreshLocalAfter(renamed.id(), "Renamed local profile to \"" + renamed.name() + "\".");
                }
            });
        }
    }

    public void duplicateSelectedLocal() {
        LocalConfigProfile selected = this.getSelectedLocalProfile();
        if (!this.busy && selected != null) {
            String name = this.resolveNameInput(selected.name() + " Copy");
            this.runBusy(
                "Duplicating local profile", CompletableFuture.supplyAsync(() -> this.localStore.duplicateProfile(selected.id(), name)), duplicated -> {
                    if (duplicated == null) {
                        this.showStatus("Local profile no longer exists.", true);
                        this.refreshLocal();
                    } else {
                        this.refreshLocalAfter(duplicated.id(), "Duplicated local profile as \"" + duplicated.name() + "\".");
                    }
                }
            );
        }
    }

    public void deleteSelectedLocal() {
        LocalConfigProfile selected = this.getSelectedLocalProfile();
        if (!this.busy && selected != null) {
            this.runBusy("Deleting local profile", CompletableFuture.supplyAsync(() -> this.localStore.deleteProfile(selected.id())), deleted -> {
                if (!Boolean.TRUE.equals(deleted)) {
                    this.showStatus("Failed to delete local profile.", true);
                    this.refreshLocal();
                } else {
                    String removedName = selected.name();
                    this.selectedLocalId = "";
                    this.refreshLocal();
                    this.showStatus("Deleted local profile \"" + removedName + "\".", false);
                }
            });
        }
    }

    public boolean canScrollUp(int visibleCount) {
        return this.localScroll > 0 && this.localProfiles.size() > visibleCount;
    }

    public boolean canScrollDown(int visibleCount) {
        return this.localScroll + Math.max(0, visibleCount) < this.localProfiles.size();
    }

    private <T> void runBusy(String nextBusyLabel, CompletableFuture<T> future, Consumer<T> successHandler) {
        this.busy = true;
        this.busyLabel = nextBusyLabel == null ? "" : nextBusyLabel;
        future.whenComplete((result, throwable) -> this.onClientThread(() -> {
                this.busy = false;
                this.busyLabel = "";
                if (throwable != null) {
                    this.handleError(nextBusyLabel, throwable);
                } else {
                    successHandler.accept((T)result);
                }
            }));
    }

    private void refreshLocalAfter(String preferredId, String message) {
        this.loadingLocal = true;
        CompletableFuture.supplyAsync(this.localStore::listProfiles).whenComplete((profiles, throwable) -> this.onClientThread(() -> {
                this.loadingLocal = false;
                if (throwable != null) {
                    this.handleError("Failed to refresh local profiles", throwable);
                } else {
                    this.localProfiles = profiles == null ? List.of() : List.copyOf(profiles);
                    this.localScroll = clampScroll(this.localProfiles.size(), 7, this.localScroll);
                    this.restoreLocalSelection(preferredId);
                    this.showStatus(message, false);
                }
            }));
    }

    private void handleError(String fallbackPrefix, Throwable throwable) {
        Throwable cause = unwrap(throwable);
        String message = cause == null ? "" : Objects.toString(cause.getMessage(), "").trim();
        if (!message.isEmpty()) {
            this.showStatus(message, true);
        } else {
            this.showStatus(fallbackPrefix != null && !fallbackPrefix.isBlank() ? fallbackPrefix + "." : "Operation failed.", true);
        }
    }

    private void restoreLocalSelection(String preferredId) {
        LocalConfigProfile selected = null;
        if (preferredId != null && !preferredId.isBlank()) {
            for (LocalConfigProfile profile : this.localProfiles) {
                if (profile.id().equals(preferredId)) {
                    selected = profile;
                    break;
                }
            }
        }

        if (selected == null && !this.localProfiles.isEmpty()) {
            selected = this.localProfiles.getFirst();
        }

        this.selectedLocalId = selected == null ? "" : selected.id();
        if (selected != null) {
            this.profileNameInput = selected.name();
        } else {
            this.profileNameInput = "";
        }
    }

    private void onClientThread(Runnable runnable) {
        if (this.client != null) {
            this.client.execute(runnable);
        } else {
            runnable.run();
        }
    }

    private String resolveNameInput(String fallback) {
        String sanitized = sanitizeProfileName(this.profileNameInput);
        return sanitized.isBlank() ? sanitizeProfileName(fallback) : sanitized;
    }

    private static String sanitizeProfileName(String value) {
        String sanitized = value == null ? "" : value.replaceAll("\\s+", " ").trim();
        if (sanitized.length() > 48) {
            sanitized = sanitized.substring(0, 48);
        }

        return sanitized;
    }

    private static int clampScroll(int size, int visibleCount, int scroll) {
        int maxScroll = Math.max(0, size - Math.max(visibleCount, 1));
        return Math.max(0, Math.min(maxScroll, scroll));
    }

    private static <T> List<T> subList(List<T> items, int offset, int count) {
        if (items != null && !items.isEmpty() && count > 0) {
            int safeOffset = Math.max(0, Math.min(offset, items.size()));
            int end = Math.min(items.size(), safeOffset + count);
            return items.subList(safeOffset, end);
        } else {
            return List.of();
        }
    }

    private static Throwable unwrap(Throwable throwable) {
        Throwable current = throwable;

        while (current.getCause() != null && (current instanceof CompletionException || current instanceof ExecutionException)) {
            current = current.getCause();
        }

        return current;
    }
}
