package dev.darg.client.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import dev.darg.client.mixin.RenderLayerInvoker;
import java.util.Collection;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;

public final class SusChunkFinderRenderUtil {
    private static final Object LAYER_LOCK = new Object();
    private static volatile RenderLayer fillLayer;

    private SusChunkFinderRenderUtil() {
    }

    public static void render(
        WorldRenderContext context,
        MinecraftClient client,
        Collection<SusChunkFinderRenderUtil.ChunkSlab> slabs,
        Collection<SusChunkFinderRenderUtil.BlockHighlight> highlights
    ) {
        boolean hasSlabs = slabs != null && !slabs.isEmpty();
        boolean hasHighlights = highlights != null && !highlights.isEmpty();
        if (hasSlabs || hasHighlights) {
            MatrixStack matrices = context.matrices();
            if (matrices != null) {
                Camera camera = client.gameRenderer.getCamera();
                if (camera != null && camera.isReady()) {
                    Vec3d cameraPos = camera.getCameraPos();
                    double cameraX = cameraPos.x;
                    double cameraY = cameraPos.y;
                    double cameraZ = cameraPos.z;
                    context.commandQueue().submitCustom(matrices, getFillLayer(), (entry, consumer) -> {
                        if (hasSlabs) {
                            for (SusChunkFinderRenderUtil.ChunkSlab slab : slabs) {
                                float minX = (float)((double)slab.pos().getStartX() - cameraX);
                                float minY = slab.minY() - (float)cameraY;
                                float minZ = (float)((double)slab.pos().getStartZ() - cameraZ);
                                float maxX = (float)((double)(slab.pos().getEndX() + 1) - cameraX);
                                float maxY = slab.maxY() - (float)cameraY;
                                float maxZ = (float)((double)(slab.pos().getEndZ() + 1) - cameraZ);
                                emitFilledBox(consumer, entry, minX, minY, minZ, maxX, maxY, maxZ, slab.color());
                            }
                        }

                        if (hasHighlights) {
                            for (SusChunkFinderRenderUtil.BlockHighlight highlight : highlights) {
                                BlockPos pos = highlight.pos();
                                float minX = (float)((double)pos.getX() - cameraX);
                                float minY = (float)((double)pos.getY() - cameraY);
                                float minZ = (float)((double)pos.getZ() - cameraZ);
                                emitFilledBox(consumer, entry, minX, minY, minZ, minX + 1.0F, minY + 1.0F, minZ + 1.0F, highlight.color());
                            }
                        }
                    });
                }
            }
        }
    }

    private static void emitFilledBox(VertexConsumer consumer, Entry entry, float x1, float y1, float z1, float x2, float y2, float z2, int argb) {
        int red = WorldRenderUtil.red(argb);
        int green = WorldRenderUtil.green(argb);
        int blue = WorldRenderUtil.blue(argb);
        int alpha = WorldRenderUtil.alpha(argb);
        quad(consumer, entry, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2, red, green, blue, alpha);
        quad(consumer, entry, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1, red, green, blue, alpha);
        quad(consumer, entry, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1, red, green, blue, alpha);
        quad(consumer, entry, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2, red, green, blue, alpha);
        quad(consumer, entry, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1, red, green, blue, alpha);
        quad(consumer, entry, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2, red, green, blue, alpha);
    }

    private static void quad(
        VertexConsumer consumer,
        Entry entry,
        float x1,
        float y1,
        float z1,
        float x2,
        float y2,
        float z2,
        float x3,
        float y3,
        float z3,
        float x4,
        float y4,
        float z4,
        int red,
        int green,
        int blue,
        int alpha
    ) {
        consumer.vertex(entry, x1, y1, z1).color(red, green, blue, alpha);
        consumer.vertex(entry, x2, y2, z2).color(red, green, blue, alpha);
        consumer.vertex(entry, x3, y3, z3).color(red, green, blue, alpha);
        consumer.vertex(entry, x4, y4, z4).color(red, green, blue, alpha);
    }

    private static RenderLayer getFillLayer() {
        RenderLayer layer = fillLayer;
        if (layer != null) {
            return layer;
        } else {
            synchronized (LAYER_LOCK) {
                if (fillLayer == null) {
                    RenderPipeline pipeline = RenderPipelines.register(
                        RenderPipeline.builder(new Snippet[]{RenderPipelines.POSITION_COLOR_SNIPPET})
                            .withLocation("pipeline/dargsclient_sus_chunk_finder_fill_no_depth")
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build()
                    );
                    RenderSetup setup = RenderSetup.builder(pipeline).layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING).translucent().build();
                    fillLayer = RenderLayerInvoker.dargsclient$invokeOf("dargs_sus_chunk_finder_fill_no_depth", setup);
                }

                return fillLayer;
            }
        }
    }

    public static record BlockHighlight(BlockPos pos, int color) {
    }

    public static record ChunkSlab(ChunkPos pos, float minY, float maxY, int color) {
    }
}
