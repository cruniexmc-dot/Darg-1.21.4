package dev.darg.client.feature.combat;

import dev.darg.client.feature.Category;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

public final class AutoJumpResetFeature extends ConfigurableCombatFeature {
    private final ConfigurableCombatFeature.NumberSetting chance = this.intSetting("chance", "Chance", 100, 0, 100);

    public AutoJumpResetFeature() {
        super("AutoJumpReset", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (ThreadLocalRandom.current().nextInt(100) < this.chance.intValue()) {
            MinecraftClient client = MinecraftClient.getInstance();
            ClientPlayerEntity player = client.player;
            if (player != null && client.currentScreen == null && !player.isUsingItem()) {
                if (player.hurtTime != 0 && player.hurtTime != player.maxHurtTime && player.isOnGround()) {
                    if (player.hurtTime == 9 && ThreadLocalRandom.current().nextInt(100) < this.chance.intValue()) {
                        player.jump();
                    }
                }
            }
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("Jump chance: " + this.chance.intValue() + "%", "Triggers while hurt");
    }
}
