package dev.darg.client.feature.crystal;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.clickgui.InlineControlRenderer;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import dev.darg.client.ui.theme.ClientTheme;
import dev.darg.client.ui.theme.ThemeManager;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public final class AutoXPFeature extends Feature {
    private static final float INLINE_HEIGHT = 32.0F;
    private static final int DELAY = 1;
    private int clock = 0;

    public AutoXPFeature() {
        super("AutoXP", Category.CRYSTAL);
    }

    @Override
    protected void onEnable() {
        this.clock = 0;
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player != null && mc.interactionManager != null && mc.currentScreen == null) {
            if (player.getMainHandStack().isOf(Items.EXPERIENCE_BOTTLE)) {
                if (GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), 1) == 1) {
                    mc.options.useKey.setPressed(false);
                    if (this.clock > 0) {
                        this.clock--;
                    } else {
                        mc.interactionManager.interactItem(player, Hand.MAIN_HAND);
                        player.swingHand(Hand.MAIN_HAND);
                        this.clock = 1 + (int)(Math.random() * 2.0);
                    }
                }
            }
        }
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 32.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        ClientTheme theme = ThemeManager.getInstance().getCurrentTheme();
        float cx = x + 10.0F;
        float keybindY = y + 8.0F;
        float bindW = 70.0F;
        float bindX = x + width - bindW - 10.0F;
        boolean capturing = DargsClient.getInstance().getKeybindManager().isCapturing(this);
        boolean hoverBind = InlineControlRenderer.containsButton((double)mouseX, (double)mouseY, bindX, keybindY, bindW);
        String bindLabel = InlineControlRenderer.fitText(
            textRenderer, DargsClient.getInstance().getKeybindManager().getBindLabel(this).toUpperCase(Locale.ROOT), 58
        );
        RenderUtil.drawText(context, textRenderer, "KEYBIND", cx, keybindY + 2.0F, theme.white());
        InlineControlRenderer.drawButton(context, textRenderer, theme, bindLabel, capturing, hoverBind, bindX, keybindY, bindW);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (!this.containsInline(mouseX, mouseY, x, y, width)) {
            return false;
        } else {
            float keybindY = y + 8.0F;
            float bindX = x + width - 80.0F;
            if (button == 0 && InlineControlRenderer.containsButton(mouseX, mouseY, bindX, keybindY, 70.0F)) {
                DargsClient.getInstance().getKeybindManager().beginCapture(this, notificationManager);
                return true;
            } else if (button == 1 && InlineControlRenderer.containsButton(mouseX, mouseY, bindX, keybindY, 70.0F)) {
                DargsClient.getInstance().getKeybindManager().clearBind(this, notificationManager);
                return true;
            } else {
                return false;
            }
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("Hold right-click with XP bottles");
    }

    private boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + 32.0F);
    }
}
