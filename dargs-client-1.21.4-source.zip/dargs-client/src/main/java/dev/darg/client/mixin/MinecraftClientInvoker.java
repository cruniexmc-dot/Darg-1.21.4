package dev.darg.client.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({MinecraftClient.class})
public interface MinecraftClientInvoker {
    @Invoker("doAttack")
    boolean dargsclient$invokeDoAttack();

    @Invoker("doItemUse")
    void dargsclient$invokeDoItemUse();
}
