package dev.darg.client.ui.clickgui;

import dev.darg.client.DargsClient;
import dev.darg.client.feature.Feature;
import dev.darg.client.ui.theme.ClientTheme;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class ClickGuiSearchBar {
    private static final float BAR_TOP = 18.0F;
    private static final float BAR_MAX_W = 236.0F;
    private static final float H_PAD = 12.0F;
    private static final float INPUT_PAD_V = 8.0F;
    private static final float ROW_H = 20.0F;
    private static final float RESULTS_MAX_H = 124.0F;
    private static final float RADIUS = 12.0F;
    private final StringBuilder query = new StringBuilder();
    private boolean focused;
    private final List<Feature> filtered = new ArrayList<>();
    private int selectedIndex;
    private float resultsScroll;

    public boolean isFocused() {
        return this.focused;
    }

    public boolean hasQuery() {
        return !this.query.isEmpty();
    }

    public void clear() {
        this.query.setLength(0);
        this.filtered.clear();
        this.selectedIndex = 0;
        this.focused = false;
        this.resultsScroll = 0.0F;
    }

    private void refilter() {
        this.filtered.clear();
        this.selectedIndex = 0;
        this.resultsScroll = 0.0F;
        if (!this.query.isEmpty()) {
            String normalized = normalizeQuery(this.query.toString());
            if (!normalized.isEmpty()) {
                for (Feature feature : DargsClient.getInstance().getFeatureManager().getFeatures()) {
                    if (feature.isVisibleInClickGui() && matches(feature, normalized)) {
                        this.filtered.add(feature);
                    }
                }
            }
        }
    }

    private static String normalizeQuery(String raw) {
        return raw.toLowerCase(Locale.ROOT).replace(" ", "");
    }

    private static boolean matches(Feature feature, String query) {
        String name = feature.getName().toLowerCase(Locale.ROOT);
        if (!name.contains(query) && !name.replace(" ", "").contains(query)) {
            String key = feature.getConfigKey().toLowerCase(Locale.ROOT);
            return key.contains(query) || key.replace("_", "").contains(query);
        } else {
            return true;
        }
    }

    public boolean containsPoint(double mouseX, double mouseY, int screenWidth) {
        float barW = this.barWidth(screenWidth);
        float barX = this.barX(screenWidth, barW);
        float totalH = this.totalHeight();
        return mouseX >= (double)barX && mouseX <= (double)(barX + barW) && mouseY >= 18.0 && mouseY <= (double)(18.0F + totalH);
    }

    private float barWidth(int screenWidth) {
        return Math.min(236.0F, Math.max(140.0F, (float)screenWidth - 48.0F));
    }

    private float barX(int screenWidth, float barWidth) {
        return (float)screenWidth - barWidth - 18.0F;
    }

    private float inputHeight() {
        return 24.0F;
    }

    private float totalHeight() {
        float total = this.inputHeight();
        if (!this.query.isEmpty()) {
            total += 4.0F + Math.min(this.visibleResultsHeight(), this.contentResultsHeight());
        }

        return total;
    }

    private float contentResultsHeight() {
        return this.filtered.isEmpty() ? 28.0F : (float)this.filtered.size() * 20.0F + 8.0F;
    }

    private float visibleResultsHeight() {
        return Math.min(124.0F, this.contentResultsHeight());
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button, int screenWidth, Consumer<Feature> onToggle, Consumer<Feature> onLocate) {
        float barW = this.barWidth(screenWidth);
        float barX = this.barX(screenWidth, barW);
        float inputH = this.inputHeight();
        boolean insideBar = mouseX >= (double)barX && mouseX <= (double)(barX + barW) && mouseY >= 18.0;
        if (!insideBar) {
            return false;
        } else {
            this.focused = true;
            if (!(mouseY <= (double)(18.0F + inputH)) && !this.query.isEmpty()) {
                float resultsTop = 18.0F + inputH + 4.0F;
                float visH = this.visibleResultsHeight();
                if (!(mouseY < (double)resultsTop) && !(mouseY > (double)(resultsTop + visH)) && !this.filtered.isEmpty()) {
                    float relY = (float)mouseY - resultsTop + this.resultsScroll;
                    int index = (int)(relY / 20.0F);
                    if (index >= 0 && index < this.filtered.size()) {
                        Feature feature = this.filtered.get(index);
                        if (button == 0) {
                            onToggle.accept(feature);
                        } else if (button == 1) {
                            onLocate.accept(feature);
                        }

                        return true;
                    } else {
                        return true;
                    }
                } else {
                    return true;
                }
            } else {
                return true;
            }
        }
    }

    public void onClickOutside() {
        this.clear();
    }

    public boolean keyPressed(int key, int screenWidth, Consumer<Feature> onToggle, Consumer<Feature> onLocate) {
        if (!this.focused) {
            return false;
        } else if (key == 259) {
            if (!this.query.isEmpty()) {
                this.query.deleteCharAt(this.query.length() - 1);
                this.refilter();
            }

            return true;
        } else if (!this.filtered.isEmpty() && !this.query.isEmpty()) {
            return switch (key) {
                case 257 -> {
                    onToggle.accept(this.filtered.get(this.selectedIndex));
                    yield true;
                }
                case 258 -> {
                    onLocate.accept(this.filtered.get(this.selectedIndex));
                    yield true;
                }
                default -> false;
                case 264 -> {
                    this.selectedIndex = (this.selectedIndex + 1) % this.filtered.size();
                    this.scrollSelectionIntoView();
                    yield true;
                }
                case 265 -> {
                    this.selectedIndex = (this.selectedIndex - 1 + this.filtered.size()) % this.filtered.size();
                    this.scrollSelectionIntoView();
                    yield true;
                }
            };
        } else {
            return false;
        }
    }

    public boolean charTyped(char chr) {
        if (!this.focused) {
            return false;
        } else if (chr >= ' ' && chr != 127) {
            this.query.append(chr);
            this.refilter();
            return true;
        } else {
            return false;
        }
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount, int screenWidth) {
        if (this.hasQuery() && !this.filtered.isEmpty() && this.containsPoint(mouseX, mouseY, screenWidth)) {
            float maxScroll = Math.max(0.0F, this.contentResultsHeight() - this.visibleResultsHeight());
            this.resultsScroll = Math.max(0.0F, Math.min(maxScroll, this.resultsScroll - (float)amount * 20.0F));
            return true;
        } else {
            return false;
        }
    }

    private void scrollSelectionIntoView() {
        float selectedTop = (float)this.selectedIndex * 20.0F;
        float selectedBottom = selectedTop + 20.0F;
        float visibleHeight = this.visibleResultsHeight();
        if (selectedTop < this.resultsScroll) {
            this.resultsScroll = selectedTop;
        } else if (selectedBottom > this.resultsScroll + visibleHeight) {
            this.resultsScroll = selectedBottom - visibleHeight;
        }

        float maxScroll = Math.max(0.0F, this.contentResultsHeight() - visibleHeight);
        this.resultsScroll = Math.max(0.0F, Math.min(maxScroll, this.resultsScroll));
    }

    public void render(DrawContext context, TextRenderer textRenderer, ClientTheme theme, int screenWidth, int mouseX, int mouseY) {
        float barW = this.barWidth(screenWidth);
        float barX = this.barX(screenWidth, barW);
        float inputH = this.inputHeight();
        float totalH = this.totalHeight();
        RenderUtil.drawRoundedRect(context, barX + 2.0F, 21.0F, barW, totalH, 12.0F, theme.clickGuiHudShadow());
        RenderUtil.drawRoundedRect(context, barX - 1.0F, 17.0F, barW + 2.0F, totalH + 2.0F, 13.0F, RenderUtil.withAlpha(theme.white(), 12));
        RenderUtil.drawRoundedRect(context, barX, 18.0F, barW, totalH, 12.0F, theme.clickGuiPanelHeader());
        String display = this.query.isEmpty() ? "Search modules" : this.query.toString();
        int textColor = this.query.isEmpty() ? theme.softGray() : theme.white();
        String hint = this.query.isEmpty() ? "Ctrl+F" : this.filtered.size() + " results";
        RenderUtil.drawText(context, textRenderer, display, barX + 12.0F, 26.0F, textColor);
        RenderUtil.drawText(context, textRenderer, hint, barX + barW - 12.0F - (float)RenderUtil.getTextWidth(textRenderer, hint), 26.0F, theme.softGray());
        if (this.hasQuery()) {
            float resultsTop = 18.0F + inputH + 4.0F;
            float visH = this.visibleResultsHeight();
            if (this.filtered.isEmpty()) {
                RenderUtil.drawText(context, textRenderer, "No matching modules", barX + 12.0F, resultsTop + 4.0F, theme.softGray());
            } else {
                int clipL = Math.round(barX + 8.0F);
                int clipT = Math.round(resultsTop);
                int clipR = Math.round(barX + barW - 8.0F);
                int clipB = Math.round(resultsTop + visH);
                context.enableScissor(clipL, clipT, clipR, clipB);

                try {
                    for (int i = 0; i < this.filtered.size(); i++) {
                        Feature feature = this.filtered.get(i);
                        float rowY = resultsTop + (float)i * 20.0F - this.resultsScroll;
                        if (!(rowY + 20.0F < resultsTop) && !(rowY > resultsTop + visH)) {
                            boolean selected = i == this.selectedIndex;
                            boolean hovered = (float)mouseX >= barX + 8.0F
                                && (float)mouseX <= barX + barW - 8.0F
                                && (float)mouseY >= rowY
                                && (float)mouseY <= rowY + 20.0F;
                            if (selected || hovered) {
                                RenderUtil.drawRoundedRect(context, barX + 8.0F, rowY, barW - 16.0F, 18.0F, 8.0F, theme.moduleButtonFillHover());
                                context.fill(
                                    Math.round(barX + 10.0F),
                                    Math.round(rowY + 4.0F),
                                    Math.round(barX + 12.0F),
                                    Math.round(rowY + 20.0F - 6.0F),
                                    theme.accent()
                                );
                            }

                            String category = feature.getCategory().displayName();
                            float categoryX = barX + barW - 12.0F - (float)RenderUtil.getTextWidth(textRenderer, category);
                            String name = InlineControlRenderer.fitText(
                                textRenderer, feature.getName(), Math.round(Math.max(34.0F, categoryX - (barX + 22.0F)))
                            );
                            int labelColor = feature.isEnabled() ? theme.white() : theme.softGray();
                            if (feature.isEnabled()) {
                                RenderUtil.drawRoundedRect(context, barX + 12.0F, rowY + 7.0F, 5.0F, 5.0F, 2.5F, theme.accent());
                            }

                            RenderUtil.drawText(context, textRenderer, name, barX + 20.0F, rowY + 6.0F, labelColor);
                            RenderUtil.drawText(
                                context, textRenderer, category, categoryX, rowY + 6.0F, !selected && !hovered ? theme.mutedGray() : theme.softGray()
                            );
                        }
                    }
                } finally {
                    context.disableScissor();
                }
            }
        }
    }
}
