package dev.darg.client.feature.combat;

import dev.darg.client.feature.Category;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

public final class AutoInventoryTotemFeature extends ConfigurableCombatFeature {
    private final ConfigurableCombatFeature.EnumSetting<AutoInventoryTotemFeature.Mode> mode = this.enumSetting(
        "mode", "Mode", AutoInventoryTotemFeature.Mode.Blatant, AutoInventoryTotemFeature.Mode.class
    );
    private final ConfigurableCombatFeature.NumberSetting delay = this.intSetting("delay", "Delay", 0, 0, 20);
    private final ConfigurableCombatFeature.BooleanSetting hotbar = this.booleanSetting("hotbar", "Hotbar", true);
    private final ConfigurableCombatFeature.NumberSetting totemSlot = this.intSetting("totem_slot", "Totem Slot", 1, 1, 9);
    private final ConfigurableCombatFeature.BooleanSetting autoSwitch = this.booleanSetting("auto_switch", "Auto Switch", false);
    private final ConfigurableCombatFeature.BooleanSetting forceTotem = this.booleanSetting("force_totem", "Force Totem", false);
    private final ConfigurableCombatFeature.BooleanSetting autoOpen = this.booleanSetting("auto_open", "Auto Open", false);
    private final ConfigurableCombatFeature.NumberSetting stayOpenFor = this.intSetting("stay_open_for", "Stay Open For", 0, 0, 20);
    private int clock = -1;
    private int closeClock = -1;

    public AutoInventoryTotemFeature() {
        super("AutoInventoryTotem", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        this.clock = -1;
        this.closeClock = -1;
    }

    @Override
    protected void onDisable() {
        this.clock = -1;
        this.closeClock = -1;
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player != null && client.world != null && client.interactionManager != null) {
            if (this.autoOpen.get() && this.shouldOpenScreen(player) && !(client.currentScreen instanceof InventoryScreen)) {
                client.setScreen(new InventoryScreen(player));
            }

            if (client.currentScreen instanceof InventoryScreen inventoryScreen) {
                if (this.clock == -1) {
                    this.clock = this.delay.intValue();
                }

                if (this.closeClock == -1) {
                    this.closeClock = this.stayOpenFor.intValue();
                }

                if (this.clock > 0) {
                    this.clock--;
                } else {
                    if (this.autoSwitch.get()) {
                        int slot = Math.max(0, Math.min(8, this.totemSlot.intValue() - 1));
                        CombatSupport.selectHotbarSlot(player, slot);
                    }

                    if (player.getOffHandStack().getItem() != Items.TOTEM_OF_UNDYING) {
                        int slot = this.resolveTotemSlot(player);
                        if (slot >= 0) {
                            this.swapToOffhand(client, inventoryScreen, player, slot);
                            return;
                        }
                    }

                    if (this.hotbar.get()) {
                        int hotbarSlot = Math.max(0, Math.min(8, this.totemSlot.intValue() - 1));
                        if (player.getMainHandStack().getItem() != Items.TOTEM_OF_UNDYING || this.forceTotem.get()) {
                            int slot = this.resolveTotemSlot(player);
                            if (slot >= 0) {
                                this.swapToHotbar(client, inventoryScreen, player, slot, hotbarSlot);
                                return;
                            }
                        }
                    }

                    if (this.autoOpen.get() && this.shouldCloseScreen(player) && this.closeClock <= 0) {
                        client.currentScreen.close();
                    } else if (this.autoOpen.get()) {
                        this.closeClock--;
                    }
                }
            } else {
                this.clock = -1;
                this.closeClock = -1;
            }
        }
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of("Mode: " + this.mode.displayValue(), "Totem slot: " + this.totemSlot.intValue(), "Auto open: " + this.autoOpen.get());
    }

    private void swapToOffhand(MinecraftClient client, InventoryScreen screen, ClientPlayerEntity player, int inventorySlot) {
        client.interactionManager
            .clickSlot(
                ((PlayerScreenHandler)screen.getScreenHandler()).syncId,
                CombatSupport.screenSlotFromInventory(inventorySlot),
                40,
                SlotActionType.SWAP,
                player
            );
        this.clock = 0;
        this.closeClock = this.stayOpenFor.intValue();
    }

    private void swapToHotbar(MinecraftClient client, InventoryScreen screen, ClientPlayerEntity player, int inventorySlot, int hotbarSlot) {
        client.interactionManager
            .clickSlot(
                ((PlayerScreenHandler)screen.getScreenHandler()).syncId,
                CombatSupport.screenSlotFromInventory(inventorySlot),
                hotbarSlot,
                SlotActionType.SWAP,
                player
            );
        this.clock = 0;
        this.closeClock = this.stayOpenFor.intValue();
    }

    private int resolveTotemSlot(ClientPlayerEntity player) {
        List<Integer> candidates = new ArrayList<>();

        for (int slot = 0; slot < 36; slot++) {
            if (player.getInventory().getStack(slot).isOf(Items.TOTEM_OF_UNDYING)) {
                candidates.add(slot);
            }
        }

        if (candidates.isEmpty()) {
            return -1;
        } else {
            return this.mode.get() == AutoInventoryTotemFeature.Mode.Random
                ? candidates.get(ThreadLocalRandom.current().nextInt(candidates.size()))
                : candidates.get(0);
        }
    }

    private boolean shouldOpenScreen(ClientPlayerEntity player) {
        boolean hasTotem = this.resolveTotemSlot(player) >= 0;
        if (!hasTotem) {
            return false;
        } else {
            return !this.hotbar.get()
                ? player.getOffHandStack().getItem() != Items.TOTEM_OF_UNDYING
                : player.getOffHandStack().getItem() != Items.TOTEM_OF_UNDYING
                    || player.getInventory().getStack(Math.max(0, Math.min(8, this.totemSlot.intValue() - 1))).getItem() != Items.TOTEM_OF_UNDYING;
        }
    }

    private boolean shouldCloseScreen(ClientPlayerEntity player) {
        return !this.hotbar.get()
            ? player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING
            : player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING
                && player.getInventory().getStack(Math.max(0, Math.min(8, this.totemSlot.intValue() - 1))).getItem() == Items.TOTEM_OF_UNDYING;
    }

    public static enum Mode {
        Blatant,
        Random;
    }
}
