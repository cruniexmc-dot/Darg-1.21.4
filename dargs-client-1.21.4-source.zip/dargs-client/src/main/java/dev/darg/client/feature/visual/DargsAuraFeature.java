package dev.darg.client.feature.visual;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import dev.darg.client.config.ClientConfig;
import dev.darg.client.feature.Category;
import dev.darg.client.feature.Feature;
import dev.darg.client.mixin.RenderLayerInvoker;
import dev.darg.client.ui.clickgui.NotificationManager;
import dev.darg.client.ui.clickgui.RenderUtil;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.RenderSetup.Builder;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3fc;

public final class DargsAuraFeature extends Feature {
    private static final float MIN_BLOCK_SPEED = 0.35F;
    private static final float MAX_BLOCK_SPEED = 2.5F;
    private static final int WHITE = -1;
    private static final int SOFT_GRAY = -4671304;
    private static final int MUTED_GRAY = -8750470;
    private static final int PANEL_LIGHT = -14013903;
    private static final int PANEL_HOVER = -13553352;
    private static final int ACCENT = -3365;
    private static final float INLINE_HEIGHT = 62.0F;
    private static final float BUTTON_HEIGHT = 16.0F;
    private static final int MAIN_ORB_COUNT = 10;
    private static final int ACCENT_ORB_COUNT = 4;
    private static final int WISP_COUNT = 5;
    private static final BlockState[] BENDING_BLOCK_STATES = new BlockState[]{
        Blocks.GRASS_BLOCK.getDefaultState(),
        Blocks.DIRT.getDefaultState(),
        Blocks.COARSE_DIRT.getDefaultState(),
        Blocks.ROOTED_DIRT.getDefaultState(),
        Blocks.GRASS_BLOCK.getDefaultState(),
        Blocks.DIRT.getDefaultState()
    };
    private static final double BASE_RADIUS = 0.52;
    private static final double BREATH_RADIUS = 0.12;
    private static final double HALO_WIDTH = 0.98;
    private static final double HALO_HEIGHT = 1.88;
    private static final int HALO_OUTER_RGB = 14735103;
    private static final int HALO_MID_RGB = 15920383;
    private static final int HALO_CORE_RGB = 16777215;
    private static final int ORB_GLOW_RGB = 14141951;
    private static final int ORB_ACCENT_RGB = 12164607;
    private static final int ORB_CORE_RGB = 16777215;
    private static final Object RENDER_LAYER_LOCK = new Object();
    private static RenderLayer noDepthFillLayer;
    private final ClientConfig config = ClientConfig.getInstance();
    private int lastParticleCount;
    private String lastAuraMode = "Celestial halo";
    private boolean dirtBendingEnabled = this.config.isDargsAuraDirtBendingEnabled();
    private float dirtBendingSpeed = this.config.getDargsAuraBlockSpeed();
    private boolean draggingSpeedSlider;

    public DargsAuraFeature() {
        super("DargsAura", Category.RENDER);
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity player = client.player;
        if (client.world != null && player != null) {
            MatrixStack matrices = context.matrices();
            if (matrices == null) {
                this.lastParticleCount = 0;
            } else {
                this.dirtBendingEnabled = this.config.isDargsAuraDirtBendingEnabled();
                this.dirtBendingSpeed = this.config.getDargsAuraBlockSpeed();
                float tickProgress = client.getRenderTickCounter().getTickProgress(false);
                double time = (double)((float)client.world.getTime() + tickProgress);
                float breath = 0.5F + 0.5F * (float)Math.sin(time * 0.14);
                double radius = 0.52 + 0.12 * (double)breath;
                Camera camera = client.gameRenderer.getCamera();
                Vec3d cameraPos = camera.getCameraPos();
                Vec3d playerPos = player.getLerpedPos(tickProgress);
                Vec3d auraBase = playerPos.add(0.0, 0.08 + 0.08 * (double)breath, 0.0);
                boolean closeCameraLite = cameraPos.squaredDistanceTo(playerPos.add(0.0, (double)player.getHeight() * 0.54, 0.0)) < 6.25;
                boolean multiplayerLite = !client.isInSingleplayer();
                boolean fpsLite = client.getCurrentFps() > 0 && client.getCurrentFps() < 95;
                boolean ultraLiteMode = multiplayerLite || fpsLite;
                boolean lightweightMode = closeCameraLite || ultraLiteMode;
                int mainOrbCount = ultraLiteMode ? 3 : (lightweightMode ? 5 : 10);
                int accentOrbCount = ultraLiteMode ? 1 : (lightweightMode ? 2 : 4);
                int wispCount = ultraLiteMode ? 1 : (lightweightMode ? 2 : 5);
                int bendingBlockCount = this.dirtBendingEnabled ? (ultraLiteMode ? 2 : (lightweightMode ? 3 : BENDING_BLOCK_STATES.length)) : 0;
                OrderedRenderCommandQueue commandQueue = context.commandQueue();
                this.lastParticleCount = mainOrbCount + accentOrbCount + wispCount + bendingBlockCount;

                this.lastAuraMode = switch (this.dirtBendingEnabled ? 1 : 0) {
                    case 1 -> ultraLiteMode ? "Earthbend adaptive" : (lightweightMode ? "Earthbend lite" : "Celestial earthbend");
                    default -> ultraLiteMode ? "Aura adaptive" : (lightweightMode ? "Celestial lite" : "Celestial halo");
                };
                this.renderBodyHalo(commandQueue, matrices, camera, cameraPos, playerPos, player.getHeight(), breath, time, lightweightMode);
                this.renderEnergyWisps(commandQueue, matrices, camera, cameraPos, playerPos, player.getHeight(), breath, time, wispCount, lightweightMode);
                this.renderOrbRing(commandQueue, matrices, camera, cameraPos, auraBase, radius, breath, time, mainOrbCount, accentOrbCount, lightweightMode);
                if (!lightweightMode) {
                    this.renderHeadCrown(commandQueue, matrices, camera, cameraPos, playerPos, player.getHeight(), breath, time);
                }

                if (this.dirtBendingEnabled && bendingBlockCount > 0) {
                    this.renderDirtBending(context, matrices, playerPos, breath, time, bendingBlockCount, lightweightMode, ultraLiteMode);
                }
            }
        } else {
            this.lastParticleCount = 0;
        }
    }

    @Override
    public boolean hasCustomClickGuiContent() {
        return true;
    }

    @Override
    public float getCustomClickGuiHeight(float width) {
        return 62.0F;
    }

    @Override
    public void renderCustomClickGuiContent(DrawContext context, TextRenderer textRenderer, float x, float y, float width, int mouseX, int mouseY) {
        if (this.draggingSpeedSlider) {
            this.setBlockSpeedFromMouse((double)mouseX, x, width);
        }

        float contentX = x + 10.0F;
        float contentWidth = width - 20.0F;
        float sliderY = y + 10.0F;
        float trackY = sliderY + 14.0F;
        float ratio = (this.dirtBendingSpeed - 0.35F) / 2.15F;
        float fillWidth = contentWidth * ratio;
        float knobX = contentX + fillWidth - 3.0F;
        float buttonY = y + 40.0F;
        boolean hoverButton = this.containsToggleButton((double)mouseX, (double)mouseY, x, y, width);
        String speedLabel = String.format("%.2fx", this.dirtBendingSpeed);
        RenderUtil.drawText(context, textRenderer, "BLOCK ORBIT SPEED", contentX, sliderY, -1);
        RenderUtil.drawText(context, textRenderer, speedLabel, x + width - 10.0F - (float)textRenderer.getWidth(speedLabel), sliderY, -4671304);
        RenderUtil.drawRoundedRect(context, contentX, trackY, contentWidth, 4.0F, 2.0F, -14013903);
        RenderUtil.drawRoundedRect(context, contentX, trackY, Math.max(4.0F, fillWidth), 4.0F, 2.0F, -3365);
        RenderUtil.drawRoundedRect(context, knobX, trackY - 3.0F, 8.0F, 10.0F, 4.0F, -3365);
        RenderUtil.drawText(context, textRenderer, "Multiplayer auto-lite stays on", contentX, y + 24.0F, -8750470);
        RenderUtil.drawRoundedRect(context, contentX, buttonY, contentWidth, 16.0F, 5.0F, hoverButton ? -13553352 : -14013903);
        RenderUtil.drawText(context, textRenderer, this.dirtBendingEnabled ? "DIRT BENDING: ON" : "DIRT BENDING: OFF", contentX + 8.0F, buttonY + 5.0F, -1);
    }

    @Override
    public boolean onCustomClickGuiMouseClicked(
        double mouseX, double mouseY, int button, float x, float y, float width, NotificationManager notificationManager
    ) {
        if (button != 0) {
            return this.containsInline(mouseX, mouseY, x, y, width);
        } else if (this.containsSpeedSlider(mouseX, mouseY, x, y, width)) {
            this.draggingSpeedSlider = true;
            this.setBlockSpeedFromMouse(mouseX, x, width);
            return true;
        } else if (this.containsToggleButton(mouseX, mouseY, x, y, width)) {
            this.dirtBendingEnabled = !this.dirtBendingEnabled;
            this.config.setDargsAuraDirtBendingEnabled(this.dirtBendingEnabled);
            this.config.save();
            notificationManager.push(
                "Dirt bending " + (this.dirtBendingEnabled ? "enabled" : "disabled"),
                this.dirtBendingEnabled ? NotificationManager.Type.SUCCESS : NotificationManager.Type.INFO
            );
            return true;
        } else {
            return this.containsInline(mouseX, mouseY, x, y, width);
        }
    }

    @Override
    public boolean onCustomClickGuiMouseReleased(double mouseX, double mouseY, int button, float x, float y, float width) {
        if (button == 0 && this.draggingSpeedSlider) {
            this.draggingSpeedSlider = false;
            this.config.save();
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isClickGuiInteractionActive() {
        return this.draggingSpeedSlider;
    }

    @Override
    public List<String> getClickGuiDetails() {
        return List.of(
            "State: " + (this.isEnabled() ? "Enabled" : "Disabled"),
            "Particles: " + this.lastParticleCount,
            "Style: " + this.lastAuraMode,
            "Motion: Breathing halo + orbit + wisps",
            "Earthbend: " + (this.dirtBendingEnabled ? "On" : "Off"),
            "Block speed: " + String.format("%.2fx", this.dirtBendingSpeed),
            "Performance: Adaptive multiplayer lite"
        );
    }

    @Override
    public String getHudSuffix() {
        return this.dirtBendingEnabled ? "EARTH" : (this.lastParticleCount > 0 ? Integer.toString(this.lastParticleCount) : "AURA");
    }

    private void renderBodyHalo(
        OrderedRenderCommandQueue commandQueue,
        MatrixStack matrices,
        Camera camera,
        Vec3d cameraPos,
        Vec3d playerPos,
        float playerHeight,
        float breath,
        double time,
        boolean closeCameraLite
    ) {
        Vec3d center = playerPos.add(0.0, (double)playerHeight * 0.54, 0.0).subtract(cameraPos);
        Vec3d right = toVec(camera.getHorizontalPlane());
        Vec3d up = toVec(camera.getVerticalPlane());
        double outerWidth = 0.98 + 0.22 * (double)breath;
        double outerHeight = 1.88 + 0.18 * (double)breath;
        double middleWidth = outerWidth * 0.81;
        double middleHeight = outerHeight * 0.88;
        double coreWidth = outerWidth * 0.6;
        double coreHeight = outerHeight * 0.72;
        double shimmer = 0.028 * Math.sin(time * 0.21);
        commandQueue.submitCustom(
            matrices,
            getNoDepthFillLayer(),
            (entry, consumer) -> {
                this.drawBillboardQuad(
                    entry,
                    consumer,
                    center,
                    right,
                    up,
                    outerWidth + shimmer,
                    outerHeight,
                    withAlpha(14735103, closeCameraLite ? 16 + (int)(10.0F * breath) : 22 + (int)(14.0F * breath)),
                    0.0
                );
                this.drawBillboardQuad(
                    entry,
                    consumer,
                    center,
                    right,
                    up,
                    middleWidth,
                    middleHeight,
                    withAlpha(15920383, closeCameraLite ? 28 + (int)(12.0F * breath) : 42 + (int)(18.0F * breath)),
                    Math.PI / 8
                );
                if (!closeCameraLite) {
                    this.drawBillboardQuad(
                        entry, consumer, center, right, up, coreWidth, coreHeight, withAlpha(16777215, 54 + (int)(14.0F * breath)), Math.PI / 4
                    );
                    this.drawBillboardQuad(
                        entry,
                        consumer,
                        playerPos.add(0.0, (double)playerHeight * 0.72, 0.0).subtract(cameraPos),
                        right,
                        up,
                        outerWidth * 0.62,
                        0.28 + 0.05 * (double)breath,
                        withAlpha(15920383, 24 + (int)(10.0F * breath)),
                        Math.PI / 5
                    );
                }
            }
        );
    }

    private void renderEnergyWisps(
        OrderedRenderCommandQueue commandQueue,
        MatrixStack matrices,
        Camera camera,
        Vec3d cameraPos,
        Vec3d playerPos,
        float playerHeight,
        float breath,
        double time,
        int wispCount,
        boolean closeCameraLite
    ) {
        Vec3d right = toVec(camera.getHorizontalPlane());
        Vec3d up = toVec(camera.getVerticalPlane());
        double bodyRadius = 0.34 + 0.05 * (double)breath;
        double baseHeight = (double)playerHeight * 0.24;
        double heightSpan = (double)playerHeight * 0.74;
        commandQueue.submitCustom(
            matrices,
            getNoDepthFillLayer(),
            (entry, consumer) -> {
                for (int index = 0; index < wispCount; index++) {
                    double progress = (double)index / (double)wispCount;
                    double angle = time * 0.06 + (Math.PI * 2) * progress;
                    double verticalPhase = time * 0.1 + progress * 9.0;
                    double swirlRadius = bodyRadius + 0.04 * Math.sin(verticalPhase);
                    Vec3d center = new Vec3d(
                        playerPos.x + Math.cos(angle) * swirlRadius - cameraPos.x,
                        playerPos.y + baseHeight + heightSpan * progress + 0.08 * Math.sin(verticalPhase) - cameraPos.y,
                        playerPos.z + Math.sin(angle) * swirlRadius - cameraPos.z
                    );
                    double width = 0.13 + 0.02 * (double)breath;
                    double height = 0.42 + 0.08 * Math.sin(verticalPhase + 1.2);
                    int glowColor = withAlpha(14735103, closeCameraLite ? 8 + (int)(6.0F * breath) : 12 + (int)(10.0F * breath));
                    int coreColor = withAlpha(15920383, closeCameraLite ? 16 + (int)(8.0F * breath) : 22 + (int)(12.0F * breath));
                    if (!closeCameraLite) {
                        this.drawBillboardQuad(entry, consumer, center, right, up, width * 1.5, height * 1.05, glowColor, angle * 0.3);
                    }

                    this.drawBillboardQuad(entry, consumer, center, right, up, width, height, coreColor, angle * 0.3);
                }
            }
        );
    }

    private void renderOrbRing(
        OrderedRenderCommandQueue commandQueue,
        MatrixStack matrices,
        Camera camera,
        Vec3d cameraPos,
        Vec3d auraBase,
        double radius,
        float breath,
        double time,
        int mainOrbCount,
        int accentOrbCount,
        boolean closeCameraLite
    ) {
        Vec3d right = toVec(camera.getHorizontalPlane());
        Vec3d up = toVec(camera.getVerticalPlane());
        double lowerBand = 0.46 + 0.04 * (double)breath;
        double upperBand = 1.02 + 0.06 * (double)breath;
        double orbitRadius = radius + 0.05 * (double)breath;
        commandQueue.submitCustom(
            matrices,
            getNoDepthFillLayer(),
            (entry, consumer) -> {
                for (int index = 0; index < mainOrbCount; index++) {
                    double progress = (double)index / (double)mainOrbCount;
                    double angle = time * 0.08 + (Math.PI * 2) * progress;
                    double bandOffset = (index & 1) == 0 ? lowerBand : upperBand;
                    double verticalWave = 0.06 * Math.sin(time * 0.15 + progress * 11.0);
                    Vec3d center = new Vec3d(
                        auraBase.x + Math.cos(angle) * orbitRadius - cameraPos.x,
                        auraBase.y + bandOffset + verticalWave - cameraPos.y,
                        auraBase.z + Math.sin(angle) * orbitRadius - cameraPos.z
                    );
                    double orbSize = 0.042 + 0.006 * Math.sin(time * 0.2 + progress * 9.0) + 0.008 * (double)breath;
                    double glowSize = orbSize * (closeCameraLite ? 1.9 : 2.25 + 0.14 * (double)breath);
                    double coreSize = orbSize * (1.12 + 0.05 * (double)breath);
                    this.drawSoftOrbLayer(
                        entry,
                        consumer,
                        center,
                        right,
                        up,
                        glowSize,
                        withAlpha(14141951, closeCameraLite ? 18 + (int)(10.0F * breath) : 24 + (int)(12.0F * breath)),
                        closeCameraLite
                    );
                    this.drawSoftOrbLayer(entry, consumer, center, right, up, coreSize, withAlpha(16777215, 112 + (int)(18.0F * breath)), true);
                    if (!closeCameraLite) {
                        this.drawSoftOrbLayer(entry, consumer, center, right, up, orbSize * 0.52, withAlpha(16777215, 208), true);
                    }
                }

                for (int indexx = 0; indexx < accentOrbCount; indexx++) {
                    double progress = (double)indexx / (double)accentOrbCount;
                    double angle = -(time * 0.11) + (Math.PI * 2) * progress;
                    double localRadius = orbitRadius * 0.66;
                    double bandOffset = 1.42 + 0.12 * Math.sin(time * 0.12 + progress * 6.0);
                    Vec3d center = new Vec3d(
                        auraBase.x + Math.cos(angle) * localRadius - cameraPos.x,
                        auraBase.y + bandOffset - cameraPos.y,
                        auraBase.z + Math.sin(angle) * localRadius - cameraPos.z
                    );
                    double orbSize = 0.027 + 0.004 * Math.sin(time * 0.19 + progress * 7.0);
                    if (!closeCameraLite) {
                        this.drawSoftOrbLayer(entry, consumer, center, right, up, orbSize * 2.35, withAlpha(12164607, 18 + (int)(8.0F * breath)), false);
                    }

                    this.drawSoftOrbLayer(entry, consumer, center, right, up, orbSize * 1.26, withAlpha(16777215, 82 + (int)(14.0F * breath)), true);
                }
            }
        );
    }

    private void renderHeadCrown(
        OrderedRenderCommandQueue commandQueue,
        MatrixStack matrices,
        Camera camera,
        Vec3d cameraPos,
        Vec3d playerPos,
        float playerHeight,
        float breath,
        double time
    ) {
        Vec3d right = toVec(camera.getHorizontalPlane());
        Vec3d up = toVec(camera.getVerticalPlane());
        Vec3d crownBase = playerPos.add(0.0, (double)playerHeight * 0.88 + 0.18 + 0.03 * (double)breath, 0.0);
        commandQueue.submitCustom(
            matrices,
            getNoDepthFillLayer(),
            (entry, consumer) -> {
                for (int index = 0; index < 4; index++) {
                    double progress = (double)index / 4.0;
                    double angle = time * 0.09 + (Math.PI * 2) * progress;
                    Vec3d center = new Vec3d(
                        crownBase.x + Math.cos(angle) * 0.18 - cameraPos.x,
                        crownBase.y + 0.03 * Math.sin(time * 0.16 + progress) - cameraPos.y,
                        crownBase.z + Math.sin(angle) * 0.18 - cameraPos.z
                    );
                    this.drawSoftOrbLayer(entry, consumer, center, right, up, 0.085, withAlpha(15920383, 34 + (int)(10.0F * breath)), false);
                    this.drawSoftOrbLayer(entry, consumer, center, right, up, 0.038, withAlpha(16777215, 156), true);
                }
            }
        );
    }

    private void renderDirtBending(
        WorldRenderContext context, MatrixStack matrices, Vec3d playerPos, float breath, double time, int blockCount, boolean liteMode, boolean ultraLiteMode
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        Camera camera = client.gameRenderer.getCamera();
        if (camera != null) {
            Vec3d cameraPos = camera.getCameraPos();
            Immediate consumers = client.getBufferBuilders().getEntityVertexConsumers();
            double orbitTime = time * (double)this.dirtBendingSpeed;
            double secondaryScale = ultraLiteMode ? 0.22 : (liteMode ? 0.42 : 1.0);

            for (int index = 0; index < blockCount; index++) {
                double progress = (double)index / (double)Math.max(1, blockCount);
                double primaryDirection = (index & 1) == 0 ? 1.0 : -1.0;
                double primaryAngle = orbitTime * (ultraLiteMode ? 0.022 : 0.028 + progress * 0.008) * primaryDirection + (Math.PI * 2) * progress;
                double secondaryAngle = orbitTime * (ultraLiteMode ? 0.034 : 0.053 + progress * 0.013) * -primaryDirection * secondaryScale
                    + progress * (ultraLiteMode ? 4.0 : 7.0);
                double radius = (ultraLiteMode ? 4.6 : (liteMode ? 5.0 : 6.0))
                    + (double)index * (ultraLiteMode ? 0.34 : (liteMode ? 0.42 : 0.52))
                    + (ultraLiteMode ? 0.36 : 0.8) * Math.sin(orbitTime * 0.033 + progress * 11.0);
                double x = playerPos.x
                    + Math.cos(primaryAngle) * radius
                    + Math.cos(secondaryAngle) * (ultraLiteMode ? 0.22 : (liteMode ? 0.48 : 1.15));
                double z = playerPos.z
                    + Math.sin(primaryAngle) * radius
                    + Math.sin(secondaryAngle * 1.14) * (ultraLiteMode ? 0.18 : (liteMode ? 0.36 : 0.92));
                double y = playerPos.y
                    + 1.15
                    + (ultraLiteMode ? 0.42 : (liteMode ? 0.72 : 1.35)) * Math.sin(orbitTime * 0.071 + progress * 9.0)
                    + (ultraLiteMode ? 0.08 : (liteMode ? 0.16 : 0.42)) * Math.cos(secondaryAngle * 0.85 + (double)breath);
                float yaw = (float)(primaryAngle * (liteMode ? 1.2 : 1.9) + secondaryAngle * (liteMode ? 0.15 : 0.4));
                float pitch = liteMode ? 0.0F : (float)(0.22 * Math.sin(orbitTime * 0.12 + progress * 6.0));
                float roll = liteMode ? 0.0F : (float)(0.18 * Math.cos(orbitTime * 0.09 - progress * 4.5));
                float scale = ultraLiteMode
                    ? 0.74F + 0.03F * (float)Math.sin(orbitTime * 0.06 + progress * 4.0)
                    : (
                        liteMode
                            ? 0.82F + 0.04F * (float)Math.sin(orbitTime * 0.08 + progress * 5.0)
                            : 0.88F + 0.08F * (float)Math.sin(orbitTime * 0.11 + progress * 8.0)
                    );
                matrices.push();
                matrices.translate(x - cameraPos.x, y - cameraPos.y, z - cameraPos.z);
                matrices.multiply(RotationAxis.POSITIVE_Y.rotation(yaw));
                if (!liteMode) {
                    matrices.multiply(RotationAxis.POSITIVE_X.rotation(pitch));
                    matrices.multiply(RotationAxis.POSITIVE_Z.rotation(roll));
                }

                matrices.scale(scale, scale, scale);
                matrices.translate(-0.5, -0.5, -0.5);
                client.getBlockRenderManager()
                    .renderBlockAsEntity(BENDING_BLOCK_STATES[index % BENDING_BLOCK_STATES.length], matrices, consumers, 15728880, OverlayTexture.DEFAULT_UV);
                matrices.pop();
            }

            consumers.draw();
        }
    }

    private void drawSoftOrbLayer(Entry entry, VertexConsumer consumer, Vec3d center, Vec3d right, Vec3d up, double size, int color, boolean crispOnly) {
        this.drawBillboardQuad(entry, consumer, center, right, up, size, size, color, 0.0);
        if (!crispOnly) {
            this.drawBillboardQuad(entry, consumer, center, right, up, size * 0.88, size * 0.88, color, Math.PI / 4);
        }
    }

    private void drawBillboardQuad(
        Entry entry, VertexConsumer consumer, Vec3d center, Vec3d right, Vec3d up, double width, double height, int color, double rotation
    ) {
        double halfWidth = width * 0.5;
        double halfHeight = height * 0.5;
        double cos = Math.cos(rotation);
        double sin = Math.sin(rotation);
        Vec3d rotatedRight = right.multiply(cos).add(up.multiply(sin));
        Vec3d rotatedUp = up.multiply(cos).subtract(right.multiply(sin));
        Vec3d topLeft = center.subtract(rotatedRight.multiply(halfWidth)).add(rotatedUp.multiply(halfHeight));
        Vec3d topRight = center.add(rotatedRight.multiply(halfWidth)).add(rotatedUp.multiply(halfHeight));
        Vec3d bottomRight = center.add(rotatedRight.multiply(halfWidth)).subtract(rotatedUp.multiply(halfHeight));
        Vec3d bottomLeft = center.subtract(rotatedRight.multiply(halfWidth)).subtract(rotatedUp.multiply(halfHeight));
        emitQuad(consumer, entry, topLeft, topRight, bottomRight, bottomLeft, color);
    }

    private static RenderLayer getNoDepthFillLayer() {
        RenderLayer layer = noDepthFillLayer;
        if (layer != null) {
            return layer;
        } else {
            synchronized (RENDER_LAYER_LOCK) {
                if (noDepthFillLayer == null) {
                    RenderPipeline pipeline = RenderPipelines.register(
                        RenderPipeline.builder(new Snippet[]{RenderPipelines.POSITION_COLOR_SNIPPET})
                            .withLocation("pipeline/dargsclient_aura_fill_no_depth")
                            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                            .withDepthWrite(false)
                            .withCull(false)
                            .build()
                    );
                    noDepthFillLayer = createRenderLayer("dargs_aura_fill_no_depth", pipeline, false);
                }

                return noDepthFillLayer;
            }
        }
    }

    private static RenderLayer createRenderLayer(String name, RenderPipeline pipeline, boolean itemEntityTarget) {
        try {
            Builder setupBuilder = RenderSetup.builder(pipeline).layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING).translucent();
            return RenderLayerInvoker.dargsclient$invokeOf(name, setupBuilder.build());
        } catch (RuntimeException var4) {
            throw new IllegalStateException("Failed to create DargsAura render layer", var4);
        }
    }

    private static Vec3d toVec(Vector3fc vector) {
        return new Vec3d((double)vector.x(), (double)vector.y(), (double)vector.z());
    }

    private static void emitQuad(VertexConsumer consumer, Entry entry, Vec3d topLeft, Vec3d topRight, Vec3d bottomRight, Vec3d bottomLeft, int color) {
        consumer.vertex(entry, (float)topLeft.x, (float)topLeft.y, (float)topLeft.z)
            .color(red(color), green(color), blue(color), alpha(color));
        consumer.vertex(entry, (float)topRight.x, (float)topRight.y, (float)topRight.z)
            .color(red(color), green(color), blue(color), alpha(color));
        consumer.vertex(entry, (float)bottomRight.x, (float)bottomRight.y, (float)bottomRight.z)
            .color(red(color), green(color), blue(color), alpha(color));
        consumer.vertex(entry, (float)bottomLeft.x, (float)bottomLeft.y, (float)bottomLeft.z)
            .color(red(color), green(color), blue(color), alpha(color));
    }

    private static int withAlpha(int rgb, int alpha) {
        return Math.max(0, Math.min(255, alpha)) << 24 | rgb & 16777215;
    }

    private static int red(int color) {
        return color >> 16 & 0xFF;
    }

    private static int green(int color) {
        return color >> 8 & 0xFF;
    }

    private static int blue(int color) {
        return color & 0xFF;
    }

    private static int alpha(int color) {
        return color >> 24 & 0xFF;
    }

    private void setBlockSpeedFromMouse(double mouseX, float x, float width) {
        float sliderStart = x + 10.0F;
        float sliderWidth = width - 20.0F;
        float ratio = MathHelper.clamp((float)((mouseX - (double)sliderStart) / (double)sliderWidth), 0.0F, 1.0F);
        this.dirtBendingSpeed = 0.35F + ratio * 2.15F;
        this.config.setDargsAuraBlockSpeed(this.dirtBendingSpeed);
    }

    private boolean containsInline(double mouseX, double mouseY, float x, float y, float width) {
        return mouseX >= (double)x && mouseX <= (double)(x + width) && mouseY >= (double)y && mouseY <= (double)(y + 62.0F);
    }

    private boolean containsSpeedSlider(double mouseX, double mouseY, float x, float y, float width) {
        float trackY = y + 24.0F;
        return mouseX >= (double)(x + 10.0F)
            && mouseX <= (double)(x + width - 10.0F)
            && mouseY >= (double)(trackY - 5.0F)
            && mouseY <= (double)(trackY + 12.0F);
    }

    private boolean containsToggleButton(double mouseX, double mouseY, float x, float y, float width) {
        float buttonY = y + 40.0F;
        return mouseX >= (double)(x + 10.0F) && mouseX <= (double)(x + width - 10.0F) && mouseY >= (double)buttonY && mouseY <= (double)(buttonY + 16.0F);
    }
}
